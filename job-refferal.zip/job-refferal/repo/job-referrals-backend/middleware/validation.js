const joi = require("joi")

const signupValidation = [
    "firstName",
    "lastName",
    "email",
    "password",
]

const signInValidation = joi.object().keys({
    email: joi.string().email().required().messages({
        "string.empty": "Email is required ",
    }),
    password: joi.string().min(8).required().messages({
        'string.empty': 'Password is required',
    }),
    fcmToken:joi.string().allow(null, '')
})

const updateProfileValidation = [
    "firstName",
    "lastName",
    "email",
    "bio",
]

const signupRValidation = joi.object().keys({
    firstName: joi.string().required().messages({
        "string.empty": "firstName is required ",
    }),
    lastName: joi.string().required().messages({
        "string.empty": "lastName is required ",
    }),
    hereAbout:joi.string().allow(null, ''),
    workEmail: joi.string().email().required().messages({
        "string.empty": "Work email is required ",
    }),
    password: joi.string().min(8).required().messages({
        'string.empty': 'Password is required',
    }),
    fcmToken:joi.string().allow(null, '')
})

const addCompanyValidation = [
    "name",
    "description",
    "category",
    "address", 
    "serviceType",
    "emailDomain",
    "isEnable",
    "roleUrl"
]

const addReferralReqValidation = [
    "resume",
    "jobUrl",
    "companyId"
]

module.exports = {
    signupValidation,
    signInValidation,
    updateProfileValidation,
    signupRValidation,
    addCompanyValidation,
    addReferralReqValidation
}