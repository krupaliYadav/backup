const jwt = require("jsonwebtoken");
const ErrorHandler = require("../utils/ErrorHandling");
const catchAsyncError = require("./catchAsyncError");
const Candidate = require("../models/candidate");
const Referral = require("../models/referral");
const Admin = require("../models/admin");
exports.isAuthenticateAdmin = catchAsyncError(async (req, res, next) => {

    const headers = req.headers.authorization;
    if (!headers) {
        throw new ErrorHandler("Please login to access this resource", 401);
    }

    const token = headers.split(" ")[1];
    if (!token) {
        throw new ErrorHandler("Please Enter valid Token", 401);
    }

    const data = jwt.verify(token, process.env.JWT_SEC);

    const admin = await Admin.findById(data._id);
    if (!admin) {
        throw new ErrorHandler("Token is expired or Invalid.", 401);
    }
    req.admin = data._id;

    next();
});
exports.isAuthenticateCandidate = catchAsyncError(async (req, res, next) => {

    const headers = req.headers.authorization;
    if (!headers) {
        throw new ErrorHandler("Please login to access this resource", 401);
    }

    const token = headers.split(" ")[1];
    if (!token) {
        throw new ErrorHandler("Please Enter valid Token", 401);
    }

    const data = jwt.verify(token, process.env.JWT_SEC);

    const candidate = await Candidate.findById(data._id);
    if (candidate?.isDeleted === 1) {
        throw new ErrorHandler("Your account is Disable.", 401);
    }
    if (!candidate) {
        throw new ErrorHandler("Token is expired or Invalid.", 401);
    }
    req.candidate = data._id;

    next();
});

exports.isAuthenticateReferral = catchAsyncError(async (req, res, next) => {

    const headers = req.headers.authorization;
    if (!headers) {
        throw new ErrorHandler("Please login to access this resource", 401);
    }

    const token = headers.split(" ")[1];
    if (!token) {
        throw new ErrorHandler("Please Enter valid Token", 401);
    }

    const data = jwt.verify(token, process.env.JWT_SEC);

    const referral = await Referral.findById(data._id);

    if (referral?.isDeleted === 1) {
        throw new ErrorHandler("Your account is Disable.", 401);
    }
    if (!referral) {
        throw new ErrorHandler("Token is expired or Invalid.", 401);
    }
    req.referral = data._id;

    next();
});