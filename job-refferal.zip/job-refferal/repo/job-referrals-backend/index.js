require("dotenv").config()
const express = require('express')
const morgan = require('morgan')
const app = express()
const port = process.env.PORT || 8000
const connectDatabase = require("./config/connectDatabase")
const router = require("./routes");
const errorMiddleware = require("./middleware/Error");
const cors = require("cors");
const cron = require('node-cron');
const { resetRemainingReferrals } = require("./libs/cron/resetRemainingReferrals ")
app.get("/", (req, res) => {
    res.status(200).json({ status: 200, message: "Hello working finely.." });
})
app.use(express.text());
app.use(express.json())
app.use(express.urlencoded({ extended: true }));
app.use(cors());
app.use(morgan('dev'))
app.options("*", cors());

app.use("/api/v1", router)



// Schedule the cron job
cron.schedule('0 0 1 * *', () => {
    // This function will run on the first day of each month at 00:00 AM
    resetRemainingReferrals();
    console.log('Running cron job...');
});
connectDatabase();
app.listen(port, async () => {
    console.log(`Server is running on ${port}`);

});
app.use(errorMiddleware)


process.on("unhandledRejection", (err) => {
    console.log("Error inside the unhandledrejection", err)
    console.log(`Error:${err.message}`);
    console.log(`Shutting down due to unhandled promise rejection `);
});
