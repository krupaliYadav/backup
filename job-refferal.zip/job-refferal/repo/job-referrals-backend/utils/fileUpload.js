const cloudinary = require("cloudinary").v2;
const HttpStatus = require("./HttpStatus")

const fileUpload = async (file, allowedTypes, options) => {
    try {
        const { mimetype } = file;
        // const img = mimetype.split("/");
        const img = file?.originalFilename?.split(".");
        let extension = img[img?.length - 1].toLowerCase();
      
        if (!allowedTypes.includes(extension)) {
            return { status: HttpStatus.ERROR, success: false, message: `${extension} is not allowed.` };
        }

        await cloudinary.config({
            cloud_name: process.env.CLOUDINARY_NAME,
            api_key: process.env.CLOUDINARYAPI_KEY,
            api_secret: process.env.CLOUDINARYAPI_SECRET
        });
        let folderOptions = { folder: 'job-referral' }
        if (options) {
            folderOptions = {...options , ...folderOptions}
        }
        const result = await cloudinary.uploader.upload(file.filepath, folderOptions);
        return result.url;

    } catch (error) {
        return { status: HttpStatus.ERROR, success: false, message: error.message };
    }
};

module.exports = fileUpload;