// const FCM = require('fcm-node');
// const fcm = new FCM(serverKey);
// const axios = require('axios');
const admin = require('firebase-admin');
// const serverKey = process.env.FCM_SERVER_KEY;

const serviceAccount = require('../public/assets/serviceAccountKey.json'); // Path to your service account key JSON file

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: 'https://job-referrals.firebaseio.com', // Replace with your database URL
});



async function fcmNotification({ messageCtx, deviceIds }) {
    return new Promise((resolve, reject) => {
        const message = {
            data: {
              title: messageCtx.title,
              body: messageCtx.message,
            },
            tokens: deviceIds,
          };
        admin.messaging().sendMulticast(message)
        .then((response) => {
          console.log('Successfully sent message:', response);
            resolve(response);
        })
        .catch((error) => {
            console.log('Error sending message:', error);
            resolve(null);
        });
    });
}
module.exports = { fcmNotification };