const mongoose = require("mongoose");

const fcmNotificationSchema = mongoose.Schema({
    memberId: {
        type: mongoose.Schema.ObjectId,
        refPath: 'member_type'
    },
    member_type: { type: String, enum: ["Candidate", "Referral"], required: true },
    firebaseToken: {
        type: String
    },
}, { timestamps: true });

module.exports = mongoose.model("FcmNotification", fcmNotificationSchema);