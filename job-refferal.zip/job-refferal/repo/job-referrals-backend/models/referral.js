const mongoose = require("mongoose");

const referralSchema = mongoose.Schema({
    workEmail: {
        type: String,
        required: [true, "Email is Required"]
    },
    password: {
        type: String,
        required: [true, "Password is Required"],
        minLength: [8, "Password must be 8 character"],
    },
    companyId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Company"
    },
    role: {
        type: String,
        default: 'referral',
    },
    firstName: {
        type: String,
    },
    lastName: {
        type: String
    },
    personalEmail: {
        type: String,
    },
    referralMail: {
        type: Boolean,
        default: true,
    },
    generalMail: {
        type: Boolean,
        default: true,
    },
    isVerifyEmail: {
        type: Boolean,
        default: false
    },
    isDeleted: {
        enum: [0, 1],
        type: Number,
        default: 0,
        comment: '0 = not deleted, 1= deleted',
    },
    hereAbout: {
        type: String,
    }
}, { timestamps: true });

module.exports = mongoose.model("Referral", referralSchema);