const mongoose = require("mongoose");

const companySchema = mongoose.Schema({
    referralId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Referral"
    },
    name: {
        type: String,
    },
    companyLogo: {
        type: String,
    },
    address: {
        type: String,
    },
    serviceType: {
        type: String,
    },
    employees: {
        type: String,
    },
    category: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Category'
    }],
    description: {
        type: String,
    },
    financialType: {
        type: String,
        enum: ["Public", "Private"],
    },
    annualRevenue: {
        type: String,
    },
    marketCap: {
        type: String,
    },
    amountRaised: {
        type: String,
    },
    facebookUrl: {
        type: String,
    },
    linkedinUrl: {
        type: String,
    },
    twitterUrl: {
        type: String,
    },
    crunchBaseUrl: {
        type: String,
    },
    roleUrl: {
        type: String,
    },
    emailDomain: {
        type: [String],
    },
    registerReferrer: {
        type: Number,
        default: 0,
    },
    isEnable: {
        enum: [0, 1],
        type: Number,
        default: 0,
        comment: '0 = not Enable, 1= Enable',
    },
    isDeleted: {
        enum: [0, 1],
        type: Number,
        default: 0,
        comment: '0 = not deleted, 1= deleted',
    }
}, { timestamps: true });

module.exports = mongoose.model("Company", companySchema);