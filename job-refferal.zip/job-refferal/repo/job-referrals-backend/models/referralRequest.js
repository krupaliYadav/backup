const mongoose = require("mongoose");

const referralReqSchema = mongoose.Schema({
    companyId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Company',
        required: true
    },
    candidateId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Candidate',
        required: true
    },
    referrerId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Referral'
    },
    resume: {
        type: String,
    },
    jobUrl: {
        type: String,
        required: [true, "Job url is Required"],
    },
    bio: {
        type: String,
        required: [true, "Bio is Required"],
    },
    status: {
        type: Number,
        default: 0,
        enum:[0,1,2],
        required: [true, "status is Required"],
        comment : "0= Waiting for referral , 1= Referrer Assigned , 2 = Referral Completed"
    },
    date: {
        type: String,
    },
    isDeleted: {
        enum: [0, 1],
        type: Number,
        default: 0,
        comment: '0 = not deleted, 1= deleted',
    }
}, { timestamps: true });

module.exports = mongoose.model("ReferralReq", referralReqSchema);