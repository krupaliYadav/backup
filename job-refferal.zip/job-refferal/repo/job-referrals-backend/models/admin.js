const mongoose = require("mongoose");

const adminSchema = mongoose.Schema({
    email: {
        type: String,
        unique: true,
        required: [true, "Email is Required"]
    },
    password: {
        type: String,
        required: [true, "Password is Required"],
        minLength: [8, "Password must be 8 character"],
    },
    isDeleted: {
        enum: [0, 1],
        type: Number,
        default: 0,
        comment: '0 = not deleted, 1= deleted',
    },
}, { timestamps: true });

module.exports = mongoose.model("Admin", adminSchema);