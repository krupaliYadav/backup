const mongoose = require("mongoose");

const candidateSchema = mongoose.Schema({
    firstName: {
        type: String,    
        required: [true, "firstName is Required"]
    },
    lastName: {
        type: String,
        required: [true, "LastName is Required"]
    },
    email: {
        type: String,
        unique:true,
        required: [true, "Email is Required"]
    },
    password: {
        type: String,
        required: [true, "Password is Required"],
        minLength: [8, "Password must be 8 character"],
    },
    resume: [{
        filePath: { type: String },
        resumeName:{type: String}
    }],
    hereAbout: {
        type: String,
    },
    role: {
        type: String,
        default: 'candidate',
    },
    isVerifyEmail: {
        type: Boolean,
        default: false
    },
    bio: {
        type: String,
    },
    generalMail: {
        type: Boolean,
        default: false,
    },
    extraReferral: {
        type: Number,
        default:0
    },
    remainingReferral:{
        type: Number,
        default:5
    },
    requestedReferral :{
        type: Number,
        default:0
    },
    isDeleted: {
        enum: [0, 1],
        type: Number,
        default: 0,
        comment: '0 = not deleted, 1= deleted',
    },
    isAgreeTandC: {
        enum: [0, 1],
        type: Number,
        default: 0,
        comment: '0 = not agree, 1= agree',
    }
}, { timestamps: true });

module.exports = mongoose.model("Candidate", candidateSchema);