const Category = require("../../models/companyCategory")
const catchAsyncError = require("../../middleware/catchAsyncError")
const HttpStatus = require("../../utils/HttpStatus")
const ErrorHandler = require("../../utils/ErrorHandling")

// add company category
const addCategory = catchAsyncError(async (req, res, next) => {
    let { name } = req.body
    try {
        if (!name) {
            throw new ErrorHandler("Name is required", HttpStatus.BAD_REQUEST, false);
        }
        name = name.charAt(0).toUpperCase() + name.slice(1)
        const category = await Category.findOne({ name: name })
        if (category) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: true, message: "Category is already exits" });
        }

        const data = await Category.create({ name })
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Category add successfully.", data });

    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});

// get category list
const getCategoryList = catchAsyncError(async (req, res, next) => {
    try {
        const category = await Category.find({})
        const count = category?.length
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Category list load successfully", data: { category, count } });

    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});

module.exports = {
    addCategory,
    getCategoryList
}