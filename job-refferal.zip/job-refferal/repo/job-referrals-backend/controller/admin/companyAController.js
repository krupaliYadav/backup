const Category = require("../../models/companyCategory")
const Company = require("../../models/company")
const catchAsyncError = require("../../middleware/catchAsyncError")
const HttpStatus = require("../../utils/HttpStatus")
const ErrorHandler = require("../../utils/ErrorHandling")
const formidable = require("formidable");
const { addCompanyValidation, } = require("../../middleware/validation")
const fileUpload = require("../../utils/fileUpload")
const mongoose = require("mongoose")
const Referral = require("../../models/referral")

// add company
const addOrUpdateCompanyInfo = catchAsyncError(async (req, res, next) => {
    const { id } = req.params;
    const form = formidable({ multiples: true });
    form.parse(req, async (err, fields, files) => {
        let { name,
            description,
            category,
            address,
            serviceType,
            emailDomain,
            isEnable,
            roleUrl } = fields
        let companyLogo = "";
        try {
            // validation
            const validation = addCompanyValidation.filter(field => !fields[field]);
            if (validation.length > 0) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: `${validation.join(', ')} is required` })
            }
            if (!id) {
                const company = await Company.findOne({ name: name, isDeleted: 0 });
                if (company) {
                    return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Company name is already added" });
                }
            }

            if (emailDomain) {
                emailDomain = emailDomain?.split(",");
                let domainQuery;
                if (id) {
                    domainQuery = {
                        $and: [
                            { _id: { $ne: new mongoose.Types.ObjectId(id) } },
                            { emailDomain: { $in: emailDomain } }
                        ]
                    }
                } else {
                    domainQuery = { emailDomain: { $in: emailDomain } }
                }
                const domainsExists = await Company.find(domainQuery);
                if (domainsExists?.length) {
                    return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: true, message: "Domain already exists." });
                }

            }
            if (category) {
                category = category?.split(",");
            }

            if (!files?.companyLogo && !fields?.companyLogo) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "companyLogo is required" });
            } else if (files?.companyLogo) {
                const result = await fileUpload(files.companyLogo, ["jpeg", "png", "jpg"])
                if (result.success === false) {
                    return res.status(result.status).json(result);
                } else {
                    companyLogo = result
                }
            } else {
                companyLogo = fields?.companyLogo
            }
            const companyDetail = {
                name,
                description,
                category,
                address,
                serviceType,
                emailDomain,
                isEnable: isEnable === "true" ? 1 : 0,
                roleUrl,
                companyLogo
            }
            if (id) {
                if (!mongoose.Types.ObjectId.isValid(id)) {
                    return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: true, message: "Company id is not valid." });
                }
                const updateData = await Company.findByIdAndUpdate(id, companyDetail, { new: true });
                if (updateData?._id) {
                    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Company updated successfully" });
                } else {
                    return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: true, message: "Company id is not valid." });
                }
            } else {
                const newCompany = await new Company(companyDetail);
                await newCompany.save();
                return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Company added successfully" });
            }
        } catch (error) {
            return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
        }
    });
});

// get company List
const getCompanyList = catchAsyncError(async (req, res, next) => {
    const { categoryIds, search, sortBy, limit, offset } = req.body
    const limitData = parseInt(limit, 10) || 21;
    const offsetData = parseInt(offset, 10) || 0;
    let query = { isDeleted: 0 }
    let sort = { createdAt: -1 }

    if (search) {
        query.name = { $regex: search, $options: "i" }
    }
    if (categoryIds?.length > 0) {
        for (const category of categoryIds) {
            if (!mongoose.Types.ObjectId.isValid(category)) {
                throw new ErrorHandler("Category Id is not valid", HttpStatus.BAD_REQUEST, false);
            } else {
                const isCategoryExists = await Category.findOne({ _id: category });
                if (!isCategoryExists) {
                    throw new ErrorHandler("Company category dose not exits", HttpStatus.BAD_REQUEST, false);
                }
            }
        }
        query = { ...query, category: { $in: categoryIds.map(id => new mongoose.Types.ObjectId(id)) } }
    }

    if (sortBy) {
        sort = sortBy === "oldest" ? { createdAt: 1 } : { createdAt: -1 };
    }
    try {
        let company = await Company.aggregate([
            {
                $match: {
                    ...query,
                }
            },
            {
                $lookup: {
                    from: 'categories',
                    localField: 'category',
                    foreignField: "_id",
                    as: 'categories',
                    pipeline: [
                        { $project: { name: 1 } }
                    ]
                }
            },
            { $sort: sort },
            // {
            //     $project: {
            //         _id: 1,
            //         name: 1,
            //         categories: 1,
            //         roleUrl: 1,
            //         companyLogo: {
            //             $ifNull: ["$companyLogo", null]
            //         },
            //     }
            // }
        ])
        let dataCompany = company.slice(offsetData, limitData + offsetData);
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Company details load successfully.", data: dataCompany, total: company.length });

    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});

// get single company
const getCompany = catchAsyncError(async (req, res, next) => {
    const companyId = req.params.id;
    let query = { isDeleted: 0, _id: new mongoose.Types.ObjectId(companyId) }
    try {
        let company = await Company.aggregate([
            { $match: query },
            {
                $lookup: {
                    from: 'categories',
                    localField: 'category',
                    foreignField: "_id",
                    as: 'categories',
                    pipeline: [
                        { $project: { name: 1 } }
                    ]
                }
            },
            {
                $project: {
                    _id: 1,
                    name: 1,
                    companyLogo: {
                        $ifNull: ["$companyLogo", null]
                    },
                    categories: 1,
                    description: 1,
                    financialType: 1,
                    facebookUrl: 1,
                    linkedinUrl: 1,
                    twitterUrl: 1,
                    crunchBaseUrl: 1,
                    roleUrl: 1,
                    address: 1,
                    serviceType: 1,
                    employees: 1,
                    financialType: 1,
                    annualRevenue: 1,
                    marketCap: 1,
                    amountRaised: 1
                }
            }
        ])
        if (company.length === 0) {
            throw new ErrorHandler("Company details not found", HttpStatus.BAD_REQUEST, false);
        }
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Company details load successfully.", data: company[0] });

    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});
// //add or update company info
// const addOrUpdateCompanyInfo = catchAsyncError(async (req, res, next) => { 

// })
const deleteCompany = catchAsyncError(async (req, res, next) => {
    const companyId = req.params.id;
    let query = { isDeleted: 0, _id: new mongoose.Types.ObjectId(companyId) }
    try {
        const company = await Company.findByIdAndUpdate(companyId, { isDeleted: 1 });
        await await Referral.updateMany(
            { companyId: company?._id },
            { $set: { isDeleted: 1 } }
          );
      
        if (company === 0) {
            throw new ErrorHandler("Company details not found", HttpStatus.BAD_REQUEST, false);
        }
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Deleted successfully." });
    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});
const handleCompanyDomains = catchAsyncError(async (req, res, next) => {
    try {
        const { id } = req.params;
        const { status } = req.query;
        if (!id || !mongoose.Types.ObjectId.isValid(id)) {
            throw new ErrorHandler("Invalid Company Id", HttpStatus.BAD_REQUEST, false);
        }
        if (!status) {
            throw new ErrorHandler("Status required.", HttpStatus.BAD_REQUEST, false);
        }
        const updatedData = await Company.findByIdAndUpdate(id, { isEnable: status }, { new: true });
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: `${!updatedData?.isEnable ? "Disable" : "Enable"} email access successfully.`, });
    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});
const getCompanyReferrerList = catchAsyncError(async (req, res, next) => {
    try {
        const { id } = req.params;
        if (!id || !mongoose.Types.ObjectId.isValid(id)) {
            throw new ErrorHandler("Invalid Company Id", HttpStatus.BAD_REQUEST, false);
        }
        const referrerList = await Referral.find({ companyId: id }).sort({ createdAt: -1 }).select("-password -__v").lean();
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "ReferrerList loaded successfully.", data: referrerList });
    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});
const disableCompanyReferrer = catchAsyncError(async (req, res, next) => {
    try {
        const { id } = req.params;
        const { status } = req.query;
        if (!id || !mongoose.Types.ObjectId.isValid(id)) {
            throw new ErrorHandler("Invalid Referrer Id", HttpStatus.BAD_REQUEST, false);
        }
        if (!status) {
            throw new ErrorHandler("Status required.", HttpStatus.BAD_REQUEST, false);
        }
        const updatedData = await Referral.findByIdAndUpdate(id, { isDeleted: status }, { new: true });
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: `${updatedData?.isDeleted ? "Disable" : "Enable"} account successfully.`, });
    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});
module.exports = {
    getCompanyList,
    getCompany,
    deleteCompany,
    handleCompanyDomains,
    addOrUpdateCompanyInfo,
    getCompanyReferrerList,
    disableCompanyReferrer
}