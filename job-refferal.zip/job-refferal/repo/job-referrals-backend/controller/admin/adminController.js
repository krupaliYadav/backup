const catchAsyncError = require("../../middleware/catchAsyncError");
const Admin = require("../../models/admin");
const HttpStatus = require("../../utils/HttpStatus");
const ErrorHandler = require("../../utils/ErrorHandling")
const bcrypt = require("bcryptjs")
const jwt = require("jsonwebtoken");
const Candidate = require("../../models/candidate");
const { default: mongoose } = require("mongoose");
// admin signup
const adminSignup = catchAsyncError(async (req, res, next) => {
    let { email, password } = req.body
    try {
        password = bcrypt.hashSync(password, 10);
        const newAdmin = await new Admin({
            email, password
        })
        await newAdmin.save();
        const token = jwt.sign({ _id: newAdmin._id }, process.env.JWT_SEC, { expiresIn: process.env.JWT_EXPIRES })

        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Signup successfully", role: "admin", token });

    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});
//for candidate list
const getCandidateList = catchAsyncError(async (req, res, next) => {
    try {
        const candidateList = await Candidate.find().sort({ createdAt: -1 }).select("-password -__v");
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Candidate list fetch successfully", data: candidateList });
    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});
//disable/enable candidate account
const handleCandidateAccount = catchAsyncError(async (req, res, next) => {
    try {
        const { id } = req.params;
        const { status } = req.query;
        if (!id || !mongoose.Types.ObjectId.isValid(id)) {
            throw new ErrorHandler("Invalid Candidate Id", HttpStatus.BAD_REQUEST, false);
        }
        if (!status) {
            throw new ErrorHandler("Status required.", HttpStatus.BAD_REQUEST, false);
        }
        const updatedData = await Candidate.findByIdAndUpdate(id, { isDeleted: status }, { new: true });
        if (updatedData?._id) {
            
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: `${updatedData?.isDeleted ? "Disable": "Enable" } account successfully.`,});
        } else {
            throw new ErrorHandler("Something went wrong.", HttpStatus.BAD_REQUEST, false);
        }
    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});
module.exports = {
    adminSignup,
    getCandidateList,
    handleCandidateAccount
}