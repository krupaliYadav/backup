const Candidate = require("../../models/candidate")
const Referral = require("../../models/referral")
const catchAsyncError = require("../../middleware/catchAsyncError")
const HttpStatus = require("../../utils/HttpStatus")
const bcrypt = require("bcryptjs")
const jwt = require("jsonwebtoken")
const ErrorHandler = require("../../utils/ErrorHandling")
const sendEmail = require("../../utils/sendEmail");
const path = require("path");
const ejs = require("ejs");
const FcmNotification = require("../../models/FcmNotification")
const Admin = require("../../models/admin")
// signIn for referral and candidate
const signIn = catchAsyncError(async (req, res, next) => {
    try {
        const { email, password, fcmToken } = req.body
        let adminDetails = await Admin.findOne({ email: email });
        let candidate = await Candidate.findOne({ email: email })
        let referral = await Referral.findOne({ workEmail: email })
        if (!candidate && !referral && !adminDetails) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please enter register email...!" });
        }
        if (adminDetails && adminDetails !== null) {
            if (!bcrypt.compareSync(password, adminDetails.password)) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Invalid credentials sent...!!" });
            }
            
            const token = jwt.sign({ _id: adminDetails._id }, process.env.JWT_SEC, { expiresIn: process.env.JWT_EXPIRES })
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, role: "admin", token, message: "SingIn successfully." });
        }

        if (candidate && candidate !== null) {
            if (candidate?.isDeleted === 1) {
                throw new ErrorHandler("Your account is Disable.", HttpStatus.UNAUTHORIZED);
            }
            if (!bcrypt.compareSync(password, candidate.password)) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Invalid credentials sent...!!" });
            }
            if (fcmToken) {
                await FcmNotification.create({
                    memberId: candidate._id,
                    member_type: "Candidate",
                    firebaseToken: fcmToken
                })
            }
            const token = jwt.sign({ _id: candidate._id }, process.env.JWT_SEC, { expiresIn: process.env.JWT_EXPIRES })
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, role: candidate.role, token, message: "SingIn successfully." });
        }

        if (referral && referral !== null) {
            if (referral?.isDeleted === 1) {
                throw new ErrorHandler("Your account is Disable.", HttpStatus.UNAUTHORIZED);
            }
            if (!bcrypt.compareSync(password, referral.password)) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Invalid credentials sent...!!" });
            }
            if (fcmToken) {
                await FcmNotification.create({
                    memberId: referral._id,
                    member_type: "Referral",
                    firebaseToken: fcmToken
                })
            }
            const token = jwt.sign({ _id: referral._id }, process.env.JWT_SEC, { expiresIn: process.env.JWT_EXPIRES })
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, role: referral.role, token, message: "SingIn successfully." });
        }
    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});
const forgotPassword = catchAsyncError(async (req, res, next) => {
    try {
        const { email } = req.body
        if (!email) {
            throw new ErrorHandler("Email is Missing!", HttpStatus.BAD_REQUEST)
        }
        let candidate = await Candidate.findOne({ email: email })
        let referral = await Referral.findOne({ workEmail: email })
        if (!candidate && !referral) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please enter register email...!" });
        }

        if (candidate && candidate !== null) {
            const token = jwt.sign({ _id: candidate._id }, '6h', { expiresIn: process.env.JWT_EXPIRES })
            const redirectLink = process.env.APP_URL + `/reset-password/${token}`
           
            const templatePath = path.join(__dirname, "../../public/assets/email-templates/resetPassword.ejs");

            const firstName = candidate?.firstName;
            const data = await ejs.renderFile(templatePath, { firstName, redirectLink });
            await sendEmail({
                email,
                subject: `Request for Reset Password.`,
                message: data,
            });
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Email sent successfully." });
        }

        if (referral && referral !== null) {
            const token = jwt.sign({ _id: referral._id }, '6h', { expiresIn: process.env.JWT_EXPIRES })
            const redirectLink = process.env.APP_URL + `/reset-password/${token}`;
            const templatePath = path.join(__dirname, "../../public/assets/email-templates/resetPassword.ejs");
            const firstName = referral?.firstName;
            const data = await ejs.renderFile(templatePath, { firstName, redirectLink });
            await sendEmail({
                email,
                subject: `Request for Reset Password.`,
                message: data,
            });
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Email sent successfully." });
        }
    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});
const verifyToken = catchAsyncError(async (req, res, next) => {
    try {
        const { token } = req.query;
        if (!token) {
            throw new ErrorHandler("Token is Missing!", HttpStatus.BAD_REQUEST)
        }
        const data = jwt.verify(token, "6h");
        if (data._id) {
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Token verified." });
        } else {
            throw new ErrorHandler("Token Expired!", HttpStatus.BAD_REQUEST)
        }
    } catch (error) {
        throw new ErrorHandler(error.message, HttpStatus.ERROR)
    }
});
const resetPassword = catchAsyncError(async (req, res, next) => {
    try {
        const { token, password } = req.body;
        if (!token || !password) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Missing token or Password!" });
        }
        const data = jwt.verify(token, "6h");
        if (!data._id) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Invalid Token...!" });
        }
        let candidate = await Candidate.findById(data._id)
        let referral = await Referral.findById(data._id)
        if (!candidate && !referral) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Invalid Token...!" });
        }
        if (candidate && candidate !== null) {
            candidate.password = bcrypt.hashSync(password, 10)
            await candidate.save();
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Password Changed successfully." });
        }

        if (referral && referral !== null) {
            referral.password = bcrypt.hashSync(password, 10)
            await referral.save();
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Password Changed successfully." });
        }
    } catch (error) {
        throw new ErrorHandler(error.message, HttpStatus.ERROR)
    }
});
const handleLogOut = catchAsyncError(async (req, res, next) => {
    try {
        const { role } = req.params;
        const { fcmToken } = req.body;
        const roleType= ["Candidate", "Referral"]
        if (fcmToken && roleType.includes(role)) {
            await FcmNotification.findOneAndDelete({ firebaseToken: fcmToken, member_type: role });
        }
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Logout successfully." });
    } catch (error) {
        throw new ErrorHandler(error.message, HttpStatus.ERROR)
    }
});
module.exports = {
    signIn,
    forgotPassword,
    verifyToken,
    resetPassword,
    handleLogOut
}