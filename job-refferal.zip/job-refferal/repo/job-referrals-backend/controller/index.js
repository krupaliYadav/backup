// auth
module.exports.authController = require("./auth/authController");

// admin
module.exports.adminController = require("./admin/adminController");
module.exports.companyCategoryController = require("./admin/companyCategory");
module.exports.companyAController = require("./admin/companyAController");

// candidate
module.exports.profileController = require("./candidate/profileController");
module.exports.referralReqController = require("./candidate/referralRequest");

// referral
module.exports.referralProfileController = require("./referral/profileController");
module.exports.referralClaimController = require("./referral/referralClaimController");