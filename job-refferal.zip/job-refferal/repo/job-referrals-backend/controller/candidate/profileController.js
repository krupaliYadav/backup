const Candidate = require("../../models/candidate")
const Referral = require("../../models/referral")
const catchAsyncError = require("../../middleware/catchAsyncError")
const HttpStatus = require("../../utils/HttpStatus")
const ErrorHandler = require("../../utils/ErrorHandling")
const formidable = require("formidable");
const bcrypt = require("bcryptjs")
const fileUpload = require("../../utils/fileUpload")
const { signupValidation, updateProfileValidation } = require("../../middleware/validation")
const mongoose = require("mongoose")
const jwt = require("jsonwebtoken")
const FcmNotification = require("../../models/FcmNotification")




// candidate signup
const signup = catchAsyncError(async (req, res, next) => {
    const form = formidable({ multiples: true });
    form.parse(req, async (err, fields, files) => {
        let { firstName, lastName, email, password, hereAbout, isAgreeTandC, fcmToken } = fields
        let resume = "";
        let resumeName = ""
        try {
            // validation
            const validation = signupValidation.filter(field => !fields[field]);
            if (validation.length > 0) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: `${validation.join(', ')} is required` })
            }
            // here check email is not exits in referral as well in candidate
            const candidate = await Candidate.findOne({ email: email, isDeleted: 0 })
            const referral = await Referral.findOne({ workEmail: email, isDeleted: 0 })

            if (!candidate && !referral) {
                password = bcrypt.hashSync(password, 10)

                console.log("%c Line:40 🍢 files?.resume.size", "color:#ffdd4d", files?.resume.size, 3 * 1024 * 1024);
                if (!files?.resume) {
                    return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Resume is required" });
                }
                else if (files?.resume.size > 3 * 1024 * 1024) {
                    // check for size of pdf
                    // console.log("%c Line:42 🍰 File size exceeds the 3MB limit.", "color:#b03734", "File size exceeds the 3MB limit.", files.resume);
                    return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "File size exceeds the 3MB limit." });
                }
                else {
                    let options;
                    if (files?.resume?.originalFilename?.includes(".doc")) {
                        options = { resource_type: "raw" }
                    }
                    const result = await fileUpload(files.resume, ["pdf", "doc", "docx"], options);
                    resumeName = files.resume.originalFilename
                    if (result.success === false) {
                        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: `File size exceeds the 3MB limit.` });
                    } else {
                        resume = result
                    }
                }
                const agreeOnTerms = isAgreeTandC === "true" ? 1 : 0
                const newCandidate = await new Candidate({
                    firstName, lastName, email, password, resume: { resumeName, filePath: resume }, hereAbout, resumeName, isAgreeTandC: agreeOnTerms
                });
                await newCandidate.save();
                if (fcmToken) {
                    await FcmNotification.create({
                        memberId: newCandidate._id,
                        member_type: "Candidate",
                        firebaseToken: fcmToken
                    })
                }
                const token = jwt.sign({ _id: newCandidate._id }, process.env.JWT_SEC, { expiresIn: process.env.JWT_EXPIRES });
                return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Signup successfully.", candidateId: newCandidate._id, role: newCandidate.role, token });
            } else {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Email already taken" });
            }
        } catch (error) {
            console.log("%c Line:75 🌽 error", "color:#2eafb0", error);
            return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
        }
    });
});

// update candidate profile
const updateProfile = catchAsyncError(async (req, res, next) => {
    try {
        const candidateId = req.candidate;
        let { firstName, lastName, email, oldPassword, newPassword, bio, generalMail } = req.body
        const updateData = { firstName, lastName, email, bio, generalMail };
        const isEmailExistWithOtherUser = await Candidate.findOne({
            $and: [
                { _id: { $ne: candidateId } },
                { email: email }
            ]
        });
        if (isEmailExistWithOtherUser) {
            throw new ErrorHandler("New Email is already registered.", HttpStatus.BAD_REQUEST)
        }
        // for change password
        if (oldPassword !== "" && newPassword !== "") {
            const candidate = await Candidate.findOne({ _id: candidateId })
            if (!bcrypt.compareSync(oldPassword, candidate.password)) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Invalid old password...!!" });
            } else {
                updateData.password = bcrypt.hashSync(newPassword, 10)
            }
        }
        if (generalMail) {
            if (typeof generalMail != "boolean") {
                throw new ErrorHandler("Please Enter valid generalMail type", HttpStatus.BAD_REQUEST);
            } else {
                updateData.generalMail = generalMail
            }
        }
        const data = await Candidate.findOneAndUpdate({ _id: candidateId, isDeleted: 0 }, updateData, { new: true }).select("-password")
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Updated successfully.", data });

    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
})

//update resume
const updateResume = catchAsyncError(async (req, res, next) => {
    const candidateId = req.candidate
    if (!mongoose.Types.ObjectId.isValid(candidateId)) {
        throw new ErrorHandler("Candidate Id is not valid", HttpStatus.BAD_REQUEST, false);
    }
    const form = formidable({ multiples: true });
    form.parse(req, async (err, fields, files) => {
        try {
            if (!files?.resume) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Resume is required." });
            }
            // check for size of pdf
            if (files?.resume.size > 3 * 1024 * 1024) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "File size exceeds the 3MB limit." });
            }
            let options;
            if (files?.resume?.originalFilename?.includes(".doc")) {
                options = { resource_type: "raw" }
            }
            let resume = "";
            let resumeName = "";
            const result = await fileUpload(files.resume, ["pdf", "doc", "docx"], options)
            if (result.success === false) {
                return res.status(result.BAD_REQUEST).json(result);
            } else {
                resume = result
                resumeName = files.resume.originalFilename
            }
            const data = await Candidate.findOneAndUpdate({ _id: candidateId, isDeleted: 0 }, { resume: { resumeName, filePath: resume } }, { new: true }).select("-password")
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Resume uploaded successfully.", data });

        } catch (error) {
            return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
        }
    })
});
const deleteResume = catchAsyncError(async (req, res, next) => {
    const candidateId = req.candidate;
    try {
        const candidate = await Candidate.findOneAndUpdate({ _id: candidateId }, { $unset: { resume: 1 } }, { new: true });
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Resume deleted successfully.", data: candidate });

    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});
// get candidate profile
const getCandidateProfile = catchAsyncError(async (req, res, next) => {
    const candidateId = req.candidate;
    if (!mongoose.Types.ObjectId.isValid(candidateId)) {
        throw new ErrorHandler("Candidate Id is not valid", HttpStatus.BAD_REQUEST, false);
    }
    try {
        let candidate = await Candidate.findOne({ _id: candidateId }).select("-password")
        if (!candidate) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Candidate not found" });
        }
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Candidate details load successfully.", data: candidate });

    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});

module.exports = {
    signup,
    updateProfile,
    updateResume,
    getCandidateProfile,
    deleteResume
}