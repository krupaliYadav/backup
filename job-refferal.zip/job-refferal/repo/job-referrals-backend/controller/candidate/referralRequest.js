const ReferralReq = require("../../models/referralRequest")
const Company = require("../../models/company")
const Candidate = require("../../models/candidate")
const catchAsyncError = require("../../middleware/catchAsyncError")
const HttpStatus = require("../../utils/HttpStatus")
const ErrorHandler = require("../../utils/ErrorHandling");
const { addReferralReqValidation } = require("../../middleware/validation");
const mongoose = require("mongoose")
const moment = require("moment")
const sendEmail = require("../../utils/sendEmail");
const path = require("path");
const ejs = require("ejs");
const FcmNotification = require("../../models/FcmNotification")
const { fcmNotification } = require("../../utils/fcmNotification")
const Referral = require("../../models/referral")
//Request a Referral to company
const addReferralReq = catchAsyncError(async (req, res, next) => {
    let { jobUrl, bio, companyId, resume } = req.body
    try {
        // validation
        const validation = addReferralReqValidation.filter(field => !req.body[field]);
        if (validation.length > 0) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: `${validation.join(', ')} is required` })
        }
        const candidateData = await Candidate.findById(req.candidate);
        if (candidateData?.remainingReferral === 0) {
            throw new ErrorHandler("You're out of referral requests!", HttpStatus.BAD_REQUEST, false);
        }
        if (!mongoose.Types.ObjectId.isValid(companyId)) {
            throw new ErrorHandler("Company Id is not valid", HttpStatus.BAD_REQUEST, false);
        }
        const company = await Company.findOne({ _id: companyId, isDeleted: 0 })
        const newReferralReq = await new ReferralReq({
            companyId: company._id,
            candidateId: req.candidate,
            jobUrl,
            bio,
            resume,
            date: moment().format('MM/DD/YYYY h:mm A')
        });
        await newReferralReq.save();
        candidateData.requestedReferral = candidateData.requestedReferral + 1;
        candidateData.remainingReferral = candidateData.remainingReferral - 1;
        await candidateData.save();
        // for email
        const templatePath = path.join(__dirname, "../../public/assets/email-templates/ReqRefereeEmailToReferee.ejs");
        const data = await ejs.renderFile(templatePath, { firstName: candidateData?.firstName, companyName: company?.name });
        await sendEmail({
            email: candidateData.email,
            subject: `Thank You for Applying to ${company?.name}`,
            message: data,
        });
        const companyTempPath = path.join(__dirname, "../../public/assets/email-templates/NewReqToCompany.ejs");
        const referralEmailData = await ejs.renderFile(companyTempPath, { firstName: candidateData?.firstName, companyName: company?.name });
        const referrerList = await Referral.find({ companyId: companyId, isDeleted: 0 }).select("workEmail referralMail");
        const referralIDList = [];
        const promises = [];
        referrerList?.forEach(ele => {
            referralIDList.push(ele._id)
            if (ele?.referralMail) {
                promises.push(sendEmail({
                    email: ele?.workEmail,
                    subject: `New Referral Request Received`,
                    message: referralEmailData,
                }))
            }
        })
        await Promise.all(promises);
        // await sendEmail({
        //     email: company.referralId?.workEmail,
        //     subject: `New Referral Request Received`,
        //     message: referralEmailData,
        // });
        const deviceData = await FcmNotification.find({ member_type: "Referral", memberId: { $in: referralIDList } });
        if (deviceData.length) {
            const deviceIds = deviceData?.map(ele => {
                return ele?.firebaseToken
            })
            const message = {
                title: 'New Referral Request',
                message: 'Visit dashboard and review the new request.',
            }
            await fcmNotification({ messageCtx: message, deviceIds });
        }
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Referral request added" });

    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});

// //get company details for referral
// const getCompanyDetails = catchAsyncError(async (req, res, next) => {
//     const candidateId = req.candidate
//     if (!mongoose.Types.ObjectId.isValid(candidateId)) {
//         throw new ErrorHandler("Candidate Id is not valid", HttpStatus.BAD_REQUEST, false);
//     }
//     const companyId = req.params.companyId
//     if (!mongoose.Types.ObjectId.isValid(companyId)) {
//         throw new ErrorHandler("company Id is not valid", HttpStatus.BAD_REQUEST, false);
//     }
//     try {

//         let candidate = await Candidate.findOne({ _id: candidateId })
//         let company = await Company.findOne({ _id: companyId })
//         if (!company) {
//             throw new ErrorHandler("Company not found", HttpStatus.BAD_REQUEST, false);
//         }

//         const data = {
//             companyId: company._id,
//             candidateId: candidate._id,
//             companyName: company.name,
//             candidateBio: candidate.bio || ''
//         }

//         return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Company details load successfully", data });
//     } catch (error) {
//         return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
//     }
// });

// //get referral request details
// const getReferralReqDetails = catchAsyncError(async (req, res, next) => {
//     const candidateId = req.candidate
//     const referralReqId = req.params.referralReqId
//     if (!mongoose.Types.ObjectId.isValid(candidateId)) {
//         throw new ErrorHandler("Candidate Id is not valid", HttpStatus.BAD_REQUEST, false);
//     }
//     if (!mongoose.Types.ObjectId.isValid(referralReqId)) {
//         throw new ErrorHandler("Referral Request Id is not valid", HttpStatus.BAD_REQUEST, false);
//     }
//     const query = { isDeleted: 0, _id: new mongoose.Types.ObjectId(referralReqId) }

//     try {
//         const data = await ReferralReq.aggregate([
//             { $match: query },
//             {
//                 $lookup: {
//                     from: 'candidates',
//                     localField: 'candidateId',
//                     foreignField: "_id",
//                     as: 'candidates',
//                     pipeline: [
//                         { $project: { firstName: 1, lastName: 1, email: 1, bio: 1 } }
//                     ]
//                 }
//             },
//             {
//                 $project: {
//                     _id: 1,
//                     jobUrl: 1,
//                     date: 1,
//                     candidates: 1,
//                     resume: {
//                         $ifNull: ["$resume", null]
//                     },
//                 }
//             }
//         ])
//         if (data.length == 0) {
//             throw new ErrorHandler("Referral request details not found", HttpStatus.BAD_REQUEST, false);
//         }
//         return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Referral request details load successfully", data });
//     } catch (error) {
//         return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
//     }
// });

//get all referral request list
const getReferralReqList = catchAsyncError(async (req, res, next) => {
    try {
        const candidateId = req.candidate
        const { search, status, company } = req.query
        if (!mongoose.Types.ObjectId.isValid(candidateId)) {
            throw new ErrorHandler("Candidate Id is not valid", HttpStatus.BAD_REQUEST, false);
        }
        const query = { isDeleted: 0, candidateId: new mongoose.Types.ObjectId(candidateId) }
        const dataList = await ReferralReq.aggregate([
            { $match: query },
            {
                $lookup: {
                    from: 'companies',
                    localField: 'companyId',
                    foreignField: "_id",
                    as: 'company',
                    pipeline: [
                        { $project: { name: 1 } }
                    ]
                }
            },
            {
                $project: {
                    _id: 1,
                    status: 1,
                    company: { $arrayElemAt: ['$company', 0] },
                }
            }
        ])
        if (search && search !== "") {
            query.jobUrl = { $regex: search, $options: "i" }
        }
        if (status && status !== "") {
            query.status = parseInt(status)
        }
        if (company && company !== "") {
            query.companyId = new mongoose.Types.ObjectId(company)
        }

        const data = await ReferralReq.aggregate([
            { $match: query },
            {
                $lookup: {
                    from: 'companies',
                    localField: 'companyId',
                    foreignField: "_id",
                    as: 'company',
                    pipeline: [
                        { $project: { name: 1, companyLogo: 1 } }
                    ]
                }
            },
            {
                $lookup: {
                    from: 'candidates',
                    localField: 'candidateId',
                    foreignField: "_id",
                    as: 'candidate',
                    pipeline: [
                        { $project: { firstName: 1, lastName: 1, email: 1 } }
                    ]
                }
            },
            {
                $project: {
                    _id: 1,
                    jobUrl: 1,
                    bio: 1,
                    resume: 1,
                    status: 1,
                    date: 1,
                    company: { $arrayElemAt: ['$company', 0] },
                    candidate: { $arrayElemAt: ['$candidate', 0] },
                }
            }
        ])
        let statusList = [], companyList = [];
        const completedRef = dataList.filter((ele) => ele.status === 2)?.length;
        dataList?.forEach((element) => {
            if (statusList.filter((ele) => ele.value === element.status)?.length === 0) {
                statusList.push({ value: element.status });
            }
            if (
                companyList.filter((ele) => ele.label === element.company.name)
                    ?.length === 0
            ) {
                companyList.push({
                    value: element.company._id,
                    label: element.company.name,
                });
            }
        });
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Referral request list load successfully", data: { data, statusList, companyList, completedRef, requestedRef: dataList?.length } });
    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});
const handleDeleteReferralReq = catchAsyncError(async (req, res, next) => {
    try {
        const candidateId = req.candidate
        const { refRequestId } = req.params;
        const data = await ReferralReq.findOneAndUpdate({ candidateId: candidateId, _id: refRequestId }, { isDeleted: 1 }, { new: true }).populate({
            path: 'candidateId',
            select: "firstName"
        }).populate(
            {
                path: 'companyId'
            }
        );
        // for email

        const templatePath = path.join(__dirname, "../../public/assets/email-templates/deleteReferralReq.ejs");
        const emailDetails = await ejs.renderFile(templatePath, {
            firstName: data?.candidateId?.firstName, companyName: data?.companyId?.name, jobUrl: data?.jobUrl
        });
        const referrerList = await Referral.find({ companyId: data?.companyId?._id, isDeleted: 0 }).select("workEmail referralMail")
        const referralIDList = [];
        const promises = [];
        referrerList?.forEach(ele => {
            referralIDList.push(ele._id)
            if (ele?.referralMail) {
                promises.push(sendEmail({
                    email: ele?.workEmail,
                    subject: `Referral Request Withdrawn`,
                    message: emailDetails,
                }))
            }

        })
        // await sendEmail({
        //     email: data?.companyId?.referralId?.workEmail,
        //     subject: `Referral Request Withdrawn`,
        //     message: emailDetails,
        // });
        const deviceData = await FcmNotification.find({ member_type: "Referral", memberId: { $in: referralIDList } });
        if (deviceData.length) {
            const deviceIds = deviceData?.map(ele => {
                console.log(ele)
                return ele?.firebaseToken
            })
            const message = {
                title: 'Referral Request Withdrawn',
                message: 'Visit dashboard for more details.',
            }
            await fcmNotification({ messageCtx: message, deviceIds });
        }
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Deleted successfully" });
    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});
module.exports = {
    addReferralReq,
    // getCompanyDetails,
    // getReferralReqDetails,
    getReferralReqList,
    handleDeleteReferralReq
}