const Candidate = require("../../models/candidate")
const Referral = require("../../models/referral")
const catchAsyncError = require("../../middleware/catchAsyncError")
const HttpStatus = require("../../utils/HttpStatus")
const ErrorHandler = require("../../utils/ErrorHandling")
const bcrypt = require("bcryptjs")
const jwt = require("jsonwebtoken")
const mongoose = require("mongoose")
const Company = require("../../models/company")
const { addCompanyValidation } = require("../../middleware/validation")
const formidable = require("formidable")
const fileUpload = require("../../utils/fileUpload")
const sendEmail = require("../../utils/sendEmail");
const path = require("path");
const ejs = require("ejs");
const FcmNotification = require("../../models/FcmNotification")
// referral signup
const signup = catchAsyncError(async (req, res, next) => {
    let { firstName, lastName, workEmail, password, hereAbout, fcmToken } = req.body
    try {
        // here check email is not exits in referral as well in candidate

        const domain = workEmail.split("@");
        const CompanyList = await Company.findOne({
            isDeleted: 0,
            $or: [
                { emailDomain: { $elemMatch: { $eq: "@" + domain[1] } } },
                { emailDomain: { $elemMatch: { $eq: domain[1] } } }
            ]
        }).select("isEnable emailDomain registerReferrer");
        if (CompanyList?._id) {
            if (CompanyList?.isEnable) {
                const candidate = await Candidate.findOne({ email: workEmail, isDeleted: 0 })
                const referral = await Referral.findOne({ workEmail: workEmail, isDeleted: 0 })
                if (!candidate && !referral) {
                    password = bcrypt.hashSync(password, 10)

                    let newReferral = await new Referral({
                        firstName, lastName, workEmail, password, hereAbout, companyId: CompanyList?._id
                    });
                    await newReferral.save();
                    await Company.findByIdAndUpdate(CompanyList?._id, { registerReferrer: CompanyList?.registerReferrer + 1 })
                    const verifyToken = jwt.sign({ _id: newReferral._id }, '6h', { expiresIn: process.env.JWT_EXPIRES })
                    const redirectLink = process.env.APP_URL + `/verify-email/${verifyToken}`
                    const templatePath = path.join(__dirname, "../../public/assets/email-templates/signUpCompany.ejs");
                    const data = await ejs.renderFile(templatePath, { firstName, redirectLink });
                    await sendEmail({
                        email: workEmail,
                        subject: `Confirmation of Company Registration with Job Referral.`,
                        message: data,
                    });
                    if (fcmToken) {
                        await FcmNotification.create({
                            memberId: newReferral._id,
                            member_type: "Referral",
                            firebaseToken: fcmToken
                        })
                    }
                    const token = jwt.sign({ _id: newReferral._id }, process.env.JWT_SEC, { expiresIn: process.env.JWT_EXPIRES })
                    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Signup successfully", data: { referralId: newReferral._id, role: newReferral.role, token } });
                } else {
                    return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Email already taken" });
                }
            } else {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "This Co-operate is not allowed." });
            }

        } else {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Email is not valid." });
        }
    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});

// update referral profile
const updateProfile = catchAsyncError(async (req, res, next) => {
    const referralId = req.referral
    let { oldPassword, newPassword, firstName, lastName, generalMail, referralMail } = req.body
    try {
        const referral = await Referral.findById(referralId);

        if (oldPassword && newPassword) {
            if (!bcrypt.compareSync(oldPassword, referral.password)) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Invalid old password...!!" });
            } else {
                req.body.password = bcrypt.hashSync(newPassword, 10)
            }
        }
        await Referral.findOneAndUpdate({ _id: referral._id, isDeleted: 0 }, req.body, { new: true });
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Updated successfully." });

    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});

const uploadCompanyLogo = catchAsyncError(async (req, res, next) => {
    const referralId = req.referral;

    const form = formidable({ multiples: true });
    form.parse(req, async (err, fields, files) => {
        try {
            if (!files?.companyLogo) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Logo is required." });
            }
            const companyData = await Company.findOne({ referralId: referralId });
            const result = await fileUpload(files.companyLogo, ["jpeg", "png", "jpg"])
            if (result.success === false) {
                return res.status(result.status).json(result);
            } else {
                const companyLogo = result;
                await Company.findOneAndUpdate({ referralId: referralId, isDeleted: 0 }, { companyLogo }, { new: true })
                return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Logo uploaded successfully." });
            }
        } catch (error) {
            return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
        }
    })
});
// get referral profile
const getProfile = catchAsyncError(async (req, res, next) => {
    const referralId = req.referral
    if (!mongoose.Types.ObjectId.isValid(referralId)) {
        throw new ErrorHandler("Referral Id is not valid", HttpStatus.BAD_REQUEST, false);
    }
    try {
        // let referral;
        // const ReferralData = await Referral.findById(referralId).select("workEmail role generalMail referralMail firstName lastName personalEmail isVerifyEmail isCompanyDetails");
        // if (!ReferralData.isCompanyDetails) {
        //     referral = { referralId: ReferralData }
        // } else {
        let referral = await Referral.findById(referralId).populate({
            path: 'companyId',
            populate: {
                path: 'category',
                model: 'Category',
                select: "name"
            }
        }).select("-__v -createdAt -updatedAt -password");
        // }

        if (!referral) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Referral not found" });
        }
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Referral details load successfully.", data: referral });

    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});
// Resend Email verification 
const resendEmailVerification = catchAsyncError(async (req, res, next) => {
    const referralId = req.referral;
    try {
        let referral = await Referral.findOne({ _id: referralId });
        if (!referral) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Referral not found" });
        }
        const verifyToken = jwt.sign({ _id: referral?._id }, '6h', { expiresIn: process.env.JWT_EXPIRES })
        const redirectLink = process.env.APP_URL + `/verify-email/${verifyToken}`
        const templatePath = path.join(__dirname, "../../public/assets/email-templates/resendEmailVerification.ejs");
        const data = await ejs.renderFile(templatePath, { firstName: referral?.firstName, redirectLink });
        await sendEmail({
            email: referral?.workEmail,
            subject: `Email Verification - Resend Link.`,
            message: data,
        });

        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Email sent! Check your inbox." });

    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});
const resendEmailVerificationByEmail = catchAsyncError(async (req, res, next) => {
    const { email } = req.body;
    try {
        if (!email) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please provide workEmail." });
        }
        let referral = await Referral.findOne({ workEmail: email });
        if (!referral) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Referral not found" });
        }
        const verifyToken = jwt.sign({ _id: referral?._id }, '6h', { expiresIn: process.env.JWT_EXPIRES })
        const redirectLink = process.env.APP_URL + `/verify-email/${verifyToken}`
        const templatePath = path.join(__dirname, "../../public/assets/email-templates/resendEmailVerification.ejs");
        const data = await ejs.renderFile(templatePath, { firstName: referral?.firstName, redirectLink });
        await sendEmail({
            email,
            subject: `Email Verification - Resend Link.`,
            message: data,
        });

        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Email sent! Check your inbox." });

    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});
const verifyEmail = catchAsyncError(async (req, res, next) => {
    try {
        const { token } = req.body;
        if (!token) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Missing token!" });
        }
        const data = jwt.verify(token, "6h");
        if (!data._id) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Invalid Token...!" });
        }
        let referral = await Referral.findById(data._id)
        if (!referral) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Invalid Token...!" });
        }
        if (referral && referral !== null) {
            referral.isVerifyEmail = true;
            await referral.save();
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Email verified successfully." });
        }
    } catch (error) {
        throw new ErrorHandler(error.message, HttpStatus.ERROR)
    }
});


module.exports = {
    signup,
    updateProfile,
    getProfile,
    uploadCompanyLogo,
    resendEmailVerification,
    resendEmailVerificationByEmail,
    verifyEmail
}