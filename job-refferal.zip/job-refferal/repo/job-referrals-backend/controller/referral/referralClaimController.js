const catchAsyncError = require("../../middleware/catchAsyncError")
const HttpStatus = require("../../utils/HttpStatus")
const ErrorHandler = require("../../utils/ErrorHandling")
const mongoose = require("mongoose");
const ReferralReq = require("../../models/referralRequest");
const Company = require("../../models/company");
const sendEmail = require("../../utils/sendEmail");
const path = require("path");
const ejs = require("ejs");
const { fcmNotification } = require("../../utils/fcmNotification");
const FcmNotification = require("../../models/FcmNotification");
const Referral = require("../../models/referral");

const getListOfReferralsListByStatus = async (data) => {
    const { referralId, limit, offset, status } = data;
    // const limitData = parseInt(limit, 10) || 10;
    // const offsetData = parseInt(offset, 10) || 0;
    let finalQuery = []
    
    if (status !== 0) {
        const query = {
            $match : { referrerId : new mongoose.Types.ObjectId(referralId) }
        }   
        finalQuery.push(query);
    }

    const finalQueries = [
        {
            $lookup: {
                from: 'referrals',
                localField: 'companyId',
                foreignField: "companyId",
                as: 'referrals',
                pipeline: [
                    { $match: { _id: new mongoose.Types.ObjectId(referralId) } },
                ]
            }
        },
        { $match: { referrals: { $ne: [] } } },
        {
            $lookup: {
                from: 'companies',
                localField: 'companyId',
                foreignField: "_id",
                as: 'company',
                pipeline: [
                    { $project: { name: 1, companyLogo: 1 } }
                ]
            }
        },
        {
            $match: {
                company: { $ne: [] },
                isDeleted: 0, status: status
            }
        }];
        finalQuery.push(...finalQueries);
    const totalData = await ReferralReq.aggregate(finalQuery);
    finalQuery.push(
        {
            $lookup: {
                from: 'candidates',
                localField: 'candidateId',
                foreignField: "_id",
                as: 'candidate',
                pipeline: [
                    { $project: { firstName: 1, lastName: 1, email: 1 } }
                ]
            }
        },
        {
            $project: {
                _id: 1,
                jobUrl: 1,
                bio: 1,
                resume: 1,
                status: 1,
                date: 1,
                company: { $arrayElemAt: ['$company', 0] },
                candidate: { $arrayElemAt: ['$candidate', 0] },
            }
        },
        {
            $sort: {
                createdAt: -1
            }
        },
        // { $skip: offsetData }, { $limit: limitData },
    )
    const list = await ReferralReq.aggregate(finalQuery);
    return {
        totalData: totalData.length,
        data: list
    }
}
// Assigned referral
const getAssignedReferrals = catchAsyncError(async (req, res, next) => {
    const referralId = req.referral;
    try {
        // const { search, status, company } = req.query
        if (!mongoose.Types.ObjectId.isValid(referralId)) {
            throw new ErrorHandler("Referral Id is not valid", HttpStatus.BAD_REQUEST, false);
        }
        const data = await getListOfReferralsListByStatus({ status: 1, referralId: referralId })

        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Referral request list load successfully", data });

    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});
// Unclaimed referral 
const getUnclaimedReferrals = catchAsyncError(async (req, res, next) => {
    const referralId = req.referral;
    try {
        // const { search, status, company } = req.query
        if (!mongoose.Types.ObjectId.isValid(referralId)) {
            throw new ErrorHandler("Referral Id is not valid", HttpStatus.BAD_REQUEST, false);
        }
        const data = await getListOfReferralsListByStatus({ status: 0, referralId: referralId })

        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Referral request list load successfully", data });

    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});
// Confirmed referral 
const getConfirmedReferrals = catchAsyncError(async (req, res, next) => {
    const referralId = req.referral;
    try {
        // const { search, status, company } = req.query
        if (!mongoose.Types.ObjectId.isValid(referralId)) {
            throw new ErrorHandler("Referral Id is not valid", HttpStatus.BAD_REQUEST, false);
        }
        const data = await getListOfReferralsListByStatus({ status: 2, referralId: referralId })

        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Referral request list load successfully", data });

    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});
const ChangeReferralStatus = catchAsyncError(async (req, res, next) => {
    const referralId = req.referral;
    const { referralReqId } = req.params;
    const { status } = req.query;
    try {
        if (!status) {
            throw new ErrorHandler("Status is missing.", HttpStatus.BAD_REQUEST, false);
        }
        if (!mongoose.Types.ObjectId.isValid(referralReqId)) {
            throw new ErrorHandler("Referral Request Id is not valid.", HttpStatus.BAD_REQUEST, false);
        }
        const company = await Referral.findById(referralId).populate("companyId");
        const data = await ReferralReq.findOneAndUpdate({ _id: referralReqId, companyId: company?.companyId?._id }, { status: status,$set :{ referrerId: referralId} }, { new: true }).populate("candidateId");
        if (data._id) {
            const templatePath = path.join(__dirname, `../../public/assets/email-templates/${status == 1 ? "ChangeStatusToAssign.ejs" : "ChangeStatusToComplete.ejs"}`);
            const emailData = await ejs.renderFile(templatePath, { firstName: data?.candidateId?.firstName, companyName: company?.companyId?.name });
            await sendEmail({
                email: data?.candidateId?.email,
                subject: `Referral Request Status Update`,
                message: emailData,
            });
            const deviceData = await FcmNotification.find({ member_type: "Candidate", memberId: data?.candidateId?._id });
            if (deviceData.length) {
                const deviceIds = deviceData?.map(ele => {
                    return ele?.firebaseToken
                })
                const message = {
                    title: 'Referral Request Status Update',
                    message: 'Visit dashboard for more details.',
                }
                await fcmNotification({ messageCtx: message, deviceIds });
            }
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: `${status == 1 ? "Referral Claimed" : "Referral Accepted"} successfully` });
        } else {
            throw new ErrorHandler("Something went wrong!!", HttpStatus.BAD_GATEWAY, false);
        }

    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});
module.exports = {
    getAssignedReferrals,
    getUnclaimedReferrals,
    getConfirmedReferrals,
    ChangeReferralStatus
}