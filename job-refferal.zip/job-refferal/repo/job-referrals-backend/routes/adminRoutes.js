const router = require("express").Router();
const { companyCategoryController, companyAController, adminController } = require("../controller/index");
const { isAuthenticateAdmin } = require("../middleware/auth");


//admin auth 
router.post("/adminSignup",adminController.adminSignup )
// category
router.post("/addCategory", companyCategoryController.addCategory);
router.get("/getCategoryList", companyCategoryController.getCategoryList);

// company
router.post("/getCompanyList", companyAController.getCompanyList);
router.get("/getCompany/:id", companyAController.getCompany);
router.get("/getCompanyReferrerList/:id", isAuthenticateAdmin, companyAController.getCompanyReferrerList);
router.get("/handleCompanyDomains/:id", isAuthenticateAdmin, companyAController.handleCompanyDomains);
router.get("/disableCompanyReferrer/:id", isAuthenticateAdmin, companyAController.disableCompanyReferrer);
router.post("/addCompanyInfo", isAuthenticateAdmin, companyAController.addOrUpdateCompanyInfo);
router.post("/updateCompanyInfo/:id",isAuthenticateAdmin, companyAController.addOrUpdateCompanyInfo);
router.delete("/deleteCompany/:id",isAuthenticateAdmin, companyAController.deleteCompany);

//candidate  
router.get("/getCandidateList", isAuthenticateAdmin, adminController.getCandidateList);
router.get("/handleCandidateAccount/:id", isAuthenticateAdmin, adminController.handleCandidateAccount);
module.exports = router