const router = require("express").Router();
const { referralProfileController, referralClaimController } = require("../controller/index");
const { isAuthenticateReferral } = require("../middleware/auth")
const validator = require("../middleware/validator")
const { signupRValidation } = require("../middleware/validation")

// for profile
router.post("/signup", validator.body(signupRValidation), referralProfileController.signup);
router.post("/updateProfile", isAuthenticateReferral, referralProfileController.updateProfile);
router.get("/getProfile", isAuthenticateReferral, referralProfileController.getProfile);
router.post("/uploadCompanyLogo", isAuthenticateReferral, referralProfileController.uploadCompanyLogo);
router.post("/resendEmailVerification", isAuthenticateReferral, referralProfileController.resendEmailVerification);
router.put("/resendEmailVerification", referralProfileController.resendEmailVerificationByEmail);
router.post("/verifyEmail", referralProfileController.verifyEmail);
// request referrals
router.get("/getAssignedReferrals", isAuthenticateReferral, referralClaimController.getAssignedReferrals);
router.get("/getUnclaimedReferrals", isAuthenticateReferral, referralClaimController.getUnclaimedReferrals);
router.get("/getConfirmedReferrals", isAuthenticateReferral, referralClaimController.getConfirmedReferrals);
router.post("/ChangeReferralStatus/:referralReqId", isAuthenticateReferral, referralClaimController.ChangeReferralStatus);
module.exports = router