const router = require("express").Router();
const { authController } = require("../controller/index");
const validator = require("../middleware/validator")
const { signInValidation } = require("../middleware/validation")

router.post("/signIn", validator.body(signInValidation), authController.signIn);
router.post("/forgotPassword", authController.forgotPassword);
router.post("/verifyToken", authController.verifyToken);
router.post("/resetPassword", authController.resetPassword);
router.post("/logout/:role", authController.handleLogOut);

module.exports = router