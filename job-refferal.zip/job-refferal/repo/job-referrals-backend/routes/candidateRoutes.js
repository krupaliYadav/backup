const router = require("express").Router();
const { profileController, referralReqController } = require("../controller/index");
const { isAuthenticateCandidate } = require("../middleware/auth")

// for profile
router.post("/signup", profileController.signup);
router.put("/updateProfile", isAuthenticateCandidate, profileController.updateProfile);
router.put("/updateResume", isAuthenticateCandidate, profileController.updateResume);
router.get("/getCandidateProfile", isAuthenticateCandidate, profileController.getCandidateProfile);
router.delete("/deleteResume", isAuthenticateCandidate, profileController.deleteResume);

// referral request
// router.get("/getCompanyDetails/:companyId", isAuthenticateCandidate, referralReqController.getCompanyDetails);
router.post("/addReferralReq", isAuthenticateCandidate, referralReqController.addReferralReq);
// router.get("/getReferralReqDetails/:referralReqId", isAuthenticateCandidate, referralReqController.getReferralReqDetails);
router.get("/getReferralReqList", isAuthenticateCandidate, referralReqController.getReferralReqList);
router.delete("/deleteReferralReq/:refRequestId", isAuthenticateCandidate, referralReqController.handleDeleteReferralReq);

module.exports = router