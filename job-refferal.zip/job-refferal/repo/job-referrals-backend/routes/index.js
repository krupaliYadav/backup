const express = require("express");
const authRoutes = require("./authRoutes");
const adminRoutes = require("./adminRoutes");
const candidateRoutes = require("./candidateRoutes");
const referralRoutes = require("./referralRoutes");
const router = express.Router();

router.use('/auth', authRoutes)
router.use('/admin', adminRoutes)
router.use('/candidate', candidateRoutes)
router.use('/referral', referralRoutes)

module.exports = router;
