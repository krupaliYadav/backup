const { existsSync, mkdirSync, unlinkSync, writeFileSync } = require("fs")
const { extname } = require("path")
const { STORAGE_PATH } = require("./constants.helper")
const { v4: uuidv4 } = require('uuid');

const uploadFile = (dir, files, allowedExtension) => {
    console.log(files);
    const { mimetype } = files;
    const img = mimetype.split("/");
    const extension = img[1].toLowerCase();

    if (!allowedExtension.includes(extension)) {
        return res.status(HTTP_STATUS_CODE.INTERNAL_SERVER).json({ status: HTTP_STATUS_CODE.INTERNAL_SERVER, success: false, message: `${extension} is not allowed..` });
    }


    const fileName = `${dir}/${uuidv4()}.${extension}`

    const storageDirExits = existsSync(STORAGE_PATH)
    if (!storageDirExits) mkdirSync(STORAGE_PATH)

    const exists = existsSync(`${STORAGE_PATH}/${dir}`)
    if (!exists) mkdirSync(`${STORAGE_PATH}/${dir}`)

    writeFileSync(`${STORAGE_PATH}/${fileName}`, files.image)
    return fileName

}

module.exports = {
    uploadFile
}



