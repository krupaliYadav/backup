const User = require("../../models/userModel")
const bcrypt = require("bcrypt")
const jwt = require("jsonwebtoken")
const mongoose = require("mongoose")
const { HTTP_STATUS_CODE, DEFAULT_PROFILE_IMG } = require("../../helper/constants.helper")
const { BadRequestException, ConflictRequestException, NotFoundRequestException } = require("../../common/exceptions/index")

// add new user
const addUser = async (req, res) => {
    let { firstName, lastName, email, password, phoneNumber, image } = req.body
    const user = await User.findOne({ email: email })
    if (user) {
        throw new ConflictRequestException("An account already exists with this email address.")
    }

    const isPhoneNumber = await User.findOne({ phoneNumber: phoneNumber })
    if (isPhoneNumber) {
        throw new ConflictRequestException("This phone number already exists! Use a different phone number")
    }
    password = bcrypt.hashSync(password, 10)

    const newUser = await User.create({ firstName, lastName, email, password, phoneNumber })

    return res.status(HTTP_STATUS_CODE.CREATED).json({ status: HTTP_STATUS_CODE.CREATED, success: true, message: "Register SuccessFully..", data: { userID: newUser?._id, token } });
}

module.exports = {
    addUser
}