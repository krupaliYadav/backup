class GeneralError extends Error { }

module.exports = GeneralError;