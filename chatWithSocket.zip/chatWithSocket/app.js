const express = require("express")
const app = express()
const http = require("http").Server(app)
const io = require("socket.io")(http)
const port = 3000

app.get("/", (req, res) => {
    res.sendFile(__dirname + "/views/index.html")
})

users = []
io.on("connection", (socket) => {
    console.log("Socket client  connected....");
    socket.on('setUsername', function (data) {
        if (users.indexOf(data) > -1) {
            socket.emit('userExists', data + ' username is taken! Try some other username.');

        } else {
            users.push(data);
            socket.emit('userSet', { username: data });
        }

        socket.on('msg', function (data) {
            //Send message to everyone
            io.sockets.emit('newmsg', data);
        })
    })

    socket.on("disconnect", () => {
        console.log("Socket client disconnected....");
    })
})

http.listen(port, () => {
    console.log(`Server is running on ${port}`);
})