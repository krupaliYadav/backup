const express = require('express')
const app = express()
const port = 3000
const mySql = require("mysql")

const conn = mySql.createConnection({
    connectionLimit: 10,
    host: "127.0.0.1",
    user: "root",
    password: "",
    database: "mydb"
})

conn.connect(function (err) {
    if (err) throw err;
    console.log("Connected!");
    //////////////////////////////////////////////////////////////////////////////////////////////
    // create database
    // conn.query("CREATE DATABASE mydb", function (err, result) {
    //     if (err) throw err;
    //     console.log("Database created");
    // });

    //////////////////////////////////////////////////////////////////////////////////////////////
    // create table
    // var sql = "CREATE TABLE AddToCart (addToCartId int auto_increment primary key ,price int, ProductId int, Quantity int  )";

    //    if table is already create and add new filed then
    // var sql = "ALTER TABLE orders ADD COLUMN ShipperId int"

    //////////////////////////////////////////////////////////////////////////////////////////////
    // insert  single record into table
    // var sql = "INSERT INTO users (name, email, password, city) VALUES ('ram', 'raam@yopmail.com', 'raam@123', 'mumbai')"
    // conn.query(sql, function (err, result) {
    //     if (err) throw err;
    //     console.log("Table created");
    // })

    //////////////////////////////////////////////////////////////////////////////////////////////
    // insert many
    // var sql = "INSERT INTO AddToCart  (price , ProductId   ) VALUES ? "
    // const values = [
    //     [200, 1],
    // [250, 2, 3],
    // [1000, 1, 3],

    // ]
    // conn.query(sql, [values], function (err, result) {
    //     if (err) throw err;
    //     console.log("Table created");
    // })

    //////////////////////////////////////////////////////////////////////////////////////////////
    // select all column query 
    // const sql = "SELECT * FROM users"

    //////////////////////////////////////////////////////////////////////////////////////////////
    // select specific column query
    // const sql = "SELECT name, email FROM users"
    // conn.query(sql, (err, result, fields) => {
    //     if (err) throw err;
    //     // this is for remove rowDataPacket from result
    //     const userData = JSON.parse(JSON.stringify(result));
    //     console.log(userData);
    // })

    //////////////////////////////////////////////////////////////////////////////////////////////
    // select with where
    // const sql = "SELECT * FROM users WHERE email = 'krupali@yopmail.com'"

    //////////////////////////////////////////////////////////////////////////////////////////////
    // for start with "LIKE"
    // const sql = "SELECT * FROM users WHERE name LIKE 'a%' "
    // conn.query(sql, (err, result) => {
    //     if (err) throw err
    //     const userData = JSON.parse(JSON.stringify(result));
    //     console.log(userData);
    // })

    //////////////////////////////////////////////////////////////////////////////////////////////
    // Escape query values by using the placeholder ? method:
    // const name = "anvi"
    // const sql = "SELECT * FROM users WHERE name = ? "
    // conn.query(sql, [name], (err, result) => {
    //     if (err) throw err
    //     const userData = JSON.parse(JSON.stringify(result));
    //     console.log(userData);
    // })

    //////////////////////////////////////////////////////////////////////////////////////////////
    // If you have multiple placeholders, the array contains multiple values, in that order:
    // const name = "anvi"
    // const city = "mumbai"
    // const sql = "SELECT * FROM users WHERE name = ? OR city = ? "
    // conn.query(sql, [name, city], (err, result) => {
    //     if (err) throw err
    //     const userData = JSON.parse(JSON.stringify(result));
    //     console.log(userData);
    // })

    //////////////////////////////////////////////////////////////////////////////////////////////
    // order by
    // in this by default it take in ascending order if we want descending then write DESC
    // for ascending
    // const sql = "SELECT * FROM users ORDER BY name"

    // for descending
    // const sql = "SELECT * FROM users ORDER BY name DESC"
    // conn.query(sql, (err, result) => {
    //     if (err) throw err
    //     const userData = JSON.parse(JSON.stringify(result));
    //     console.log(userData);
    // })

    //////////////////////////////////////////////////////////////////////////////////////////////
    // Delete Record
    // const sql = "DELETE FROM users WHERE name = 'ankit'"
    // conn.query(sql, (err, result) => {
    //     if (err) throw err

    //     console.log("Delete successfully");
    // })

    //////////////////////////////////////////////////////////////////////////////////////////////
    // Delete a Table
    // const sql = "DROP TABLE products"

    // drop only if exits
    // const sql = "DROP TABLE IF EXISTS products"

    //////////////////////////////////////////////////////////////////////////////////////////////
    // update table
    // const sql = "UPDATE users SET email = 'rahul@yopmail.com', password = 'rahul@123'  WHERE id = 1 "
    // conn.query(sql, (err, result) => {
    //     if (err) throw err
    //     console.log("Delete successfully");
    // })

    //////////////////////////////////////////////////////////////////////////////////////////////
    // You can limit the number of records returned from the query, by using the "LIMIT" statement:
    // const sql = "SELECT * FROM users LIMIT 3"
    // conn.query(sql, (err, result) => {
    //     if (err) throw err
    //     const userData = JSON.parse(JSON.stringify(result))
    //     console.log("users list load successfully", userData);
    // })

    //////////////////////////////////////////////////////////////////////////////////////////////
    // Start From Another Position
    // Start from position 3, and return the next 2 records:
    // var sql = "select * from users limit 2 offset 2";
    // conn.query(sql, function (err, result) {
    //     if (err) throw err;
    //     const userData = JSON.parse(JSON.stringify(result))
    //     console.log("users list load successfully", userData);
    // });

    //////////////////////////////////////////////////////////////////////////////////////////////
    // inner join
    // record that have matching values in both tables
    // const sql = "select orders.OrderID, Customers.CustomerName, Orders.OrderDate from orders inner join customers on orders.CustomerID = customers.CustomerID"

    //////////////////////////////////////////////////////////////////////////////////////////////
    // join three tables
    // const sql = "select orders.OrderId, customers.CustomerName, orders.OrderDate, shippers.ShipperName from ((orders INNER JOIN Customers ON Orders.CustomerID = Customers.CustomerID) INNER JOIN Shippers ON Orders.ShipperID = Shippers.ShipperID); "

    //////////////////////////////////////////////////////////////////////////////////////////////
    // left join
    // The LEFT JOIN keyword returns all records from the left table (table1), and the matching records (if any) from the right table (table2).
    // const sql = "select customers.CustomerName, orders.OrderId from customers LEFT JOIN Orders ON Customers.CustomerID = Orders.CustomerID"

    //////////////////////////////////////////////////////////////////////////////////////////////
    // MySQL RIGHT JOIN Keyword
    // The RIGHT JOIN keyword returns all records from the right table (table2), and the matching records (if any) from the left table (table1).
    // const sql = "SELECT orders.OrderID, customers.CustomerName  FROM orders RIGHT JOIN customers ON customers.CustomerID = orders.CustomerID"

    //////////////////////////////////////////////////////////////////////////////////////////////
    // SQL CROSS JOIN Keyword
    // The CROSS JOIN keyword returns all records from both tables (table1 and table2).
    // const sql = "SELECT Customers.CustomerName, Orders.OrderID FROM Customers CROSS JOIN Orders;"
    // conn.query(sql, (err, result) => {
    //     if (err) throw err
    //     const data = JSON.parse(JSON.stringify(result))
    //     console.log(data);
    // })

    //////////////////////////////////////////////////////////////////////////////////////////////
    // union operator
    // The UNION operator is used to combine the result-set of two or more SELECT statements.
    // Every SELECT statement within UNION must have the same number of columns
    // The columns must also have similar data types
    // The columns in every SELECT statement must also be in the same order
    // if we use only union then it will skip duplicate and if we use union all it return all records with duplicate
    // const sql = "SELECT Country FROM Customers union  select Country from suppliers"

    //////////////////////////////////////////////////////////////////////////////////////////////
    // MySQL GROUP BY
    // The following SQL statement lists the number of customers in each country:
    // const sql = "SELECT COUNT(SuppliersId), Country FROM suppliers GROUP BY Country;"
    // conn.query(sql, (err, result) => {
    //     if (err) throw err
    //     const data = JSON.parse(JSON.stringify(result))
    //     console.log(data);
    // })

    // The following SQL statement lists the number of orders sent by each shipper:
    // const sql = "select shippers.ShipperName, count(orders.orderId) as NumbersOfOrders from orders left join shippers on orders.shipperID = shippers.shipperId group by ShipperName"


    //////////////////////////////////////////////////////////////////////////////////////////////
    // having
    // const sql = "select COUNT(CustomerId), Country from customers group by Country HAVING COUNT(CustomerId) > 5;"


    // //////////////////////////////////////////////////////////////////////////////////////////////////
    // const sql = "SELECT ShipperName FROM shippers WHERE EXISTS (SELECT ProductName FROM products WHERE Price = 22)"
    // // const sql = "select ShipperName from shippers where  EXISTS (SELECT ProductName FROM products WHERE products.SupplierID = suppliers.supplierID AND Price = 22)"


    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // ALL and ANY
    // ANY means that the condition will be true if the operation is true for any of the values in the range.
    // const sql = "select productName from products where ProductId = ANY (select ProductId  from  OrderDetails where Quantity > 20)"


    // ALL means that the condition will be true only if the operation is true for all values in the range.
    // const sql = "select ProductName from products where ProductId = ALL (select ProductId from OrderDetails where Quantity = 10)"
    // conn.query(sql, (err, result) => {
    //     if (err) throw err
    //     const data = JSON.parse(JSON.stringify(result))
    //     console.log(data);
    // })

    // ////////////////////////////////////////////////////////////////////////////////////////////////////////
    // The INSERT INTO SELECT statement copies data from one table and inserts it into another table.
    // const sql = "insert into suppliers (SupplierName, ContactName, Country) select CustomerName, ContactName, Country from customers"
    // conn.query(sql, (err, result) => {
    //     if (err) throw err
    //     console.log(result);
    // })

    /////////////////////////////////////////////////////////////////////////////////////
    // const sql = 'SELECT productId, price *  IFNULL(Quantity, 0) FROM AddToCart;'
    // conn.query(sql, (err, result) => {
    //     if (err) throw err
    //     const data = JSON.parse(JSON.stringify(result))
    //     console.log(data);
    // })


    // ///////////////////////////////////////////////////////////////////////////////////////
    // To create a NOT NULL constraint on the "email" column when the "users" table is already created, use the following SQL:
    // const sql = "alter table users modify email varchar(255) not null"
    // conn.query(sql, (err, result) => {
    //     if (err) throw err
    //     const data = JSON.parse(JSON.stringify(result))
    //     console.log(data);
    // })

    //////////////////////////////////////////////////////////////////////////////////////////////
    // unique key
    // var sql = "CREATE TABLE Persons ( ID int NOT NULL, LastName varchar(255) NOT NULL,FirstName varchar(255),Age int, UNIQUE (ID));"

    // apply unique key on multiple column
    // "CREATE TABLE Persons (ID int NOT NULL,LastName varchar(255) NOT NULL, FirstName varchar(255),Age int,CONSTRAINT UC_Person UNIQUE (ID,LastName));"

    // To create a UNIQUE constraint on the "ID" column when the table is already created, use the following SQL:
    // "ALTER TABLE Persons ADD UNIQUE (ID);"

    // conn.query(sql, (err, result) => {
    //     if (err) throw err
    //     // const data = JSON.parse(JSON.stringify(result))
    //     console.log(result);
    // })

    // PRIMARY KEY on CREATE TABLE
    // The following SQL creates a PRIMARY KEY on the "ID" column when the "Persons" table is created:
    // "CREATE TABLE Persons (ID int NOT NULL,LastName varchar(255) NOT NULL,FirstName varchar(255), Age int,PRIMARY KEY (ID));"

    // To allow naming of a PRIMARY KEY constraint, and for defining a PRIMARY KEY constraint on multiple columns, use the following SQL syntax:
    // "CREATE TABLE Persons (ID int NOT NULL,LastName varchar(255) NOT NULL,FirstName varchar(255), Age int,CONSTRAINT PK_Person PRIMARY KEY (ID,LastName));"


    // FOREIGN KEY on CREATE TABLE
    // The following SQL creates a FOREIGN KEY on the "PersonID" column when the "Orders" table is created:
    // " CREATE TABLE Orders (OrderID int NOT NULL,OrderNumber int NOT NULL,PersonID int,PRIMARY KEY (OrderID),FOREIGN KEY (PersonID) REFERENCES Persons(PersonID));"


    // DEFAULT Constraint
    // The DEFAULT constraint is used to set a default value for a column.
    // "CREATE TABLE Persons (ID int NOT NULL,LastName varchar(255) NOT NULL,FirstName varchar(255),Age int,City varchar(255) DEFAULT 'Sandnes');"



});
app.get('/', (req, res) => res.send('Hello World!'))

app.listen(port, () => console.log(`Example app listening on port ${port}!`))