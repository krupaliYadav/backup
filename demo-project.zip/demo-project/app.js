require("dotenv").config()
require("./src/config/database")
const express = require("express")
const routes = require("./src/routes/index")
const User = require("./src/model/userModel")
const path = require("path")
const port = process.env.PORT || 3000
const app = express()

app.use(express.json())
app.use(routes)
app.set("view engine", "ejs")
app.use("/src/public", express.static(path.join(__dirname, "/src/public")))

app.get("/", async (req, res) => {
    const user = await User.find().count()
    res.render('dashboard', { user: user })
})

app.get("/html", (req, res) => {
    res.sendFile(__dirname + "/views/index.html")
})
app.use((err, req, res, next) => {
    if (err && err.error && err.error.isJoi) {
        return res.status(400).json({ Error: true, message: err.error.message });
    }
    return res.status(500).json({ Error: true, message: err.message });
});

app.listen(port, () => {
    console.log(`Server is running on ${port}`);
})