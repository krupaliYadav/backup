const mongoose = require("mongoose")
const { Schema } = mongoose
const userSchema = new Schema({
    firstName: {
        type: String,
        require: [true, "First Name is required..."]
    },
    lastName: {
        type: String,
        require: [true, "Last Name is required..."]
    },
    email: {
        type: String,
        require: [true, "Email is required..."]
    },
    password: {
        type: String,
        require: [true, "Password is required..."]
    },
    phoneNumber: {
        type: String,
        require: [true, "Phone Number is required..."]
    },
    profileImage: {
        type: String
    },
    gender: {
        type: String,
        enum: ["Male", "Female", "other"],
    },
    hobbies: {
        type: [String]
    },
    city: {
        type: String,

    },
    state: {
        type: String
    },
    zipCode: {
        type: Number
    }
}, { timestamps: true })

module.exports = mongoose.model("Users", userSchema)