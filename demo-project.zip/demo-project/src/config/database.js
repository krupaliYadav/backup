const mongoose = require("mongoose")

module.exports = mongoose.connect(process.env.MONGO_URL)
    .then(() => { console.log("Backend connected....") })
    .catch((err) => { console.log("Database Err: ", err); })