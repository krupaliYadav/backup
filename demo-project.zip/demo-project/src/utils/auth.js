const { catchAsyncError, HttpStatus, responseHandler, HttpException } = require("../utils/index")
const jwt = require("jsonwebtoken")
const User = require("../model/userModel")

module.exports = catchAsyncError(async (req, res, next) => {
    if (!req.headers.authorization) {
        throw new HttpException("Please login to access this resource", 401);
    }
    const token = req.headers.authorization.split(" ")[1]
    if (!token) {
        throw new HttpException("Please Enter valid Token", 401);
    }
    const decode = jwt.verify(token, process.env.KEY)
    const user = await User.findById(decode._id)
    if (!user) {
        throw new HttpException("Token is expired or Invalid.", 401);
    }
    req.user = user;
    next();
})