const { catchAsyncError, HttpStatus, responseHandler, HttpException } = require("../utils/index")
const bcrypt = require("bcryptjs")
const jwt = require("jsonwebtoken")
const User = require("../model/userModel")

/*signup */
exports.signup = catchAsyncError(async (req, res, next) => {
    const user = await User.findOne({ email: req.body.email })
    if (user) {
        throw new HttpException("User is already exits!!!", HttpStatus.BAD_REQUEST, true);
    }
    req.body.password = bcrypt.hashSync(req.body.password, 10)
    const data = await User.create(req.body)
    res.status(HttpStatus.OK).json(responseHandler("SignUp done successfully...", HttpStatus.OK))
})

/*login */
exports.login = catchAsyncError(async (req, res, next) => {
    let data = {}
    let { email, password } = req.body
    let user = await User.findOne({ email: email })
    if (!user) {
        throw new HttpException("Please Enter registered email..!!!", HttpStatus.BAD_REQUEST);
    }
    if (!bcrypt.compareSync(password, user?.password)) {
        throw new HttpException("password not match..!!!", HttpStatus.BAD_REQUEST);
    }

    const token = jwt.sign({ _id: user._id }, process.env.KEY)
    data = {
        userId: user._id,
        token: token
    }
    res.status(HttpStatus.OK).json(responseHandler("Login done successfully...", HttpStatus.OK, data))
})

/*get user details*/
exports.getUserDetails = catchAsyncError(async (req, res, next) => {
    const userId = req.params.id
    if (userId?.toString() === req.user?._id.toString()) {
        let user = await User.findById({ _id: userId })
        if (!user) {
            throw new HttpException("User not found..!!!", HttpStatus.NOT_FOUND);
        }
        res.status(HttpStatus.OK).json(responseHandler("User details...", HttpStatus.OK, user))
    } else {
        throw new HttpException("You are Not authorized...!!!", HttpStatus.UNAUTHORIZED);
    }

})

/*update user details*/
exports.updateUser = catchAsyncError(async (req, res, next) => {
    const user = await User.findById(req.user._id)
    if (req.body.hobbies) {
        const checkExits = user.hobbies.findIndex(hobby => hobby == req.body.hobbies)
        if (checkExits == -1) {
            user.hobbies.push(req.body.hobbies)
            user.save()
        }
    }

    const setData = {
        firstName: req.body?.firstName,
        lastName: req.body?.lastName,
        email: req.body?.email,
        phoneNumber: req.body?.phoneNumber,
        gender: req.body?.gender,
        city: req.body?.city,
        state: req.body?.state,
        zipCode: req.body?.zipCode,
        profileImage: req.file?.filename
    }
    const data = await User.findByIdAndUpdate(req.user._id, setData)
    res.status(HttpStatus.OK).json(responseHandler("User update successfully...", HttpStatus.OK, data))
})

/*get all user details*/
exports.getUserList = catchAsyncError(async (req, res, next) => {
    const query = {}
    if (req.query.search) {
        query.firstName = { $regex: req.query.search }
    }
    const users = await User.find(query)
    let img = ""
    users.map(user => {
        if (user?.profileImage) {
            img = `<img src="${process.env.APP_URL}/src/public/${user?.profileImage}" style="height: 80px; width: 80px;">`
            return user.profileImage = img
        }
    })
    res.render("users", { users: users })

})

