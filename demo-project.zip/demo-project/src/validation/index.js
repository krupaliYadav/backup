const joi = require("joi")

const signup = joi.object().keys({
    firstName: joi.string().trim().required().messages({
        "string.empty": "First name is required ",
    }),
    lastName: joi.string().trim().required().messages({
        "string.empty": "Last name is required ",
    }),
    email: joi.string().email().required().messages({
        "*": "Please enter valid email..",
        "string.empty": "Email is required ",
    }),
    password: joi.string().min(4).max(10).required().messages({
        'string.min': 'Password should have at least 4 characters',
        'string.max': 'Password should not exceed 10 characters',
        'string.empty': 'Password is required',
    }),
    phoneNumber: joi.string().min(10).max(10).trim().required().messages({
        'string.min': 'Phone number should have at least 10 characters',
        'string.max': 'Phone number should not exceed 10 characters',
        'string.empty': 'Phone number is required',
    }),
})

const login = joi.object().keys({
    email: joi.string().email().required().messages({
        "string.empty": "Email is required ",
    }),
    password: joi.string().min(4).max(10).required().messages({
        'string.min': 'Password should have at least 4 characters',
        'string.max': 'Password should not exceed 10 characters',
        'string.empty': 'Password is required',
    }),
})

const getUserDetails = joi.object().keys({
    id: joi.string().required().messages({
        "string.empty": "id is required ",
    }),
})

const updateUser = joi.object().keys({
    firstName: joi.string().trim(),
    lastName: joi.string().trim(),
    email: joi.string().email(),
    phoneNumber: joi.string().min(10).max(10).trim().messages({
        'string.min': 'Phone number should have at least 10 characters',
        'string.max': 'Phone number should not exceed 10 characters'
    }),
    profileImage: joi.any(),
    gender: joi.string().trim(),
    hobbies: joi.string(),
    city: joi.string().trim(),
    state: joi.string().trim(),
    zipCode: joi.number(),
})

module.exports = {
    signup,
    login,
    getUserDetails,
    updateUser
}