const express = require("express")
const multer = require("multer")
const path = require("path")
const routes = express.Router()
const validator = require("../utils/validatorSchema")
const { signup, login, getUserDetails, updateUser } = require("../validation/index")
const controller = require("../controller/userController")
const auth = require("../utils/auth")

const storage = multer.diskStorage({
    destination: function (req, file, callback) {
        callback(null, "./src/public")
    },
    filename: function (req, file, callback) {
        callback(null, file.fieldname + "-" + Date.now() + path.extname(file.originalname))
    },
})
// console.log(storage.DiskStorage.ge);

const upload = multer({ storage: storage })

routes
    .post("/signup", validator.body(signup), controller.signup)
    .post("/login", validator.body(login), controller.login)
    .get("/:id", auth, validator.params(getUserDetails), controller.getUserDetails)
    .put("/", auth, upload.single("profileImage"), validator.body(updateUser), controller.updateUser)
    // .get("/", (req, res) => {
    //     res.render("user")
    // })
    .get("/", controller.getUserList)

module.exports = routes