const mongoose = require("mongoose")
const Grid = require("gridfs-stream")

// db connection
const dbConnection = async () => {
    const conn = mongoose.createConnection(process.env.MONGO_URL)

    let gfs;
    conn.once("open", () => {
        // initialization stream
        gfs = Grid(conn.db, mongoose.mongo)
        gfs.collection("uploads")
    })
}

module.exports = dbConnection
