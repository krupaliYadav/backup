const route = require("express").Router()
const fileUploadRoutes = require("./fileUpload")

route.use("/fileUpload", fileUploadRoutes)

module.exports = route