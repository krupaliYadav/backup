const route = require("express").Router()
const controller = require("../controller/fileUpload")
const upload = require("../utils/fileupload")


route.post("/addFile", upload.single('file'), controller.addFile)
route.get("/getFiles", controller.getFile)
route.get("/getFile/:filename", controller.getSingleFile)

module.exports = route