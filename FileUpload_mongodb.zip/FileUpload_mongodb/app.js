require("dotenv").config()
const express = require('express')
const app = express()
const port = 3000
const bodyParser = require("body-parser")
const routes = require("./routes/index")
const dbConnection = require("./config/db.connection")
const methodOverride = require("method-override")


app.use(bodyParser.json())
app.use(methodOverride("_method"))
app.use("/api/v1", routes)

app.get("/", (req, res) => {
    res.json({ message: "It's working finely" })
})

app.listen(port, async () => {
    await dbConnection()
    console.log(`Server is running on ${port}`);
})