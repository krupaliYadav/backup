const mongoose = require("mongoose")
const Grid = require("gridfs-stream")

const conn = mongoose.createConnection(process.env.MONGO_URL)
let gfs;
conn.once("open", () => {
    // initialization stream
    gfs = Grid(conn.db, mongoose.mongo)
    gfs.collection("uploads")
    console.log("MongoDB connection successful");
})

const addFile = async (req, res) => {
    res.json({ file: req.file })
}

const getFile = async (req, res) => {
    gfs.files.find().toArray((err, files) => {
        if (err) {
            console.error("Error querying files:", err);
            return res.status(500).json({ err: "Internal Server Error" });
        }
        if (!files || files.length === 0) {
            console.log("No files found");
            return res.json({ err: "File not exists" });
        }
        return res.json({ files: files });
    });
}

const getSingleFile = async (req, res) => {
    gfs.files.findOne({ filename: req.params.filename }, (err, files) => {
        if (err) {
            console.error("Error querying files:", err);
            return res.status(500).json({ err: "Internal Server Error" });
        }
        if (!files || files.length === 0) {
            console.log("No files found");
            return res.json({ err: "File not exists" });
        }
        if (files.contentType === "image/png") {
            const readStream = gfs.createReadStream(files.filename)
            console.log(readStream);
            readStream.pipe(res)
        } else {
            res.json({ err: "Not an image" })
        }

    });
}


module.exports = {
    addFile,
    getFile,
    getSingleFile
}