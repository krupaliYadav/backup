const crypto = require("crypto")
const multer = require("multer")
const path = require("path")
const GridFsStorage = require("multer-gridfs-storage")

// create storage engine
let storage = new GridFsStorage({
    url: process.env.MONGO_URL,
    file: (req, file) => {
        return new Promise((resolve, reject) => {
            crypto.randomBytes(16, (err, buf) => {
                if (err) {
                    return reject(err)
                }
                const fileName = buf.toString("hex") + path.extname(file.originalname)
                const fileInfo = {
                    filename: fileName,
                    bucketName: "uploads"
                }
                resolve(fileInfo)
            })
        })
    }
})

const upload = multer({ storage: storage })

module.exports = upload
