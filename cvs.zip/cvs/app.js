const mongoose = require('mongoose');
const fs = require('fs');
const csv = require('csv-parser');
const User = require('./models/User');
const Beautician = require('./models/Beautician');
const Client = require('./models/Client');

const connectDatabase = () => {
    mongoose.connect('mongodb+srv://testingdata:RW8seyFe4YvJlcMX@cluster0.eimzhl1.mongodb.net/csv_demo', {
        useNewUrlParser: true,
        useUnifiedTopology: true,
    }).then(() => {
        console.log("Backend is Connected")
        insertDataFromCSV();
    }).catch((Error) => {
        console.log("Error =>", Error);
    })
};
connectDatabase();


const generateBeauticianId = (length) => {
    let uid = "";
    // let pieces = length.split('-');
    let lastNum = length;
    lastNum = parseInt(lastNum, 10);
    lastNum++;

    if (lastNum < 9) {
        uid = "SLKC" + "-" + "000000" + lastNum.toString()
    } else if (lastNum < 99) {
        uid = "SLKC" + "-" + "00000" + lastNum.toString()
    }
    else if (lastNum < 999) {
        uid = "SLKC" + "-" + "0000" + lastNum.toString()
    }
    else if (lastNum < 9999) {
        uid = "SLKC" + "-" + "000" + lastNum.toString()
    }
    else if (lastNum < 99999) {
        uid = "SLKC" + "-" + "00" + lastNum.toString()
    }
    else if (lastNum < 999999) {
        uid = "SLKC" + "-" + "0" + lastNum.toString()
    }
    else if (lastNum <= 9999999) {
        uid = "SLKC" + "-" + lastNum.toString()
    }
    return uid;
}
// Function to read the CSV file and insert data into the database
async function insertDataFromCSV() {
    try {
        const promises = [];
        let tempId = 0;
        fs.createReadStream('users.csv')
            .pipe(csv())
            .on('data', async (row) => {

                if (row.type && JSON.parse(row.type).includes('client')) {
                    const data = {}
                    data.userId = row._id;
                    data.firstName = row.firstName;
                    data.lastName = row.lastName;
                    data.country_code = 'Ca';
                    data.country = 'Canada';
                    data.language =row.locale;
                    data.uid = generateBeauticianId(tempId)
                    data.screenStatus =3
                    console.log("data", data)
                    const person = new Client(data);
                    promises.push(person.save());
                    tempId++;
                }
            })
            .on('end', async () => {
                try {
                    // Wait for all the promises to resolve before disconnecting
                    await Promise.all(promises);
                    console.log('All data saved to the database.');
                    mongoose.disconnect();
                } catch (error) {
                    console.error('Error saving data:', error);
                    mongoose.disconnect();
                }
            });
    } catch (error) {
        console.error('Error reading CSV:', error);
        mongoose.disconnect();
    }
}

// Call the function to insert data from the CSV file

