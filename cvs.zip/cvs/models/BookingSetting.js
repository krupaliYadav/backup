const mongoose = require("mongoose");

const bookingSetting = mongoose.Schema({
    beauticianId: {
        type: mongoose.Schema.ObjectId,
        ref: "Beautician",
        require: [true, "beauticianId is Required"]
    },
    confirmAuto: {
        type: Boolean,
        default: true
    },
    bookingWindow: {
        type: String,
        comment: "no less than value in advance"
    },
    futureBookingDay: {
        type: Number,
        comment: "Up to value in the future"
    },
    futureBookingMonths: {
        type: Number,
        comment: "Up to value in the future"
    },
    rescheduling: {
        type: String,
        comment: "no less than value in advance"
    }
}, { timestamps: true });

module.exports = mongoose.model("BookingSetting", bookingSetting);