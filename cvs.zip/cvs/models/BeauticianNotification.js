const mongoose = require("mongoose");

const beauticianNotificationSchema = mongoose.Schema({
    beauticianId: {
        type: mongoose.Schema.ObjectId,
        ref: "Beautician",
        require: [true, "beauticianId is Required"]
    },
    title: { type: String, require: [true, "Title is Required"] },
    details: { type: String, require: [true, "Details is Required"] },
}, { timestamps: true });

module.exports = mongoose.model("BeauticianNotification", beauticianNotificationSchema);