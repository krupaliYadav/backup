const mongoose = require("mongoose");

const provinceSchema = mongoose.Schema({
    name: {
        type: String,
        unique: true,
        required: [true, "Name is Required"]
    },
    subType: [
        {
            taxName: { type: String, enum: ["GST", "PST", "QST", "HST"] },
            tax: { type: Number, comment: "Count in percentage" }
        }
    ],
    colorCode: {
        type: String
    }
}, { timestamps: true })

module.exports = mongoose.model("Province", provinceSchema);