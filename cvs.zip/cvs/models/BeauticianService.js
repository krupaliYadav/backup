const mongoose = require("mongoose");

const beauticianServiceSchema = mongoose.Schema({
    beauticianId: {
        type: mongoose.Schema.ObjectId,
        ref: "Beautician",
        require: [true, "beauticianId is Required"]
    },
    serviceCategory: {
        type: mongoose.Schema.ObjectId,
        ref: "ServiceCategoryList",
        require: [true, "serviceCategoryId is Required"]
    },
    serviceType: {
        type: mongoose.Schema.ObjectId,
        ref: "ServiceTypeList",
        require: [true, "ServiceTypeId is Required"]
    },
    duration: {
        type: String,
        require: [true, "duration is Required"]
    },
    price: {
        type: Number,
        require: [true, "price is Required"]
    },
    priceStatus: {
        type: String,
        enum: ["Fixed", "Seasonal"]
    },
    imgName: {
        type: String,
    },
    description: {
        type: String,
        maxlength: 150,
    },
    isBookOnline: {
        type: Boolean,
        default: true
    },
    isHomeService: {
        type: Boolean
    },
    inBetweenInterval: {
        type: String
    },
    noOfParallelClient: {
        type: Number
    },
    showCancelPolicy: {
        type: Boolean
    },
    nubOfCartClicked: {
        type: Number,
        default: 0,
    },
    nubOfView: {
        type: Number,
        default: 0,
    },
    isDelete: {
        type: Number,
        default: 0,
        enum: [0, 1],
        comment: "1 : deleted , 0 :not deleted"
    }
}, { timestamps: true });

beauticianServiceSchema.set('toObject', { virtuals: true })
beauticianServiceSchema.set('toJSON', { virtuals: true })

beauticianServiceSchema.virtual('imageUrl').get(function () {
    return this.imgName;
});
module.exports = mongoose.model("BeauticianService", beauticianServiceSchema);