const mongoose = require("mongoose");

const productCategorySchema = mongoose.Schema({
    productCategoryName: {
        type: String,
        unique: true,
        required: [true, "Service category name is Required"]
    },
    imgPath: {
        type: String
    },
    colorCode: {
        type: String
    },
    isDeleted: {
        type: Number,
        enum: [0, 1],
        default: 0,
        Comment: "0 : not deleted , 1 deleted"
    }
}, { timestamps: true })

module.exports = mongoose.model("ProductCategoryList", productCategorySchema);