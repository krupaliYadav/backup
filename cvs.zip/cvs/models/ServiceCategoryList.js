const mongoose = require("mongoose");

const ServiceCategorySchema = mongoose.Schema({
    serviceCategoryName: {
        type: String,
        unique: true,
        required: [true, "Service category name is Required"]
    },
    imgPath: {
        type: String
    },
    colorCode: {
        type: String
    }
}, { timestamps: true })

module.exports = mongoose.model("ServiceCategoryList", ServiceCategorySchema);