const mongoose = require("mongoose");

const paymentSchema = mongoose.Schema({
    BookingId: {
        type: String,
        unique: true,
        require: [true, "BookingId is required."]
    },
    clientId: {
        type: mongoose.Schema.ObjectId,
        ref: "Client",
        require: [true, "ClientId is Required"]
    },
    appointmentIds: {
        type: [mongoose.Schema.ObjectId],
        ref: "Appointment",
        require: [true, "appointmentIds is Required"]
    },
    cardId: {
        type: mongoose.Schema.ObjectId,
        ref: "Card",
        require: [true, "payment method Id is Required"]
    },
    transactionId: {
        type: String,
        require: [true, "transaction Id is Required"]
    },
    addressId: {
        type: mongoose.Schema.ObjectId,
        ref: "Address",
    },
    subTotal: {
        type: Number,
        require: [true, "tax is Required"]
    },
    GST: {
        type: Number,
        default: 0
    },
    PST: {
        type: Number,
        default: 0
    },
    HST: {
        type: Number,
        default: 0
    },
    QST: {
        type: Number,
        default: 0
    },
    GstInPer: {
        type: Number,
        default: 0
    },
    PstInPer: {
        type: Number,
        default: 0
    },
    HstInPer: {
        type: Number,
        default: 0
    },
    QstInPer: {
        type: Number,
        default: 0
    },
    // gstORhst: {
    //     type: Number,
    // },
    // pstORqst: {
    //     type: Number,
    // },
    // gstORhstInPer: {
    //     type: Number,
    // },
    // pstORqstInPer: {
    //     type: Number,
    // },
    discount: {
        type: Number,
        default: 0,
        comment: " in percentage"
    },
    TotalPrice: {
        type: Number,
        require: [true, "TotalPrice is Required"]
    },
    paymentStatus: {
        enum: [0, 1, 2],
        type: Number,
        default: 0,
        comment: '0 = pending, 1 = confirmed,2 = failed',
    }
}, { timestamps: true });

module.exports = mongoose.model("Payment", paymentSchema);