const mongoose = require("mongoose");

const ServiceTypeSchema = mongoose.Schema({
    serviceCategoryId : {
        type: mongoose.Schema.ObjectId,
        ref:"ServiceCategoryList",
        require:[true,"serviceCategoryId is Required"]
    },
    serviceTypeName:{
        type:String,
        unique : true,
        required:[true,"ServiceTypeName is Required"]
    },
},{timestamps:true})

module.exports = mongoose.model("ServiceTypeList",ServiceTypeSchema);