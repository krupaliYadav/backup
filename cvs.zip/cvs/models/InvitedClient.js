const mongoose = require("mongoose");

const invitedClientSchema = mongoose.Schema({
    beauticianId: {
        type: mongoose.Schema.ObjectId,
        ref: "Beautician"
    },
    name:{
        type:String
    },
    email:{
        type:String
    },
    clientId: {
        type: mongoose.Schema.ObjectId,
        ref: "Client"
    },
    phoneNubWithFormat: {
        type: String,
        require: [true, "phoneNubWithFormat is Required"]
    },
    phoneNumber: {
        type: Number,
        require: [true, "phoneNumber is Required"]
    },
    message_id: {
        type: String
    },
    status: {
        type: Number,
        enum: [0, 1],
        default: 0,
        comment: " 0 = pending ;  1 = accepted"
    },
    note:{
        type: String,
    },
    attachFile:{
        type:String
    },
    acceptEmailNotification:{
        type: Number,
        enum: [0, 1],
        default: 0,
        comment: " 0 = not accept ;  1 = accepted"
    },
    acceptSMSNotification:{
        type: Number,
        enum: [0, 1],
        default: 0,
        comment: " 0 = not accept ;  1 = accepted"
    },
    isDeleted:{
        type: Number,
        enum: [0, 1],
        default: 0,
        comment: " 0 = not deleted ;  1 = deleted"
    }
}, { timestamps: true })

module.exports = mongoose.model("InvitedClient", invitedClientSchema);