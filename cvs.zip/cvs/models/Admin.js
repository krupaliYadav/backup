const mongoose = require("mongoose");

const adminSchema = mongoose.Schema({
    uid: {
        type: String,
        unique: true
    },
    firstName: {
        type: String,
        required: [true, "firstName is Required"]
    },
    lastName: {
        type: String,
        required: [true, "LastName is Required"]
    },
    email:{
        type:String,
        required:[true,"Email is Required"]
    },
    password:{
        type:String,
        required:[true,"Password is Required"],
        minLength:[6,"Password must be 6 character"],
    },
    phoneNumber:{
        type:Number,
        required:[true,"Phone Number is Required"],
    },
    profileImage:{
        type:String,
    },
    role:{
        enum: ['superAdmin', 'subAdmin'],
        type:String,
        default:"subAdmin",
        required: true
    },
    isDeleted: {
        enum: [0, 1],
        type: Number,
        default: 0,
        comment: '0 = not deleted, 1= deleted',
    },
    status:{
        enum:[0,1],
        type:Number,
        default:1,
        comment: '0 = deactive, 1= active',
    },
    dashboard:{
        enum:[0,1],
        type:Number,
        default:1,
        comment: '0 = view only, 1= all action 2=view & download',
    },
    beauticians:{
        enum:[0,1],
        type:Number,
        default:1,
        comment: '0 = view only, 1= all action 2=view & download',
    },
    clients:{
        enum:[0,1],
        type:Number,
        default:1,
        comment: '0 = view only, 1= all action 2=view & download',
    },
    products:{
        enum:[0,1],
        type:Number,
        default:1,
        comment: '0 = view only, 1= all action 2=view & download',
    },
    brands:{
        enum:[0,1],
        type:Number,
        default:1,
        comment: '0 = view only, 1= all action 2=view & download',
    },
    gists:{
        enum:[0,1],
        type:Number,
        default:1,
        comment: '0 = view only, 1= all action 2=view & download',
    },
    promotions:{
        enum:[0,1],
        type:Number,
        default:1,
        comment: '0 = view only, 1= all action 2=view & download',
    },
    admins:{
        enum:[0,1],
        type:Number,
        default:1,
        comment: '0 = view only, 1= all action 2=view & download',
    },
},{timestamps:true});

module.exports = mongoose.model("Admin",adminSchema);