// This Model is for send message notifiaction from the admin  side
const mongoose = require("mongoose");

const notificationSchema = mongoose.Schema({
    sendTo: {
        enum: ["Beautician", "Client"],
        type: String,
    },
    title: {
        type: String,
        required: [true, "Name is Required"]
    },
    message: {
        type: String,
        required: [true, "Name is Required"]
    },
    status: {
        enum: [0, 1],
        type: Number,
        default: 1,
        comment: '0 = deactivate, 1= active',
    },
}, { timestamps: true })

module.exports = mongoose.model("adminNotification", notificationSchema);