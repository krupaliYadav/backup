const mongoose = require("mongoose");

const clientSchema = mongoose.Schema({
    userId: {
        type: mongoose.Schema.ObjectId,
        ref: "User",
        unique: true,
        require: [true, "UserId is Required"]
    },
    uid: {
        type: String,
        unique: true
    },
    customerId: {
        type: String,
        comment: "Stripe customer Id"
    },
    firstName: {
        type: String,
        required: [true, "firstName is Required"]
    },
    lastName: {
        type: String,
        required: [true, "LastName is Required"]
    },
    country: {
        type: String,
    },
    country_code: {
        type: String,
    },
    DOB: {
        type: Date
    },
    profileImage: {
        type: String,
    },
    gender: {
        type: String
    },
    address: [{
        addressId: {
            type: mongoose.Schema.ObjectId,
            ref: "Address"
        },
        addressType: {
            type: String,
            enum: ['Home', 'Work', 'Other']
        }
    }],
    notifications: {
        appointmentText: {
            enum: [0, 1],
            type: Number,
            default: 0,
        },
        productText: {
            enum: [0, 1],
            type: Number,
            default: 0,
        },
        emailNotification: {
            enum: [0, 1],
            type: Number,
            default: 0,
        }
    },
    //This is for services
    favorites: {
        type: [mongoose.Schema.ObjectId],
        ref: "Beautician",
        default: []
    },
    recent: {
        type: [mongoose.Schema.ObjectId],
        ref: "Beautician",
        default: []
    },
    // This is for products
    favProducts: {
        type: [mongoose.Schema.ObjectId],
        ref: "BeauticianProduct",
        default: []
    },
    recentProducts: {
        type: [mongoose.Schema.ObjectId],
        ref: "BeauticianProduct",
        default: []
    },
    searchText: {
        type: [String],
        default: []
    },
    productSearchText: {
        type: [String],
        default: []
    },
    unSuccessfulSearch: {
        type: Number,
        default: 0
    },
    screenStatus: {
        type: Number,
        default: 2
    },
    isDeleted: {
        enum: [0, 1],
        type: Number,
        default: 0,
        comment: '0 = not deleted, 1= deleted',
    },
    deleteReason: {
        type: String,
    }
}, { timestamps: true });

clientSchema.set('toObject', { virtuals: true })
clientSchema.set('toJSON', { virtuals: true })

clientSchema.virtual('profileImgPath').get(function () {
    return this.profileImage;
});
module.exports = mongoose.model("Client", clientSchema);