const mongoose = require("mongoose");

const beauticianSchema = mongoose.Schema({
    userId: {
        type: mongoose.Schema.ObjectId,
        ref: "User",
        unique: true,
        require: [true, "UserId is Required"]
    },
    uid: {
        type: String,
        unique: true
    },
    firstName: {
        type: String,
        required: [true, "FirstName is Required"]
    },
    lastName: {
        type: String,
        required: [true, "LastName is Required"]
    },
    logo: {
        type: String,
    },
    profileImage: {
        type: String,
    },
    workSpaceImgs: {
        type: [String],
        default: []
    },
    businessName: {
        type: String,
    },
    businessNumber: {
        type: Number,
    },
    country: {
        type: String,
    },
    country_code: {
        type: String,
    },
    gender: {
        type: String,
    },
    DOB: {
        type: Date
    },
    beauticianServiceId: [{
        type: mongoose.Schema.ObjectId,
        ref: "BeauticianService",
    }],
    address: {
        type: mongoose.Schema.ObjectId,
        ref: "Address",
    },
    location: {
        type: {
            type: String,
            enum: ['Point']
        },
        coordinates: {
            type: [Number]
        }
    },
    isProvideService: {
        enum: [0, 1],
        type: Number,
        default: 0,
        comment: '0 = provided, 1= notProvided',
    },
    isProvideProduct: {
        enum: [0, 1],
        type: Number,
        default: 0,
        comment: '0 = provided, 1= notProvided',
    },
    isRecommended: {
        enum: [0, 1],
        type: Number,
        default: 0,
        comment: '0 = no, 1= yes',
    },
    subscriptionPlanType: {
        type: mongoose.Schema.ObjectId,
        ref: "Package",
    },
    totalEmployee: {
        type: Number,
        default: 0
    },
    demographicIds: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Demography'
    }],
    amenityIds: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Amenities'
    }],
    healthSafety: {
        detailForClient: {
            type: String
        },
        healthId: [{
            type: mongoose.Schema.Types.ObjectId,
            ref: 'HealthSafety'
        }]
    },
    taxProvinceDetails: {
        provinceID: {
            type: mongoose.Schema.ObjectId,
            ref: "Province"
        },
        isProvinceTaxInfo: {
            type: Boolean
        },
        totalTax: { type: Number },
        GSTNumber: { type: String },
        PSTNumber: { type: String },
        HSTNumber: { type: String },
        QSTNumber: { type: String }
    },
    hasShop: {
        enum: [0, 1],
        type: Number,
        default: 0,
        comment: '0 = Independent, 1= has salon ',
    },
    isLicensed: {
        enum: [0, 1],
        type: Number,
        default: 0,
        comment: '0 = not licensed beautician, 1= licensed beautician',

    },
    licenseImage: {
        type: String,
    },
    IsServeAtClient: {
        enum: [0, 1],
        type: Number,
        default: 0,
        comment: '0 = not serve at Client`s place, 1= serve at Client`s place',
    },
    IsServeAtOwnPlace: {
        enum: [0, 1],
        type: Number,
        default: 1,
        comment: '0 = not serve at beautician`s place, 1= serve at beautician`s place',
    },
    rating: {
        type: Number,
    },
    noOfReviews: {
        type: Number,
    },
    screenStatus: {
        type: Number,
        default: 2
    },
    stripe_id: {
        type: String
    },
    facebookUrl: {
        type: String
    },
    instagramUrl: {
        type: String
    },
    website: {
        type: String
    },
    description: {
        type: String
    },
    calenderSetting: {
        formate: {
            type: Number,
            enum: [12, 24],
            comment: '12 = 12 hour formate, 24= 24 hours formate',
        },
        startDay: {
            type: String,
            enum: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        }
    },
    language: {
        type: String
    },
    noShowProtection: {
        type: Number,
        enum: [1, 2, 3, 4],
        default: 4,
        comment: "1 = None :  reschedule , 2=Relax: 70% refund , 3 = Strict : 20% refund , 4 = very strict: no refund ,no reschedule"
    },
    cancelProtection: {
        type: Number,
        enum: [1, 2, 3, 4],
        default: 1,
        comment: "1 = Free :full refund , 2=flexible:full refund  & before 7 to 24 hours , 3 = Strict : 50% refund & before 10 to 24 hours , 4 = very strict: no refund if cancel less than 10 hours"
    },
    nubOfShareClicked: {
        type: Number,
        default: 0,
    },
    isDeleted: {
        enum: [0, 1],
        type: Number,
        default: 0,
        comment: '0 = notDeleted, 1= deleted',
    },
}, { timestamps: true });

// beauticianSchema.plugin(mongoosePaginate);
beauticianSchema.index({ location: "2dsphere" });

beauticianSchema.set('toObject', { virtuals: true })
beauticianSchema.set('toJSON', { virtuals: true })

beauticianSchema.virtual('logoPath').get(function () {
    return this.logo;
});

beauticianSchema.virtual('profileImgPath').get(function () {
    return this.profileImage;
});
beauticianSchema.virtual('licenseImagePath').get(function () {
    return this.licenseImage;
});
beauticianSchema.virtual('workSpaceImgPaths').get(function () {
    return this.workSpaceImgs;
});

module.exports = mongoose.model("Beautician", beauticianSchema);