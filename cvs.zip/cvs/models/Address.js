const mongoose = require("mongoose");

const addressSchema = mongoose.Schema({
    address: {
        type: String,
    },
    province: {
        type: mongoose.Schema.ObjectId,
        ref: "Province",
    },
    street: {
        type: String,
    },
    apartment: {
        type: String,
    },
    city: {
        type: String,
    },
    zipCode: {
        type: String,
    },
    location: {
        type: {
            type: String,
            enum: ['Point']
        },
        coordinates: {
            type: [Number]
        }
    }
}, { timestamps: true });

addressSchema.set('toObject', { virtuals: true });
addressSchema.set('toJSON', { virtuals: true });
addressSchema.index({ location: "2dsphere" });

addressSchema.virtual('provinceName', {
    ref: 'Province',
    localField: 'province',
    foreignField: '_id',
    justOne: true,
});

module.exports = mongoose.model("Address", addressSchema);