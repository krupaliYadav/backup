const mongoose = require("mongoose");

const orderSchema = mongoose.Schema({
    BookingId: {
        type: String,
        unique: true,
        require: [true, "BookingId is required."]
    },
    clientId: {
        type: mongoose.Schema.ObjectId,
        ref: "Client",
        require: [true, "ClientId is Required"]
    },
    productData: [
        {
            productId: {
                type: mongoose.Schema.ObjectId,
                ref: "BeauticianProduct",
            },
            price: {
                type: Number,
                ref: "BeauticianProduct",
            },
        }
    ],
    cardId: {
        type: mongoose.Schema.ObjectId,
        ref: "Card",
        require: [true, "payment method Id is Required"]
    },
    transactionId: {
        type: String,
        require: [true, "transaction Id is Required"]
    },
    shippingAddressId: {
        type: mongoose.Schema.ObjectId,
        ref: "Address",
    },
    billingAddressId: {
        type: mongoose.Schema.ObjectId,
        ref: "Address",
    },
    subTotal: {
        type: Number,
    },
    GST: {
        type: Number,
        default: 0
    },
    PST: {
        type: Number,
        default: 0
    },
    HST: {
        type: Number,
        default: 0
    },
    QST: {
        type: Number,
        default: 0
    },
    GstInPer: {
        type: Number,
        default: 0
    },
    PstInPer: {
        type: Number,
        default: 0
    },
    HstInPer: {
        type: Number,
        default: 0
    },
    QstInPer: {
        type: Number,
        default: 0
    },
    subTotal: {
        type: Number,
    },
    // discount: {
    //     type: Number,
    //     default: 0,
    //     comment: " in percentage"
    // },
    total: {
        type: Number,
    },
    orderStatus: {
        enum: [0, 1, 2],
        type: Number,
        default: 0,
        comment: '0 = pending, 1 = delivered, 2 = cancelled',
    },
    paymentStatus: {
        enum: [0, 1, 2],
        type: Number,
        default: 0,
        comment: '0 = pending, 1 = confirmed, 2 = failed',
    }
}, { timestamps: true });

module.exports = mongoose.model("Order", orderSchema);