const mongoose = require("mongoose");

const helpContactListSchema = mongoose.Schema({
    memberId: {
        type: mongoose.Schema.ObjectId,
        refPath: 'member_type',
    },
    member_type: {
        type: String,
        enum: ["Client", "Beautician"],
        required: true
    },
    status: {
        enum: [0, 1],
        type: Number,
        default: 1,
        comment: '0 = deleted, 1= active',
    }
}, { timestamps: true });

module.exports = mongoose.model("HelpContactList", helpContactListSchema);