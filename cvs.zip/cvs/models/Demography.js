const mongoose = require("mongoose");

const demographySchema = mongoose.Schema({
    demographyName:{
        type:String,
        unique : true,
        required:[true,"Service category name is Required"]
    },
    status:{
        enum:[0,1],
        type:Number,
        default:1,
        comment: '0 = deactive, 1= active',
    }
},{timestamps:true})

module.exports = mongoose.model("Demography",demographySchema);