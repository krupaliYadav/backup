require("dotenv").config()
const express = require("express")
const app = express()
const port = process.env.PORT || 3000
app.use(express.json())
var http = require('http').Server(app);
const io = require("socket.io")(http)

app.get("/", (req, res) => {
    res.sendFile(__dirname + "/index.html")
})


// socket emit and on from sever side and client side
// io.on("connection", function (socket) {
//     console.log("Socket is connected");

//     setTimeout(function () {
//         // event send to client side
//         socket.emit("message", { data: 'Sent a message 4seconds after connection!' });
//     }, 4000);

//     socket.on("clientEvent", (data) => {
//         // catch event from client side
//         console.log(data);
//     })

//     socket.on("disconnect", function () {
//         console.log("Socket disconnected");
//     })
// })

// ===================================================================================================================
// io.sockets.emit ==> broadcasting for all connected client 
// let client = 0
// io.on("connection", function (socket) {
//     client++
//     io.sockets.emit("broadcast", { description: client + "connected clients......!" })

//     socket.on("disconnect", function () {
//         client--
//         io.sockets.emit("broadcast", { description: client + "connected clients......!" })
//     })
// })

// ===================================================================================================================
// socket.broadcast.emit
// let client = 0
// io.on("connection", function (socket) {
//     client++
//     socket.emit('newClientConnect', { description: 'Hey, welcome!' });
//     socket.broadcast.emit("newClientConnect", { description: client + "connected clients......!" })

//     socket.on("disconnect", function () {
//         client--
//         socket.broadcast.emit("newClientConnect", { description: client + "connected clients......!" })
//     })
// })

// ===================================================================================================================
// namespace
// let nsp = io.of("/namespace")
// nsp.on("connection", function (socket) {
//     console.log("client connected");
//     nsp.emit('newClientConnect', { description: 'Hey, welcome!' });
// })

// ===============================================================================================================
// ROOM   => io.sockets.in
let roomNo = 1;
io.on('connection', function (socket) {
    socket.join("room-" + roomNo);
    io.sockets.in("room-" + roomNo).emit('connectToRoom', "You are in room no. " + roomNo);
})




http.listen(port, () => {
    console.log(`Server is running on ${port}`);
})