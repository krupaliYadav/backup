const mongoose = require("mongoose")
const { Schema } = mongoose
const messageSchema = new Schema({
    message: {
        type: String,
        required: true
    },
    groupId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Group"
    }
}, { timestamps: true })

const userSchema = new Schema({
    name: {
        type: String,
        required: [true, "Name is required.."]
    },
    joinAt: {
        type: String
    },
    exitAt: {
        type: String
    },
    message: {
        type: [messageSchema]
    }
}, {
    timestamps: true
})

module.exports = mongoose.model("User", userSchema)