const jwt = require("jsonwebtoken")
const User = require("../model/user")

exports.auth = async (token) => {
    try {
        if (!token) {
            return { error: "Token is required.....!!!" }
        }

        const decode = jwt.verify(token, process.env.KEY)
        if (!decode) {
            return { error: "Unauthorized...." }
        }

        const user = await User.findById(decode._id)
        user.token = token
        return user

    } catch (error) {
        if (error.name === "TokenExpiredError") {
            return { error: "Token has expired." };
        } else {
            return { error: "Unauthorized." };
        }
    }
    authentication
}