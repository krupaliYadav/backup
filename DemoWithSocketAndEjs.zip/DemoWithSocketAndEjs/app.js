require("dotenv").config()
const express = require("express")
require("./config/database")
const path = require("path")
const app = express()
const port = process.env.PORT || 3000
const http = require("http")
const socketServer = require('./config/socket');
const server = http.createServer(app);
const routes = require("./routes/index")

// path to public folder
app.use(express.static(path.join(__dirname + "/public")))
app.use(routes)
// set view engine 
app.set("view engine", "ejs")
app.get('/', function (req, res) {
    res.render("index")
});

app.get('/chat', function (req, res) {
    res.render("existingChat")
});

socketServer(server)
server.listen(port, () => {
    console.log(`Server is running on ${port}`);
})
