document.addEventListener('DOMContentLoaded', function () {
    const app = document.querySelector(".app")
    const socket = io()
    let uname;
    let gname;


    app.querySelector(".joinPage #join").addEventListener("click", () => {

        let userName = app.querySelector(".joinPage #userName").value
        let groupName = app.querySelector(".joinPage #groupName").value
        if (userName.length === 0) {
            return
        }
        uname = userName
        gname = groupName
        localStorage.setItem("userName", userName);
        localStorage.setItem("groupName", groupName);

        // login and add user if user is not exist
        socket.emit("addAndLoginUser", groupName, userName)

        // store token in localStorage
        socket.on("token", (data) => {
            localStorage.setItem("token", data)
            let chatToken = localStorage.getItem("token");
            socket.emit("checkAuth", chatToken, userName)
        })


        socket.on("auth", (data) => {
            if (data.error) {
                app.querySelector("#error-container").innerHTML = `<p>${data.error} </p>`;
            } else {
                app.querySelector(".joinPage").classList.remove("active")
                app.querySelector(".chat-room").classList.add("active")
                socket.emit("getMessages", groupName)
            }
        })
    })

    app.querySelector(".chat-room #send-message").addEventListener("click", () => {
        let message = app.querySelector(".chat-room #message-input").value
        if (message.length === 0) {
            return
        }
        renderMessage("my", {
            userName: uname,
            text: message
        })
        socket.emit("chat", {
            groupName: gname,
            userName: uname,
            text: message
        })
        app.querySelector(".chat-room #message-input").value = ""

    })
    window.addEventListener('load', (event) => {
        let chatToken = localStorage.getItem("token");
        uname = localStorage.getItem("userName")
        gname = localStorage.getItem("groupName");

        if (chatToken === null && uname === null && gname === null) {
            app.querySelector(".chat-room").classList.remove("active");
            app.querySelector(".joinPage").classList.add("active")
        } else {
            app.querySelector(".joinPage").classList.remove("active")
            app.querySelector(".chat-room").classList.add("active");
            socket.emit("getMessages", gname)
        }
    });
    app.querySelector(".chat-room #exitChatRoom").addEventListener("click", function () {
        socket.emit("ExistUser", uname)
        localStorage.removeItem("token");
        localStorage.removeItem("groupName");
        localStorage.removeItem("userName");
        window.location.href = window.location.href
    })



    socket.on("update", function (update) {
        renderMessage("update", update)
    })

    socket.on("chat", function (data) {
        console.log(data.groupInfo.name === gname);
        if (data.groupInfo.name === gname) {
            renderMessage("other", data.message)
        }

    })
    socket.on("message", function (data) {
        renderExistingMessage(data)
    })
    function renderExistingMessage(data) {
        uname = uname.charAt(0).toUpperCase() + uname.slice(1)
        let messageContainer = app.querySelector(".chat-room .messages");

        if (data !== undefined) {
            data.forEach(message => {
                const isMyMessage = message.userName === (uname);
                const name = isMyMessage ? 'You' : message.userName;

                let el = document.createElement("div");
                el.setAttribute("class", `message ${isMyMessage ? 'my-message' : 'other-message'}`);
                el.innerHTML = `
                    <div>
                        <div class="name"><b>${name}</b></div>
                        <div class="text">${message.message}</div>
                    </div>
                `;
                messageContainer.appendChild(el);
            });
        }
    }

    function renderMessage(type, message) {
        let messageContainer = app.querySelector(".chat-room .messages")
        if (type === "my") {
            let el = document.createElement("div")
            el.setAttribute("class", "message my-message")
            el.innerHTML = `
            <div>
            <div class="name"><b>You</b></div>
            <div class="text">${message.text}</div>
            </div>
            `
            messageContainer.appendChild(el)
        } else if (type === "other") {
            let el = document.createElement("div")
            el.setAttribute("class", "message other-message")
            el.innerHTML = `
            <div>
            <div class="name"><b>${message.userName}</b>  </div>
            <div class="text">${message.text}</div>
            </div>
            `
            messageContainer.appendChild(el)
        } else if (type === "update") {
            let el = document.createElement("div")
            el.setAttribute("class", "update")
            el.innerText = message
            messageContainer.appendChild(el)
        }
        messageContainer.scrollTop = messageContainer.scrollHeight - messageContainer.clientHeight

    }
});
