const Group = require("../model/groupModel")

exports.addGroup = async (groupName) => {
    try {
        let name = groupName
        const group = await Group.findOne({ name: name })
        if (group) {
            return group
        } else {
            data = await Group.create({ name: name })
            return data
        }
    } catch (err) {
        console.log("ERROR: ", err);
    }
}

// exports.getGroupInfo = async (name) => {
//     try {
//         const group = await Group.findOne({ name: name })
//         console.log(group);
//     } catch (err) {
//         console.log("ERROR: ", err);
//     }
// }

// exports.exitUser = async (userName) => {
//     try {
//         let name = userName.charAt(0).toUpperCase() + userName.slice(1)
//         const user = await User.findOne({ name: name })
//         if (user) {
//             let setData = {
//                 exitAt: date
//             }
//             await User.findByIdAndUpdate({ _id: user._id }, setData)
//         }
//     } catch (err) {
//         console.log("ERROR: ", err);
//     }
// }

// exports.listing = async (req, res) => {
//     try {
//         const query = {}
//         if (req.query.search) {
//             query.name = { $regex: req.query.search, $options: "i" }
//         }
//         if (req.query.date) {
//             query.joinAt = { $gte: req.query.date }
//         }
//         const user = await User.find(query)
//         if (user.length <= 0) {
//             return res.status(400).json({ error: true, message: "No data for display.." })
//         }
//         res.status(200).json({ error: false, message: "User Listing load successfully...", user })
//     } catch (err) {
//         console.log("ERROR: ", err);
//     }
// }

// exports.getUser = async (req, res) => {
//     try {
//         const user = await User.findOne({ _id: req.params.id })
//         if (!user) {
//             return res.status(400).json({ error: true, message: "No data for display.." })
//         }
//         res.status(200).json({ error: false, message: "User details load successfully...", user })
//     } catch (err) {
//         console.log("ERROR: ", err);
//     }
// }

// exports.getExistingChat = async (userName) => {
//     try {
//         let name = userName.charAt(0).toUpperCase() + userName.slice(1)
//         const user = await User.findOne({ name: name })
//         if (!user) {
//             return "No data for display.."
//         }
//         return user
//     } catch (err) {
//         console.log("ERROR: ", err);
//     }
// }