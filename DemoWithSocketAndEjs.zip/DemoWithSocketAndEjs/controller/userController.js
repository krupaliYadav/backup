const User = require("../model/user")
const Group = require("../model/groupModel")
const jwt = require("jsonwebtoken")
const currentDate = new Date();
const date = currentDate.toLocaleString();


exports.addUser = async (userName) => {
    try {
        let name = userName.charAt(0).toUpperCase() + userName.slice(1)
        const user = await User.findOne({ name: name })
        if (user) {
            let setData = {
                joinAt: date
            }
            data = await User.findByIdAndUpdate({ _id: user._id }, setData)
        } else {
            setData = {
                name: name,
                joinAt: date
            }
            data = await User.create(setData)
        }

        let token = jwt.sign({ _id: data._id }, process.env.KEY, { expiresIn: '1m' })
        return token


    } catch (err) {
        console.log("ERROR: ", err);
    }
}

exports.addMessage = async (message) => {
    try {
        let name = message.userName.charAt(0).toUpperCase() + message.userName.slice(1)
        const group = await Group.findOne({ name: message?.groupName })
        const user = await User.findOne({ name: name })
        if (user) {
            let setData = {
                message: message.text,
                groupId: group?._id
            }
            user.message.push(setData)
            user.save()
        }
        return group
    } catch (err) {
        console.log("ERROR: ", err);
    }
}

exports.exitUser = async (userName) => {
    try {
        let name = userName.charAt(0).toUpperCase() + userName.slice(1)
        const user = await User.findOne({ name: name })
        if (user) {
            let setData = {
                exitAt: date
            }
            await User.findByIdAndUpdate({ _id: user._id }, setData)
        }
    } catch (err) {
        console.log("ERROR: ", err);
    }
}

exports.listing = async (req, res) => {
    try {
        const query = {}
        if (req.query.search) {
            query.name = { $regex: req.query.search, $options: "i" }
        }
        if (req.query.date) {
            query.joinAt = { $gte: req.query.date }
        }
        const user = await User.find(query)
        if (user.length <= 0) {
            return res.status(400).json({ error: true, message: "No data for display.." })
        }
        res.status(200).json({ error: false, message: "User Listing load successfully...", user })
    } catch (err) {
        console.log("ERROR: ", err);
    }
}

exports.getUser = async (req, res) => {
    try {
        const user = await User.findOne({ _id: req.params.id })
        if (!user) {
            return res.status(400).json({ error: true, message: "No data for display.." })
        }
        res.status(200).json({ error: false, message: "User details load successfully...", user })
    } catch (err) {
        console.log("ERROR: ", err);
    }
}

exports.getExistingChat = async (groupName) => {
    try {
        const group = await Group.findOne({ name: groupName })
        let messages = []
        const groupMessage = await User.aggregate([
            {
                $match: {
                    'message.groupId': group._id
                }
            },
            {
                $addFields: {
                    messagesInGroup: {
                        $filter: {
                            input: '$message',
                            as: 'msg',
                            cond: { $eq: ['$$msg.groupId', group._id] }
                        }
                    }
                }
            },

        ]);

        if (groupMessage !== undefined) {
            groupMessage.forEach(user => {
                user.messagesInGroup.map(u => {
                    u.userName = user.name
                })
                messages.push(user.messagesInGroup)
                messages = messages.flat().sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))
            });
        }
        return messages

    } catch (err) {
        console.log("ERROR: ", err);
    }
}

