const socketIO = require('socket.io');
const userController = require("../controller/userController")
const groupController = require("../controller/groupController")
const auth = require("../middleware/auth")

module.exports = (server) => {
    const io = socketIO(server);

    io.on('connection', (socket) => {
        socket.on("newUser", (userName) => {
            userController.addUser(userName)
            socket.broadcast.emit("update", userName + " Joined the conversation")
        })
        socket.on("ExistUser", (userName) => {
            userController.exitUser(userName)
            socket.broadcast.emit("update", userName + " Left the conversation")
        })
        socket.on("chat", async (message) => {
            const groupInfo = await userController.addMessage(message)
            socket.broadcast.emit("chat", { message: message, groupInfo: groupInfo })
        })

        socket.on("addAndLoginUser", async (userName) => {
            const token = await userController.addUser(userName)
            socket.emit("token", token)
        })

        socket.on("checkAuth", async (chatToken) => {
            const authentication = await auth.auth(chatToken)
            socket.emit("auth", authentication)
        })

        socket.on("getMessages", async (groupName) => {
            await groupController.addGroup(groupName)
            const data = await userController.getExistingChat(groupName)
            socket.emit("message", data.map(e => { return e }))
        })

    });
};
