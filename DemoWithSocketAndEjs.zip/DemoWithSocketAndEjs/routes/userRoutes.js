const express = require("express")
const routes = express.Router()
const controller = require("../controller/userController")

routes
    .get("/", controller.listing)
    .get("/:id", controller.getUser)
module.exports = routes