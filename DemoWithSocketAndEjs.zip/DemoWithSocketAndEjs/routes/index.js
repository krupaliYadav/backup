const express = require("express")
const routes = express.Router()
const userRoutes = require("./userRoutes")

routes
    .use("/api/v1/users", userRoutes)
module.exports = routes