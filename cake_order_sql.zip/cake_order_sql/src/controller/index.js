//user
module.exports.userAuthController = require("./User/auth");
module.exports.userProfileController = require("./User/profileController");
module.exports.userCategoryController = require("./User/category");
module.exports.userCakeController = require("./User/cake");
module.exports.userOrderController = require("./User/order");

// admin
module.exports.adminAuthController = require("./admin/auth");
module.exports.adminOptionController = require("./admin/optionsController");
module.exports.adminCakeController = require("./admin/cakeController");
module.exports.adminOrderController = require("./admin/order");
module.exports.adminUserController = require("./admin/user");
