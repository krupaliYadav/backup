const Category = require("../../models/category")
const Variant = require("../../models/variants")
const Cake = require("../../models/cake")
const CakeVariant = require("../../models/cakeVariants")
const CakeImages = require("../../models/cakeImage")
const formidable = require("formidable")
const { HTTP_STATUS_CODE, IMAGE_PATH } = require("../../helper/constants.helper")
const { BadRequestException } = require("../../common/exceptions/index")
const { fileUpload, deleteFile } = require("../../helper/fileUpload")
const { addCakeValidation } = require("../../common/validation")
const Op = require("sequelize").Op;

const addCake = async (req, res) => {
    let form = formidable({ multiples: true })
    form.parse(req, async (err, fields, files) => {
        let { category_id, name, price, description, variant, is_custom } = fields
        let imgData = []
        let prices = []
        // validation
        const validation = addCakeValidation.filter(field => !fields[field]);
        if (validation.length > 0) {
            return res.status(HTTP_STATUS_CODE.BAD_REQUEST).json({ status: HTTP_STATUS_CODE.BAD_REQUEST, success: false, message: `The ${validation.join(', ')} is required.` })
        }

        // check category exits or not
        const isCategoryExits = await Category.findOne({ where: { id: category_id, is_deleted: '0', is_active: '1' } })
        if (!isCategoryExits) return res.status(HTTP_STATUS_CODE.BAD_REQUEST).json({ status: HTTP_STATUS_CODE.BAD_REQUEST, success: true, message: "Category not exits." })

        if (files.image) {
            files.image = Array.isArray(files.image) ? files.image : [files.image];
            const imgDataPromises = files.image.map(async newImg => {
                const result = await fileUpload(newImg, ["jpeg", "png", "jpg"], "cake")
                return result
            });
            imgData = await Promise.all(imgDataPromises);
            imgData.map(img => {
                if (img.success === false) return res.status(img.status).json(img)
            })
        } else {
            return res.status(HTTP_STATUS_CODE.BAD_REQUEST).json({ status: HTTP_STATUS_CODE.BAD_REQUEST, success: true, message: "Cake image is required." })
        }

        if (variant) {
            for (const val of variant) {
                const isVariantExists = await Variant.findOne({ where: { id: val.variant_id, is_deleted: '0', is_active: '1' } });
                if (!isVariantExists) {
                    return res.status(HTTP_STATUS_CODE.BAD_REQUEST).json({ status: HTTP_STATUS_CODE.BAD_REQUEST, success: false, message: "Cake variant id does not exists." });
                }
                prices.push(val.price);
            }
            price = Math.min(...prices);

        }

        const cake = await Cake.create({ category_id: category_id, name: name, price: price, description: description, is_custom: is_custom || '0' })
        if (cake) {
            const data = imgData.map((val) => {
                return { cake_id: cake.id, images_path: val }
            })
            variant.map(val => val.cake_id = cake.id)
            await CakeImages.bulkCreate(data)
            await CakeVariant.bulkCreate(variant)
        }
        return res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "Cake added successfully." })
    })
}

const getCakeList = async (req, res) => {
    const { search, cake_id } = req.query
    let where = { is_deleted: '0' }
    if (search) {
        where[Op.or] = [
            { name: { [Op.like]: `%${search}%` } },
            sequelize.where(sequelize.col('category.name'), 'LIKE', `%${search}%`)
        ];
    }
    if (cake_id) {
        where = { ...where, id: cake_id }
    }
    let data = await Cake.findAll({
        where: where,
        attributes: ['id', 'name', 'price', 'description', 'is_custom', 'is_active'],
        include: [
            {
                model: Category,
                attributes: ['id', 'name']
            },
            {
                model: Variant,
                attributes: ['id', 'name'],
                through: {
                    model: CakeVariant,
                    attributes: ['price'],
                },
            },
            {
                model: CakeImages,
                attributes: ['images_path', 'id'],
            },
        ],
        order: [['created_at', 'DESC']]
    })
    if (data.length > 0) {
        data = data.map(item => {
            const plainData = item.get({ plain: true })
            const variantDetails = plainData.variants.map((val) => {
                const valData = {}
                valData.variant_id = val.id,
                    valData.variant_name = val.name
                valData.variant_price = val.CakeVariants.price
                return valData
            })
            const imageData = plainData.cakeimages.map((img) => {
                return { imgPath: `${IMAGE_PATH.CAKE_IMAGE_URL}${img.images_path}`, id: img.id }
            })

            delete plainData.variants
            delete plainData.cakeimages
            return {
                ...plainData,
                imageData,
                variantDetails
            };
        });
    }
    const filterCount = data.length
    return res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "Cake list loaded successfully.", data: { filterCount, data } })

}

const updateCake = async (req, res) => {
    const cakeId = req.params.cake_id
    let form = formidable({ multiples: true })
    form.parse(req, async (err, fields, files) => {
        let { category_id, name, price, description, variant, is_custom } = fields
        let imgData = []
        let prices = []

        // check category exits or not
        if (category_id) {
            const isCategoryExits = await Category.findOne({ where: { id: category_id, is_deleted: '0', is_active: '1' } })
            if (!isCategoryExits) {
                return res.status(HTTP_STATUS_CODE.BAD_REQUEST).json({ status: HTTP_STATUS_CODE.BAD_REQUEST, success: true, message: "Category not exits." })
            } else {
                fields.category_id = category_id
            }
        }

        if (files.image) {
            files.image = Array.isArray(files.image) ? files.image : [files.image];
            const imgDataPromises = files.image.map(async newImg => {
                const result = await fileUpload(newImg, ["jpeg", "png", "jpg"], "cake")
                return result
            });
            imgData = await Promise.all(imgDataPromises);
            const image = imgData.map(img => {
                if (img.success === false) {
                    return res.status(img.status).json(img)
                } else {
                    return { cake_id: cakeId, images_path: img }
                }
            })
            await CakeImages.bulkCreate(image)
        }

        if (variant) {
            for (const val of variant) {
                const isVariantExists = await Variant.findOne({ where: { id: val.variant_id, is_deleted: '0', is_active: '1' } });
                if (!isVariantExists) {
                    return res.status(HTTP_STATUS_CODE.BAD_REQUEST).json({ status: HTTP_STATUS_CODE.BAD_REQUEST, success: false, message: "Cake variant id does not exists." });
                } else {
                    await CakeVariant.destroy({ where: { cake_id: cakeId } })
                }
                prices.push(val.price);
            }
            price = Math.min(...prices);
            variant.map(val => val.cake_id = cakeId)
            await CakeVariant.bulkCreate(variant)
        }

        await Cake.update(fields, { where: { id: cakeId } })
        return res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "Cake updated successfully." })
    })
}

const deleteSingleImg = async (req, res) => {
    let cakeId = req.params.cake_id
    const { imageId } = req.body
    const cakeImage = await CakeImages.findOne({ where: { cake_id: cakeId, id: imageId } })
    if (cakeImage) {
        await CakeImages.destroy({ where: { cake_id: cakeId, id: imageId } })
        await deleteFile('cake', cakeImage.images_path)
        res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "Cake image removed successfully." })
    } else {
        throw new BadRequestException("Cake image details not found.")
    }
}

const deleteCake = async (req, res) => {
    let cakeId = req.params.cake_id
    const cakeData = await Cake.findOne({ where: { id: cakeId } })
    if (cakeData) {
        await Cake.update({ is_deleted: '1' }, { where: { id: cakeId } })
        await CakeImages.update({ is_deleted: '1' }, { where: { cake_id: cakeId } })
        await CakeVariant.update({ is_deleted: '1' }, { where: { cake_id: cakeId } })
        res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "Cake deleted successfully." })
    } else {
        throw new BadRequestException("Cake details not found.")
    }
}

const changeCakeStatus = async (req, res) => {
    const cakeId = req.params.cake_id
    const { status } = req.body
    if (!status) throw new BadRequestException("Cake status is required.")
    const cake = await Cake.findOne({ where: { id: cakeId } });
    if (!cake) {
        throw new BadRequestException("Cake details not found.")
    } else {
        await Cake.update({ is_active: status }, { where: { id: cakeId } });
        res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "Cake status updated successfully." })
    }
}
module.exports = {
    addCake,
    getCakeList,
    updateCake,
    deleteSingleImg,
    deleteCake,
    changeCakeStatus
}