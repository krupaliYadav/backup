const Admin = require("../../models/admin")
const bcrypt = require("bcrypt")
const jwt = require("jsonwebtoken")
const { HTTP_STATUS_CODE } = require("../../helper/constants.helper")
const { BadRequestException } = require("../../common/exceptions/index")

const adminRegister = async (req, res) => {
    let { name, email, password, phoneNumber, address } = req.body
    const admin = await Admin.findOne({ where: { email: email } })
    if (admin) throw new BadRequestException("Email is already exits.")
    password = bcrypt.hashSync(password, 10)

    await Admin.create({ name, email, password, phoneNumber, address })
    res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "User registered successfully." })
}

const adminLogin = async (req, res) => {
    let { email, password } = req.body
    const admin = await Admin.findOne({ where: { email: email } })

    if (!admin || !bcrypt.compareSync(password, admin?.password)) throw new BadRequestException("Invalid email or password.")

    const token = jwt.sign({ id: admin.id }, process.env.JWT_SEC, { expiresIn: process.env.JWT_EXPIRES })
    res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "Logged in successfully.", data: { adminId: admin.id, token } })
}

const getProfile = async (req, res) => {
    const adminId = req.admin
    const data = await Admin.findByPk(adminId, {
        attributes: { exclude: ['password', 'created_at', 'updated_at'] }
    })
    res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "Admin details loaded successfully.", data })
}


const editProfile = async (req, res) => {
    const adminId = req.admin
    const { password } = req.body
    if (password) {
        req.body.password = bcrypt.hashSync(password, 10)
    }
    await Admin.update(req.body, { where: { id: adminId } })
    res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "Admin details updated successfully." })
}
module.exports = {
    adminRegister,
    adminLogin,
    getProfile,
    editProfile
}