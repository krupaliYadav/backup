const Users = require("../../models/userModel")
const { BadRequestException } = require("../../common/exceptions/index")
const { HTTP_STATUS_CODE, IMAGE_PATH } = require("../../helper/constants.helper")

const getAllUsers = async (req, res) => {
    let data = await Users.scope('checkDeleteStatus').findAll({ attributes: { exclude: ['updated_at', 'created_at', 'is_deleted', 'remember_token', 'reset_password_token', 'email_verified_at', 'firebase_token', 'device_token', 'password'] } })
    if (data.length > 0) {
        data = data.map(item => {
            const plainData = item.get({ plain: true })
            plainData.image = `${IMAGE_PATH.PROFILE_IMAGE_URL}${plainData.image}`
            return plainData
        });
    }
    const totalCount = data.length
    return res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "User details loaded successfully.", data: { totalCount, data } })
}

module.exports = {
    getAllUsers
}