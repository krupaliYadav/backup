const Cake = require("../../models/cake")
const User = require("../../models/userModel")
const CakeImages = require("../../models/cakeImage")
const { HTTP_STATUS_CODE, IMAGE_PATH } = require("../../helper/constants.helper")
const Address = require("../../models/address")
const Order = require("../../models/order")
const { BadRequestException } = require("../../common/exceptions/index")


const getAllOrderList = async (req, res) => {
    let data = await Order.findAll({
        include: [
            {
                model: User,
                attributes: ['id', 'first_name', 'last_name', 'email']
            },
            {
                model: Cake,
                attributes: ['id', 'name', 'price', 'description'],
                include: [
                    {
                        model: CakeImages,
                        attributes: ['id', 'images_path'],
                    },
                ],
            },
            {
                model: Address,
                attributes: ['id', 'address']
            },
        ],
        attributes: { exclude: ['cake_id', 'address_id', 'is_deleted', 'created_at', 'updated_at', 'user_id'] }
    })

    if (data.length > 0) {
        data = data.map(item => {
            const plainData = item.get({ plain: true })
            plainData.cake.cakeimages = plainData.cake.cakeimages.map((image) => {
                image.images_path = `${IMAGE_PATH.CAKE_IMAGE_URL}${image.images_path}`;
                return image;
            })
            if (plainData.custom_cake_image !== null) {
                plainData.custom_cake_image = `${IMAGE_PATH.CUSTOM_IMAGE_URL}${plainData?.custom_cake_image}`
            }
            return plainData
        });
    }
    return res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "Order details loaded successfully.", data })
}

const changeOrderStatus = async (req, res) => {
    const orderId = req.params.order_id
    const { status } = req.body
    if (!status) throw new BadRequestException("Order status is required.")
    if (!['0', '1', '2', '3', '4'].includes(status)) {
        throw new BadRequestException('Invalid status value.')
    }
    const order = await Order.findOne({ where: { id: orderId } });
    if (!order) {
        throw new BadRequestException("Order details not found.")
    } else {
        await Order.update({ status: status }, { where: { id: orderId } });
        res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "Order status updated successfully." })
    }
}
module.exports = {
    getAllOrderList,
    changeOrderStatus
}
