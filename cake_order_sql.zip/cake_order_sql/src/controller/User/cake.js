const Category = require("../../models/category")
const Variant = require("../../models/variants")
const Cake = require("../../models/cake")
const CakeVariant = require("../../models/cakeVariants")
const CakeImages = require("../../models/cakeImage")
const Rate = require("../../models/rate")
const { HTTP_STATUS_CODE, IMAGE_PATH } = require("../../helper/constants.helper")
const { BadRequestException } = require("../../common/exceptions")

const getCakes = async (req, res) => {
    const { category_id, cake_id } = req.query
    let where = { is_deleted: '0', is_active: '1' }
    if (category_id) {
        where = { ...where, category_id: category_id }
    }

    if (cake_id) {
        where = { ...where, id: cake_id }
    }
    let data = await Cake.findAll({
        where: where,
        attributes: ['id', 'name', 'price', 'description', 'is_custom', 'is_active', 'rating', 'noOfReview'],
        include: [
            {
                model: Category,
                attributes: ['id', 'name']
            },
            {
                model: Variant,
                attributes: ['id', 'name'],
                through: {
                    model: CakeVariant,
                    attributes: ['price'],
                },
            },
            {
                model: CakeImages,
                attributes: ['images_path', 'id'],
            },
        ],
        order: [['created_at', 'DESC']]
    })
    if (data.length > 0) {
        data = data.map(item => {
            const plainData = item.get({ plain: true })
            const variantDetails = plainData.variants.map((val) => {
                const valData = {}
                valData.variant_id = val.id,
                    valData.variant_name = val.name
                valData.variant_price = val.CakeVariants.price
                return valData
            })
            const imageData = plainData.cakeimages.map((img) => {
                return { imgPath: `${IMAGE_PATH.CAKE_IMAGE_URL}${img.images_path}`, id: img.id }
            })

            delete plainData.variants
            delete plainData.cakeimages
            return {
                ...plainData,
                imageData,
                variantDetails
            };
        });
    }
    return res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "Category list loaded successfully", data })

}

const addRating = async (req, res) => {
    const userId = req.user
    const { cakeId, rating, review } = req.body
    const isCake = await Cake.findOne({ where: { id: cakeId } });
    if (isCake) {
        await Rate.create({ user_id: userId, cake_id: cakeId, rating: rating, review: review })
        return res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "Rating added successfully." })
    } else {
        throw new BadRequestException("Cake details not found.")
    }


}
module.exports = {
    getCakes,
    addRating
}
