const User = require("../../models/userModel")
const Address = require("../../models/address")
const bcrypt = require("bcrypt")
const jwt = require("jsonwebtoken")
const { HTTP_STATUS_CODE, defaultProfileImage } = require("../../helper/constants.helper")
const { BadRequestException, ConflictRequestException, NotFoundRequestException } = require("../../common/exceptions/index")
const Op = require("sequelize").Op;

// user registration
const register = async (req, res) => {
    let { first_name, last_name, email, password, phone_number, lat, long, address, device_token, firebase_token } = req.body
    const user = await User.findOne({ where: { email: email } })
    if (user) {
        throw new ConflictRequestException("An account already exists with this email address.")
    }

    const isPhoneNumber = await User.findOne({ where: { phone_number } })
    if (isPhoneNumber) {
        throw new ConflictRequestException("This phone number already exists! Use a different phone number")
    }
    password = bcrypt.hashSync(password, 10)

    const data = await User.create({ first_name, last_name, email, password, phone_number, image: defaultProfileImage.image }, { plain: true })
    // add address in address table
    if (address && lat && long) {
        await Address.create({
            user_id: data?.id, lat, long, address
        })
    }

    // add device token and firebaseToken
    if (device_token && firebase_token) {
        data.device_token = device_token
        data.firebase_token = firebase_token
        await data.save()
    }
    const token = jwt.sign({ id: data.id }, process.env.JWT_SEC, { expiresIn: process.env.JWT_EXPIRES })
    return res.status(HTTP_STATUS_CODE.CREATED).json({ status: HTTP_STATUS_CODE.CREATED, success: true, message: "Register SuccessFully..", data: { user_id: data.id, token } });
}

// user login
const login = async (req, res) => {
    let { email, password, device_token, firebase_token } = req.body
    const user = await User.findOne({ where: { email: email } })

    if (!user || !bcrypt.compareSync(password, user?.password)) {
        throw new BadRequestException("Invalid email or password")
    }

    if (device_token && firebase_token) {
        if (user?.device_token === device_token) {
            user.firebase_token = firebase_token
            await user.save()
        } else {
            user.device_token = device_token
            user.firebase_token = firebase_token
            await user.save()

        }
    }
    const token = jwt.sign({ id: user?.id }, process.env.JWT_SEC, { expiresIn: process.env.JWT_EXPIRES })
    res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "Login SuccessFully..", data: { userID: user?.id, token } });
}

// Forgot Password
const forgotPassword = async (req, res, next) => {
    const { email } = req.body;

    if (!email) {
        throw new BadRequestException("Please Enter Valid Email.");
    }

    const user = await User.findOne({ where: { email: email } });

    if (user) {
        var digits = '0123456789';
        let OTP = '';
        for (let i = 0; i < 4; i++) {
            OTP += digits[Math.floor(Math.random() * 10)];
        }

        // send mail
        // await forgotPasswordMail({ OTP, email });

        user.reset_password_token = OTP;
        await user.save();
        return res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, OTP, message: "OTP send successfully for reset password" });
    } else {
        throw new BadRequestException("User Not Found.");
    }
}

// verify OTP for reset Password
const verifyOTP = async (req, res, next) => {
    const { email, OTP } = req.body;

    if (!OTP) {
        throw new BadRequestException("Please enter reset password code");
    }
    if (!email) {
        throw new BadRequestException("Please enter email for verification");
    }
    const user = await User.findOne({ where: { email, reset_password_token: OTP } });
    if (!user) {
        throw new BadRequestException("Invalid OTP Send")
    }
    const user_id = user.id
    return res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "OTP verification done successfully", user_id })
}

// reset password
const resetPassword = async (req, res) => {
    let { user_id, password } = req.body
    const user = await User.findOne({ where: { id: user_id } })

    if (user && user.reset_password_token !== null) {
        user.password = bcrypt.hashSync(password, 10)
        user.reset_password_token = null
        await user.save()
        return res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "Reset Password SuccessFully.." });
    } else {
        throw new NotFoundRequestException("User not found")
    }
}

// change password
const changePassword = async (req, res) => {
    const user_id = req.user
    let { old_password, new_password } = req.body
    const user = await User.findByPk(user_id)

    if (user) {
        if (bcrypt.compareSync(old_password, user.password)) {
            new_password = bcrypt.hashSync(new_password, 10)
            user.password = new_password
            await user.save()
            return res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "Change Password SuccessFully.." });

        } else {
            throw new BadRequestException("Old password not match")
        }
    } else {
        throw new BadRequestException("User details not found")
    }
}

// For logout
const handleLogOut = async (req, res) => {
    const { device_token } = req.body;
    const user_id = req.user;
    if (!device_token) {
        throw new BadRequestException("device token is required")
    }

    await User.update({ firebase_token: null },
        {
            where: {
                [Op.and]: [
                    { id: user_id },
                    { device_token: device_token },
                ]
            }
        });

    return res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, message: "user logout successfully." });
}

module.exports = {
    register,
    login,
    forgotPassword,
    verifyOTP,
    resetPassword,
    changePassword,
    handleLogOut
}