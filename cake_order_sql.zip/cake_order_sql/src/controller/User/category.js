const Category = require("../../models/category")
const { HTTP_STATUS_CODE, IMAGE_PATH } = require("../../helper/constants.helper")

const getCategory = async (req, res) => {
    let data = await Category.findAll({
        where: { is_deleted: '0', is_active: '1' },
        attributes: { exclude: ['is_active', 'is_deleted', 'updated_at', 'created_at'] }
    })
    if (data.length > 0) {
        data = data.map(item => {
            const plainData = item.get({ plain: true })
            plainData.image = `${IMAGE_PATH.CATEGORY_IMAGE_URL}${plainData.image}`
            return plainData
        });
    }
    return res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "Category list loaded successfully", data })

}

module.exports = {
    getCategory
}
