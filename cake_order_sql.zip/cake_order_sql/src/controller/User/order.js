const Variant = require("../../models/variants")
const Cake = require("../../models/cake")
const CakeVariant = require("../../models/cakeVariants")
const CakeImages = require("../../models/cakeImage")
const formidable = require("formidable")
const { HTTP_STATUS_CODE, IMAGE_PATH } = require("../../helper/constants.helper")
const { fileUpload } = require("../../helper/fileUpload")
const { placeOrderValidation } = require("../../common/validation")
const Address = require("../../models/address")
const Order = require("../../models/order")
const Rating = require("../../models/rate")


const placeOrder = async (req, res) => {
    const userId = req.user
    console.log(req.user);
    const form = formidable({ multiples: true })
    form.parse(req, async (err, fields, files) => {
        // validation
        const { cake_id, address_id, variant_id, order_type, date_time, is_custom } = fields
        const validation = placeOrderValidation.filter((field) => !fields[field])
        if (validation.length > 0) {
            return res.status(HTTP_STATUS_CODE.BAD_REQUEST).json({ status: HTTP_STATUS_CODE.BAD_REQUEST, success: false, message: `The ${validation.join(', ')} is required.` })
        }

        const cake = await Cake.findOne({ where: { id: cake_id, is_deleted: '0', is_active: '1' } })
        if (!cake) return res.status(HTTP_STATUS_CODE.BAD_REQUEST).json({ status: HTTP_STATUS_CODE.BAD_REQUEST, success: false, message: "Cake details not exits." })

        const address = await Address.findOne({ where: { id: address_id, user_id: userId } })
        if (!address) return res.status(HTTP_STATUS_CODE.BAD_REQUEST).json({ status: HTTP_STATUS_CODE.BAD_REQUEST, success: false, message: "Address is not exits for this user." })


        let variant = await CakeVariant.findOne({
            where: { variant_id: variant_id, cake_id: cake_id }, include: [{
                model: Variant,
                attributes: ['id', 'name']
            },],
        })
        variant = variant ? variant.get({ plain: true }) : null;
        if (variant && variant !== null) {
            fields.variant_id = variant.variant_id
            fields.variant_name = variant.variant.name
            fields.variant_price = variant.price
        } else {
            return res.status(HTTP_STATUS_CODE.BAD_REQUEST).json({ status: HTTP_STATUS_CODE.BAD_REQUEST, success: false, message: "This variant dose not exits in this cake..!" })
        }

        if ((is_custom === '0' && order_type === "1") || (is_custom === "1" && order_type === "1")) {
            if (!date_time) {
                return res.status(HTTP_STATUS_CODE.BAD_REQUEST).json({ status: HTTP_STATUS_CODE.BAD_REQUEST, success: false, message: 'Delivery date and time is required' })
            }
            fields.date_time = date_time
        }

        if ((is_custom === "1" && order_type === "1") || (is_custom === "1" && order_type === "2")) {
            if (files.custom_cake_image) {
                const result = await fileUpload(files.custom_cake_image, ['jpeg', 'png', 'jpg'], 'customCake')
                if (result.success === false) {
                    res.status(result.status).json(result)
                } else {
                    fields.custom_cake_image = result
                }
            } else {
                return res.status(HTTP_STATUS_CODE.BAD_REQUEST).json({ status: HTTP_STATUS_CODE.BAD_REQUEST, success: false, message: "Cake image is required." });
            }
        }
        fields.user_id = userId
        await Order.create(fields)
        return res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "Order placed successfully" })
    })

}

const getMyOrderList = async (req, res) => {
    const userId = req.user
    let data = await Order.findAll({
        where: { user_id: userId },
        include: [
            {
                model: Cake,
                attributes: ['id', 'name', 'price', 'description'],
                include: [
                    {
                        model: CakeImages,
                        attributes: ['id', 'images_path'],
                    },
                    {
                        model: Rating,
                        attributes: ['rating', 'review']
                    }
                ],
            },
            {
                model: Address,
                attributes: ['id', 'address']
            },
        ],
        attributes: { exclude: ['cake_id', 'address_id', 'is_deleted', 'created_at', 'updated_at'] }
    })

    if (data.length > 0) {
        data = data.map(item => {
            const plainData = item.get({ plain: true })
            plainData.cake.cakeimages = plainData.cake.cakeimages.map((image) => {
                image.images_path = `${IMAGE_PATH.CAKE_IMAGE_URL}${image.images_path}`;
                return image;
            })
            if (plainData.custom_cake_image !== null) {
                plainData.custom_cake_image = `${IMAGE_PATH.CUSTOM_IMAGE_URL}${plainData?.custom_cake_image}`
            }
            return plainData
        });
    }
    return res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "Order details loaded successfully.", data })
}

module.exports = {
    placeOrder,
    getMyOrderList
}
