const formidable = require("formidable")
const Op = require("sequelize").Op;
const User = require("../../models/userModel")
const Order = require("../../models/order")
const Address = require("../../models/address")
const { HTTP_STATUS_CODE, defaultProfileImage, IMAGE_PATH } = require("../../helper/constants.helper")
const { BadRequestException } = require("../../common/exceptions/index");
const { fileUpload, deleteFile } = require("../../helper/fileUpload")


// get user profile details
const getProfile = async (req, res) => {
    const user_id = req.user
    const data = await User.findOne({
        where: {
            [Op.and]: [
                { id: user_id },
                { is_active: "1" },
                { is_deleted: "0" },
            ]
        },
        attributes: { exclude: ['password', 'reset_password_token', 'remember_token', 'email_verification_at', 'is_deleted', 'updated_at', 'created_at', 'device_token', 'firebase_token', 'email_verified_at'] },
    })

    if (!data) {
        throw new BadRequestException("User details not found")
    }
    if (data?.image) {
        data.image = `${IMAGE_PATH.PROFILE_IMAGE_URL}${data.image}`
    }
    const totalNumOfOrders = await Order.count({ user_id: user_id })
    return res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "User details load successfully", data: { data, totalNumOfOrders } })
}

// update user profile
const updateUserProfile = async (req, res) => {
    const user_id = req.user
    const form = formidable({ multiples: true });
    form.parse(req, async (err, fields, files) => {
        try {
            let { email, phone_number } = fields
            const user = await User.findByPk(user_id)
            // check email is exits or not
            if (email) {
                const isEmailExists = await User.findOne({ where: { email } });
                if (isEmailExists !== null && isEmailExists?.id !== user_id) {
                    return res.status(HTTP_STATUS_CODE.CONFLICT).json({ status: HTTP_STATUS_CODE.CONFLICT, success: false, message: "Email is already exits" });
                } else {
                    fields.email = email
                }
            }
            // check phone number is exits or not
            if (phone_number) {
                const isPhoneNumberExists = await User.findOne({ where: { phone_number } });
                if (isPhoneNumberExists !== null && isPhoneNumberExists?.id !== user_id) {
                    return res.status(HTTP_STATUS_CODE.CONFLICT).json({ status: HTTP_STATUS_CODE.CONFLICT, success: false, message: "This phone number already exists! Use a different phone number" });
                } else {
                    fields.phone_number = phone_number
                }
            }

            // if profileImage
            if (files.image) {
                const result = await fileUpload(files.image, ['jpeg', 'png', 'jpg'], 'profile')
                if (result.success === false) {
                    res.status(result.status).json(result)
                } else {
                    fields.image = result
                }
                if (user.image !== defaultProfileImage.image) {
                    await deleteFile('profile', user.image)
                }
            };
            await User.update(fields, { where: { id: user_id } })
            return res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "User profile update successfully" })

        } catch (error) {
            return res.status(HTTP_STATUS_CODE.INTERNAL_SERVER).json({ status: HTTP_STATUS_CODE.INTERNAL_SERVER, success: false, message: error.message })
        }
    })
}

// add new address
const addAddress = async (req, res) => {
    const userId = req.user
    let { lat, long, address } = req.body
    await Address.create({ user_id: userId, lat, long, address })

    return res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "Address add successfully" })
}

// get user all address
const getAllAddressList = async (req, res) => {
    const userId = req.user
    const data = await Address.findAll({
        where: {
            [Op.and]: [
                { user_id: userId },
                { is_deleted: "0" },
            ],
        },
        attributes: { exclude: ['created_at', 'updated_at', 'is_deleted', 'email_verified_at', 'firebase_token', 'device_token'] }
    })
    if (!data) {
        throw new BadRequestException("User address details not found")
    }
    return res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "User address list load successfully", data })
}

//update user address
const updateAddress = async (req, res) => {
    const userId = req.user
    const { addressId } = req.params
    const address = await Address.findOne({ where: { id: addressId, user_id: userId } })
    if (address) {
        await Address.update(req.body, { where: { id: addressId, user_id: userId } })
        return res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "Address update successfully" })
    } else {
        throw new BadRequestException("Address details not found")
    }
}

// delete address
const deleteAddress = async (req, res) => {
    const userId = req.user
    const { addressId } = req.params
    const address = await Address.findOne({ where: { id: addressId, user_id: userId } })
    if (address) {
        await Address.update({ is_deleted: "1" }, { where: { id: addressId } })
        return res.status(HTTP_STATUS_CODE.OK).json({ status: HTTP_STATUS_CODE.OK, success: true, message: "Address deleted successfully" })
    } else {
        throw new BadRequestException("Address details not found")
    }
}


module.exports = {
    getProfile,
    updateUserProfile,
    getAllAddressList,
    addAddress,
    updateAddress,
    deleteAddress,
}