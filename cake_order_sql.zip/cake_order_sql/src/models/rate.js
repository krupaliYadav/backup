const { sequelize, DataTypes } = require("../config/dbConnection")

const Rate = sequelize.define("ratings", {
    id: {
        type: DataTypes.BIGINT,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true,
    },
    user_id: {
        type: DataTypes.INTEGER
    },
    cake_id: {
        type: DataTypes.INTEGER
    },
    rating: {
        type: DataTypes.FLOAT
    },
    review: {
        type: DataTypes.STRING
    },
    is_deleted: {
        type: DataTypes.ENUM('0', '1'),
        defaultValue: '0',
        comment: '0 = notDeleted, 1 = deleted'
    }
}, {
    createdAt: "created_at",
    updatedAt: "updated_at",
    hooks: {
        async beforeSave(review) {
            const Cake = sequelize.models.cakes;
            const ratings = await Rate.findAll({
                where: { cake_id: review.cake_id },
            });
            const filteredReviews = ratings.filter(rating => rating.review !== undefined);
            const totalRating = ratings.reduce((total, rating) => total + rating.rating, 0) / ratings.length;

            const cake = await Cake.findByPk(review.cake_id);
            cake.rating = totalRating.toFixed(2);
            cake.noOfReview = filteredReviews.length;
            await cake.save();
        }
    }
})


module.exports = Rate
