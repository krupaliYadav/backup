const { sequelize, DataTypes } = require("../config/dbConnection")

const Category = sequelize.define("categories", {
    id: {
        type: DataTypes.BIGINT,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true,
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false,
        required: [true, "Category Name is required"]
    },
    image: {
        type: DataTypes.STRING,
        allowNull: false
    },
    is_active: {
        type: DataTypes.ENUM('0', '1'),
        defaultValue: '1',
        comment: '0 = deactive, 1= active'
    },
    is_deleted: {
        type: DataTypes.ENUM('0', '1'),
        defaultValue: '0',
        comment: '0 = notDeleted, 1 = deleted'
    }
}, {
    createdAt: "created_at",
    updatedAt: "updated_at"
})

module.exports = Category
