const { sequelize, DataTypes } = require("../config/dbConnection")

const CakeImage = sequelize.define("cakeimages", {
    id: {
        type: DataTypes.BIGINT,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true,
    },
    cake_id: {
        type: DataTypes.INTEGER,
    },
    images_path: {
        type: DataTypes.STRING,
    },
    is_deleted: {
        type: DataTypes.ENUM('0', '1'),
        defaultValue: '0',
        comment: '0 = notDeleted, 1 = deleted'
    }
}, {
    createdAt: "created_at",
    updatedAt: "updated_at"
})
module.exports = CakeImage
