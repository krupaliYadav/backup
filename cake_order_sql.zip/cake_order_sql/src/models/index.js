const { sequelize } = require("../config/dbConnection")
const Sequelize = require("sequelize");
const Users = require("./userModel")
const Address = require("./address")
const Category = require("./category")
const Cake = require("./cake")
const CakeVariant = require("./cakeVariants")
const Variant = require("./variants")
const CakeImages = require("./cakeImage")
const Order = require("./order")
const Rating = require("./rate")

const db = {};
db.Sequelize = Sequelize;
db.sequelize = sequelize;
db.sequelize.sync()
    // {alter:true}  for alter model
    .then(() => console.log("Re-sync"))



Users.hasMany(Address, { foreignKey: "id" })
Address.belongsTo(Users, { foreignKey: "user_id" })

Category.hasMany(Cake, { foreignKey: 'category_id' })
Cake.belongsTo(Category, { foreignKey: 'category_id' })

Cake.belongsToMany(Variant, {
    through: 'CakeVariants', // Use the name of your junction table
    foreignKey: 'cake_id', // Name of the foreign key in CakeVariant
    otherKey: 'variant_id' // Name of the foreign key in CakeVariant referring to Variant
});
Variant.belongsToMany(Cake, {
    through: 'CakeVariants', // Use the name of your junction table
    foreignKey: 'variant_id', // Name of the foreign key in CakeVariant
    otherKey: 'cake_id' // Name of the foreign key in CakeVariant referring to Cake
});


Cake.hasMany(CakeImages, { foreignKey: 'cake_id' })
CakeImages.belongsTo(Cake, { foreignKey: 'cake_id' })

Variant.hasMany(CakeVariant, { foreignKey: "id" })
CakeVariant.belongsTo(Variant, { foreignKey: "variant_id" })

Order.belongsTo(Cake, { foreignKey: "cake_id" });
Order.belongsTo(Address, { foreignKey: "address_id" })
Order.belongsTo(Users, { foreignKey: "user_id" });

Cake.hasMany(Rating, { foreignKey: 'cake_id' })
Rating.belongsTo(Cake, { foreignKey: 'cake_id' })


// scopes
Users.addScope('checkDeleteStatus', {
    where: {
        is_deleted: '0'
    }
})
module.exports = db



