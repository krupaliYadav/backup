const { sequelize, DataTypes } = require("../config/dbConnection")

const Address = sequelize.define("addresses", {
    id: {
        type: DataTypes.BIGINT,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true,
    },
    user_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
    },
    lat: {
        type: DataTypes.STRING,
        allowNull: false,
        required: [true, "lat is required"]
    },
    long: {
        type: DataTypes.STRING,
        allowNull: false,
        required: [true, "long is required"]
    },
    address: {
        type: DataTypes.STRING,
        allowNull: false,
        required: [true, "address is required"]
    },
    is_deleted: {
        type: DataTypes.ENUM('0', '1'),
        defaultValue: '0',
        comment: '0 = notDeleted, 1 = deleted'
    }
}, {
    createdAt: "created_at",
    updatedAt: "updated_at"
})
module.exports = Address
