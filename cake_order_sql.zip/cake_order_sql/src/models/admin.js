const { sequelize, DataTypes } = require("../config/dbConnection")

const Admin = sequelize.define("admins", {
    id: {
        type: DataTypes.BIGINT,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true,
    },
    name: {
        type: DataTypes.STRING,
    },
    email: {
        type: DataTypes.STRING
    },
    password: {
        type: DataTypes.STRING
    },
    phoneNumber: {
        type: DataTypes.STRING
    },
    address: {
        type: DataTypes.STRING
    }
}, {
    createdAt: "created_at",
    updatedAt: "updated_at"
})
module.exports = Admin