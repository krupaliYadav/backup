const { sequelize, DataTypes } = require("../config/dbConnection")

const Order = sequelize.define("orders", {
    id: {
        type: DataTypes.BIGINT,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true,
    },
    user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        required: [true, "User id is required"]
    },
    cake_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        required: [true, "Cake id is required"]
    },
    address_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        required: [true, "Address id is required"]
    },
    variant_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        required: [true, "Variant id is required"]
    },
    variant_name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    variant_price: {
        type: DataTypes.STRING,
        allowNull: false
    },
    is_custom: {
        type: DataTypes.ENUM('0', '1'),
        defaultValue: '0',
        comment: '0 = non custom, 1= custom'
    },
    name_on_cake: {
        type: DataTypes.STRING,
        allowNull: false
    },
    order_type: {
        type: DataTypes.ENUM('1', '2'),
        allowNull: false,
        comment: '1= schedule, 2 = instant'
    },
    alter_phone: {
        type: DataTypes.STRING
    },
    note: {
        type: DataTypes.STRING
    },
    status: {
        type: DataTypes.ENUM('0', '1', '2', '3', '4'),
        defaultValue: '0',
        comment: '0 = pending, 1 = accepted, 2 = cancelled, 3 = inProgress, 4 = completed'
    },
    custom_cake_image: {
        type: DataTypes.STRING,
    },
    date_time: {
        type: DataTypes.DATE
    },
    is_deleted: {
        type: DataTypes.ENUM('0', '1'),
        defaultValue: '0',
        comment: '0 = notDeleted, 1 = deleted'
    }
}, {
    createdAt: "created_at",
    updatedAt: "updated_at"
})

module.exports = Order
