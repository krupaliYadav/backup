const { sequelize, DataTypes } = require("../config/dbConnection")

const User = sequelize.define("users", {
    id: {
        type: DataTypes.BIGINT,
        autoIncrement: true,
        primaryKey: true,
    },
    first_name: {
        type: DataTypes.STRING,
    },
    last_name: {
        type: DataTypes.STRING,
    },
    email: {
        type: DataTypes.STRING,
    },
    password: {
        type: DataTypes.STRING,
    },
    phone_number: {
        type: DataTypes.STRING,
    },
    image: {
        type: DataTypes.TEXT,
    },
    is_active: {
        type: DataTypes.ENUM('0', '1'),
        defaultValue: '1',
        comment: '0 = deactive, 1= active'
    },
    device_token: {
        type: DataTypes.STRING,
    },
    firebase_token: {
        type: DataTypes.STRING,
    },
    email_verified_at: {
        type: DataTypes.DATE,
        allowNull: true
    },
    reset_password_token: {
        type: DataTypes.STRING,
        allowNull: true
    },
    remember_token: {
        type: DataTypes.STRING,
        allowNull: true
    },
    is_deleted: {
        type: DataTypes.ENUM('0', '1'),
        defaultValue: '0',
        comment: '0 = notDeleted, 1 = deleted'
    }
}, {
    createdAt: "created_at",
    updatedAt: "updated_at"
})

module.exports = User
