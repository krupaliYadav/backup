const { sequelize, DataTypes } = require("../config/dbConnection")

const Cake = sequelize.define("cakes", {
    id: {
        type: DataTypes.BIGINT,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true,
    },
    category_id: {
        type: DataTypes.INTEGER,
    },
    name: {
        type: DataTypes.STRING,
    },
    price: {
        type: DataTypes.DOUBLE,
    },
    description: {
        type: DataTypes.STRING,
    },
    is_custom: {
        type: DataTypes.ENUM('0', '1'),
        defaultValue: '0',
        comment: '0 = nonCustom, 1= custom'
    },
    is_active: {
        type: DataTypes.ENUM('0', '1'),
        defaultValue: '1',
        comment: '0 = deactive, 1= active'
    },
    is_deleted: {
        type: DataTypes.ENUM('0', '1'),
        defaultValue: '0',
        comment: '0 = notDeleted, 1 = deleted'
    },
    rating: {
        type: DataTypes.FLOAT,
        defaultValue: 0
    },
    noOfReview: {
        type: DataTypes.NUMBER,
        defaultValue: 0
    }
}, {
    createdAt: "created_at",
    updatedAt: "updated_at"
})

module.exports = Cake
