const routes = require("express").Router()
const expressAsyncHandler = require("express-async-handler")
const validator = require("../helper/validator.helper")
const { adminRegister, login } = require("../common/validation")
const { isAuthenticatedAdmin } = require("../common/middleware/authenticate.middleware")
const { adminAuthController, adminOptionController, adminCakeController, adminOrderController, adminUserController } = require("../controller/index")

routes
    // auth
    .post("/register", validator.body(adminRegister), expressAsyncHandler(adminAuthController.adminRegister))
    .post("/login", validator.body(login), expressAsyncHandler(adminAuthController.adminLogin))
    .get("/getProfile", isAuthenticatedAdmin, expressAsyncHandler(adminAuthController.getProfile))
    .post("/editProfile", isAuthenticatedAdmin, expressAsyncHandler(adminAuthController.editProfile))

    // users
    .get("/getUsers", isAuthenticatedAdmin, expressAsyncHandler(adminUserController.getAllUsers))
    // category
    .post("/addCategory", isAuthenticatedAdmin, expressAsyncHandler(adminOptionController.addCategory))
    .get("/getCategory", expressAsyncHandler(adminOptionController.getAllCategory))
    .get("/getSingleCategory/:categoryId", expressAsyncHandler(adminOptionController.getSingleCategory))
    .post("/updateCategory/:categoryId", isAuthenticatedAdmin, expressAsyncHandler(adminOptionController.updateCategory))
    .post("/deleteCategory/:categoryId", isAuthenticatedAdmin, expressAsyncHandler(adminOptionController.deleteCategory))
    .post("/categoryStatus/:categoryId", isAuthenticatedAdmin, expressAsyncHandler(adminOptionController.changeCategoryStatus))

    // variant
    .post("/addVariant", isAuthenticatedAdmin, expressAsyncHandler(adminOptionController.addVariant))
    .get("/getVariant", expressAsyncHandler(adminOptionController.getAllVariant))
    .get("/getSingleVariant/:variantId", expressAsyncHandler(adminOptionController.getSingleVariant))
    .post("/updateVariant/:variantId", isAuthenticatedAdmin, expressAsyncHandler(adminOptionController.updateVariant))
    .post("/deleteVariant/:variantId", isAuthenticatedAdmin, expressAsyncHandler(adminOptionController.deleteVariant))
    .post("/variantStatus/:variantId", isAuthenticatedAdmin, expressAsyncHandler(adminOptionController.changeVariantStatus))

    // Cake
    .post("/addCake", isAuthenticatedAdmin, expressAsyncHandler(adminCakeController.addCake))
    .get("/getCakes", isAuthenticatedAdmin, expressAsyncHandler(adminCakeController.getCakeList))
    .post("/updateCake/:cake_id", isAuthenticatedAdmin, expressAsyncHandler(adminCakeController.updateCake))
    .post("/deleteSingleImg/:cake_id", isAuthenticatedAdmin, expressAsyncHandler(adminCakeController.deleteSingleImg))
    .post("/deleteCake/:cake_id", isAuthenticatedAdmin, expressAsyncHandler(adminCakeController.deleteCake))
    .post("/cakeStatus/:cake_id", isAuthenticatedAdmin, expressAsyncHandler(adminCakeController.changeCakeStatus))

    // order
    .get("/getAllOrders", isAuthenticatedAdmin, expressAsyncHandler(adminOrderController.getAllOrderList))
    .post("/changeOrderStatus/:order_id", isAuthenticatedAdmin, expressAsyncHandler(adminOrderController.changeOrderStatus))

module.exports = routes