const routes = require("express").Router()
const expressAsyncHandler = require("express-async-handler")
const validator = require("../helper/validator.helper")
const { registration, login, resetPassword, changePassword, addAddress } = require("../common/validation")
const { isAuthenticatedUser } = require("../common/middleware/authenticate.middleware")
const { userAuthController, userProfileController, userCategoryController, userCakeController, userOrderController } = require("../controller/index")

routes
    // auth
    .post("/register", validator.body(registration), expressAsyncHandler(userAuthController.register))
    .post("/login", validator.body(login), expressAsyncHandler(userAuthController.login))
    .post("/forgotPassword", expressAsyncHandler(userAuthController.forgotPassword))
    .post("/verifyOTP", expressAsyncHandler(userAuthController.verifyOTP))
    .post("/resetPassword", validator.body(resetPassword), expressAsyncHandler(userAuthController.resetPassword))
    .post("/changePassword", isAuthenticatedUser, validator.body(changePassword), expressAsyncHandler(userAuthController.changePassword))
    .post("/logOut", isAuthenticatedUser, expressAsyncHandler(userAuthController.handleLogOut))
    // user profile
    .get("/getUser", isAuthenticatedUser, expressAsyncHandler(userProfileController.getProfile))
    .put("/updateProfile", isAuthenticatedUser, expressAsyncHandler(userProfileController.updateUserProfile))
    .get("/getAllAddressList", isAuthenticatedUser, expressAsyncHandler(userProfileController.getAllAddressList))
    .post("/addAddress", isAuthenticatedUser, validator.body(addAddress), expressAsyncHandler(userProfileController.addAddress))
    .put("/updateAddress/:addressId", isAuthenticatedUser, expressAsyncHandler(userProfileController.updateAddress))
    .delete("/deleteAddress/:addressId", isAuthenticatedUser, expressAsyncHandler(userProfileController.deleteAddress))

    // category
    .get("/getCategory", expressAsyncHandler(userCategoryController.getCategory))

    //cake
    .get("/getCakes", expressAsyncHandler(userCakeController.getCakes))
    .post("/addRating", isAuthenticatedUser, expressAsyncHandler(userCakeController.addRating))

    // order
    .post("/placeOrder", isAuthenticatedUser, expressAsyncHandler(userOrderController.placeOrder))
    .get("/getMyOrders", isAuthenticatedUser, expressAsyncHandler(userOrderController.getMyOrderList))


module.exports = routes

