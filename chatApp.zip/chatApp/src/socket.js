const socketIO = require('socket.io');

module.exports = (server) => {
    const io = socketIO(server);

    io.on('connection', (socket) => {
        console.log('A user connected.');
        user = []
        socket.on("getUserName", (data) => {
            socket.emit('userSet', { username: data });

            socket.on('msg', function (data) {
                io.sockets.emit('newmsg', data);
            })
        })
        socket.on('disconnect', () => {
            // console.log('A user disconnected.');
        });

    });
};
