const express = require("express")
const app = express()
const http = require("http")
const socketServer = require('./src/socket');
const server = http.createServer(app);
const port = 8080

app.get("/", (req, res) => {
    res.sendFile(__dirname + "/views/index.html")
})

socketServer(server);

server.listen(port, () => {
    console.log(`Server is running on ${port}`);
})