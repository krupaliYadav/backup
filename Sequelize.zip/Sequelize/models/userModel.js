const { sequelize, DataTypes } = require("../config/db")
const User = sequelize.define("User", {
    firstName: {
        type: DataTypes.STRING,
        allowNull: false,
        defaultValue: "John"
    },
    lastName: {
        type: DataTypes.STRING,
        allowNull: false
    },
    email: {
        type: DataTypes.STRING,
        allowNull: false
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false
    },
    // date: {
    //     type: DataTypes.DATETIME,
    //     defaultValue: DataTypes.NOW
    //     // This way, the current date/time will be used to populate this column (at the moment of insertion)
    // },
    age: {
        type: DataTypes.INTEGER
    }
})

module.exports = User;