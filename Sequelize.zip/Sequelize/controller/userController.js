const User = require("../models/userModel")

// add an instance
const addUser = async (req, res) => {
    try {
        const data = await User.create({
            firstName: "john",
            lastName: "alena",
            email: "johnalena@yopmail.com",
            password: "alena@123"
        });
        console.log(data.toJSON());
    } catch (error) {
        console.log(error);
    }
}

// update an instance
const update = async (req, res) => {
    try {
        const data = await User.create({
            firstName: "john",
            lastName: "alena",
            email: "johnada@yopmail.com",
            password: "alena@123"
        });
        // data.lastName = "Ada";
        // await data.save();

        // OR
        // data.set({
        //     firstName: "raam",
        //     lastName: "patel",
        //     email: "raampatel@yopmail.com",
        //     password: "raam@123"
        // });

        // OR
        await data.update({ lastName: "marvel" })
        await data.save()
    } catch (error) {
        console.log(error);
    }
}

// Deleting an instance
const deleteUser = async (req, res) => {
    try {
        const data = await User.create({
            firstName: "krupali",
            lastName: "yadav",
            email: "krupali@yopmail.com",
            password: "krupali@123"
        })

        await data.destroy()
    } catch (error) {
        console.log(error);
    }
}

// Reloading an instance
// The reload call generates a SELECT query to get the up-to-date data from the database.
const reloadUser = async (req, res) => {
    try {

        const data = await User.create({
            firstName: "anvi",
            lastName: "yadav",
            email: "anvi@yopmail.com",
            password: "anvi@123"
        })
        await data.reload()
        console.log(data.toJSON());
    } catch (error) {
        console.log(error);
    }
}

// // Incrementing and decrementing integer values
// const incrementDecrement = async (req, res) => {
//     try {
//         const data = await User.create({
//             firstName: "test",
//             lastName: "user",
//             email: "test@yopmail.com",
//             password: "test@123",
//             age: 2
//         })
//         const increment = await data.increment('age')
//         console.log(increment);
//     } catch (error) {
//         console.log(error);
//     }
// }
module.exports = {
    addUser,
    update,
    deleteUser,
    reloadUser,
}