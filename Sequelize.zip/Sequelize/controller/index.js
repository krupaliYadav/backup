const userController = require("./userController")

module.exports = {
    addUser: userController.addUser,
    update: userController.update,
    deleteUser: userController.deleteUser,
    reloadUser: userController.reloadUser
}