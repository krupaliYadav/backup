const Product = require("../models/productModel")

const addProduct = async (req, res) => {
    try {

        const data = await Product.create({
            productName: "Lakmee hair spray",
            description: "Do not damage hairs",
            price: 500
        })
        console.log(data.toJSON());
    } catch (error) {
        console.log(error);
    }
}

module.exports = {
    addProduct
}