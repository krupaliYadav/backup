const express = require('express')
const app = express()
const port = 3000
const { dbConnection } = require("./config/db")
const { addUser, update, deleteUser, reloadUser, incrementDecrement } = require("./controller/userController")

app.get('/', (req, res) => res.send('Hello World!'))


app.listen(port, async () => {
    await dbConnection()
    // await addUser()
    // await update()
    // await deleteUser()
    // await reloadUser()
    // await incrementDecrement()
    console.log(`Server is running on  ${port}`);
});