const express = require("express")
const routes = express.Router()
const validator = require("../middleware/validation")
const { signup } = require("../validation/index")
const controller = require("../controller/userController")
const upload = require("../middleware/multer")

routes
    .post("/signup", upload.single("profileImage"), validator.body(signup), controller.signup)

module.exports = routes