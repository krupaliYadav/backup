const multer = require("multer")
const path = require("path")

const checkFileType = function (file, cb) {
    const uploadedExtension = path.extname(file.originalname).toLowerCase();
    const fileTypes = ["jpeg", "jpg", "png", "gif", "svg"]

    const extName = fileTypes.includes(uploadedExtension.slice(1));
    const mimeType = fileTypes.includes(uploadedExtension.slice(1));

    if (mimeType && extName) {
        return cb(null, true);
    } else {
        cb({ message: "This image type not allowed....." });
    }
};


const storage = multer.diskStorage({
    destination: function (req, file, callback) {
        callback(null, "public")
    },
    filename: function (req, file, callback) {
        callback(null, file.fieldname + "-" + Date.now() + path.extname(file.originalname))
    },
})

const upload = multer({
    storage: storage,
    fileFilter: (req, file, cb) => {
        checkFileType(file, cb);
    },
})

module.exports = upload