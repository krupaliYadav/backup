require("dotenv").config()
require("./config/database")
const express = require('express')
const routes = require("./routes/index")
const validationError = require("./util/validationError")
const app = express()
const port = process.env.PORT || 3000

app.use(express.json())
app.use(routes)
app.use(validationError)

app.listen(port, () => console.log(`Sever is running on ${port}!`))