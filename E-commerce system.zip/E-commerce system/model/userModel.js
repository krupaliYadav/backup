const mongoose = require("mongoose")
let softDelete = require('mongoosejs-soft-delete');
const { Schema } = mongoose

const userSchema = new Schema({
    firstName: {
        type: String,
        required: true
    },
    lastName: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    phoneNo: {
        type: String,
        required: true
    },
    profileImage: {
        type: String,
    },
    country: {
        type: String,
        required: true
    },
    role: {
        type: String,
        enum: ['user', 'merchant', 'admin']
    },
    approvalStatus: {
        type: String,
        enum: ['Approved', 'Pending', 'Rejected'],
        default: "Pending"
    }
}, { timestamps: true })

userSchema.plugin(softDelete)
module.exports = mongoose.model("User", userSchema)