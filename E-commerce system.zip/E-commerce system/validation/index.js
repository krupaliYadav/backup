const joi = require("joi")

const signup = joi.object().keys({
    firstName: joi.string().required().messages({
        "string.empty": "First name is required... "
    }),
    lastName: joi.string().required().messages({
        "string.empty": "Last name is required... "
    }),
    email: joi.string().email({ tlds: { allow: ["in", "com", "net"] }, maxDomainSegments: 2 }).required().messages({
        "*": "Please enter valid email..",
        "string.empty": "Email is required ",
    }),
    password: joi.string().min(4).max(10).required().messages({
        'string.min': 'Password should have at least 4 characters',
        'string.max': 'Password should not exceed 10 characters',
        'string.empty': 'Password is required',
    }),
    phoneNo: joi.string().min(10).max(10).required().messages({
        'string.min': 'Phone number should have at least 10 characters',
        'string.max': 'Phone number should not exceed 10 characters',
        'string.empty': 'Phone number is required',
    }),
    profileImage: joi.any(),
    country: joi.string().required().messages({
        "string.empty": "Country name is required... ",
    }),
    role: joi.string().required().messages({
        "*": "Role much be 'User' OR 'Merchant'OR 'Admin'..",
        "string.empty": "Workshop address is required... ",
    }),
})


module.exports = {
    signup,
}