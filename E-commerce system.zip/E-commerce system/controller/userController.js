const { HttpStatus, catchAsyncError, ErrorHandler, responseHandler } = require("../util/index")
const bcrypt = require("bcryptjs")
const jwt = require("jsonwebtoken")
const User = require("../model/userModel")

/*signup */
exports.signup = catchAsyncError(async (req, res, next) => {
    let approvalStatus;
    const user = await User.findOne({ email: req.body.email })
    if (user) {
        throw new ErrorHandler("Email is already exists with this role", HttpStatus.BAD_REQUEST, false);
    }
    req.body.password = bcrypt.hashSync(req.body.password, 10)
    if (req.file) {
        req.body.profileImage = req.file.filename
    }
    if (req.body.role === "admin") {
        console.log(">>>>>>>>>>>>>>>");
        req.body.approvalStatus === "Approved"
    }

    const data = await User.create(req.body)
    console.log(data);
    res.status(HttpStatus.OK).json(responseHandler(HttpStatus.OK, { type: "admin" }, "SignUp done successfully...",))
})

// /*login */
// exports.login = catchAsyncError(async (req, res, next) => {
//     let data = {}
//     let { email, password } = req.body
//     let user = await User.findOne({ email: email })
//     if (!user) {
//         throw new HttpException("Please Enter registered email..!!!", HttpStatus.BAD_REQUEST);
//     }
//     if (!bcrypt.compareSync(password, user?.password)) {
//         throw new HttpException("password not match..!!!", HttpStatus.BAD_REQUEST);
//     }

//     const token = jwt.sign({ _id: user._id }, process.env.KEY)
//     data = {
//         userId: user._id,
//         token: token
//     }
//     res.status(HttpStatus.OK).json(responseHandler("Login done successfully...", HttpStatus.OK, data))
// })