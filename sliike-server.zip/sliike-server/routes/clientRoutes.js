const router = require("express").Router();
const { filterServiceController, appointmentController, clientProfileController, HomePageController, productCController, brandCController, gistController } = require("../controller");
const { isAunticatedUser, isAuthenticatedClient, isAuthorizedRole, isAuthenticateAdmin } = require("../middleware/auth");
const { appointmentValidation, paymentControllerValidation, cardDetailValidation, orderValidation, shippingValidation, pickupValidation, clientNotificationValidation } = require("../middleware/validations");

//for filter 
router.post("/findServices", isAunticatedUser, filterServiceController.findServices);
router.post("/findServicesNew", isAunticatedUser, filterServiceController.findServicesNew);
router.get("/checkAvailability/:beauticianId", isAunticatedUser, isAuthenticatedClient, filterServiceController.getBeauticianAvailability);

router.post("/getBeauticianDetails", isAunticatedUser, isAuthenticatedClient, filterServiceController.getBeauticianDetails);
router.post("/beauticianReviews", isAunticatedUser, isAuthenticatedClient, filterServiceController.beauticianReviews);
router.get("/findAddress", filterServiceController.findAddress);
router.get("/searchServiceType", isAunticatedUser, isAuthenticatedClient, filterServiceController.searchServiceType);
router.get("/getRecentSearchList", isAunticatedUser, isAuthenticatedClient, filterServiceController.getRecentSearchList);
router.post("/getBusinessDeatils", isAunticatedUser, isAuthenticatedClient, filterServiceController.businessDetails);
// router.post("/getBusinessDetailsNew", isAunticatedUser, filterServiceController.businessDetailsNew);
router.post("/addCountForService/:type/:dataId", isAunticatedUser, filterServiceController.addCountForService);
router.get("/getBePolicyDetails/:beauticianId", isAunticatedUser, filterServiceController.getBePolicyDetails)
router.get("/getPortfolioImages/:beauticianId", isAunticatedUser, filterServiceController.getPortfolioImages)

// for Appointment
router.post("/getStylistList", isAunticatedUser, appointmentController.getStylishList)
router.post("/addAppointment", appointmentValidation, isAunticatedUser, appointmentController.addAppointment);
router.post("/updateAppointment/:appId", appointmentValidation, isAunticatedUser, appointmentController.addAppointment);
router.post("/getBookedPendingAppointment", isAunticatedUser, appointmentController.getBookedPendingAppointment);
router.get("/getAppointmentList", isAunticatedUser, appointmentController.getAppointmentList);
router.post("/addRating", isAunticatedUser, appointmentController.addRating);
router.delete("/cancelAppointment/:appId", isAunticatedUser, appointmentController.cancelAppointment);
router.get("/getSingleAppointmentData/:appId", isAunticatedUser, appointmentController.getSingleAppointmentData);
router.post("/makePayment", isAunticatedUser, paymentControllerValidation, appointmentController.makePaymentForServices);
router.post("/getPrePaymentDetails", isAunticatedUser, appointmentController.getPrePaymentDetails);
router.post("/appointmentDetails", isAunticatedUser, appointmentController.appointmentDetails);

// payment and card module
router.get("/getCardDetails", isAunticatedUser, isAuthenticatedClient, appointmentController.getCardDetails);
router.get("/getCardDetails/:value", isAunticatedUser, isAuthenticatedClient, appointmentController.getCardDetails);
router.post("/addCardDetails", cardDetailValidation, isAunticatedUser, isAuthenticatedClient, appointmentController.addCardDetails)
router.delete("/deleteCardDetails/:cardToken", isAunticatedUser, isAuthenticatedClient, appointmentController.deleteCardDetails);
router.put("/setCardASPrimary/:cardToken", isAunticatedUser, isAuthenticatedClient, appointmentController.setCardASPrimary)
//Profile and address
router.get("/getClientPersonalInfo", isAunticatedUser, isAuthenticatedClient, clientProfileController.getClientPersonalInfo);
router.post("/updateProfileImage", isAunticatedUser, isAuthenticatedClient, clientProfileController.updateProfileImage);
router.post("/addPersonalInfo", isAunticatedUser, isAuthenticatedClient, clientProfileController.addPersonalInfo);
router.post("/addClientAddress", isAunticatedUser, isAuthenticatedClient, clientProfileController.addEditClientAddress);
router.delete("/deleteClientAccount", isAunticatedUser, isAuthenticatedClient, clientProfileController.handleDeleteClientAccount);
router.post("/saveNotification", isAunticatedUser, isAuthenticatedClient, clientNotificationValidation, clientProfileController.handleNotificationSettings);
router.post("/addToMyFavorites", isAunticatedUser, isAuthenticatedClient, clientProfileController.addToMyFavorites);
router.post("/removeFromMyFavorites", isAunticatedUser, isAuthenticatedClient, clientProfileController.removeFromMyFavorites);
router.post("/changeLanguage", isAunticatedUser, isAuthenticatedClient, clientProfileController.changeLanguage);
router.get("/getClientNotification", isAunticatedUser, isAuthenticatedClient, clientProfileController.getClientNotification);
router.post("/changeClientNotifications", isAunticatedUser, isAuthenticatedClient, clientNotificationValidation, clientProfileController.changeClientNotifications);

// homepage
router.get("/getAllBeauticianDetails", isAunticatedUser, isAuthenticatedClient, HomePageController.getAllBeauticianDetails);
router.get("/getClientFavoriteList", isAunticatedUser, isAuthenticatedClient, HomePageController.getClientFavoriteList);
router.get("/getRecentBeauticians", isAunticatedUser, isAuthenticatedClient, HomePageController.getRecentBeauticians);
router.post("/getNearerBeauticianList", isAunticatedUser, isAuthenticatedClient, HomePageController.getNearerBeauticianList);
router.post("/getRecomadedBeauticians", isAunticatedUser, isAuthenticatedClient, HomePageController.getRecomadedBeauticians);

//Product module routes
router.get("/getproductCategoryList", isAunticatedUser, productCController.getproductCategoryList);
router.get("/getSingleProductDetail/:productPId", isAunticatedUser, isAuthenticatedClient, productCController.getSingleProductDetail);
router.get("/getBeauticianProducts/:beauticianId", isAunticatedUser, isAuthenticatedClient, productCController.getBeauticianProducts);
router.post("/getFilterProduct", isAunticatedUser, isAuthenticatedClient, productCController.getFilterProduct);
router.post("/addProductInFavorites", isAunticatedUser, isAuthenticatedClient, productCController.addProductInFavorites);
router.post("/removeProductInFavorites", isAunticatedUser, isAuthenticatedClient, productCController.removeProductInFavorites);
router.post("/findProductOrVendor", isAunticatedUser, isAuthenticatedClient, productCController.findProductOrVendor);
router.get("/getRecentProductSearch", isAunticatedUser, isAuthenticatedClient, productCController.getRecentProductSearch);
router.get("/getFavoriteProductList", isAunticatedUser, isAuthenticatedClient, productCController.getFavoriteProductList);
router.get("/getRecentViewdProdcts", isAunticatedUser, isAuthenticatedClient, productCController.getRecentViewdProdcts);
router.post("/addToCartProduct", isAunticatedUser, isAuthenticatedClient, productCController.addToCartProduct);
router.post("/removeCart", isAunticatedUser, isAuthenticatedClient, productCController.removeCart);
router.post("/changeCartQuanity", isAunticatedUser, isAuthenticatedClient, productCController.changeCartQuanity);
router.post("/addShareClickCount/:prodId", isAunticatedUser, isAuthenticatedClient, productCController.addShareClickCount);
router.get("/getCartData", isAunticatedUser, isAuthenticatedClient, productCController.getCartData);
router.post("/getOrderReview", isAunticatedUser, isAuthenticatedClient, productCController.getOrderReview);
router.post("/addOrderToPlace", isAunticatedUser, isAuthenticatedClient, orderValidation, productCController.addOrderToPlace);
router.get("/getRecomadedProducts", isAunticatedUser, isAuthenticatedClient, productCController.getRecomadedProducts);
router.get("/getMyOrders", isAunticatedUser, isAuthenticatedClient, productCController.getMyOrders);
router.get("/getClientAddress", isAunticatedUser, isAuthenticatedClient, productCController.getClientAddress);
router.put("/updateShippingInfo", isAunticatedUser, isAuthenticatedClient, shippingValidation, productCController.updateShippingInfo);
router.post("/verifyPickupDetails", isAunticatedUser, isAuthenticatedClient, pickupValidation, productCController.verifyPickupDetails);

// Brand routes
router.post("/addToMyFavoritesBrand", isAunticatedUser, isAuthenticatedClient, brandCController.addToMyFavorites);
router.post("/removeBrandFromFavorites", isAunticatedUser, isAuthenticatedClient, brandCController.removeBrandFromFavorites);
router.get("/favBrandsList", isAunticatedUser, isAuthenticatedClient, brandCController.getFavBrandList);
router.post("/getFilterBrand", isAunticatedUser, isAuthenticatedClient, brandCController.getFilterBrand);
router.post("/findBrandsProducts", isAunticatedUser, isAuthenticatedClient, brandCController.findBrandsProducts);
router.get("/recentSearchBrand", isAunticatedUser, isAuthenticatedClient, brandCController.getRecentSearchBrand);
router.get("/getSingleBrandDetails/:brandId", isAunticatedUser, isAuthenticatedClient, brandCController.getSingleBrandDetails);
router.get("/getSingleBrandProduct/:productId", isAunticatedUser, brandCController.getSingleBrandProduct);
router.get("/getAllCategoryBrands", isAunticatedUser, brandCController.getAllCategoryBrands);
router.post("/storeClicks", isAunticatedUser, brandCController.storeClicks);
router.post("/addToFavoritesBrandProducts", isAunticatedUser, isAuthenticatedClient, brandCController.addToFavoritesBrandProducts);

// Gist routes
router.post("/createGist", isAuthorizedRole, gistController.createGist);
router.get("/getAllGist", isAuthorizedRole, gistController.getAllGist);
router.get("/getSingleGist/:gistId", isAuthorizedRole, gistController.getSingleGist);
router.post("/sendResponse", isAuthorizedRole, gistController.sendResponse);
router.get("/getMyGist", isAuthorizedRole, gistController.getMyGist);
router.delete("/removeGist", isAuthenticateAdmin, gistController.removeGist);

module.exports = router;