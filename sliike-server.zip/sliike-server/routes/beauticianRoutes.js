const router = require("express").Router();
const { businessController, profileController, serviceController, workHoursController, employeeController, paymentTaxController, appointmentBController, promotionBController, appointmentController, reportController, productBController, clientBController, brandBController } = require("../controller");
const { isAunticatedUser, isAunticatedBeautician } = require("../middleware/auth");
const { businessValidation, calenderAdjustmentValidation, addPromotionValidation, appointmentValidation, validateClientList, productEditValidator, productAddValidator, productPIdValidator, checkAppointIDValidation, emailMarketingValidation, productValidation, beauticainNotificationValidation, myClientNotificationValidation } = require("../middleware/validations");

//for business details
router.post("/addBusinessType", businessValidation, isAunticatedUser, isAunticatedBeautician, businessController.addBusinessType);
router.post("/addBusinessDetail", businessValidation, isAunticatedUser, isAunticatedBeautician, businessController.addBusinessDetails);
router.put("/updateBusinessDetails", isAunticatedUser, isAunticatedBeautician, businessController.updateBusinessDetails);
router.post("/addBeauticianServiceMethod", isAunticatedUser, isAunticatedBeautician, businessController.addBeauticianServiceMethod);
router.get("/getLocationDetails", isAunticatedUser, isAunticatedBeautician, businessController.getLocationDetails);
router.put("/updateSalonLocation", isAunticatedUser, isAunticatedBeautician, businessController.updateSalonLocation);

router.get("/getBeauticianProfile", isAunticatedUser, isAunticatedBeautician, profileController.getBeauticianProfile);
router.put("/updateBeauticianProfile", isAunticatedUser, isAunticatedBeautician, profileController.updateBeautician);
router.delete("/deleteBeauticianAccount", isAunticatedUser, isAunticatedBeautician, profileController.deleteBeauticianAccount)
router.post("/addBusinessLogo", isAunticatedUser, isAunticatedBeautician, businessController.addBusinessLogo);
router.post("/addWorkSpaceImg", isAunticatedUser, isAunticatedBeautician, businessController.addWorkSpaceImg);
router.get("/getBeauticianLogoImg", isAunticatedUser, isAunticatedBeautician, businessController.getLogoImg);
router.get("/getWorkSpaceImg", isAunticatedUser, isAunticatedBeautician, businessController.getWorkSpaceImg);
router.put("/updateWorkSpaceImg", isAunticatedUser, isAunticatedBeautician, businessController.updateWorkSpaceImg);
router.delete("/deleteWorkSpaceImg", isAunticatedUser, isAunticatedBeautician, businessController.deleteWorkSpaceImg);
router.get("/getLicenseDetails", isAunticatedUser, isAunticatedBeautician, businessController.getLicenseDetails)
router.post("/addBusinessLicense", isAunticatedUser, isAunticatedBeautician, businessController.addBusinessLicense)

//get screen status
router.get("/getScreenStatus", isAunticatedUser, isAunticatedBeautician, profileController.getScreenStatus);

// for service details
router.get("/getServiceDetails", isAunticatedUser, isAunticatedBeautician, serviceController.getServiceDetails);
router.get("/getSingleServiceDetails/:serviceId", isAunticatedUser, isAunticatedBeautician, serviceController.getSingleServiceDetails);
router.post("/addServiceDetails", isAunticatedUser, isAunticatedBeautician, serviceController.addServiceDetails);
router.post("/addSingleServiceDetails", isAunticatedUser, isAunticatedBeautician, serviceController.addSingleServiceDetails);
router.put("/updateServiceDetails/:serviceId", isAunticatedUser, isAunticatedBeautician, serviceController.updateServiceDetails);
router.post("/addServiceDetailsNEW", isAunticatedUser, isAunticatedBeautician, serviceController.addServiceWithImageDetails);
router.delete("/deleteServiceDetails/:serviceId", isAunticatedUser, isAunticatedBeautician, serviceController.deleteServiceDetails)

//for work hours 

router.get("/getWorkHours", isAunticatedUser, isAunticatedBeautician, workHoursController.getWorkHours);
router.post("/addWorkHours", isAunticatedUser, isAunticatedBeautician, workHoursController.addWorkHours);
router.put("/updateWorkHours/:workHoursId", isAunticatedUser, isAunticatedBeautician, workHoursController.updateWorkHours);
router.post("/saveCalenderAdjustment", calenderAdjustmentValidation, isAunticatedUser, isAunticatedBeautician, workHoursController.saveCalenderAdjustment)
router.post("/getScheduleForDate", calenderAdjustmentValidation, isAunticatedUser, isAunticatedBeautician, workHoursController.getScheduleForDate)

// for profile 
router.get("/getMyDemographics", isAunticatedUser, isAunticatedBeautician, profileController.getDemographics);
router.post("/addMyDemographics", isAunticatedUser, isAunticatedBeautician, profileController.saveDemographies);
router.get("/getAmenities", isAunticatedUser, isAunticatedBeautician, profileController.getAmenities);
router.post("/saveAmenities", isAunticatedUser, isAunticatedBeautician, profileController.saveAmenities);
router.get("/getHealthSafety", isAunticatedUser, isAunticatedBeautician, profileController.getHealthSafety);
router.post("/saveHealthSafety", isAunticatedUser, isAunticatedBeautician, profileController.saveHealthSafety);
router.get("/getBeuaticianNotification", isAunticatedUser, isAunticatedBeautician, profileController.getBeuaticianNotification);
router.get("/getMyClientsNotification", isAunticatedUser, isAunticatedBeautician, profileController.getMyClientsNotification);
router.post("/changeBeuaticianNotifications", isAunticatedUser, isAunticatedBeautician, beauticainNotificationValidation, profileController.changeBeuaticianNotifications);
router.post("/changeMyClientNotifications", isAunticatedUser, isAunticatedBeautician, myClientNotificationValidation, profileController.changeMyClientNotifications);
router.get("/getSubscriptionStatus", isAunticatedUser, isAunticatedBeautician, profileController.getSubscriptionStatus);
router.put("/changeSubscriptionStatus", isAunticatedUser, isAunticatedBeautician, profileController.changeSubscriptionStatus);

//for stuff or Employee ;
router.get("/getEmployeeList", isAunticatedUser, isAunticatedBeautician, employeeController.getEmployeeList);
router.get("/allowAddEmployee", isAunticatedUser, isAunticatedBeautician, employeeController.allowAddEmployee);
router.post("/addEmployeeDetails", isAunticatedUser, isAunticatedBeautician, employeeController.addEmployeeDetails);
router.get("/getEmployeeDetail/:employeeId", isAunticatedUser, isAunticatedBeautician, employeeController.getEmployeeDetail);
router.put("/updateEmployeeDetail/:employeeId", isAunticatedUser, isAunticatedBeautician, employeeController.UpdateEmployeeDetails);

//province and tax detail 

router.post("/addProvinceDetails", isAunticatedUser, isAunticatedBeautician, paymentTaxController.saveProvinceDetails);
router.post("/saveStripeAccId", isAunticatedUser, isAunticatedBeautician, paymentTaxController.saveStripeAccId);
router.get("/getTaxSetUpStatus", isAunticatedUser, isAunticatedBeautician, paymentTaxController.getTaxSetUpStatus)
router.get("/getTaxProvinceDetails", isAunticatedUser, isAunticatedBeautician, paymentTaxController.getTaxProvinceDetails)

// appointment 
router.post("/addBAppointment", appointmentValidation, isAunticatedUser, appointmentController.addAppointment);
router.post("/updateAppointment/:appId", appointmentValidation, isAunticatedUser, appointmentController.addAppointment);
router.post("/getCalenderAppointmentList", isAunticatedUser, isAunticatedBeautician, appointmentBController.getCalenderAppointmentList);
router.get("/getAppointmentDetails/:appoId", isAunticatedUser, isAunticatedBeautician, appointmentBController.getAppointmentDetails);
router.post("/getAppointmentPreDetails", isAunticatedUser, isAunticatedBeautician, appointmentBController.getAppointmentPreDetails);
router.post("/saveAppointmentDetails", isAunticatedUser, isAunticatedBeautician, appointmentBController.saveAppointmentDetails)
router.put("/handlePastAppointmentStatus", isAunticatedUser, isAunticatedBeautician, appointmentBController.handlePastAppointmentStatus);
router.get("/getAppointmentPaymentDetails/:appoId", isAunticatedUser, isAunticatedBeautician, appointmentBController.getAppointmentPaymentDetails);
router.delete("/cancelAppointment/:appoId", isAunticatedUser, isAunticatedBeautician, appointmentBController.cancelAppointmentByBeautician);
router.get("/getNOShow&CancellationProtection", isAunticatedUser, isAunticatedBeautician, appointmentBController.getNOShowAndCancellationProtection);
router.post("/saveNoShowProtection", isAunticatedUser, isAunticatedBeautician, appointmentBController.saveNoShowProtection);
router.post("/saveCancelProtection", isAunticatedUser, isAunticatedBeautician, appointmentBController.saveCancelProtection);
router.post("/saveBookingSettings", isAunticatedUser, isAunticatedBeautician, appointmentBController.saveBookingSettings);
router.get("/getBookingSettings", isAunticatedUser, isAunticatedBeautician, appointmentBController.getBookingSettings);
router.post("/inviteContacts", validateClientList, isAunticatedUser, isAunticatedBeautician, appointmentBController.inviteContacts);
router.get("/getInvitedClientList", isAunticatedUser, isAunticatedBeautician, appointmentBController.getInvitedClientList);
router.post("/SendAppointmentReminder/:appId", isAunticatedUser, isAunticatedBeautician, appointmentBController.SendAppointmentReminder);
//promotion
router.post("/addPromotion", addPromotionValidation, isAunticatedUser, isAunticatedBeautician, promotionBController.addPromotion);
router.get("/getPromotionList/:promotionFor", isAunticatedUser, isAunticatedBeautician, promotionBController.getPromotionList);
router.get("/getServicesList", isAunticatedUser, isAunticatedBeautician, promotionBController.getServicesList);
router.get("/getProductList", isAunticatedUser, isAunticatedBeautician, promotionBController.getProductList);
router.post("/emailMarketing", isAunticatedUser, isAunticatedBeautician, emailMarketingValidation, promotionBController.emailMarketing);

// reports 
router.post("/getBeauticianReports", isAunticatedUser, isAunticatedBeautician, reportController.getBeauticianReports);

//Product routes
router.get("/getInventoryCode", isAunticatedUser, isAunticatedBeautician, productBController.getInventoryCode)
// router.post("/addProductImgs", isAunticatedUser, isAunticatedBeautician, productBController.addProductImgs)
router.post("/addEditProductDetails", isAunticatedUser, isAunticatedBeautician, productBController.addEditProductDetails)
router.put("/editProductDetails/:productPId", isAunticatedUser, isAunticatedBeautician, productPIdValidator, productEditValidator, productBController.addEditProductDetails)
// router.put("/editProductImgs/:productPId", isAunticatedUser, isAunticatedBeautician, productPIdValidator, productBController.addProductImgs)
router.put("/updateSingleProductImg/:productPId", isAunticatedUser, isAunticatedBeautician, productPIdValidator, productBController.updateSingleProductImg);
router.delete("/deleteSingleImg/:productPId", isAunticatedUser, isAunticatedBeautician, productPIdValidator, productBController.deleteSingleImg);
router.get("/getProductDetails/:productPId", isAunticatedUser, isAunticatedBeautician, productPIdValidator, productBController.getProductDetails)
router.delete("/deleteProductDetail/:productPId", isAunticatedUser, isAunticatedBeautician, productPIdValidator, productBController.deleteProductDetail)
router.get("/getBeauticianProductList", isAunticatedUser, isAunticatedBeautician, productBController.getBeauticianProductList)
router.get("/stockRecords", isAunticatedUser, isAunticatedBeautician, productBController.stockRecords)
router.get("/getOrderData", isAunticatedUser, isAunticatedBeautician, productBController.getOrderData)
router.get("/getSingleOrderDetails/:orderId", isAunticatedUser, isAunticatedBeautician, productBController.getSingleOrderDetails)

//client Module 
router.post("/sendEmailInvoice", isAunticatedUser, isAunticatedBeautician, clientBController.sendEmailInvoice);
router.get("/getNotificationList", isAunticatedUser, isAunticatedBeautician, clientBController.getNotificationList);
router.get("/getReviewList", isAunticatedUser, isAunticatedBeautician, clientBController.getReviewList);
router.post("/addReplys", isAunticatedUser, isAunticatedBeautician, clientBController.addReplys);
router.post("/getInvitedClientAppointments", isAunticatedUser, isAunticatedBeautician, clientBController.getInvitedClientAppointments);
router.get("/getPaymentHistory", isAunticatedUser, isAunticatedBeautician, clientBController.getPaymentHistory);
router.get("/getPaymentDetailHistory/:appoId", isAunticatedUser, isAunticatedBeautician, clientBController.getPaymentDetailHistory);
router.post("/addNotes", isAunticatedUser, isAunticatedBeautician, clientBController.addNotes);
router.delete("/deleteClient", isAunticatedUser, isAunticatedBeautician, clientBController.deleteClient);
router.get("/getSingleClientReview", isAunticatedUser, isAunticatedBeautician, clientBController.getSingleClientReview);
router.get("/getOrderedProducts/:clientId", isAunticatedUser, isAunticatedBeautician, clientBController.getOrderedProducts);

// Brand routes
router.post("/addToMyFavoritesBrand", isAunticatedUser, isAunticatedBeautician, brandBController.addToMyFavorites);
router.post("/removeBrandFromFavorites", isAunticatedUser, isAunticatedBeautician, brandBController.removeBrandFromFavorites);
router.get("/favBrandsList", isAunticatedUser, isAunticatedBeautician, brandBController.getFavBrandList);
router.get("/getSingleBrandDetails/:brandId", isAunticatedUser, isAunticatedBeautician, brandBController.getSingleBrandDetails);
router.post("/findBeautiBrandsProducts", isAunticatedUser, isAunticatedBeautician, brandBController.findBeautiBrandsProducts);
router.post("/getBeautiFilterBrand", isAunticatedUser, isAunticatedBeautician, brandBController.getBeautiFilterBrand);
router.get("/getBeautiRecentSearchBrand", isAunticatedUser, isAunticatedBeautician, brandBController.getBeautiRecentSearchBrand);
router.post("/beautiAddToFavoritesBrandProducts", isAunticatedUser, isAunticatedBeautician, brandBController.beautiAddToFavoritesBrandProducts);
router.get("/getSingleBaeutiBrandProduct/:productId", isAunticatedUser, isAunticatedBeautician, brandBController.getSingleBaeutiBrandProduct);
router.get("/getAllBeautiCategoryBrands", isAunticatedUser, isAunticatedBeautician, brandBController.getAllBeautiCategoryBrands);
router.get("/categoryWiseBrands/:categoryId", isAunticatedUser, isAunticatedBeautician, brandBController.categoryWiseBrands);


module.exports = router;
