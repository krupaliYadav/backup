const { helpCenterController } = require("../controller");
const { isAuthenticateAdmin, isAunticatedUser } = require("../middleware/auth");

const router = require("express").Router();


//FAQ
router.get("/getFAQList/:useFor", helpCenterController.getFAQList);
router.post("/addFAQ", isAuthenticateAdmin, helpCenterController.addFAQ);
router.delete("/deleteFAQ/:faqId", isAuthenticateAdmin, helpCenterController.deleteFAQ)

//feedback 
router.post("/addFeedback/:useFor", isAunticatedUser, helpCenterController.addFeedback);
router.get("/getFeedBackList/:useFor", isAuthenticateAdmin, helpCenterController.getFeedBackList);


//Contact us 
router.post("/addHelpContact/:useFor", isAunticatedUser, helpCenterController.addHelpContact);
router.get("/getContactUserList/:useFor", isAuthenticateAdmin, helpCenterController.getContactUserList);

//
router.post("/callToCustomerCare/:useFor",isAunticatedUser,helpCenterController.callToCustomerCare);

module.exports = router;