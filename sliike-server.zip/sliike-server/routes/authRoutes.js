const router = require("express").Router();

// const { Signup, sendOtp, verifyOtp, SignIn,forgotPassword, resetPassword,verifyresetOtp, adminSignIn, adminSingUp, switchUserAccount } 

const { authController, adminAuthController } = require("../controller");
const { isAunticatedUser } = require("../middleware/auth");
const { regiserValidation, SingInValidation, adminSignupValidation, socialLoginValidation } = require("../middleware/validations");


//for user
router.post("/getBusinessName", authController.getBusinessName);
router.post("/Signup", regiserValidation, authController.Signup);
router.post("/sendOtp", authController.sendOtp);
router.post("/verifyOtp", authController.verifyOtp);
router.post("/Signin", SingInValidation, authController.SignIn);
router.post("/forgotPassword", authController.forgotPassword);
router.post("/verifyResetCode", authController.verifyresetOtp);
router.post("/resetPassword", authController.resetPassword);
router.post("/handleLogOut", isAunticatedUser, authController.handleLogOut);
router.post("/socialLogin", authController.socialLogin);


//for switch user 
router.post("/switch-account/:role", isAunticatedUser, authController.switchUserAccount);


//for admin 
router.post("/admin-signUp", adminSignupValidation, adminAuthController.adminSingUp);
router.post("/admin-signIn", SingInValidation, adminAuthController.adminSignIn);


module.exports = router;
