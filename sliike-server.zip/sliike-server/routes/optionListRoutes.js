const { optionController, demographyController, packageController, provinceController } = require("../controller");
const { isAuthenticateAdmin } = require("../middleware/auth");
const { serviceTypeValidation } = require("../middleware/validations");

const router = require("express").Router();

router.get("/fetchServiceCategories", optionController.fetchServiceCategories)
router.post("/addServiceCategory", isAuthenticateAdmin, optionController.addServiceCategoryOpt);
router.put("/updateServiceCategory/:serviceCategoryId", isAuthenticateAdmin, optionController.updateServiceCategoryOpt);
router.get("/getSingleCategory/:categoryId", isAuthenticateAdmin, optionController.getSingleCategory);
router.delete("/deleteServiceCategory", isAuthenticateAdmin, optionController.deleteServiceCategoryOpt);

router.post("/fetchServiceWithList", optionController.fetchServiceWithList);
router.get("/fetchServiceTypes/:serviceCategoryId", optionController.fetchServiceTypes);
router.post("/addServiceType", serviceTypeValidation, isAuthenticateAdmin, optionController.addServiceTypeOpt);
router.put("/updateServiceType/:serviceId", serviceTypeValidation, isAuthenticateAdmin, optionController.updateServiceTypeOpt);
router.delete("/deleteServiceType", isAuthenticateAdmin, optionController.deleteServiceTypeOpt);
//for products
router.get("/getProductCatList", optionController.getProductCatList);
router.post("/addProductCategory", isAuthenticateAdmin, optionController.addProductCategoryOpt);
router.put("/updateProductCategory/:prodId", isAuthenticateAdmin, optionController.updateProductCategory)
router.delete("/deleteProductCategory", isAuthenticateAdmin, optionController.deleteProductCategoryOpt);
//for demography
router.post("/addDemography", isAuthenticateAdmin, demographyController.addDemography);
router.get("/getDemography", demographyController.getAllDemography);
router.put("/updateDemography/:demographyId", isAuthenticateAdmin, demographyController.updateDemography);
router.post("/addAmenity", isAuthenticateAdmin, demographyController.addAndUpdateAmenity);
router.put("/updateAmenity/:amenityId", isAuthenticateAdmin, demographyController.addAndUpdateAmenity);
router.get("/getAmenityList", demographyController.getAmenityList);
router.delete("/deleteAmenity", isAuthenticateAdmin, demographyController.deleteAmenity);
router.post("/addHealthSafety", isAuthenticateAdmin, demographyController.addAndUpdateHealthSafety);
router.put("/updateHealthSafety/:healthId", isAuthenticateAdmin, demographyController.addAndUpdateHealthSafety);
router.get("/getHealthSafetyList", demographyController.getHealthSafetyList);
router.delete("/deleteHealthSafety", isAuthenticateAdmin, demographyController.deleteHealthSafety);
router.delete("/deleteDemography", isAuthenticateAdmin, demographyController.deleteDemography);

//for Packages
router.post("/addPackageDetails", isAuthenticateAdmin, packageController.addPackageDetail);
router.get("/getAllPackageList", packageController.getAllPackageList);
router.put("/updatePackageDetail/:packageId", isAuthenticateAdmin, packageController.updatePackageDetail);

//for Province
router.post("/addProvince", isAuthenticateAdmin, provinceController.addProvince)
router.get("/getProvinceList", provinceController.getProvinceList)
router.post("/updateProvinceList", isAuthenticateAdmin, provinceController.updateProvinceList);
router.delete("/deleteProvince", isAuthenticateAdmin, provinceController.deleteProvince);

// for Brand
router.post("/addBrandCategory", isAuthenticateAdmin, optionController.addBrandCategory);
router.get("/getBrandCategory", optionController.getBrandCategory);
router.put("/updateBrandCategory/:brandId", isAuthenticateAdmin, optionController.updateBrandCategory);
router.delete("/deleteBrandCategory", isAuthenticateAdmin, optionController.deleteBrandCategory);

module.exports = router;