const express = require("express");
const authRoutes = require("./authRoutes");
const beauticianRoutes = require("./beauticianRoutes");
const optionRoutes = require("./optionListRoutes")
const clientRoutes = require("./clientRoutes");
const adminRoutes = require("./adminRoutes");
const helpCenterRoutes = require("./helpRoutes");

const router = express.Router();


router.use('/auth', authRoutes)
router.use('/beautician', beauticianRoutes)
router.use('/option', optionRoutes)
router.use('/client', clientRoutes);
router.use('/admin', adminRoutes)
router.use('/help', helpCenterRoutes)

module.exports = router;
