const router = require("express").Router();

const { clientAController, beauticianAController, adminprofileController, productController, serviceAcontroller, promotionBController, promotionAController, adminNotificationController, brandController, adminsController } = require("../controller");
const { termsController } = require("../controller");
const { isAuthenticateAdmin } = require("../middleware/auth");
const { invitationValidation, termsValidation, addPromotionValidation, pushNotificationValidator, discountValidation, addBrandValidation, businessValidation, updateBeauticianValidation } = require("../middleware/validations");

// for admin profile 
router.get("/getProfile", isAuthenticateAdmin, adminprofileController.getSingleAdmin);
router.post("/changePassword", isAuthenticateAdmin, adminprofileController.changePasswordAdmin);
router.post("/updateProfile", isAuthenticateAdmin, adminprofileController.updateAdminProfile);
router.get("/dashbordSummary", adminprofileController.dashbordSummary);
router.get("/getPeriodicBusinessBarChart", isAuthenticateAdmin, adminprofileController.getPeriodicBusinessBarChart)
router.get("/getRegisteredBarChart", isAuthenticateAdmin, adminprofileController.getRegisteredBarChart)
router.get("/getPeriodicFinancialBarChart", isAuthenticateAdmin, adminprofileController.getPeriodicFinancialBarChart)
router.get("/getActiveInactiveData/:type", adminprofileController.getActiveInactiveData)

// for Both client and beautician
router.post("/changeStatus", isAuthenticateAdmin, beauticianAController.changeStatus);
router.post("/changeArchive", isAuthenticateAdmin, beauticianAController.changeArchive);

//for Beautician
router.post("/getAllBeautician", beauticianAController.getAllBeautician);
router.post("/updateRecomandedStatus", isAuthenticateAdmin, beauticianAController.updateRecomandedStatus);
router.post("/sendInvtaion", invitationValidation, isAuthenticateAdmin, beauticianAController.sendInvtaion);
router.get("/getSingleBeautician/:beauticianId", beauticianAController.getSingleBeautician);
router.delete("/removeBeautician/:beauticianId", beauticianAController.deleteBeautician);
router.post("/beauticianReports", beauticianAController.beauticianReports);
router.post("/beauticianDashboard", beauticianAController.beauticianDashboard);
router.post("/changeMultipleStatus", beauticianAController.changeMultipleStatus);
router.post("/addBeauticianBusinessDetails", businessValidation, beauticianAController.addBeauticianBusinessDetails);
router.post("/addBeauticianBusinessType", beauticianAController.addBeauticianBusinessType);
router.post("/addBeauticianServices", beauticianAController.addBeauticianServices);
router.post("/addBeauticianWorkingHours", beauticianAController.addBeauticianWorkingHours);
router.post("/productSalesReports", isAuthenticateAdmin, beauticianAController.productSalesReports);
router.get("/getDetailsOfBeautician/:beauticianId", isAuthenticateAdmin, beauticianAController.getDetailsOfBeautician);
router.post("/updateBeautician/:beauticianId", isAuthenticateAdmin, updateBeauticianValidation, beauticianAController.updateBeautician);

//for Services
router.post("/getAllServices", serviceAcontroller.getServicesDetails);
router.post("/getServiceDashboard", serviceAcontroller.getServiceDashboard)

// for Clients
router.post("/getAllClient", clientAController.getAllClient);
router.post("/getSingleClient", clientAController.getSingleClient);
router.post("/getClientSalesSummary", isAuthenticateAdmin, clientAController.getClientSalesSummary);
router.delete("/removeClient/:clientId", isAuthenticateAdmin, clientAController.removeClient);

//for terms
router.post("/addTerms", isAuthenticateAdmin, termsValidation, termsController.addTerms);
router.post("/getTerms", termsController.getTerms);
router.post("/getTermsAndPolicy", termsController.getTermsAndPolicy);
router.put("/updateTerms/:Id", termsController.updateTerms);

//for promotion 
router.get("/getBusinessNameList", isAuthenticateAdmin, promotionAController.getBusinessNameList)
router.get("/getPromotionList/:time", isAuthenticateAdmin, promotionAController.getPromotionList)
router.post("/addPromotion", addPromotionValidation, isAuthenticateAdmin, promotionBController.addPromotion)
router.get("/getServicesList/:beauticianId", isAuthenticateAdmin, promotionBController.getServicesList)
router.get("/getProductList/:beauticianId", isAuthenticateAdmin, promotionBController.getProductList)
// for get referrals 
router.get("/getReferrals", promotionAController.getReferrals);
router.get("/getRecipients/:referralId", promotionAController.getRecipients);

// for pushNotification 
router.post("/addNotification", isAuthenticateAdmin, pushNotificationValidator, adminNotificationController.addNotification);
router.post("/getNotifications", isAuthenticateAdmin, adminNotificationController.getNotifications);
router.put("/updateNotification", isAuthenticateAdmin, pushNotificationValidator, adminNotificationController.updateNotification);
router.get("/getUserJourneyList", isAuthenticateAdmin, adminNotificationController.getUserJourneyList);
router.get("/getAllData", isAuthenticateAdmin, adminNotificationController.getAllData);
// router.get("/getUserJourneyListDetails",isAuthenticateAdmin, adminNotificationController.getUserJourneyListDetails);
router.get("/getClientList", isAuthenticateAdmin, adminNotificationController.getClientList);
router.post("/addDiscount", isAuthenticateAdmin, discountValidation, adminNotificationController.addDiscount);
router.get("/getDiscountList", isAuthenticateAdmin, adminNotificationController.getDiscountList);


// for brand
router.post("/addBrand", isAuthenticateAdmin, brandController.addBrand);
router.post("/addBrandProducts", isAuthenticateAdmin, brandController.addBrandProducts);
router.get("/getBrandDetails/:brandId", brandController.getBrandDetails);
router.post("/completeBrandSteps", isAuthenticateAdmin, brandController.completeBrandSteps);
router.get("/getBrand", isAuthenticateAdmin, brandController.getBrandList);
router.put("/updateBrand/:brandId", isAuthenticateAdmin, brandController.updateBrand);
router.post("/updateStatus/:brandId", isAuthenticateAdmin, brandController.updateStatus);
router.post("/deleteBrand/:brandId", isAuthenticateAdmin, brandController.deleteBrand);
router.post("/getBrandDashboard", isAuthenticateAdmin, brandController.getBrandDashboard);

//for Product
router.put("/updateProductRecomandedStatus", isAuthenticateAdmin, productController.updateProductRecomandedStatus);
router.post("/getProductDashord", productController.getProductDashord);
router.post("/getSingleProductDashboard", productController.getSingleProductDashboard);

// for admins Module
router.post("/addAdmins", isAuthenticateAdmin, adminsController.addAdmin);
router.get("/getAdmins", isAuthenticateAdmin, adminsController.getAdmins);
router.put("/changeAdminStatus", isAuthenticateAdmin, adminsController.changeAdminStatus);
router.put("/chnageAdminProfile", isAuthenticateAdmin, adminsController.chnageAdminProfile);
router.put("/changeSettings", isAuthenticateAdmin, adminsController.changeSettings);

module.exports = router;
