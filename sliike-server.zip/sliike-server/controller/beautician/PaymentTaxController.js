const catchAsyncError = require("../../middleware/catchAsyncError");
const Province = require("../../models/Province");
const Beautician = require("../../models/Beautician");
const { default: mongoose } = require("mongoose");
const HttpStatus = require("../../utils/HttpStatus");
const { createAccountOauth } = require("../../libs/stripe/createAccountOauth");
const ErrorHandler = require("../../utils/ErrorHandling");

const saveProvinceDetails = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { provinceID, isProvinceTaxInfo, GSTNumber, PSTNumber, HSTNumber, QSTNumber } = req.body;
    if (!mongoose.Types.ObjectId.isValid(provinceID)) {
        throw new ErrorHandler("Please Enter valid provoince Id.", HttpStatus.BAD_REQUEST);
    }
    const beauticianDetail = await Beautician.findOne({ userId: id });

    if (beauticianDetail) {
        beauticianDetail.taxProvinceDetails = {};
        const provinceDetails = await Province.aggregate([
            { $match: { _id: new mongoose.Types.ObjectId(provinceID) } },
            {
                $project: {
                    _id: 1,
                    subType: 1,
                    totalTax: { $sum: "$subType.tax" }
                }
            }
        ]);
        req.body.totalTax = 0;
        if (isProvinceTaxInfo == 1) {
            const requiredTaxNumbers = provinceDetails?.[0]?.subType.map(ele => ele.taxName);
            if (requiredTaxNumbers.includes('GST') && !GSTNumber) {
                throw new ErrorHandler(req.t("GSTRequired"), HttpStatus.BAD_REQUEST);
            }
            if (requiredTaxNumbers.includes('PST') && !PSTNumber) {
                throw new ErrorHandler(req.t("PSTRequired"), HttpStatus.BAD_REQUEST);
            }
            if (requiredTaxNumbers.includes('HST') && !HSTNumber) {
                throw new ErrorHandler(req.t("HSTRequired"), HttpStatus.BAD_REQUEST);
            }
            if (requiredTaxNumbers.includes('QST') && !QSTNumber) {
                throw new ErrorHandler(req.t("QSTRequired"), HttpStatus.BAD_REQUEST);
            }
            req.body.totalTax = provinceDetails[0].totalTax;
        }
        beauticianDetail.taxProvinceDetails = req.body;
        await beauticianDetail.save();
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("saveProvinceDetailsSuccess") });

    } else {
        throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST);
    }
});
const getTaxProvinceDetails = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const beauticianDetail = await Beautician.findOne({ userId: id });
    const taxDetails = {
        provinceID: beauticianDetail.taxProvinceDetails.provinceID,
        isProvinceTaxInfo: beauticianDetail.taxProvinceDetails?.isProvinceTaxInfo || false,
        GSTNumber: beauticianDetail.taxProvinceDetails?.GSTNumber || "",
        PSTNumber: beauticianDetail.taxProvinceDetails?.PSTNumber || "",
        HSTNumber: beauticianDetail.taxProvinceDetails?.HSTNumber || "",
        QSTNumber: beauticianDetail.taxProvinceDetails?.QSTNumber || "",
    }
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: taxDetails });

})

// stripe account for beautician
const saveStripeAccId = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { accountID } = req.body;
    const beauticianDetails = await Beautician.findOne({ userId: id });
    if (beauticianDetails) {
        const data = await createAccountOauth({ accountID });
        if (data.status === 200) {
            if (data.result.stripe_user_id) {
                beauticianDetails.stripe_id = data.result.stripe_user_id;
                await beauticianDetails.save();
                return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("saveStripeAccIdSuccess"), data: { isStripeSetUp: true } });
            } else {
                throw new ErrorHandler(req.t("saveStripeAccIdError"), HttpStatus.BAD_REQUEST);
            }
        } else {
            throw new ErrorHandler(data.message, HttpStatus.BAD_REQUEST);
        }
    } else {
        throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST);
    }
})
const getTaxSetUpStatus = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const beauticianDetails = await Beautician.findOne({ userId: id });
    if (beauticianDetails && beauticianDetails.stripe_id) {
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { isStripeSetUp: true } });
    } else {
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { isStripeSetUp: false } });
    }
});

module.exports = { saveProvinceDetails, getTaxProvinceDetails, saveStripeAccId, getTaxSetUpStatus }