const catchAsyncError = require("../../middleware/catchAsyncError");
const formidable = require("formidable");
const fs = require('fs');
const { shareFileEmail } = require("../../utils/emailTeplates");
const HttpStatus = require("../../utils/HttpStatus");
const BeauticianNotification = require("../../models/BeauticianNotification");
const Beautician = require("../../models/Beautician");
const { default: mongoose } = require("mongoose");
const ErrorHandler = require("../../utils/ErrorHandling");
const Rating = require("../../models/Rating");
const InvitedClient = require("../../models/InvitedClient");
const Appointment = require("../../models/Appointment");
const { pathEndpoint } = require("../../utils/Constant");
const platform_fees = process.env.PLATFORM_FEES || 0.10;
const { v4: uuidv4 } = require('uuid');
const { uploadFile } = require("../../libs/aws/uploadImg");
const moment = require("moment");
const Order = require("../../models/Order");

//send email invoice pdf 
const sendEmailInvoice = catchAsyncError(async (req, res, next) => {
    const form = formidable({ multiples: true });
    form.parse(req, async (err, fields, files) => {
        if (err) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("somethingIsWrongInImageUpload") });
        }
        if (files.invoicePdf) {
            const { email, bookingId } = fields;
            if (!bookingId) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t('bookingIdMissing') });
            }
            if (email) {
                const { filepath: tempPath, originalFilename: fileName } = files.invoicePdf;
                const uploadPath = __dirname + '/../../public/' + fileName;
                // Move the file to the upload folder
                fs.copyFile(tempPath, uploadPath, async (err) => {
                    if (err) {
                        return res.status(HttpStatus.ERROR).json({ success: false, message: req.t('UploadFileError') });
                    }
                    // Send email with attachment
                    const data = {
                        email,
                        subject: "Payment Invoice",
                        text: "Your service payment invoice PDF.",
                        filename: `invoice-${bookingId}.pdf`,
                        filePath: uploadPath
                    }
                    await shareFileEmail(data)
                        .then(() => {
                            // Delete the file from the upload folder
                            fs.unlink(uploadPath, (err) => {
                                if (err) {
                                    console.log('Error deleting file:', err);
                                }
                            });
                            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t('sendEmailInvoiceSuccess') });
                        })
                        .catch((err) => {
                            return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: req.t('sendEmailInvoiceError') });
                        });
                });
            } else {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("emailMissing") });
            }
        } else {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("InvoiceMissing") });
        }
    })
});

// get notification list
const getNotificationList = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { limit, offset } = req.query;
    const limitData = parseInt(limit, 10) || 10;
    const offsetData = parseInt(offset, 10) || 0;

    const beauticianData = await Beautician.findOne({ userId: id });

    if (beauticianData) {
        let list = await BeauticianNotification.aggregate([
            {
                $match: { beauticianId: new mongoose.Types.ObjectId(beauticianData._id) }
            },
            { $sort: { createdAt: -1 } },
            {
                $project: { updatedAt: 0, __v: 0 }
            }
        ]);

        const count = list.length;
        list = list.slice(offsetData, limitData + offsetData);

        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { count, list } });
    } else {
        throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST, false)
    }
});

// get review list
const getReviewList = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { limit, offset } = req.query;
    const limitData = parseInt(limit, 10) || 10;
    const offsetData = parseInt(offset, 10) || 0;

    const beauticianData = await Beautician.findOne({ userId: id });
    if (beauticianData) {
        let reviewList = await Rating.aggregate([
            {
                $lookup: {
                    from: 'appointments',
                    localField: 'appointmentId',
                    foreignField: "_id",
                    as: 'appointmentDeatils',
                },
            },
            {
                $lookup: {
                    from: 'beauticians',
                    localField: 'appointmentDeatils.beauticianId',
                    foreignField: "_id",
                    as: 'beauticianDetails',
                },
            },
            {
                $lookup: {
                    from: 'clients',
                    localField: 'appointmentDeatils.clientId',
                    foreignField: "_id",
                    as: 'clientDeatils',
                    pipeline: [
                        {
                            $project: {
                                firstName: 1, lastName: 1,
                                profileImage: {
                                    $ifNull: ["$profileImage", null]
                                },
                            }
                        }
                    ]
                },
            },
            {
                $match: { 'beauticianDetails._id': new mongoose.Types.ObjectId(beauticianData._id) }
            },
            { $sort: { createdAt: -1 } },
            { $project: { __v: 0, appointmentDeatils: 0, beauticianDetails: 0, } }
        ]);

        const count = reviewList.length;
        reviewList = reviewList.slice(offsetData, limitData + offsetData);
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { count, reviewList } });
    } else {
        throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST, false)
    }
});

// add replays on reviews
const addReplys = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { reviewId, message } = req.body;

    if (!mongoose.Types.ObjectId.isValid(reviewId)) throw new ErrorHandler(req._t("validReviewId"), HttpStatus.BAD_REQUEST);


    if (!message) throw new ErrorHandler(req.t("messageMissing"), HttpStatus.BAD_REQUEST);

    const beauticianData = await Beautician.findOne({ userId: id });
    const reviewData = await Rating.findOne({ _id: reviewId });

    if (reviewData) {
        reviewData.replays.unshift({ senderId: beauticianData._id, message });
        await reviewData.save();

        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("addReplaysSuccess") });
    } else {
        throw new ErrorHandler(req.t("reviewNotfound"), HttpStatus.BAD_REQUEST);
    }

});

// get single client details
const getInvitedClientAppointments = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const beauticianData = await Beautician.findOne({ userId: id });
    const { Id, limit, offset, type } = req.body;
    const limitData = parseInt(limit, 10) || 10;
    const offsetData = parseInt(offset, 10) || 0;
    if (!Id) throw new ErrorHandler("Plaese Enter Id ", HttpStatus.BAD_REQUEST);
    if (!mongoose.Types.ObjectId.isValid(Id)) throw new ErrorHandler("Please Enter valid Client Id", HttpStatus.BAD_REQUEST);

    let findQuery = {
        $nor: [
            { createdBy: "client", status: 3, status: 4 }
        ],
        beauticianId: new mongoose.Types.ObjectId(beauticianData._id)
    };
    if (type) {
        if (type === "upcoming") {
            findQuery = { ...findQuery, dateTime: { $gte: new Date() } }
            // findQuery.dateTime = { $gte: new Date().toLocaleString("en-US", { timeZone: "America/New_York" }) }
        } else if (type === "previous") {
            findQuery = { ...findQuery, dateTime: { $lte: new Date() } }
        } else {
            throw new ErrorHandler(req.t("appoimentStatusNotValid"), HttpStatus.BAD_REQUEST);
        }
    }

    let inviteClient = await InvitedClient.aggregate([
        { $match: { clientId: new mongoose.Types.ObjectId(Id) } },
        {
            $lookup: {
                from: 'clients',
                localField: 'clientId',
                foreignField: "_id",
                as: 'clientDetails',
            },
        },
        {
            $lookup: {
                from: 'appointments',
                localField: 'clientId',
                foreignField: "clientId",
                as: 'appointmentDetails',
                pipeline: [
                    {
                        $match: findQuery
                    },
                    { $project: { clientId: 1, serviceId: 1, dateTime: 1, createdBy: 1, endDateTime: 1, price: 1, place: 1, status: 1 } }
                ]
            },
        },
        {
            $lookup: {
                from: 'beauticianservices',
                localField: 'appointmentDetails.serviceId',
                foreignField: "_id",
                as: 'serviceDetails',
                pipeline: [
                    { $project: { serviceType: 1, } }
                ]
            },
        },
        {
            $lookup: {
                from: 'servicetypelists',
                localField: 'serviceDetails.serviceType',
                foreignField: "_id",
                as: 'typeDetails',
            },
        },
        {
            $lookup: {
                from: 'appointments',
                localField: 'clientId',
                foreignField: "clientId",
                as: 'noshowAppo',
                pipeline: [
                    {
                        $match:
                        {
                            $and: [{
                                $nor: [
                                    { createdBy: "client", status: 0, }
                                ],
                                status: 5,
                                beauticianId: new mongoose.Types.ObjectId(beauticianData._id)
                            }]
                        },
                    },
                    { $project: { serviceId: 1, dateTime: 1, endDateTime: 1, price: 1, place: 1, status: 1 } }
                ]
            },
        },
        {
            $lookup: {
                from: 'appointments',
                localField: 'clientId',
                foreignField: "clientId",
                as: 'cancelApo',
                pipeline: [
                    {
                        $match: {
                            $and: [{
                                $nor: [
                                    { createdBy: "client", status: 0 },
                                ],
                                status: { $in: [3, 4] },
                                beauticianId: new mongoose.Types.ObjectId(beauticianData._id)
                            }]
                        }
                    },
                    { $project: { serviceId: 1, dateTime: 1, endDateTime: 1, price: 1, place: 1, status: 1 } }
                ]
            },
        },
        {
            $lookup: {
                from: 'appointments',
                localField: 'clientId',
                foreignField: "clientId",
                as: 'totalApo',
                pipeline: [
                    {
                        $match: {
                            $and: [{
                                $nor: [
                                    { createdBy: "client", status: 0 }
                                ],
                                beauticianId: new mongoose.Types.ObjectId(beauticianData._id)
                            }]
                        }
                    },
                    { $project: { serviceId: 1, dateTime: 1, endDateTime: 1, price: 1, place: 1, status: 1 } }
                ]
            },
        },
        {
            $lookup: {
                from: 'appointments',
                localField: 'clientId',
                foreignField: "clientId",
                as: 'lastAppoDate',
                pipeline: [
                    { $match: { createdBy: "client", beauticianId: new mongoose.Types.ObjectId(beauticianData._id) } },
                    { $sort: { dateTime: -1 }, },
                    { $limit: 1 },
                    { $project: { dateTime: 1 } }
                ]
            },
        },
        {
            $addFields: { cancellation: { $size: "$cancelApo" } }
        },
        {
            $addFields: { noShows: { $size: "$noshowAppo" } }
        },
        {
            $addFields: { TotalApo: { $size: "$totalApo" } }
        },
        {
            $project: {
                paymentApo: 1, paymentData: 1,
                phoneNubWithFormat: 1, phoneNumber: 1, TotalApo: 1, noShows: 1, cancellation: 1,
                note: {
                    $ifNull: ["$note", null]
                },
                attachFile: 1, lastAppoDate: 1,
                typeDetails: 1,
                appointmentData: {
                    $map: {
                        input: "$appointmentDetails",
                        as: "appointment",
                        in: {
                            $mergeObjects: [
                                "$$appointment",
                                {
                                    serviceDetails: {
                                        $arrayElemAt: [{
                                            $filter: {
                                                input: "$serviceDetails",
                                                as: "serviceData",
                                                cond: { $eq: ["$$serviceData._id", "$$appointment.serviceId"] }
                                            }
                                        }, 0]
                                    },
                                }
                            ]
                        }
                    },
                },
            }
        },
    ]);
    if (!inviteClient.length) throw new ErrorHandler(req.t("invitedClientNotFound"), HttpStatus.BAD_REQUEST);

    const count = inviteClient[0].appointmentData.length;

    inviteClient[0].appointmentData.forEach(appData => {
        inviteClient[0].typeDetails.forEach(service => {
            if (service._id.equals(appData.serviceDetails.serviceType)) {
                appData.serviceDetails.serviceTypeName = service.serviceTypeName
            }
        })
    });
    // inviteClient[0].appointmentData = inviteClient[0].appointmentData.slice(offsetData, limitData + offsetData);

    const totalRevenue = await InvitedClient.aggregate([
        { $match: { clientId: new mongoose.Types.ObjectId(Id) } },
        {
            $lookup: {
                from: 'clients',
                localField: 'clientId',
                foreignField: "_id",
                as: 'clientDetails',
            },
        },
        {
            $lookup: {
                from: 'appointments',
                localField: 'clientId',
                foreignField: "clientId",
                as: 'paymentApo',
                pipeline: [
                    {
                        $match: {
                            $and: [{
                                $nor: [
                                    { createdBy: "client", status: 2 }
                                ],
                                beauticianId: new mongoose.Types.ObjectId(beauticianData._id)
                            }]
                        }
                    },
                    { $project: { paymentDetails: 1, price: 1 } }
                ]
            },
        },
        {
            $lookup: {
                from: 'payments',
                localField: 'paymentApo.paymentDetails',
                foreignField: "_id",
                pipeline: [
                    {
                        $project: {
                            createdAt: 1, BookingId: 1, subTotal: 1, GstInPer: 1, PstInPer: 1, QstInPer: 1, HstInPer: 1,
                            discount: 1, GST: 1, PST: 1, QST: 1, HST: 1, TotalPrice: 1,
                        }
                    }
                ],
                as: 'paymentData',
            },
        },
        { $match: { paymentData: { $gt: [] } } },
        {
            $project: { paymentApo: 1, paymentData: 1, discount: 1, }
        }
    ]);

    if (totalRevenue.length) {
        let priceTemp = 0;
        totalRevenue[0].paymentApo.forEach((val) => {
            totalRevenue[0].paymentData.forEach((ele) => {
                totalRevenue[0].totalPrice = 0;
                if (ele._id.equals(val.paymentDetails)) {

                    let GST = (val.price * ele.GstInPer) / 100;
                    let HST = (val.price * ele.HstInPer) / 100;
                    let QST = (val.price * ele.QstInPer) / 100;
                    let PST = (val.price * ele.PstInPer) / 100;
                    let discount = (val.price * ele.discount) / 100;

                    let temp = val.price + GST + HST + QST + PST - discount;

                    priceTemp += temp;
                }
            })
        });
        totalRevenue[0].totalPrice = priceTemp;
        inviteClient[0].totalRevenue = totalRevenue[0].totalPrice;
    }

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, count, inviteClient });
});

// get payment history of particular client
const getPaymentHistory = catchAsyncError(async (req, res) => {
    const { Id, limit, offset } = req.query;

    const limitData = parseInt(limit, 10) || 10;
    const offsetData = parseInt(offset, 10) || 0;

    if (!Id) throw new ErrorHandler("Plaese Enter Id ", HttpStatus.BAD_REQUEST);
    if (!mongoose.Types.ObjectId.isValid(Id)) throw new ErrorHandler("Please Enter valid Client Id", HttpStatus.BAD_REQUEST);

    let paymentDetails = await InvitedClient.aggregate([
        { $match: { clientId: new mongoose.Types.ObjectId(Id) } },
        {
            $lookup: {
                from: 'appointments',
                localField: 'clientId',
                foreignField: "clientId",
                as: 'appointmentDetails',
                pipeline: [
                    {
                        $match: {
                            $and:
                                [{
                                    $nor: [
                                        { createdBy: "client", status: 0, }
                                    ]
                                }],
                        }
                    },
                    { $project: { dateTime: 1, serviceId: 1, endDateTime: 1, price: 1, place: 1, status: 1 } }
                ]
            },
        },
        {
            $lookup: {
                from: 'beauticianservices',
                localField: 'appointmentDetails.serviceId',
                foreignField: "_id",
                as: 'serviceDetails',
                pipeline: [
                    { $project: { serviceType: 1, } }
                ]
            },
        },
        {
            $lookup: {
                from: 'servicetypelists',
                localField: 'serviceDetails.serviceType',
                foreignField: "_id",
                as: 'typeDetails',
            },
        },
        {
            $project: {
                typeDetails: 1,
                appointmentData: {
                    $map: {
                        input: "$appointmentDetails",
                        as: "appointment",
                        in: {
                            $mergeObjects: [
                                "$$appointment",
                                {
                                    serviceDetails: {
                                        $arrayElemAt: [{
                                            $filter: {
                                                input: "$serviceDetails",
                                                as: "serviceData",
                                                cond: { $eq: ["$$serviceData._id", "$$appointment.serviceId"] }
                                            }
                                        }, 0]
                                    },
                                }
                            ]
                        }
                    },
                },
            }
        },
    ]);

    let count = 0
    if (paymentDetails.length) {
        if (paymentDetails[0]?.appointmentData.length)
            paymentDetails[0]?.appointmentData?.forEach(appData => {
                paymentDetails[0]?.typeDetails?.forEach(service => {
                    if (service._id.equals(appData.serviceDetails.serviceType)) {
                        appData.serviceDetails.serviceTypeName = service.serviceTypeName;
                    }
                })
                count = paymentDetails[0].appointmentData.length;
            });
    }
    // paymentDetails[0].appointmentData = paymentDetails[0].appointmentData.slice(offsetData, limitData + offsetData);

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: false, count, paymentDetails });
});

// get payment history details of particulat client
const getPaymentDetailHistory = catchAsyncError(async (req, res, next) => {
    const { appoId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(appoId)) throw new ErrorHandler("Please Enter valid Appoiment Id", HttpStatus.BAD_REQUEST);

    let paymentData = await Appointment.aggregate([
        { $match: { _id: new mongoose.Types.ObjectId(appoId) } },
        {
            $lookup: {
                from: 'beauticians',
                localField: 'beauticianId',
                foreignField: "_id",
                as: 'beauticianDetails',
                pipeline: [
                    { $project: { firstName: 1, lastName: 1, businessName: 1 } }
                ]
            },
        },
        {
            $lookup: {
                from: 'beauticianservices',
                localField: 'serviceId',
                foreignField: "_id",
                as: 'serviceDetails',
                pipeline: [
                    { $project: { serviceType: 1 } }
                ]
            },
        },
        {
            $lookup: {
                from: 'servicetypelists',
                localField: 'serviceDetails.serviceType',
                foreignField: "_id",
                as: 'typeDetails',
                pipeline: [
                    { $project: { serviceTypeName: 1, serviceTypeName_fr: 1, } }
                ]
            },
        },
        {
            $lookup: {
                from: 'payments',
                localField: 'paymentDetails',
                foreignField: "_id",
                as: 'paymentDetails',
                pipeline: [
                    { $project: { BookingId: 1, createdAt: 1, addressId: 1, discount: 1, GstInPer: 1, PstInPer: 1, HstInPer: 1, QstInPer: 1 } }
                ]
            },
        },
        // { $match: { paymentDetails: { $gt: [] } } },
        {
            $lookup: {
                from: 'addresses',
                localField: 'paymentDetails.addressId',
                foreignField: "_id",
                as: 'addressDetails',
                pipeline: [
                    { $project: { address: 1, street: 1, apartment: 1 } }
                ]
            },
        },
        {
            $addFields: {
                discount: { $round: [{ $multiply: ["$price", { $first: "$paymentDetails.discount" }, 0.01] }, 2] },
                GST: { $round: [{ $multiply: ['$price', { $first: "$paymentDetails.GstInPer" }, 0.01] }, 2] },
                HST: { $round: [{ $multiply: ['$price', { $first: "$paymentDetails.HstInPer" }, 0.01] }, 2] },
                QST: { $round: [{ $multiply: ['$price', { $first: "$paymentDetails.QstInPer" }, 0.01] }, 2] },
                PST: { $round: [{ $multiply: ['$price', { $first: "$paymentDetails.PstInPer" }, 0.01] }, 2] },
                // gstORhst: { $sum: [{ $round: [{ $multiply: ['$price', { $first: "$paymentDetails.GstInPer" }, 0.01] }, 2] }, { $round: [{ $multiply: ['$price', { $first: "$paymentDetails.HstInPer" }, 0.01] }, 2] }] },
                // pstORqst: { $sum: [{ $round: [{ $multiply: ['$price', { $first: "$paymentDetails.PstInPer" }, 0.01] }, 2] }, { $round: [{ $multiply: ['$price', { $first: "$paymentDetails.QstInPer" }, 0.01] }, 2] }] },
            }
        },
        {
            $project: {
                dateTime: 1, endDateTime: 1, price: 1, place: 1, status: 1, paymentDetails: 1, beauticianDetails: 1, addressDetails: 1, typeDetails: 1,
                discount: 1, GST: 1, HST: 1, QST: 1, PST: 1

            }
        }
    ]);
    if (!paymentData.length) throw new ErrorHandler("Please Enter valid Appointment Id", HttpStatus.BAD_REQUEST);

    const totalTemp = paymentData[0].price + paymentData[0].GST + paymentData[0].HST + paymentData[0].QST + paymentData[0].PST - paymentData[0].discount;
    const subTotal = paymentData[0].price - paymentData[0].discount;
    paymentData[0].Total = totalTemp;
    paymentData[0].subTotal = subTotal;

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, paymentData });
});

// For add notes realted particular client
const addNotes = catchAsyncError(async (req, res, next) => {
    const form = formidable({ multiples: true });
    try {
        form.parse(req, async (err, fields, files) => {
            const { Id, note } = fields;
            if (!mongoose.Types.ObjectId.isValid(Id)) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please enter valid client Id" });
            }
            if (!note) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("noteMissing") });
            const invitationData = await InvitedClient.findOne({ clientId: Id });

            if (invitationData) {
                // if (invitationData.note == null) {
                invitationData.note = note;
                if (files.attachFile) {
                    const imgName = files.attachFile.originalFilename.split(".");
                    const extension = imgName[imgName.length - 1];

                    // if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                    //     return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: `${extension} is not allowed..` });
                    // }
                    const fileName = (files.attachFile.originalFilename = uuidv4() + "." + extension);
                    const newPath = `${pathEndpoint.noteFile}${fileName}`;
                    try {
                        const uploadImgRes = await uploadFile(files.attachFile, newPath, extension);

                        invitationData.attachFile = uploadImgRes.imageUrl;
                        await invitationData.save();
                    } catch (error) {
                        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: req.t('somethingIsWrongInImageUpload') });
                    }
                }
                await invitationData.save();
                return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("addNotesSuccess") });
                // } else {
                //     return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "You already added note for this client" });
                // }
            } else {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("clientNotFound") });
            }

        })
    } catch (error) {
    }
});

// For Edit note deatils 
const deleteClient = catchAsyncError(async (req, res, next) => {
    const { invitationId } = req.body;
    if (!mongoose.Types.ObjectId.isValid(invitationId)) {
        throw new ErrorHandler("Please enter valid client Id", HttpStatus.BAD_REQUEST, false);
    }

    const invitedClientData = await InvitedClient.findOne({ _id: invitationId });

    if (invitedClientData) {
        invitedClientData.isDeleted = 1;
        await invitedClientData.save();
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("deleteClientSuccess") });
    } else {
        throw new ErrorHandler(req.t("clientNotFound"), HttpStatus.BAD_REQUEST, false);
    }
});

// Get single client review 
const getSingleClientReview = catchAsyncError(async (req, res, next) => {
    const { clientId, limit, offset } = req.query;
    const limitData = parseInt(limit, 10) || 10;
    const offsetData = parseInt(offset, 10) || 0;

    if (!mongoose.Types.ObjectId.isValid(clientId)) {
        throw new ErrorHandler("Please enter valid client Id", HttpStatus.BAD_REQUEST, false);
    }

    const invitedClientData = await InvitedClient.findOne({ clientId: clientId });
    if (invitedClientData) {
        let reviewList = await Rating.aggregate([
            {
                $lookup: {
                    from: 'appointments',
                    localField: 'appointmentId',
                    foreignField: "_id",
                    as: 'appointmentDeatils',
                },
            },
            {
                $lookup: {
                    from: 'clients',
                    localField: 'appointmentDeatils.clientId',
                    foreignField: "_id",
                    as: 'clientDeatils',
                    pipeline: [
                        {
                            $project: {
                                firstName: 1, lastName: 1,
                                profileImage: {
                                    $ifNull: ["$profileImage", null]
                                },
                            }
                        }
                    ]
                },
            },
            {
                $match: { 'clientDeatils._id': new mongoose.Types.ObjectId(clientId) }
            },
            { $project: { __v: 0, appointmentDeatils: 0, updatedAt: 0 } }
        ]);

        const count = reviewList.length;
        // reviewList = reviewList.slice(offsetData, limitData + offsetData);
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { count, reviewList } });
    } else {
        throw new ErrorHandler(req.t("clientNotFound"), HttpStatus.BAD_REQUEST, false);
    }
});

// get product details
const getOrderedProducts = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { clientId } = req.params;
    const beauticianData = await Beautician.findOne({ userId: id });
    if (beauticianData) {
        if (!mongoose.Types.ObjectId.isValid(clientId)) throw new ErrorHandler("Please Enter valid Client Id", HttpStatus.BAD_REQUEST);

        const productDetails = await Order.aggregate([
            { $match: { clientId: new mongoose.Types.ObjectId(clientId), "productData.beauticianId": new mongoose.Types.ObjectId(beauticianData._id) } },
            { $unwind: "$productData" }
            , {
                $lookup: {
                    from: 'beauticianproducts',
                    localField: 'productData.productId',
                    foreignField: "_id",
                    as: 'produts',
                    pipeline: [
                        { $project: { productName: 1, beauticianId: 1, imgName: 1, } }
                    ]
                },
            },
            {
                $project: {
                    productName: {
                        $arrayElemAt: ['$produts.productName', 0]
                    },
                    productImages: {
                        $arrayElemAt: ['$produts.imgName', 0]
                    },
                    productPrice: {
                        $ifNull: ['$productData.price', 0]
                    },
                    productQuanity: {
                        $ifNull: ['$productData.totalQuantity', 0]
                    }

                }
            }
        ]);

        if (productDetails.length) {
            productDetails.forEach((val) => {
                val.totalPrice = val.productPrice * val.productQuanity
            })
        }
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, productDetails })
    } else {
        throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST, false);
    }
});

module.exports = { sendEmailInvoice, getNotificationList, getReviewList, addReplys, getInvitedClientAppointments, getPaymentHistory, getPaymentDetailHistory, addNotes, deleteClient, getSingleClientReview, getOrderedProducts }