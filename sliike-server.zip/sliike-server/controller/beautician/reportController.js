const moment = require("moment");
const catchAsyncError = require("../../middleware/catchAsyncError");
const ErrorHandler = require("../../utils/ErrorHandling");
const HttpStatus = require("../../utils/HttpStatus");
const Appointment = require("../../models/Appointment");
const { default: mongoose } = require("mongoose");
const BeauticianService = require("../../models/BeauticianService");
const Beautician = require("../../models/Beautician");
const Order = require("../../models/Order");
const BeauticianProduct = require("../../models/BeauticianProduct");
const platform_fees = process.env.PLATFORM_FEES || 0.10;

const monthCounts = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nav",
    "Dec",
];

const getTopServices = async (beauticianId, sliceLength) => {
    //for top services
    let TopServices = await BeauticianService.aggregate([
        {
            $match: { beauticianId: new mongoose.Types.ObjectId(beauticianId) },
        },
        {
            $lookup: {
                from: 'servicetypelists',
                localField: 'serviceType',
                foreignField: "_id",
                as: 'serviceTypeData',
            },
        },
        {
            $lookup: {
                from: 'appointments',
                localField: '_id',
                foreignField: 'serviceId',
                as: 'appointments',
                pipeline: [
                    { $match: { $nor: [{ createdBy: "client", status: 0 }] } },
                    { $project: { dateTime: 1, serviceId: 1 } }
                ]
            }
        },
        { $project: { _id: 1, appointments: 1, serviceTypeName: { $first: '$serviceTypeData.serviceTypeName' }, serviceTypeName_fr: { $first: '$serviceTypeData.serviceTypeName_fr' } } }
    ]);

    let TopProducts = await BeauticianProduct.aggregate([
        {
            $match: { beauticianId: new mongoose.Types.ObjectId(beauticianId) },
        },
        {
            $lookup: {
                from: 'orders',
                localField: '_id',
                foreignField: 'productData.productId',
                as: 'orderDetails',
                pipeline: [
                    { $match: { $nor: [{ createdBy: "client", status: 0 }] } },
                    { $project: { dateTime: 1, serviceId: 1 } }
                ]
            }
        },
        { $project: { _id: 1, orderDetails: 1, productName: 1, imgName: 1 } }
    ]);

    if (TopProducts.length) {

        const currentMonthStart = moment().startOf('month').format('YYYY-MM-DD');
        const currentMonthEnd = moment().endOf('month').format('YYYY-MM-DD');
        const lastMonthStart = moment().subtract(1, 'months').startOf('month').format('YYYY-MM-DD');
        const lastMonthEnd = moment().subtract(1, 'months').endOf('month').format('YYYY-MM-DD');
        TopProducts = TopProducts.map(product => {
            product.currentMonth = 0;
            product.lastMonth = 0;
            product.orderDetails?.forEach(ele => {
                let formateDate = moment(ele.dateTime).format("YYYY-MM-DD")
                if (formateDate >= currentMonthStart && formateDate <= currentMonthEnd) {
                    product.currentMonth = product.currentMonth + 1
                }
                if (formateDate >= lastMonthStart && formateDate <= lastMonthEnd) {
                    product.lastMonth = product.lastMonth + 1
                }
            });
            return {
                id: product._id,
                productName: product.productName,
                productImages: product.imgName,
                currentMonth: product.currentMonth,
                lastMonth: product.lastMonth,
            }
        }).sort((a, b) => {
            return (b.currentMonth + b.lastMonth) - (a.currentMonth + a.lastMonth);
        }).slice(0, 3);
    }

    if (TopServices.length) {

        const currentMonthStart = moment().startOf('month').format('YYYY-MM-DD');
        const currentMonthEnd = moment().endOf('month').format('YYYY-MM-DD');
        const lastMonthStart = moment().subtract(1, 'months').startOf('month').format('YYYY-MM-DD');
        const lastMonthEnd = moment().subtract(1, 'months').endOf('month').format('YYYY-MM-DD');
        TopServices = TopServices.map(service => {
            service.currentMonth = 0;
            service.lastMonth = 0;
            service.appointments?.forEach(ele => {
                let formateDate = moment(ele.dateTime).format("YYYY-MM-DD")
                if (formateDate >= currentMonthStart && formateDate <= currentMonthEnd) {
                    service.currentMonth = service.currentMonth + 1
                }
                if (formateDate >= lastMonthStart && formateDate <= lastMonthEnd) {
                    service.lastMonth = service.lastMonth + 1
                }
            });
            return {
                id: service._id,
                serviceTypeName: service.serviceTypeName,
                currentMonth: service.currentMonth,
                lastMonth: service.lastMonth,
            }
        }).sort((a, b) => {
            return (b.currentMonth + b.lastMonth) - (a.currentMonth + a.lastMonth);
        }).slice(0, sliceLength);
    }
    return { TopServices, TopProducts }
}

const getAppointCountByYearForBarChart = async (beauticianId, year) => {
    const appointments = await Appointment.find({
        beauticianId: new mongoose.Types.ObjectId(beauticianId),
        $nor: [
            { createdBy: "client", status: 0 }
        ],
        step: 2
    });

    const orders = await Order.find({
        "productData.beauticianId": new mongoose.Types.ObjectId(beauticianId),
        paymentStatus: 1
    });

    let servicesValue = [], productValue = []

    if (appointments.length || orders.length) {
        const currentYear = year || moment().year();
        for (let month = 0; month < 12; month++) {
            const startDate = moment().year(currentYear).month(month).startOf('month').format('YYYY-MM-DD');
            const endDate = moment().year(currentYear).month(month).endOf('month').format('YYYY-MM-DD');

            // Filter appointments within the current month
            const appointmentsData = appointments.filter(ele => {
                let formateDate = moment(ele.dateTime).format("YYYY-MM-DD")
                return formateDate >= startDate && formateDate <= endDate
            });

            // filter orders within the current month
            const orderCount = orders.filter((val) => {
                let formateDate = moment(val.createdAt).format("YYYY-MM-DD")
                return formateDate >= startDate && formateDate <= endDate
            })

            // Count the appointments for the current month
            const count = appointmentsData.length;
            const productCount = orderCount.length;
            // Store the count in the servicesValue array
            servicesValue.push(count);
            productValue.push(productCount);
        }
    }
    // if (appointments.length) {
    //     const currentYear = year || moment().year();
    //     for (let month = 0; month < 12; month++) {
    //         const startDate = moment().year(currentYear).month(month).startOf('month').format('YYYY-MM-DD');
    //         const endDate = moment().year(currentYear).month(month).endOf('month').format('YYYY-MM-DD');
    //         // Filter appointments within the current month
    //         const appointmentsData = appointments.filter(ele => {
    //             let formateDate = moment(ele.dateTime).format("YYYY-MM-DD")
    //             return formateDate >= startDate && formateDate <= endDate
    //         })
    //         // Count the appointments for the current month
    //         const count = appointmentsData.length;
    //         // Store the count in the monthCounts array
    //         monthCounts.push(count);
    //     }
    // }
    // if (orders.length) {
    //     const currentYear = year || moment().year();
    //     for (let month = 0; month < 12; month++) {
    //         const startDate = moment().year(currentYear).month(month).startOf('month').format('YYYY-MM-DD');
    //         const endDate = moment().year(currentYear).month(month).endOf('month').format('YYYY-MM-DD');
    //         // Filter appointments within the current month
    //         const orderData = orders.filter(ele => {
    //             let formateDate = moment(ele.createdAt).format("YYYY-MM-DD")
    //             return formateDate >= startDate && formateDate <= endDate
    //         })
    //         // Count the appointments for the current month
    //         const count = orderData.length;
    //         // Store the count in the monthCounts array
    //         monthCounts.push(count);
    //     }
    // }

    return { productValue, servicesValue }
}
const getBeauticianReports = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { date, appoLimit, appoOffset } = req.body;
    let offsetData = appoOffset || 0;
    let limitData = appoLimit || 4;
    let appointActivity = { totalAppointment: 0, completed: 0, notCompleted: 0, cancelled: 0, noShowStatus: 0 };
    if (!moment(date, "YYYY-MM-DD").isValid()) {
        throw new ErrorHandler("Invalid date formate.", HttpStatus.BAD_REQUEST, false);
    }
    const beauticianData = await Beautician.findOne({ userId: id })
    const appointmentList = await Appointment.aggregate([
        {
            $match: {
                beauticianId: new mongoose.Types.ObjectId(beauticianData._id),
                $nor: [
                    { createdBy: "client", status: 0 }
                ],
                step: 2,
                $expr: {
                    $and: [
                        { $gte: [{ $dateToString: { format: "%Y-%m-%d", date: "$dateTime" } }, date] },
                        { $lte: [{ $dateToString: { format: "%Y-%m-%d", date: "$dateTime" } }, date] }
                    ]
                },
            }
        }
    ]);

    //for appointActivity report  
    if (appointmentList.length > 0) {
        appointActivity.totalAppointment = appointmentList.length;
        appointmentList.forEach(app => {
            switch (app.status) {
                case 0:
                    if (app.createdBy === 'beautician') { appointActivity.notCompleted = appointActivity.notCompleted + 1; }
                    break;
                case 1:
                    appointActivity.notCompleted = appointActivity.notCompleted + 1;
                    break;
                case 2:
                    appointActivity.completed = appointActivity.completed + 1;
                    break;
                case 3:
                    appointActivity.cancelled = appointActivity.cancelled + 1;
                    break;
                case 4:
                    appointActivity.cancelled = appointActivity.cancelled + 1;
                    break;
                case 5:
                    appointActivity.noShowStatus = appointActivity.noShowStatus + 1
                    break;
                default:
                    appointActivity;
                    break;
            }
        });
    }
    //for upcoming appointment
    const currentMoment = moment().utcOffset('+05:30');
    const query = [
        {
            $match: {
                beauticianId: new mongoose.Types.ObjectId(beauticianData._id),
                $nor: [
                    { createdBy: "client", status: 0 }
                ],
                step: 2,
                $expr: {
                    $gt: [
                        { $toDate: "$dateTime" },
                        currentMoment.toDate()
                    ]
                }
                // $expr: {
                //     $gt: [
                //         { $toDate: "$dateTime" },
                //         currentMoment.toDate()
                //     ]
                // }
            }
        }]
    const TotalUpcoming = await Appointment.aggregate(query)

    const upcomingAppointment = await Appointment.aggregate([
        ...query,
        {
            $lookup: {
                from: 'beauticianservices',
                localField: 'serviceId',
                foreignField: "_id",
                pipeline: [
                    { $project: { serviceCategory: 1, beauticianId: 1, serviceType: 1, price: 1, duration: 1 } }
                ],
                as: 'serviceDetails',
            },
        },
        {
            $lookup: {
                from: 'servicetypelists',
                localField: 'serviceDetails.serviceType',
                foreignField: "_id",
                as: 'serviceTypeData',
            },
        },
        {
            $lookup: {
                from: 'clients',
                localField: 'clientId',
                foreignField: "_id",
                as: 'clientDetails',
            },
        },
        {
            $lookup: {
                from: 'payments',
                localField: 'paymentDetails',
                foreignField: "_id",
                pipeline: [
                    {
                        $project: {
                            BookingId: 1, subTotal: 1, TotalPrice: 1, GstInPer: 1, PstInPer: 1, QstInPer: 1, HstInPer: 1,
                            discount: 1, GST: 1, PST: 1, QST: 1, HST: 1
                        }
                    }
                ],
                as: 'paymentDetails',
            },
        },
        {
            $project: {
                _id: '$_id',
                place: '$place',
                dateTime: '$dateTime',
                dummDis: { $first: "$paymentDetails.discount" },
                clientFirstName: { $first: '$clientDetails.firstName' },
                clientLastName: { $first: '$clientDetails.lastName' },
                serviceName: { $first: '$serviceTypeData.serviceTypeName' },
                serviceName_fr: { $first: '$serviceTypeData.serviceTypeName_fr' },
                subTotal: '$price',
                discount: { $round: [{ $multiply: ['$price', { $first: "$paymentDetails.discount" }, 0.01] }, 2] },
                gstORhst: { $sum: [{ $round: [{ $multiply: ['$price', { $first: "$paymentDetails.GstInPer" }, 0.01] }, 2] }, { $round: [{ $multiply: ['$price', { $first: "$paymentDetails.HstInPer" }, 0.01] }, 2] }] },
                pstORqst: { $sum: [{ $round: [{ $multiply: ['$price', { $first: "$paymentDetails.PstInPer" }, 0.01] }, 2] }, { $round: [{ $multiply: ['$price', { $first: "$paymentDetails.QstInPer" }, 0.01] }, 2] }] },
                sliikFee: {
                    $ifNull: ["$sliikFee", 0]
                },
                // sliikFee: { $round: [{ $multiply: ['$price', parseFloat(platform_fees)] }, 2] },
                sliikFeeGST: {
                    $ifNull: ["$sliikFeeGST", 0]
                },
                // sliikFeeGST: { $sum: [{ $round: [{ $multiply: ['$price', parseFloat(platform_fees), { $first: "$paymentDetails.GstInPer" }, 0.01] }, 2] }, { $round: [{ $multiply: ['$price', parseFloat(platform_fees), { $first: "$paymentDetails.HstInPer" }, 0.01] }, 2] }] },
                sliikFeePST: {
                    $ifNull: ["$sliikFeePST", 0]
                },
                // sliikFeePST: { $sum: [{ $round: [{ $multiply: ['$price', parseFloat(platform_fees), { $first: "$paymentDetails.PstInPer" }, 0.01] }, 2] }, { $round: [{ $multiply: ['$price', parseFloat(platform_fees), { $first: "$paymentDetails.QstInPer" }, 0.01] }, 2] }] },
                totalSum: {
                    $round: [{
                        $subtract: [
                            {
                                $sum: ['$price', { $multiply: ['$price', { $first: "$paymentDetails.GstInPer" }, 0.01] }, { $multiply: ['$price', { $first: "$paymentDetails.HstInPer" }, 0.01] }, { $multiply: ['$price', { $first: "$paymentDetails.PstInPer" }, 0.01] }, { $multiply: ['$price', { $first: "$paymentDetails.QstInPer" }, 0.01] }]
                            },
                            { $multiply: ['$price', { $first: "$paymentDetails.discount" }, 0.01] },
                        ]
                    }, 2]
                }
            },
        }, { $skip: offsetData }, { $limit: limitData }]
    );

    let productSales = await Order.aggregate([
        { $match: { "productData.beauticianId": new mongoose.Types.ObjectId(beauticianData._id) } },
        {
            $unwind: "$productData",
        },
        {
            $lookup: {
                from: 'beauticianproducts',
                localField: 'productData.productId',
                foreignField: "_id",
                pipeline: [
                    { $project: { productName: 1 } }
                ],
                as: 'productDetails',
            },
        },
        {
            $lookup: {
                from: 'clients',
                localField: 'clientId',
                foreignField: "_id",
                pipeline: [
                    // { $match: clientQuery },
                    { $project: { firstName: 1, lastName: 1 } }
                ],
                as: 'clientDetails',
            },
        },
        { $match: { clientDetails: { $gt: {} } } },
        {
            $lookup: {
                from: 'addresses',
                localField: 'shippingAddressId',
                foreignField: "_id",
                pipeline: [
                    {
                        $project: {
                            address: { $ifNull: ["$address", null] },
                            street: { $ifNull: ["$street", null] },
                            apartment: { $ifNull: ["$apartment", null] },
                            city: { $ifNull: ["$city", null] },
                            zipCode: { $ifNull: ["$zipCode", null] },
                        }
                    }
                ],
                as: 'addressDetails',
            },
        },
        {
            $lookup: {
                from: 'addresses',
                localField: 'shippingAddressId',
                foreignField: "_id",
                pipeline: [
                    // { $match: productProviceQuery },
                    { $project: { province: 1 } }
                ],
                as: 'paymentAddress',
            },
        },
        { $match: { paymentAddress: { $gt: {} } } },
        { $sort: { createdAt: -1 } },
        {
            $project: {
                beauticianId: { $ifNull: ["$productData.beauticianId", 0] },
                productName: { $arrayElemAt: ['$productDetails.productName', 0] },
                clientFirstName: { $arrayElemAt: ['$clientDetails.firstName', 0] },
                clientLastName: { $arrayElemAt: ['$clientDetails.lastName', 0] },
                productPrice: { $ifNull: ["$productData.price", 0] },
                totalQuantity: { $ifNull: ["$productData.totalQuantity", 0] },
                productDiscount: { $ifNull: ["$productData.discount", 0] },
                productPurchaseDate: { $ifNull: ["$createdAt", 0] },
                deliveredDate: { $ifNull: ["$createdAt", 0] },
                orderStatus: { $ifNull: ["$orderStatus", "pending"] },
                addressDetails: 1,
                shippingCharge: { $ifNull: ["$shippingCharge", 0] },
                GstInPer: 1, PstInPer: 1, HstInPer: 1, QstInPer: 1,
            }
        }
    ]);

    if (productSales.length) {
        await productSales.forEach(async (val) => {
            const GSTTAX = val?.GstInPer;
            const PSTTAX = val?.PstInPer;
            const HSTTAX = val?.HstInPer;
            const QSTTAX = val?.QstInPer;

            let tempPrice = val.productPrice * val.totalQuantity;
            tempPrice = tempPrice - val.productDiscount;

            const total = tempPrice + tempPrice * (GSTTAX / 100) + tempPrice * (HSTTAX / 100) + tempPrice * (QSTTAX / 100) + tempPrice * (PSTTAX / 100);
            // const sllikFee = (tempPrice - val.discount) / 10;

            val.TotalPrice = total;
            val.productPrice = val.productPrice;
            val.sliikFee = 0;
            val.sliikFeeGST = 0;
            val.sliikFeePST = 0;
            val.sliikFeeHST = 0;
            val.sliikFeeQST = 0;
            val.GST = (tempPrice * (GSTTAX / 100))
            val.PST = (tempPrice * (PSTTAX / 100))
            val.HST = (tempPrice * (HSTTAX / 100))
            val.QST = (tempPrice * (QSTTAX / 100))
        });
    }

    //for top services
    const { TopServices, TopProducts } = await getTopServices(beauticianData._id, 3)

    //for appointment and products chart
    const chartData = await getAppointCountByYearForBarChart(beauticianData._id);

    const responseData = monthCounts.map((ele, i) => {
        return {
            month: ele,
            services: chartData.servicesValue[i],
            product: chartData.productValue[i] || 0,
        }
    });
    return res.status(HttpStatus.OK).json({
        status: HttpStatus.OK, success: true,
        data: {
            appointActivity,
            upcomingAppointment: { total: TotalUpcoming?.length, appointmentList: upcomingAppointment },
            productSales,
            salesChart: responseData,
            TopServices,
            TopProducts
        }
    })
});

module.exports = { getBeauticianReports, getTopServices, getAppointCountByYearForBarChart }