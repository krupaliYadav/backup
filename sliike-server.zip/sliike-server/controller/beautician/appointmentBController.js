const { default: mongoose } = require("mongoose");
const catchAsyncError = require("../../middleware/catchAsyncError");
const Beautician = require("../../models/Beautician");
const HttpStatus = require("../../utils/HttpStatus");
const moment = require("moment");
const Appointment = require("../../models/Appointment");
const ErrorHandler = require("../../utils/ErrorHandling");
const BookingSetting = require("../../models/BookingSetting");
const User = require("../../models/User");
const InvitedClient = require("../../models/InvitedClient");
const { getTimeOfSelectedDate } = require("./workHoursController");
const { validationResult } = require("express-validator");
const { bookingServiceBEmail, bookingServiceCEmail, ReminderServiceCEmail, markAsDelivered, noShowC, cancelAppEmailC, cancelAppEmailB, sendInvtaionMail } = require("../../utils/emailTeplates");
const Address = require("../../models/Address");
const Client = require("../../models/Client");
const { getPolicyDetails } = require("../../utils/Constant");
const Employee = require("../../models/Employee");


const checkAppointmentIdValidation = (appointmentIds) => {
    if (appointmentIds.length > 0) {
        const validationPromises = appointmentIds.map((ele) => {
            return new Promise((resolve, reject) => {
                if (!mongoose.Types.ObjectId.isValid(ele)) {
                    reject(new Error(('appoimentIdValidation')));
                } else {
                    resolve();
                }
            });
        });
        return Promise.all(validationPromises);
    } else {
        throw new ErrorHandler(req.t("appoimentIdEmpty"), HttpStatus.BAD_REQUEST, false);
    }
}
//get appointment list to display in calender
const getCalenderAppointmentList = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { date, day, stylistId } = req.body;

    const timingOfDay = await getTimeOfSelectedDate(req.body, id)
    const matchQuery = {
        step: 2,
        $nor: [
            { createdBy: "client", status: 0 },
            { status: { $in: [3, 4] } }
        ]
    };
    if (date) {
        const nextDay = moment(date, 'YYYY-MM-DD').add(1, 'day').format('YYYY-MM-DD');
        matchQuery.dateTime = {
            $gte: new Date(date),
            $lt: new Date(nextDay)
        }
    }
    let employeeList = []
    if (stylistId) {
        const stylistIDs = stylistId.map(id => new mongoose.Types.ObjectId(id));
        matchQuery.stylistID = { $in: stylistIDs }
        employeeList = await Employee.find({ _id: { $in: stylistIDs } }).select("-createdAt -updatedAt -status -__v -beauticianId")
    }
    const beauticianData = await Beautician.aggregate([
        {
            $match: { userId: new mongoose.Types.ObjectId(id) }
        },
        {
            $lookup: {
                from: "appointments",
                localField: "_id",
                foreignField: "beauticianId",
                as: "appoData",
                pipeline: [
                    {
                        $match: matchQuery
                    },
                    {
                        $project: {
                            createdAt: 0, __v: 0, updatedAt: 0, recurringOpt: 0, createdBy: 0, price: 0, place: 0, note: 0, status: 0,
                        }
                    }
                ]
            }
        },
        {
            $lookup: {
                from: "employees",
                localField: "appoData.stylistID",
                foreignField: "_id",
                as: 'Stylist',
                pipeline: [
                    { $project: { firstName: 1, lastName: 1, profileImage: 1 } }
                ]
            },
        },
        {
            $lookup: {
                from: "clients",
                localField: "appoData.clientId",
                foreignField: "_id",
                as: 'clientData',
                pipeline: [
                    { $project: { firstName: 1, lastName: 1 } }
                ]

            },
        },
        {
            $lookup: {
                from: "beauticianservices",
                localField: "appoData.serviceId",
                foreignField: "_id",
                as: 'serviceDetails',
                pipeline: [
                    { $project: { serviceType: 1 } }
                ]

            },
        },
        {
            $lookup: {
                from: "servicetypelists",
                localField: "serviceDetails.serviceType",
                foreignField: "_id",
                as: 'ServiceTypeDetails',
                pipeline: [
                    { $project: { serviceTypeName: 1, serviceTypeName_fr: 1, serviceCategoryId: 1 } }
                ]
            },
        },
        {
            $project: {
                stripe_id: 1,
                appoData: {
                    $map: {
                        input: "$appoData",
                        as: "appointment",
                        in: {
                            $mergeObjects: [
                                "$$appointment",
                                {
                                    serviceDetails: {
                                        $arrayElemAt: [{
                                            $filter: {
                                                input: "$serviceDetails",
                                                as: "service",
                                                cond: { $eq: ["$$service._id", "$$appointment.serviceId"] }
                                            }
                                        }, 0]

                                    },
                                    clientData: {
                                        $arrayElemAt: [{
                                            $filter: {
                                                input: "$clientData",
                                                as: "clientData",
                                                cond: { $eq: ["$$clientData._id", "$$appointment.clientId"] }
                                            }
                                        }, 0]
                                    },
                                    Stylist: {
                                        $arrayElemAt: [{
                                            $filter: {
                                                input: "$Stylist",
                                                as: "stylist",
                                                cond: { $eq: ["$$stylist._id", "$$appointment.stylistID"] }
                                            }
                                        }, 0]
                                    },
                                }
                            ]
                        }
                    },

                },
                ServiceTypeDetails: 1,
                calenderSetting: 1
            }
        },
        {
            $group: {
                _id: "$_id",
                stripe_id: { $first: '$stripe_id' },
                calenderSetting: { $first: '$calenderSetting' },
                appointmentData: { $first: '$appoData' },
                ServiceTypeDetails: { $first: '$ServiceTypeDetails' }
            }
        }
    ])
    let isStripeSetUp = false;
    if (beauticianData && beauticianData.length > 0) {
        if (beauticianData[0].stripe_id) {
            isStripeSetUp = true
        }
        beauticianData[0].appointmentData.forEach(appData => {
            beauticianData[0].ServiceTypeDetails.forEach(service => {
                if (service._id.equals(appData.serviceDetails.serviceType)) {
                    appData.serviceDetails.serviceTypeName = service.serviceTypeName
                }
            })
        });
    }
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { appointmentData: beauticianData[0].appointmentData, timingOfDay, calenderSetting: beauticianData[0].calenderSetting, isStripeSetUp, employeeList } })
});
////get appointment detail from step 1 by beautician
const getAppointmentPreDetails = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { appointmentIds } = req.body;
    await checkAppointmentIdValidation(appointmentIds)
    const beauticianData = await Beautician.findOne({ userId: id });
    if (beauticianData) {
        const appointmentId = appointmentIds.map(id => new mongoose.Types.ObjectId(id));
        const matchQuery = {
            _id: { $in: appointmentId },
            beauticianId: beauticianData._id,
            status: 0,
            createdBy: "beautician",
            step: 1
        }
        const getData = await Appointment.find(matchQuery).populate({ path: 'clientId', select: 'firstName lastName' }).populate([
            {
                path: "serviceId", select: '-createdAt -updatedAt -__v',
                populate: [{ path: 'serviceType', select: '-_id serviceTypeName' }],
                select: "serviceType -_id"
            },
            {
                path: 'stylistID', select: 'firstName lastName -_id'
            },
        ]).lean();
        let totalPrice = 0;
        getData.forEach(ele => totalPrice = ele.price + totalPrice)
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { appointmentData: getData, totalPrice } })

    } else {
        throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST, false)
    }

});
//save appointment detail from step 2 by beautician
const saveAppointmentDetails = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { appointmentIds, isDepositReq, depositAmtPercentage, note } = req.body;
    await checkAppointmentIdValidation(appointmentIds)
    const beauticianData = await Beautician.findOne({ userId: id }).populate('userId').populate({
        path: 'address',
        model: 'Address',
        select: '-_id address province apartment city zipCode',
        populate: {
            path: 'province',
            model: 'Province',
            select: 'name'
        },
    });
    if (beauticianData) {
        const appointmentId = appointmentIds.map(id => new mongoose.Types.ObjectId(id));
        const matchQuery = {
            _id: { $in: appointmentId },
            beauticianId: beauticianData._id,
            status: 0,
            createdBy: "beautician",
            step: 1
        }
        // update step and other value.
        //query for send Email
        const getClientAndAppointmentDetails = await Appointment.aggregate([
            {
                $match: matchQuery
            },
            {
                $lookup: {
                    from: "clients",
                    localField: "clientId",
                    foreignField: "_id",
                    as: 'clientData',
                    pipeline: [
                        { $project: { firstName: 1, lastName: 1, userId: 1 } }
                    ]
                },
            },
            {
                $lookup: {
                    from: "users",
                    localField: "clientData.userId",
                    foreignField: "_id",
                    as: 'userDetail',
                    pipeline: [
                        { $project: { phoneNumber: 1, email: 1 } }
                    ]

                },
            },
            {
                $lookup: {
                    from: "beauticianservices",
                    localField: "serviceId",
                    foreignField: "_id",
                    as: 'serviceDetails',
                    pipeline: [
                        { $project: { serviceType: 1, price: 1, duration: 1 } }
                    ]

                },
            },
            {
                $lookup: {
                    from: "servicetypelists",
                    localField: "serviceDetails.serviceType",
                    foreignField: "_id",
                    as: 'ServiceTypeDetails',
                    pipeline: [
                        { $project: { serviceTypeName: 1, serviceTypeName_fr: 1, serviceCategoryId: 1 } }
                    ]
                },
            },
            {
                $project: {
                    _id: 1,
                    dateTime: 1,
                    firstName: { $arrayElemAt: ['$clientData.firstName', 0] },
                    lastName: { $arrayElemAt: ['$clientData.lastName', 0] },
                    phoneNumber: { $arrayElemAt: ['$userDetail.phoneNumber', 0] },
                    email: { $arrayElemAt: ['$userDetail.email', 0] },
                    serviceName: { $arrayElemAt: ['$ServiceTypeDetails.serviceTypeName', 0] },
                    serviceName_fr: { $arrayElemAt: ['$ServiceTypeDetails.serviceTypeName_fr', 0] },
                    duration: { $arrayElemAt: ['$serviceDetails.duration', 0] },
                    price: 1,
                }
            },
            {
                $group: {
                    _id: '$_id',
                    clientEmail: { $first: '$email' },
                    dateTime: { $first: '$dateTime' },
                    price: { $first: '$price' },
                    phoneNumber: { $first: '$phoneNumber' },
                    firstName: { $first: '$firstName' },
                    lastName: { $first: '$lastName' },
                    serviceName: { $first: '$serviceName' },
                    duration: { $first: '$duration' },
                }
            }
        ])
        // update step and other value.
        const updateData = await Appointment.updateMany(matchQuery, {
            $set: {
                isDepositReq: isDepositReq,
                depositAmtPercentage: depositAmtPercentage,
                note: note,
                step: 2
            }
        });
        if (updateData.matchedCount === 0) {
            throw new ErrorHandler(req.t("detailsAlredaySaved"), HttpStatus.BAD_REQUEST, false)
        }

        //send Email
        if (getClientAndAppointmentDetails?.length > 0) {
            getClientAndAppointmentDetails.forEach(async (ele, i) => {

                const emailDetails = {
                    email: beauticianData.userId.email,
                    clientEmail: ele.clientEmail,
                    businessName: beauticianData.businessName,
                    firstName: ele.firstName,
                    lastName: ele.lastName,
                    phoneNumber: ele.phoneNumber,
                    date: moment(ele.dateTime).utc().format('dddd, DD-MMM-YYYY'),
                    time: moment(ele.dateTime).utc().format('HH:mm A'),
                    address: beauticianData.address?.address + beauticianData.address?.city + beauticianData.address?.province?.name,
                    serviceTypeName: ele.serviceName,
                    price: ele.price
                }
                await bookingServiceBEmail(emailDetails);
                await bookingServiceCEmail(emailDetails);
            })
        }

        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("saveAppointmentDetailsSuccess") })
    } else {
        throw new ErrorHandler("beautician Data not found.", HttpStatus.BAD_REQUEST, false)
    }
})
//get single Appointment detail
const getAppointmentDetails = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { appoId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(appoId)) {
        throw new ErrorHandler(req.t("AppointmentIdWrong"), HttpStatus.BAD_REQUEST, false)
    }
    const beauticianData = await Beautician.findOne({ userId: id });

    const appointmentDetail = await Appointment.aggregate([
        {
            $match: {
                _id: new mongoose.Types.ObjectId(appoId),
                beauticianId: new mongoose.Types.ObjectId(beauticianData._id),
                step: 2
            }
        },
        {
            $lookup: {
                from: "clients",
                localField: "clientId",
                foreignField: "_id",
                as: 'clientData',
                pipeline: [
                    { $project: { firstName: 1, lastName: 1, country_code: 1, userId: 1 } }
                ]

            },
        },
        {
            $lookup: {
                from: "users",
                localField: "clientData.userId",
                foreignField: "_id",
                as: 'clientContact',
                pipeline: [
                    { $project: { phoneNumber: 1 } }
                ]

            },
        },
        {
            $lookup: {
                from: "beauticianservices",
                localField: "serviceId",
                foreignField: "_id",
                as: 'serviceDetails',
                pipeline: [
                    { $project: { serviceType: 1, price: 1, duration: 1 } }
                ]

            },
        },
        {
            $lookup: {
                from: "servicetypelists",
                localField: "serviceDetails.serviceType",
                foreignField: "_id",
                as: 'ServiceTypeDetails',
                pipeline: [
                    { $project: { serviceTypeName: 1, serviceTypeName_fr: 1, serviceCategoryId: 1 } }
                ]
            },
        },
        {
            $lookup: {
                from: "payments",
                localField: "paymentDetails",
                foreignField: "_id",
                as: 'paymentDetails',
                pipeline: [
                    { $project: { TotalPrice: 1, paymentStatus: 1 } }
                ]
            },
        },
        {
            $project: {
                _id: 1,
                dateTime: 1,
                clientData: {
                    customerId: { $arrayElemAt: ['$clientData._id', 0] },
                    firstName: { $arrayElemAt: ['$clientData.firstName', 0] },
                    lastName: { $arrayElemAt: ['$clientData.lastName', 0] },
                    country_code: { $arrayElemAt: ['$clientData.country_code', 0] },
                    phoneNumber: { $arrayElemAt: ['$clientContact.phoneNumber', 0] },
                },
                serviceDetails: {
                    serviceId: { $arrayElemAt: ['$serviceDetails._id', 0] },
                    serviceName: { $arrayElemAt: ['$ServiceTypeDetails.serviceTypeName', 0] },
                    serviceName_fr: { $arrayElemAt: ['$ServiceTypeDetails.serviceTypeName_fr', 0] },
                    price: { $arrayElemAt: ['$serviceDetails.price', 0] },
                    duration: { $arrayElemAt: ['$serviceDetails.duration', 0] },
                },
                status: 1,
                paymentDetails: 1
            }
        },
        {
            $group: {
                _id: '$_id',
                dateTime: { $first: '$dateTime' },
                status: { $first: '$status' },
                clientData: { $first: { $arrayElemAt: ['$clientData', 0] } },
                serviceDetails: { $first: { $arrayElemAt: ['$serviceDetails', 0] } },
                paymentDetails: { $first: { $arrayElemAt: ['$paymentDetails', 0] } },
            }
        }
    ]);
    if (appointmentDetail.length > 0) {
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: appointmentDetail[0] })
    }
    throw new ErrorHandler(req.t("AppointmentIdWrong"), HttpStatus.BAD_REQUEST, false)
});
//get payment details
const getAppointmentPaymentDetails = catchAsyncError(async (req, res, next) => {
    const { appoId } = req.params;
    if (mongoose.Types.ObjectId.isValid(appoId)) {
        const paymentDetails = await Appointment.aggregate([
            {
                $match: { _id: new mongoose.Types.ObjectId(appoId), step: 2 },
            },
            {
                $lookup:
                {
                    from: 'clients',
                    localField: 'clientId',
                    foreignField: '_id',
                    as: 'clientData',
                    pipeline: [
                        { $project: { userId: 1 } }
                    ]
                }
            },
            {
                $lookup:
                {
                    from: 'users',
                    localField: 'clientData.userId',
                    foreignField: '_id',
                    as: 'userDetails',
                    pipeline: [
                        { $project: { email: 1 } }
                    ]
                }
            },
            {
                $lookup:
                {
                    from: 'beauticianservices',
                    localField: 'serviceId',
                    foreignField: '_id',
                    as: 'serviceDetails'
                }
            },
            {
                $lookup: {
                    from: 'servicetypelists',
                    localField: 'serviceDetails.serviceType',
                    foreignField: "_id",
                    pipeline: [
                        { $project: { serviceTypeName: 1, serviceTypeName_fr: 1, } }
                    ],
                    as: 'typeDetails',
                },
            },
            {
                $lookup: {
                    from: 'payments',
                    localField: 'paymentDetails',
                    foreignField: '_id',
                    as: 'paymentInfo'
                }
            },
            {
                $project: {
                    _id: 1,
                    dateTime: 1,
                    status: 1,
                    serviceDetails: {
                        duration: { $arrayElemAt: ['$serviceDetails.duration', 0] },
                        price: { $arrayElemAt: ['$serviceDetails.price', 0] },
                        serviceName: { $arrayElemAt: ['$typeDetails.serviceTypeName', 0] },
                        serviceName_fr: { $arrayElemAt: ['$typeDetails.serviceTypeName_fr', 0] },
                    },
                    paymentInfo: {
                        BookingId: { $arrayElemAt: ['$paymentInfo.BookingId', 0] },
                        paymentDate: { $arrayElemAt: ['$paymentInfo.createdAt', 0] },
                        paymentStatus: { $arrayElemAt: ['$paymentInfo.status', 0] },
                        subTotal: { $round: [{ $arrayElemAt: ['$serviceDetails.price', 0] }, 2] },
                        discount: { $round: [{ $arrayElemAt: ['$paymentInfo.discount', 0] }, 2] },
                        GST: { $round: [{ $multiply: [{ $arrayElemAt: ['$paymentInfo.GstInPer', 0] }, { $arrayElemAt: ['$serviceDetails.price', 0] }, 0.01] }, 2] },
                        HST: { $round: [{ $multiply: [{ $arrayElemAt: ['$paymentInfo.HstInPer', 0] }, { $arrayElemAt: ['$serviceDetails.price', 0] }, 0.01] }, 2] },
                        PST: { $round: [{ $multiply: [{ $arrayElemAt: ['$paymentInfo.PstInPer', 0] }, { $arrayElemAt: ['$serviceDetails.price', 0] }, 0.01] }, 2] },
                        QST: { $round: [{ $multiply: [{ $arrayElemAt: ['$paymentInfo.QstInPer', 0] }, { $arrayElemAt: ['$serviceDetails.price', 0] }, 0.01] }, 2] },
                    },
                    clientEmail: {
                        email: { $arrayElemAt: ['$userDetails.email', 0] }
                    }
                }
            },
            {
                $group: {
                    _id: '$_id',
                    dateTime: { $first: '$dateTime' },
                    status: { $first: '$status' },
                    clientEmail: { $first: '$clientEmail' },
                    serviceDetails: { $first: { $arrayElemAt: ['$serviceDetails', 0] } },
                    paymentInfo: { $first: { $arrayElemAt: ['$paymentInfo', 0] } },
                }
            }
        ])

        if (paymentDetails.length > 0) {
            let payment = paymentDetails[0].paymentInfo
            paymentDetails[0].paymentInfo.total = payment.subTotal + payment.GST + payment.HST + payment.PST + payment.QST - payment.discount
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: paymentDetails })
        } else {
            throw new ErrorHandler(req.t("AppointmentIdWrong"), HttpStatus.BAD_REQUEST, false)
        }
    } else {
        throw new ErrorHandler(req.t("AppointmentIdWrong"), HttpStatus.BAD_REQUEST, false)
    }

});
//delivered and no-show
const handlePastAppointmentStatus = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { appoId, newStatus } = req.body;
    if (!mongoose.Types.ObjectId.isValid(appoId)) {
        throw new ErrorHandler(req.t("AppointmentIdWrong"), HttpStatus.BAD_REQUEST, false)
    }
    const beauticianData = await Beautician.findOne({ userId: id })
    const appointmentData = await Appointment.findOne({ _id: appoId, dateTime: { $lt: new Date() }, step: 2 });
    if (appointmentData) {
        const EmailData = await Appointment.aggregate([
            {
                $match: {
                    _id: new mongoose.Types.ObjectId(appoId),
                }
            },
            {
                $lookup: {
                    from: "beauticians",
                    localField: "beauticianId",
                    foreignField: "_id",
                    as: 'beauticianDetails',
                },
            },
            {
                $lookup: {
                    from: "clients",
                    localField: "clientId",
                    foreignField: "_id",
                    as: 'clientDetails',
                },
            },
            {
                $lookup: {
                    from: "users",
                    localField: "clientDetails.userId",
                    foreignField: "_id",
                    as: 'userDetails',
                },
            },
            {
                $lookup: {
                    from: "payments",
                    localField: "_id",
                    foreignField: "appointmentIds",
                    as: 'paymentDetails',
                },
            },
            {
                $project: {
                    price: 1,
                    firstName: { $arrayElemAt: ['$clientDetails.firstName', 0] },
                    lastName: { $arrayElemAt: ['$clientDetails.lastName', 0] },
                    phoneNumber: { $arrayElemAt: ['$userDetails.phoneNumber', 0] },
                    businessName: { $arrayElemAt: ['$beauticianDetails.businessName', 0] },
                    clientEmail: { $arrayElemAt: ['$userDetails.email', 0] },
                    GstInPer: { $arrayElemAt: ['$paymentDetails.GstInPer', 0] },
                    HstInPer: { $arrayElemAt: ['$paymentDetails.HstInPer', 0] },
                    QstInPer: { $arrayElemAt: ['$paymentDetails.QstInPer', 0] },
                    PstInPer: { $arrayElemAt: ['$paymentDetails.PstInPer', 0] },
                    discount: { $arrayElemAt: ['$paymentDetails.discount', 0] },
                }
            }
        ]);

        if (newStatus === "delivered") {
            if (appointmentData.status === 2) {
                throw new ErrorHandler(req.t("statusAlreadyChanged", { newStatus: newStatus }), HttpStatus.BAD_REQUEST, false)
            }
            appointmentData.status = 2;
            if (EmailData) {
                EmailData.forEach(async (ele, i) => {
                    const priceWithTax = ele.price + ele.price * (ele.GstInPer / 100) + ele.price * (ele.HstInPer / 100) + ele.price * (ele.QstInPer / 100) + ele.price * (ele.PstInPer / 100) - ele.price * (ele.discount / 100);
                    const emailDetails = {
                        email: ele.email,
                        clientEmail: ele.clientEmail,
                        businessName: ele.businessName,
                        firstName: ele.firstName,
                        lastName: ele.lastName,
                        price: ele.price,
                        priceWithTax
                    }
                    await markAsDelivered(emailDetails);
                });
            }
        } else if (newStatus === "no-show") {
            if (appointmentData.status === 5) {
                throw new ErrorHandler(req.t("statusAlreadyChanged", { newStatus: newStatus }), HttpStatus.BAD_REQUEST, false)
            }
            appointmentData.status = 5
            appointmentData.noShowPolicyNub = beauticianData.noShowProtection
            if (EmailData) {
                EmailData.forEach(async (ele, i) => {
                    const priceWithTax = ele.price + ele.price * (ele.GstInPer / 100) + ele.price * (ele.HstInPer / 100) + ele.price * (ele.QstInPer / 100) + ele.price * (ele.PstInPer / 100) - ele.price * (ele.discount / 100);
                    const emailDetails = {
                        email: ele.email,
                        clientEmail: ele.clientEmail,
                        businessName: ele.businessName,
                        firstName: ele.firstName,
                        lastName: ele.lastName,
                        price: ele.price,
                        priceWithTax: priceWithTax
                    }
                    await noShowC(emailDetails);
                });
            }
        } else {
            throw new ErrorHandler("Status value is wrong.", HttpStatus.BAD_REQUEST, false)
        }
        await appointmentData.save();
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("handlePastAppointmentStatusSuccess") });
    } else {
        throw new ErrorHandler(req.t("handlePastAppointmentStatusError"), HttpStatus.BAD_REQUEST, false)
    }
});
//cancel appointment
const cancelAppointmentByBeautician = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { appoId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(appoId)) {
        throw new ErrorHandler(req.t("AppointmentIdWrong"), HttpStatus.BAD_REQUEST, false)
    }
    const beauticianData = await Beautician.findOne({ userId: id })
    const isPastAppointment = await Appointment.findOne({ _id: appoId, beauticianId: beauticianData._id });
    if (isPastAppointment && isPastAppointment.status === 0 && isPastAppointment.createdBy === "beautician" && moment(isPastAppointment?.dateTime).isBefore(moment())) {
        isPastAppointment.status = 4
        await isPastAppointment.save();
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("cancelAppointmentByBeauticianSuccess") });
    }
    if (isPastAppointment && moment(isPastAppointment?.dateTime).isBefore(moment()) && isPastAppointment.createdBy !== "beautician") {
        throw new ErrorHandler(req.t("pastAppoimentNotCancel"), HttpStatus.BAD_REQUEST, false);
    }
    const isFutureAppointment = await Appointment.aggregate([
        {
            $match: {
                _id: new mongoose.Types.ObjectId(appoId),
                beauticianId: new mongoose.Types.ObjectId(beauticianData._id),
                step: 2
            },

        },
    ])
    if (isFutureAppointment.length > 0 && (isFutureAppointment[0].status === 3 || isFutureAppointment[0].status === 4)) {
        throw new ErrorHandler(req.t("appoimentAlredayCancel"), HttpStatus.BAD_REQUEST, false)
    }
    if (isFutureAppointment.length > 0 && moment(isFutureAppointment?.[0]?.dateTime).isAfter(moment())) {
        await Appointment.findByIdAndUpdate(appoId, { status: 4, $set: { cancelationPolicyNub: beauticianData.cancelProtection } }, { new: true });

        const EmailData = await Appointment.aggregate([
            {
                $match: {
                    _id: new mongoose.Types.ObjectId(appoId),
                }
            },
            {
                $lookup: {
                    from: "beauticianservices",
                    localField: "serviceId",
                    foreignField: "_id",
                    as: 'serviceDetails',
                    pipeline: [
                        { $project: { serviceType: 1 } }
                    ]
                },
            },
            {
                $lookup: {
                    from: "servicetypelists",
                    localField: "serviceDetails.serviceType",
                    foreignField: "_id",
                    as: 'ServiceTypeDetails',
                    pipeline: [
                        { $project: { serviceTypeName: 1, serviceTypeName_fr: 1, serviceCategoryId: 1 } }
                    ]
                },
            },
            {
                $lookup: {
                    from: "beauticians",
                    localField: "beauticianId",
                    foreignField: "_id",
                    as: 'beauticianDetails',
                },
            },
            {
                $lookup: {
                    from: "clients",
                    localField: "clientId",
                    foreignField: "_id",
                    as: 'clientDetails',
                },
            },
            {
                $lookup: {
                    from: "users",
                    localField: "beauticianDetails.userId",
                    foreignField: "_id",
                    as: 'beauticianUser',
                },
            },
            {
                $lookup: {
                    from: "users",
                    localField: "clientDetails.userId",
                    foreignField: "_id",
                    as: 'userDetails',
                },
            },
            {
                $lookup: {
                    from: "addresses",
                    localField: "clientDetails.address.addressId",
                    foreignField: "_id",
                    as: "userAddressData",
                    pipeline: [
                        { $project: { address: 1, street: 1, apartment: 1 } }
                    ]
                }
            },
            {
                $lookup: {
                    from: "addresses",
                    localField: "beauticianDetails.address",
                    foreignField: "_id",
                    as: "beauticianAddressData",
                    pipeline: [
                        { $project: { address: 1, street: 1, apartment: 1, city: 1, zipCode: 1 } }
                    ]
                }
            },
            {
                $project: {
                    status: 1,
                    dateTime: 1,
                    place: 1,
                    beauticanEmail: { $arrayElemAt: ['$beauticianUser.email', 0] },
                    userAddressData: 1,
                    beauticianAddressData: 1,
                    date: { $dateToString: { format: "%d-%m-%Y", date: "$dateTime" } },
                    time: { $dateToString: { format: "%H:%M", date: "$dateTime" } },
                    ServiceTypeName: { $arrayElemAt: ['$ServiceTypeDetails.serviceTypeName', 0] },
                    ServiceTypeName_fr: { $arrayElemAt: ['$ServiceTypeDetails.serviceTypeName_fr', 0] },
                    cancelProtection: { $arrayElemAt: ['$beauticianDetails.cancelProtection', 0] },
                    firstName: { $arrayElemAt: ['$clientDetails.firstName', 0] },
                    lastName: { $arrayElemAt: ['$clientDetails.lastName', 0] },
                    phoneNumber: { $arrayElemAt: ['$userDetails.phoneNumber', 0] },
                    businessName: { $arrayElemAt: ['$beauticianDetails.businessName', 0] },
                    CancelDay: moment().format("dddd"),
                    Cancellation_date: moment().format('DD-MM-YYYY'),
                    clientEmail: { $arrayElemAt: ['$userDetails.email', 0] },
                    Cancellation_time: moment().format("HH:MM a")
                }
            }
        ]);

        let tempAddess = [];
        if (EmailData[0].place == 1) {
            tempAddess = EmailData[0].userAddressData.map((val) => {
                return [val?.apartment, val?.street, val?.address,];
            })
        } else {
            tempAddess = EmailData[0].beauticianAddressData.map((val) => {
                return [val?.apartment, val?.street, val?.address, val?.city, val?.zipCode];
            })
        }

        const { policy } = getPolicyDetails(EmailData[0].cancelProtection);

        const emailDetails = {
            email: EmailData[0].beauticanEmail,
            businessName: EmailData[0].businessName,
            firstName: EmailData[0].firstName,
            lastName: EmailData[0].lastName,
            phoneNumber: EmailData[0].phoneNumber.toString(),
            day: moment(EmailData[0].dateTime).format("dddd"),
            date: EmailData[0].date,
            time: EmailData[0].time,
            address: tempAddess.toString(),
            serviceTypeName: EmailData[0].ServiceTypeName,
            cancelDay: EmailData[0].CancelDay,
            cancelDate: EmailData[0].Cancellation_date,
            cancelTime: EmailData[0].Cancellation_time,
            cancelPolicy: policy,
            clientEmail: EmailData[0].clientEmail,
        }

        await cancelAppEmailB(emailDetails);
        await cancelAppEmailC(emailDetails);

        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("cancelAppointmentByBeauticianSuccess") });
    } else {
        throw new ErrorHandler("Appointment is not found. ", HttpStatus.BAD_REQUEST, false);
    }
})

//no-show protection setting
const saveNoShowProtection = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { select } = req.body;
    // const selectValues = [1, 2, 3, 4];
    const selectValues = [1, 4];
    if (selectValues.includes(Number(select))) {
        await Beautician.findOneAndUpdate({ userId: id }, { noShowProtection: select }, { new: true });
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("saveNoShowProtectionSuccess") })
    } else {
        throw new ErrorHandler(req.t("accept1-4"), HttpStatus.BAD_REQUEST, false)
    }
})

//Cancel protection setting
const saveCancelProtection = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { select } = req.body;
    const selectValues = [1, 2, 3, 4];
    if (selectValues.includes(Number(select))) {
        await Beautician.findOneAndUpdate({ userId: id }, { cancelProtection: select }, { new: true });
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("saveCancelProtectionSuccess") })
    } else {
        throw new ErrorHandler(req.t("accept1-4"), HttpStatus.BAD_REQUEST, false)
    }
});

// get saved cancellation and no-shown protection values
const getNOShowAndCancellationProtection = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const beauticianData = await Beautician.findOne({ userId: id }).select("noShowProtection cancelProtection");
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: beauticianData })

})

// set booking setting 
const saveBookingSettings = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const beauticianData = await Beautician.findOne({ userId: id });
    let futureBookingDay, futureBookingMonths;
    const { confirmAuto, bookingWindow, futureBooking, rescheduling } = req.body;
    // set futureBooking value in two different keys in DB 
    let futureBookingValue = futureBooking?.split(" ")
    if (futureBooking?.includes('month')) {
        futureBookingDay = undefined
        futureBookingMonths = futureBookingValue[0]
    }
    if (futureBooking?.includes('day')) {
        futureBookingMonths = undefined
        futureBookingDay = futureBookingValue[0]
    }
    const isExistSetting = await BookingSetting.findOne({ beauticianId: beauticianData._id });
    if (isExistSetting) {
        isExistSetting.confirmAuto = confirmAuto
        isExistSetting.bookingWindow = bookingWindow
        isExistSetting.futureBookingDay = futureBookingDay
        isExistSetting.futureBookingMonths = futureBookingMonths
        isExistSetting.rescheduling = rescheduling
        await isExistSetting.save();
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("saveBookingSettingsUpdated") })
    } else {
        await BookingSetting.create({
            beauticianId: beauticianData._id, confirmAuto, bookingWindow, futureBookingDay, futureBookingMonths, rescheduling
        });
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("saveBookingSettingsAdded") })
    }
});

// get saved booking setting value
const getBookingSettings = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const beauticianData = await Beautician.findOne({ userId: id });
    const bookingSetting = await BookingSetting.findOne({ beauticianId: beauticianData._id });
    let response = {}
    if (bookingSetting) {
        response = {
            confirmAuto: bookingSetting.confirmAuto,
            bookingWindow: bookingSetting.bookingWindow,
            futureBooking: (bookingSetting.futureBookingDay && `${bookingSetting.futureBookingDay} days`) || (bookingSetting.futureBookingMonths && `${bookingSetting.futureBookingMonths} months`),
            rescheduling: bookingSetting.rescheduling
        }
    }
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: response })
});

// invite contact 
// const inviteContacts = catchAsyncError(async (req, res, next) => {
//     const id = req.user;
//     let { contactDetails } = req.body;
//     const errors = validationResult(req);

//     if (errors.errors.length !== 0) {
//         throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST);
//     };
//     const beauticianData = await Beautician.findOne({ userId: id });
//     const existingList = await User.aggregate([
//         { $match: { roles: "user", isActiveUser: 1 } },
//         { $project: { phoneNumber: 1 } }
//     ]);

//     //check canadian phone number formate and get onl contact digits
//     const canadaPhoneNumberRegex = /(?:\+?(?:1[-.\s]?)?)?(?:\((?:[2-9]\d{2})\)|(?:[2-9]\d{2}))(?:[-.\s]?)\d{3}(?:[-.\s]?)\d{4}/g;

//     const numbersWithoutCountryCode = contactDetails.map((phoneNumber) => {
//         const matches = phoneNumber.match(canadaPhoneNumberRegex);
//         if (matches) {
//             const cleanedNumber = matches[0].replace(/\D/g, '');
//             return { phoneNumber: cleanedNumber.substring(cleanedNumber.length - 10) };
//         } else {
//             return null;
//         }
//     });

//     contactDetails = numbersWithoutCountryCode.filter(Boolean);
//     let phoneNumbers = [...new Set(contactDetails?.map(ele => ele.phoneNumber))]; //for remove duplicate numbers

//     // const isAlreadyInvited = await InvitedClient.find({ phoneNumber: { $in: phoneNumbers }, beauticianId: { $nin: [beauticianData._id] } });
//     let isAlreadyInvited = await InvitedClient.find({ phoneNumber: { $in: phoneNumbers } });

//     //add beautician Id in existing invite
//     const updateResult = await InvitedClient.updateMany(
//         { phoneNumber: { $in: phoneNumbers }, beauticianId: { $nin: [beauticianData._id] } },
//         { $push: { beauticianId: beauticianData._id } }
//     );

//     const isAlreadyPhoneNumber = isAlreadyInvited.map(ele => ele.phoneNumber);

//     //remove data which are already exist
//     contactDetails = contactDetails.filter(ele => {
//         return !isAlreadyPhoneNumber.includes(parseInt(ele.phoneNumber))
//     });
//     contactDetails?.forEach(contact => {
//         //check user is already sign up
//         existingList?.forEach(number => {
//             if (number.phoneNumber == contact.phoneNumber) {
//                 contact.status = 1
//             }
//         });
//         contact.beauticianId = [beauticianData._id];
//         contact.phoneNumber = contact.phoneNumber;
//         //add invite message code here
//     });
//     await InvitedClient.insertMany(contactDetails);
//     return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, message: "Invitation sent successfully.", success: true })
// });

// Send Invitation 
const inviteContacts = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    let { contactDetails, email, name, acceptEmailNotification, acceptSMSNotification } = req.body;
    const errors = validationResult(req);

    if (errors.errors.length !== 0) {
        throw new ErrorHandler(req.t(errors?.errors[0]?.msg), HttpStatus.BAD_REQUEST);
    };
    const beauticianData = await Beautician.findOne({ userId: id });
    const canadaPhoneNumberRegex = /(?:\+?(?:1[-.\s]?)?)?(?:\((?:[2-9]\d{2})\)|(?:[2-9]\d{2}))(?:[-.\s]?)\d{3}(?:[-.\s]?)\d{4}/g;

    const matches = contactDetails.match(canadaPhoneNumberRegex);
    if (!matches) {
        throw new ErrorHandler(req.t("invalidContact"), HttpStatus.BAD_REQUEST)
    }
    let phoneNumber;

    if (matches) {
        const cleanedNumber = matches[0].replace(/\D/g, '');
        phoneNumber = cleanedNumber.substring(cleanedNumber.length - 10)
    }
    const numberIsAlreadyInvited = await InvitedClient.findOne({ beauticianId: beauticianData._id, phoneNumber: phoneNumber, isDeleted: 0 });

    if (numberIsAlreadyInvited && phoneNumber) {
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, message: req.t("inviteContactsSuccess"), success: true })
    }
    let status = 0, clientId, existingList;
    if (phoneNumber) {
        existingList = await User.findOne({ roles: "user", isActiveUser: 1, phoneNumber });
    }

    if (existingList) {
        const getClient = await Client.findOne({ userId: existingList?._id });
        status = 1; clientId = getClient?._id;
    }
    const data = await InvitedClient.create({
        beauticianId: beauticianData._id,
        phoneNumber: phoneNumber,
        phoneNubWithFormat: contactDetails,
        email, name, acceptEmailNotification, acceptSMSNotification,
        status,
        clientId
    });

    if (data && email && acceptEmailNotification) {
        await sendInvtaionMail({ name, email, firstName: beauticianData.firstName, lastName: beauticianData.lastName })
    }
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("inviteContactsSuccess"), })
});

// List of Invited client list
const getInvitedClientList = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const beauticianData = await Beautician.findOne({ userId: id });
    const invitedClient = await InvitedClient.find({ beauticianId: beauticianData._id, isDeleted: 0 }).select("phoneNumber status phoneNubWithFormat clientId");
    res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: invitedClient })
});

const SendAppointmentReminder = catchAsyncError(async (req, res, next) => {
    const { appId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(appId)) {
        throw new ErrorHandler(req.t("AppointmentIdWrong"), HttpStatus.BAD_REQUEST, false);
    }
    const IsInPending = await Appointment.findOne({ status: 0, _id: new mongoose.Types.ObjectId(appId) });
    if (!IsInPending) {
        throw new ErrorHandler(req.t("SendAppointmentReminderError"), HttpStatus.BAD_REQUEST, false);
    }
    //send Email
    const getClientAndAppointmentDetails = await Appointment.aggregate([
        { $match: { _id: new mongoose.Types.ObjectId(appId) } },
        {
            $lookup: {
                from: "clients",
                localField: "clientId",
                foreignField: "_id",
                as: 'clientData',
                pipeline: [
                    { $project: { firstName: 1, lastName: 1, userId: 1 } }
                ]

            },
        },
        {
            $lookup: {
                from: "beauticians",
                localField: "beauticianId",
                foreignField: "_id",
                as: 'beauticianData',
                pipeline: [
                    { $project: { businessNumber: 1, address: 1 } }
                ]

            },
        },
        {
            $lookup: {
                from: 'addresses',
                localField: 'beauticianData.address',
                foreignField: "_id",
                as: 'addressB'
            }
        },
        {
            $lookup: {
                from: 'provinces',
                localField: 'addressB.province',
                foreignField: "_id",
                as: 'province'
            }
        },
        {
            $lookup: {
                from: "users",
                localField: "clientData.userId",
                foreignField: "_id",
                as: 'userDetail',
                pipeline: [
                    { $project: { phoneNumber: 1, email: 1 } }
                ]

            },
        },
        {
            $lookup: {
                from: "beauticianservices",
                localField: "serviceId",
                foreignField: "_id",
                as: 'serviceDetails',
                pipeline: [
                    { $project: { serviceType: 1, price: 1, duration: 1 } }
                ]

            },
        },
        {
            $lookup: {
                from: "servicetypelists",
                localField: "serviceDetails.serviceType",
                foreignField: "_id",
                as: 'ServiceTypeDetails',
                pipeline: [
                    { $project: { serviceTypeName: 1, serviceTypeName_fr: 1, serviceCategoryId: 1 } }
                ]
            },
        },
        {
            $project: {
                _id: 1,
                dateTime: 1,
                addressB: { $arrayElemAt: ['$addressB', 0] },
                businessName: { $arrayElemAt: ['$beauticianData.businessName', 0] },
                firstName: { $arrayElemAt: ['$clientData.firstName', 0] },
                lastName: { $arrayElemAt: ['$clientData.lastName', 0] },
                phoneNumber: { $arrayElemAt: ['$userDetail.phoneNumber', 0] },
                email: { $arrayElemAt: ['$userDetail.email', 0] },
                serviceName: { $arrayElemAt: ['$ServiceTypeDetails.serviceTypeName', 0] },
                serviceName_fr: { $arrayElemAt: ['$ServiceTypeDetails.serviceTypeName_fr', 0] },
                duration: { $arrayElemAt: ['$serviceDetails.duration', 0] },
                price: 1,
                place: 1,
                provinceName: { $arrayElemAt: ['$province.name', 0] },
                provinceName_fr: { $arrayElemAt: ['$province.name_fr', 0] }
            }
        },
        {
            $group: {
                _id: '$_id',
                addressB: { $first: '$addressB' },
                place: { $first: '$place' },
                provinceName: { $first: '$provinceName' },
                clientEmail: { $first: '$email' },
                businessName: { $first: '$businessName' },
                dateTime: { $first: '$dateTime' },
                price: { $first: '$price' },
                phoneNumber: { $first: '$phoneNumber' },
                firstName: { $first: '$firstName' },
                lastName: { $first: '$lastName' },
                serviceName: { $first: '$serviceName' },
                duration: { $first: '$duration' },
            }
        }
    ])
    if (getClientAndAppointmentDetails?.length > 0) {
        getClientAndAppointmentDetails.forEach(async (ele, i) => {
            const emailDetails = {
                clientEmail: ele.clientEmail,
                businessName: ele.businessName,
                firstName: ele.firstName,
                lastName: ele.lastName,
                phoneNumber: ele.phoneNumber,
                date: moment(ele.dateTime).utc().format('dddd, DD-MMM-YYYY'),
                time: moment(ele.dateTime).utc().format('HH:mm A'),
                address: ele.addressB[0]?.address + "," + ele.provinceName,
                price: ele.price,
                serviceTypeName: ele.serviceName,
            }
            await ReminderServiceCEmail(emailDetails);
        })
    }

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("SendAppointmentReminderSuccess") })

})
module.exports = { getCalenderAppointmentList, getAppointmentDetails, getAppointmentPreDetails, saveAppointmentDetails, handlePastAppointmentStatus, getAppointmentPaymentDetails, cancelAppointmentByBeautician, saveNoShowProtection, saveCancelProtection, getNOShowAndCancellationProtection, saveBookingSettings, getBookingSettings, inviteContacts, getInvitedClientList, SendAppointmentReminder }