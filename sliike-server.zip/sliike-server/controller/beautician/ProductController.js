const catchAsyncError = require("../../middleware/catchAsyncError");
const { validationResult } = require("express-validator");
const Beautician = require("../../models/Beautician");
const ErrorHandler = require("../../utils/ErrorHandling");
const HttpStatus = require("../../utils/HttpStatus");
const BeauticianProduct = require("../../models/BeauticianProduct");
const formidable = require("formidable");
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const path = require("path");
const { pathEndpoint } = require("../../utils/Constant");
const { generateInventoryCode } = require("../../utils/generateNumericId");
const { default: mongoose } = require("mongoose");
const { uploadFile } = require("../../libs/aws/uploadImg");
const { deleteFile } = require("../../libs/aws/deleteImg");
const { productValidation } = require("../../middleware/validations");
const ValidationError = require("../../utils/validationError");
const ProductCategoryList = require("../../models/ProductCategoryList");
const BrandProducts = require("../../models/BrandProducts");
const Order = require("../../models/Order");
const { addProductMail } = require("../../utils/emailTeplates");

//generate Inventory Code
const getInventoryCode = catchAsyncError(async (req, res, next) => {
    let InventoryCode = generateInventoryCode(6);
    async function codeExists(code) {
        const isCodeExists = await BeauticianProduct.findOne({ inventoryCode: code });
        return new Promise((resolve, reject) => {
            if (isCodeExists) {
                resolve();
            } else {
                reject();
            }
        });
    };
    codeExists(InventoryCode)
        .then(() => {
            InventoryCode = generateInventoryCode(6);//if code exists generate again and check
            return codeExists(InventoryCode);
        })
        .then(() => {
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { inventoryCode: InventoryCode }, message: "InventoryCode generated successfully." });
        })
        .catch(() => {
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { inventoryCode: InventoryCode }, message: "InventoryCode generated successfully." });
        });
});
//add edit bulk ProductImg 
const addEditProductDetails = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const beauticianDetails = await Beautician.findOne({ userId: id }).populate({ path: 'userId', select: "email" });

    if (beauticianDetails) {
        if (beauticianDetails.screenStatus !== 7 && beauticianDetails?.stripe_id === null) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please complete you payment setup" });
        }
        const form = formidable({ multiples: true });
        form.parse(req, async (err, fields, files) => {
            if (err) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("somethingIsWrongInImageUpload") });
            }
            const { productId, productCategory, colorVariation, productName, wtValue, wtUnit, htValue, htUnit, lengthValue, lengthUnit, widthValue, widthUnit, description, price, inventoryCode, isPromotion, isStockTrack, stockQuantity, promotionDetails, oldImgURLs, proPrice, discount, startDate, endDate } = fields;
            const validation = productValidation.filter(field => !fields[field]);
            if (validation.length > 0) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: `${validation.join(', ')} is required` });
            }

            if (!mongoose.Types.ObjectId.isValid(productCategory)) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Invalid productCategory." });
            }

            const validCategoryId = await ProductCategoryList.findOne({ _id: productCategory });
            if (!validCategoryId) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Product category id is not valid" });
            }
            if (isStockTrack === true) {
                if (!stockQuantity) {
                    return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Missing values for stockQuantity." });
                }
            }
            if (isPromotion === true) {
                if (!proPrice || !discount || !startDate || !endDate) {
                    return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Missing values for proPrice, discount, startDate or endDate." });
                }
            }
            try {
                if (productId) {
                    const productData = await BeauticianProduct.findOne({ _id: productId });
                    if (productData) {
                        productData.productCategory = productCategory
                        productData.productName = productName || productData.productName;
                        productData.wtValue = wtValue || productData.wtValue;
                        productData.wtUnit = wtUnit || productData.wtUnit;
                        productData.htValue = htValue || productData.htValue;
                        productData.htUnit = htUnit || productData.htUnit;
                        productData.lengthValue = lengthValue || productData.lengthValue;
                        productData.lengthUnit = lengthUnit || productData.lengthUnit;
                        productData.widthValue = widthValue || productData.widthValue;
                        productData.widthUnit = widthUnit || productData.widthUnit;
                        productData.description = description || productData.description;
                        productData.price = price || productData.price;
                        productData.inventoryCode = inventoryCode || productData.inventoryCode;
                        productData.isStockTrack = isStockTrack || productData.isStockTrack;
                        if (productData.isStockTrack == true) {
                            productData.stockQuantity = stockQuantity || productData.stockQuantity;
                        }
                        if (colorVariation?.length) {
                            productData.colorVariation = colorVariation
                        }
                        if (isPromotion === true) {
                            if (productData.price <= proPrice) {
                                throw new ErrorHandler(req.t("priceIsGreater"), HttpStatus.BAD_REQUEST, false);
                            }
                            productData.promotionDetails = {
                                proPrice, discount, startDate, endDate
                            }
                        }
                        files.images = Array.isArray(files.images) ? files.images : [files.images];
                        if (files.images[0] != undefined) {
                            if (oldImgURLs && oldImgURLs.length) {
                                await Promise.all(files.images?.map(async newImg => {
                                    const ImgName = newImg.originalFilename.split(".")
                                    const extension = ImgName[ImgName.length - 1];
                                    if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                                        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: req.t("ImageExtension", { extension: extension }) });
                                    }
                                    const fileName = (newImg.originalFilename = uuidv4() + "." + extension);

                                    const newPath = `${pathEndpoint.beauticianProductImg}${fileName}`;

                                    // Upload to AWS
                                    const uploadImgRes = await uploadFile(newImg, newPath, extension);
                                    productData.imgName.push(uploadImgRes.imageUrl);
                                    // return uploadImgRes.imageUrl
                                }));

                                await Promise.all(oldImgURLs.map(async (val) => {
                                    const removeImg = val.includes(process.env.AWS_BUCKET_REGION) ? val.replace(process.env.IMAGE_BASE_URL_WITH_REGION, "") : val.replace(process.env.IMAGE_BASE_URL, "")
                                    await deleteFile(removeImg)
                                    productData.imgName.pull(val);
                                }));
                            } else {
                                return res.status(HttpStatus.OK).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Old image URL's missing" })
                            }
                        }
                        await productData.save();
                        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("editProductImgsSuccess") })
                    } else {
                        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Product details not found" });
                    }
                } else {
                    if (!files.images) {
                        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("imageMissing") });
                    } else {
                        let imgName = [];
                        try {
                            if (files.images.length) {
                                imgName = await Promise.all(files.images?.map(async newImg => {
                                    const ImgName = newImg.originalFilename.split(".")
                                    const extension = ImgName[ImgName.length - 1];
                                    if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                                        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: req.t("ImageExtension", { extension: extension }) });
                                    }
                                    const fileName = (newImg.originalFilename = uuidv4() + "." + extension);

                                    const newPath = `${pathEndpoint.beauticianProductImg}${fileName}`;

                                    // Upload to AWS
                                    const uploadImgRes = await uploadFile(newImg, newPath, extension);
                                    return uploadImgRes.imageUrl
                                }));

                            }
                            else if (files.images) {
                                const ImgName = files.images.originalFilename.split(".")
                                const extension = ImgName[ImgName.length - 1];
                                if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                                    return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: req.t("ImageExtension", { extension: extension }) });
                                }
                                const fileName = (files.images.originalFilename = uuidv4() + "." + extension);

                                const newPath = `${pathEndpoint.beauticianProductImg}${fileName}`;

                                // Upload to AWS
                                const uploadImgRes = await uploadFile(files.images, newPath, extension);
                                imgName.push(uploadImgRes.imageUrl)

                            } else {
                                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("imageMissing") });
                            }
                        } catch (error) {
                            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, error });
                        }
                        if (imgName.length) {
                            const newProduct = await BeauticianProduct.create({
                                productCategory, colorVariation, productName, imgName: imgName, wtValue, wtUnit, htValue, htUnit, lengthValue, lengthUnit, widthValue, widthUnit,
                                description, price, inventoryCode, isStockTrack, stockQuantity, isPromotion, promotionDetails, beauticianId: beauticianDetails._id,
                            });
                            if (promotionDetails !== null) {
                                if (isPromotion) {
                                    newProduct.promotionDetails = {
                                        proPrice, discount, startDate, endDate
                                    }
                                }
                            }
                            await newProduct.save();
                            const emailDetails = {
                                beauticianEmail: beauticianDetails.userId.email,
                                businessName: beauticianDetails.businessName
                            }
                            await addProductMail(emailDetails);
                            return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, data: { productId: newProduct._id }, message: req.t("addProductImgsSuccess") });
                        }
                    }
                }
            } catch (error) {
                console.log("error", error);
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Something is wrong" });
            }
        })
    } else {
        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("beauticianNotFound") });
    }
});

// add  & Edit Product by beautician
// const addEditProductDetails = catchAsyncError(async (req, res, next) => {
//     const id = req.user;
//     const { productPId } = req.params; //for edit API
//     const { productId, productCategory, productName, wtValue, wtUnit, htValue, htUnit, lengthValue, lengthUnit, widthValue, widthUnit, colorVariation, description, price, inventoryCode, isStockTrack, stockQuantity, isPromotion, proPrice, discount, startDate, endDate } = req.body;
//     let proId = productPId || productId;
//     let productExists;
//     //throw error from middleware
//     const errors = validationResult(req);
//     if (errors.errors.length !== 0) {
//         throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST);
//     };

//     const beauticianData = await Beautician.findOne({ userId: id, isDeleted: 0 });
//     if (beauticianData) {
//         productExists = await BeauticianProduct.findOne({ _id: proId, beauticianId: beauticianData._id });

//         if (productId && productExists.detailStep === 2) {
//             throw new ErrorHandler(req.t("productDetailExists"), HttpStatus.BAD_REQUEST);
//         }
//         if (inventoryCode) {
//             if (productPId) {
//                 throw new ErrorHandler(req.t("editInventoryCode"), HttpStatus.BAD_REQUEST, false);
//             }
//             const isCodeExists = await BeauticianProduct.findOne({ inventoryCode });
//             if (isCodeExists) {
//                 throw new ErrorHandler(req.t("inventoryCodeExists"), HttpStatus.BAD_REQUEST);
//             }
//         }

//         if (productExists) {
//             if (productCategory && productPId) {
//                 throw new ErrorHandler(req.t("editProductCat"), HttpStatus.BAD_REQUEST, false);
//             }
//             productExists.productCategory = productCategory
//             productExists.productName = productName || productExists.productName;
//             productExists.wtValue = wtValue || productExists.wtValue;
//             productExists.wtUnit = wtUnit || productExists.wtUnit;
//             productExists.htValue = htValue || productExists.htValue;
//             productExists.htUnit = htUnit || productExists.htUnit;
//             productExists.lengthValue = lengthValue || productExists.lengthValue;
//             productExists.lengthUnit = lengthUnit || productExists.lengthUnit;
//             productExists.widthValue = widthValue || productExists.widthValue;
//             productExists.widthUnit = widthUnit || productExists.widthUnit;
//             productExists.description = description || productExists.description;
//             productExists.price = price || productExists.price;
//             productExists.inventoryCode = inventoryCode || productExists.inventoryCode;
//             productExists.isStockTrack = isStockTrack || productExists.isStockTrack;
//             if (productExists.isStockTrack == true) {
//                 productExists.stockQuantity = stockQuantity || productExists.stockQuantity;
//             }
//             if (colorVariation?.length) {
//                 productExists.colorVariation = colorVariation
//             }
//             if (productExists.detailStep === 1) {
//                 productExists.detailStep = 2;
//             }
//             if (isPromotion) {
//                 if (productExists.price <= proPrice) {
//                     throw new ErrorHandler(req.t("priceIsGreater"), HttpStatus.BAD_REQUEST, false);
//                 }
//                 productExists.promotionDetails = {
//                     proPrice, discount, startDate, endDate
//                 }
//             }
//             await productExists.save();
//             if (productPId) {
//                 return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("productUpdated") })
//             }
//             return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, message: req.t("productAdded") })
//         } else {
//             throw new ErrorHandler(req.t("InavlidProductId"), HttpStatus.BAD_REQUEST, false)
//         }
//     } else {
//         throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.UNAUTHORIZED, false);
//     }

// });

// edit single Img

const updateSingleProductImg = catchAsyncError(async (req, res, next) => {
    const { productPId } = req.params;
    //throw error from middleware
    const errors = validationResult(req);
    if (errors.errors.length !== 0) {
        throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST);
    };
    const productData = await BeauticianProduct.findOne({ _id: productPId });
    if (!productData) {
        throw new ErrorHandler("Invalid ProductId", HttpStatus.BAD_REQUEST, false)
    }
    const form = formidable({ multiples: true });
    form.parse(req, async (err, fields, files) => {
        if (err) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("somethingIsWrongInImageUpload") });
        }
        const { oldImgURL } = fields;
        if (files.image && oldImgURL) {
            const imgName = files.image.originalFilename.split(".");
            const extension = imgName[imgName.length - 1];
            if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: req.t("ImageExtension", { extension: extension }) });
            }

            const fileName = (files.image.originalFilename =
                uuidv4() + "." + extension);
            const newPath = __dirname + `${pathEndpoint.beauticianProductImg}${fileName}`;
            try {
                const uploadImgRes = await uploadFile(files.image, newPath, extension);
                //remove old file
                if (oldImgURL) {
                    const removeImg = oldImgURL.includes(process.env.AWS_BUCKET_REGION) ? oldImgURL.replace(process.env.IMAGE_BASE_URL_WITH_REGION, "") : oldImgURL.replace(process.env.IMAGE_BASE_URL, "")
                    await deleteFile(removeImg)
                    productData.imgName.pull(oldImgURL);
                }
                productData.imgName.push(uploadImgRes.imageUrl);
                await productData.save();
                return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { imgName: imgNameList }, message: req.t("updateSingleProductImgSuccess") });

            } catch (error) {
                return res.status(HttpStatus.ERROR).json({
                    status: HttpStatus.ERROR,
                    success: false,
                    message: req.t("somethingIsWrongInImageUpload"),
                });
            }
        } else {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("updateSingleProductImgError") });
        }
    })
});
// delete Single Img
const deleteSingleImg = catchAsyncError(async (req, res, next) => {
    const { productPId } = req.params;
    const { imgPath } = req.body;
    //throw error from middleware
    const errors = validationResult(req);
    if (errors.errors.length !== 0) {
        throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST);
    };
    const isImgExists = await BeauticianProduct.findOne({ _id: productPId, imgName: { $in: imgPath } });
    if (!isImgExists) {
        throw new ErrorHandler(req.t("imageNotExists"), HttpStatus.BAD_REQUEST);
    }
    const productData = await BeauticianProduct.findOneAndUpdate(
        { _id: new mongoose.Types.ObjectId(productPId) },
        { $pull: { imgName: imgPath } },
        { new: true }
    );
    if (!productData.imgName.includes(imgPath)) {
        const removeImg = imgPath.includes(process.env.AWS_BUCKET_REGION) ? imgPath.replace(process.env.IMAGE_BASE_URL_WITH_REGION, "") : imgPath.replace(process.env.IMAGE_BASE_URL, "")
        await deleteFile(removeImg)
    }
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { imgName: productData.imgName }, message: req.t("deleteSingleImgSuccess") });

});

//get Product details
const getProductDetails = catchAsyncError(async (req, res, next) => {
    const { productPId } = req.params;
    const id = req.user;
    //throw error from middleware
    const errors = validationResult(req);
    if (errors.errors.length !== 0) {
        throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST);
    };
    const beauticianData = await Beautician.findOne({ userId: id });

    const productDetails = await BeauticianProduct.findOne({ beauticianId: beauticianData._id, _id: productPId, isDelete: 0 }).select("-nubOfCartClicked -nubOfShareClicked -nubOfView -isDelete -createdAt -updatedAt -__v");
    if (productDetails) {
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: productDetails, message: "Product details" });
    }
    throw new ErrorHandler("Data not found.", HttpStatus.BAD_REQUEST);
});

//const delete product
const deleteProductDetail = catchAsyncError(async (req, res, next) => {
    const { productPId } = req.params;
    const id = req.user;
    //throw error from middleware
    const errors = validationResult(req);
    if (errors.errors.length !== 0) {
        throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST);
    };
    const beauticianData = await Beautician.findOne({ userId: id });
    const productDetails = await BeauticianProduct.findOneAndUpdate({ beauticianId: beauticianData._id, _id: productPId, isDelete: 0 }, { isDelete: 1 }, { new: true });
    if (productDetails) {
        return res.status(HttpStatus.DELETED).json({ status: HttpStatus.DELETED, success: true, message: req.t("deleteProductDetailSuccess") });
    }
    throw new ErrorHandler(req.t("alreadyDeleted"), HttpStatus.BAD_REQUEST);

})

// get Product List
const getBeauticianProductList = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    //throw error from middleware
    const errors = validationResult(req);
    if (errors.errors.length !== 0) {
        throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST);
    };
    const beauticianData = await Beautician.findOne({ userId: id });

    const productDetails = await BeauticianProduct.find({ beauticianId: beauticianData._id, isDelete: 0 }).select("productName isStockTrack stockQuantity imgName price promotionDetails").lean();
    if (productDetails.length) {
        productDetails?.forEach((val) => {
            val.imgUrl = val.imgName;
            val.promoPrice = null;
            if (val.promotionDetails) {
                if (val.promotionDetails.startDate < new Date() && val.promotionDetails.endDate > new Date()) {
                    val.promoPrice = val.promotionDetails.proPrice;
                }
            }
        })
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: productDetails, message: "Product details" });
    } else {
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: productDetails, message: "Product details" });
    }
    // throw new ErrorHandler("Data not found.", HttpStatus.BAD_REQUEST);
});

// get product stocks
const stockRecords = catchAsyncError(async (req, res, next) => {
    const Id = req.user;
    const beauticianData = await Beautician.findOne({ userId: Id });

    if (beauticianData) {
        const data = await BeauticianProduct.aggregate([
            { $match: { beauticianId: new mongoose.Types.ObjectId(beauticianData._id), isStockTrack: true } },
            {
                $lookup: {
                    from: 'productcategorylists',
                    localField: 'productCategory',
                    foreignField: "_id",
                    as: 'categoryData',
                    pipeline: [
                        { $project: { productCategoryName: 1, productCategoryName_fr: 1, } }
                    ]
                },
            },
            { $project: { productName: 1, isStockTrack: 1, stockQuantity: 1, soldQuantity: 1, productsCategory: { $arrayElemAt: ['$categoryData.productCategoryName', 0] }, productsCategory_fr: { $arrayElemAt: ['$categoryData.productCategoryName_fr', 0] } } }
        ]);
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data });
    } else {
        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("beauticianNotFound") });
    }
});

// get order data
const getOrderData = catchAsyncError(async (req, res, next) => {
    const Id = req.user;
    const beauticianData = await Beautician.findOne({ userId: Id });
    if (beauticianData) {
        const data = await Order.aggregate([
            {
                $match: {
                    productData: {
                        $elemMatch: {
                            beauticianId: new mongoose.Types.ObjectId(beauticianData._id)
                        }
                    }
                }
            },
            {
                $lookup: {
                    from: 'beauticianproducts',
                    localField: 'productData.productId',
                    foreignField: "_id",
                    as: 'productDetails',
                    pipeline: [
                        { $project: { productName: 1, imgName: 1 } }
                    ]
                },
            },
            {
                $project: {
                    productId: { $arrayElemAt: ['$productData.productId', 0] },
                    price: { $arrayElemAt: ['$productData.price', 0] },
                    createdAt: 1,
                    status: {
                        $ifNull: ["$status", "pending"]
                    },
                    productName: { $arrayElemAt: ['$productDetails.productName', 0] },
                    productImage: { $arrayElemAt: ['$productDetails.imgName', 0] },
                }
            },
        ]);
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data });
    } else {
        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("beauticianNotFound") });
    }
});

// get single order details
const getSingleOrderDetails = catchAsyncError(async (req, res, next) => {
    const { orderId } = req.params;

    const data = await Order.aggregate([
        { $match: { _id: new mongoose.Types.ObjectId(orderId) } },
        {
            $lookup: {
                from: 'beauticianproducts',
                localField: 'productData.productId',
                foreignField: "_id",
                as: 'productDetails',
                pipeline: [
                    { $project: { productName: 1, } }
                ]
            },
        },
        {
            $lookup: {
                from: 'addresses',
                localField: 'shippingAddressId',
                foreignField: "_id",
                as: 'deliveryAddress',
                pipeline: [
                    {
                        $project: {
                            address: { $ifNull: ["$address", null] },
                            street: { $ifNull: ["$street", null] },
                            apartment: { $ifNull: ["$apartment", null] },
                            zipCode: { $ifNull: ["$zipCode", null] },
                        }
                    }
                ]
            },
        },
        {
            $lookup: {
                from: 'clients',
                localField: 'clientId',
                foreignField: "_id",
                as: 'clientDetails',
                pipeline: [
                    { $project: { firstName: 1, userId: 1, lastName: 1 } }
                ]
            },
        },
        {
            $lookup: {
                from: 'users',
                localField: 'clientDetails.userId',
                foreignField: "_id",
                as: 'userDetails',
                pipeline: [
                    { $project: { phoneNumber: 1, } }
                ]
            },
        },
        {
            $project: {
                subTotal: 1,
                GST: 1,
                PST: 1,
                HST: 1,
                QST: 1,
                TotalPrice: 1,
                status: {
                    $ifNull: ["$status", "pending"]
                },
                quantity: { $arrayElemAt: ["$productData.totalQuanity", 0] },
                productName: { $arrayElemAt: ["$productDetails.productName", 0] },
                clientFirstName: { $arrayElemAt: ["$clientDetails.firstName", 0] },
                clientLastName: { $arrayElemAt: ["$clientDetails.lastName", 0] },
                clientPhoneNo: { $arrayElemAt: ["$userDetails.phoneNumber", 0] },
                deliveryAddress: 1,
            }
        }
    ]);

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data })
})
module.exports = { getInventoryCode, addEditProductDetails, updateSingleProductImg, deleteSingleImg, getProductDetails, deleteProductDetail, getBeauticianProductList, stockRecords, getOrderData, getSingleOrderDetails }