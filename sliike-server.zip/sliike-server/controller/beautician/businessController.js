const Beautician = require("../../models/Beautician");
const User = require("../../models/User");
const Address = require("../../models/Address");
const HttpStatus = require("../../utils/HttpStatus");

const catchAsyncError = require("../../middleware/catchAsyncError");
const ErrorHandler = require("../../utils/ErrorHandling");
const { validationResult } = require("express-validator");
const formidable = require("formidable");
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const { pathEndpoint, notificationMSGs } = require("../../utils/Constant");
const { default: mongoose } = require("mongoose");
const Employee = require("../../models/Employee");
const Client = require("../../models/Client");
const FcmNotification = require("../../models/FcmNotification");
const { fcmNotification } = require("../../utils/fcmNotification");
const { uploadFile } = require("../../libs/aws/uploadImg");
const { deleteFile } = require("../../libs/aws/deleteImg");
const BeauticianNotification = require("../../models/BeauticianNotification");

// Beautician Sign Up 
const addBusinessDetails = catchAsyncError(async (req, res, next) => {

    const id = req.user;

    const { businessName, businessNumber, address, country, province, street_address, apartment, city, post_code, coordinates } = req.body;

    const errors = validationResult(req);
    if (errors.errors.length !== 0) {
        throw new ErrorHandler(req.t(errors?.errors[0]?.msg), HttpStatus.BAD_REQUEST);
    };

    if (!coordinates?.length) {
        throw new ErrorHandler(req.t("validLocation"), HttpStatus.BAD_REQUEST);
    }
    const data = await User.findOne({ _id: id });

    if (data) {
        const beauticianData = await Beautician.findOne({ userId: id });
        // if (beauticianData.address) {
        //     throw new ErrorHandler(req.t("alredayAddress"), HttpStatus.BAD_REQUEST);
        // }

        if (beauticianData) {
            if (beauticianData.address) {
                const coordinates_new = [coordinates[1], coordinates[0]]
                beauticianData.businessName = businessName;
                beauticianData.businessNumber = businessNumber;
                beauticianData.country = country;
                // beauticianData.address = newAddress._id;
                beauticianData.screenStatus = 4;
                beauticianData.location = { type: 'Point', coordinates: coordinates_new };
                await beauticianData.save();
                const addressData = await Address.findOne({ _id: beauticianData.address });
                if (addressData) {
                    addressData.address = address;
                    addressData.country = country;
                    addressData.province = province;
                    addressData.street = street_address;
                    addressData.apartment = apartment;
                    addressData.city = city;
                    addressData.zipCode = post_code;
                    await addressData.save();
                }
                return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("addBusinessDetailsSuccess") });
            } else {
                const newAddress = await Address.create({ address, country, province, street: street_address, apartment, city, zipCode: post_code });
                const coordinates_new = [coordinates[1], coordinates[0]]
                beauticianData.businessName = businessName;
                beauticianData.businessNumber = businessNumber;
                beauticianData.country = country;
                beauticianData.address = newAddress._id;
                beauticianData.screenStatus = 4;
                beauticianData.location = { type: 'Point', coordinates: coordinates_new };
                await beauticianData.save();
                // push notification
                const deviceData = await FcmNotification.find({ memberId: beauticianData._id });
                const deviceIds = deviceData?.map(ele => ele.firebaseToken);
                if (deviceIds.length > 0) {
                    let message = notificationMSGs.businessSetUPCtx;
                    await BeauticianNotification.create({
                        beauticianId: beauticianData._id,
                        title: message.title,
                        details: message.message
                    })
                    const notifications = fcmNotification({ messageCtx: message, deviceIds });
                    await Promise.all([notifications]);
                }
                return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("addBusinessDetailsSuccess") });
            }
        } else {
            throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST);
        }
    } else {
        throw new ErrorHandler(req.t("userNotFound"), HttpStatus.BAD_REQUEST);
    }
});

const addBusinessType = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { isProvideProduct, isProvideService } = req.body;

    const data = await User.findOne({ _id: id });

    if (data) {
        const beauticianData = await Beautician.findOne({ userId: id });

        if (beauticianData) {
            if (isProvideProduct === 1) {
                beauticianData.isProvideProduct = isProvideProduct;
            }

            if (isProvideService === 1) {
                beauticianData.isProvideService = isProvideService;
            }
            beauticianData.screenStatus = 5;
            await beauticianData.save();

            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("addBusinessTypeSuccess") });
        } else {
            throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST);
        }
    } else {
        throw new ErrorHandler(req.t("userNotFound"), HttpStatus.BAD_REQUEST);
    }
});

const addBeauticianServiceMethod = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { hasShop, IsServeAtClient, IsServeAtOwnPlace } = req.body;
    const EnumType = [0, 1]
    if (!EnumType.includes(hasShop) || !EnumType.includes(IsServeAtClient) || !EnumType.includes(IsServeAtOwnPlace)) {
        throw new ErrorHandler(req.t("serviceMethodError"), HttpStatus.BAD_REQUEST);
    }
    const beauticianData = await Beautician.findOne({ userId: id });
    if (beauticianData) {
        if (hasShop === 1 && IsServeAtOwnPlace !== 1) {
            throw new ErrorHandler(req.t("isNotServeAtOwnPlace"), HttpStatus.BAD_REQUEST);
        }
        if (hasShop === 0 && IsServeAtClient !== 1) {
            throw new ErrorHandler(req.t("isNotServeAtClientPlace"), HttpStatus.BAD_REQUEST);
        }
        beauticianData.hasShop = hasShop;
        beauticianData.IsServeAtClient = IsServeAtClient;
        beauticianData.IsServeAtOwnPlace = IsServeAtOwnPlace;
        await beauticianData.save();
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("addBeauticianServiceMethodSuccess") });
    } else {
        throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST);
    }
});
const getLocationDetails = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const locationDetails = await Beautician.aggregate([
        { $match: { userId: new mongoose.Types.ObjectId(id) } },
        {
            $lookup: {
                from: 'addresses',
                localField: 'address',
                foreignField: '_id',
                as: 'address'
            }
        },
        {
            $lookup: {
                from: 'provinces',
                localField: 'address.province',
                foreignField: '_id',
                pipeline: [
                    { $project: { name: 1, name_fr: 1, } },
                ],
                as: 'province'
            }
        },
        {
            $project: {
                location: 1,
                hasShop: 1,
                IsServeAtOwnPlace: 1,
                IsServeAtClient: 1,
                country: 1,
                address: {
                    address: { $first: '$address.address' },
                    province: { $first: '$province' },
                    street: { $first: '$address.street' },
                    apartment: { $first: '$address.apartment' },
                    city: { $first: '$address.city' },
                    zipCode: { $first: '$address.zipCode' }
                }
            }
        }
    ]);
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t('getLocationDetailsSuccess'), data: locationDetails });

});
const updateSalonLocation = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { latitude, longitude, address, city, provinceId, zipCode, country } = req.body;
    if (!mongoose.Types.ObjectId.isValid(provinceId)) {
        throw new ErrorHandler(req.t("provinceIdNotValid"), HttpStatus.BAD_REQUEST, false);
    }
    if (!latitude && !longitude) {
        throw new ErrorHandler(req.t("lat&lonMissing"), HttpStatus.BAD_REQUEST, false);
    }
    const updateBeautician = await Beautician.findOneAndUpdate({ userId: id }, {
        location: {
            type: 'Point',
            coordinates: [longitude, latitude]
        },
        country
    }, { new: true });
    //update address
    const updateAddress = await Address.findOneAndUpdate({ _id: updateBeautician.address }, {
        address, city, zipCode, province: provinceId, location: {
            type: 'Point',
            coordinates: [longitude, latitude]
        },
    }, { new: true });
    if (updateBeautician && updateAddress) {
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("updateSalonLocationSucess") });
    } else {
        throw new ErrorHandler(req.t("updateSalonLocationError"), HttpStatus.BAD_REQUEST, false);
    }
})
//business logo and workspace
const addBusinessLogo = catchAsyncError(async (req, res, next) => {
    const id = req.user;

    const beauticianDetails = await Beautician.findOne({ userId: id });
    const form = formidable({ multiples: true });
    form.parse(req, async (err, fields, files) => {
        if (err) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("somethingIsWrongInImageUpload") });
        }
        if (files.logo) {
            const imgName = files.logo.originalFilename.split(".");
            const extension = imgName[imgName.length - 1];
            if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: req.t("ImageExtension", { extension: extension }) });
            }

            const fileName = (files.logo.originalFilename =
                uuidv4() + "." + extension);
            const newPath = `${pathEndpoint.beauticianLogo}${fileName}`

            try {
                const uploadImgRes = await uploadFile(files.logo, newPath, extension);
                if (beauticianDetails.logo) {
                    const removeImg = beauticianDetails.logo.includes(process.env.AWS_BUCKET_REGION) ? beauticianDetails.logo.replace(process.env.IMAGE_BASE_URL_WITH_REGION, "") : beauticianDetails.logo.replace(process.env.IMAGE_BASE_URL, "")
                    await deleteFile(removeImg)
                }
                beauticianDetails.logo = uploadImgRes.imageUrl;
                await beauticianDetails.save();
                return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, message: req.t("addBusinessLogoImgSuccess") });
            } catch (error) {
                return res.status(HttpStatus.ERROR).json({
                    status: HttpStatus.ERROR,
                    success: false,
                    message: req.t('somethingWentWrong'),
                });
            }
        } else {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("addBusinessLogoImgError") });
        }
    })
});
const addWorkSpaceImg = catchAsyncError(async (req, res, next) => {
    const id = req.user;

    const beauticianDetails = await Beautician.findOne({ userId: id });
    if (beauticianDetails.workSpaceImgs.length >= 4) {
        throw new ErrorHandler(req.t("workSpaceImgLength"), HttpStatus.BAD_REQUEST, false)
    }
    if (beauticianDetails) {
        const form = formidable({ multiples: true });
        form.parse(req, async (err, fields, files) => {
            if (err) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t('somethingIsWrongInImageUpload') });
            }

            if (files.workspace) {
                files.workspace = Array.isArray(files.workspace) ? files.workspace : [files.workspace];
                try {
                    const imgData = await Promise.all(files.workspace?.map(async newImg => {
                        const imgName = newImg.originalFilename.split(".");
                        const extension = imgName[imgName.length - 1];
                        if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                            return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: req.t("ImageExtension", { extension: extension }) });
                        }
                        const fileName = uuidv4() + "." + extension;
                        const newPath = `${pathEndpoint.beauticianWorkSpace}${fileName}`;
                        // Upload to AWS
                        const uploadImgRes = await uploadFile(newImg, newPath, extension);
                        return uploadImgRes.imageUrl;
                    }));
                    beauticianDetails.workSpaceImgs = [...beauticianDetails.workSpaceImgs, ...imgData]
                    await beauticianDetails.save();
                    return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, message: req.t("addWorkSpaceImgSuccess") });

                } catch (error) {
                    return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, error });
                }
            } else {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("workSpaceImgError") });
            }
        })
    } else {
        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("beauticianNotFound") });
    }
});

const getLogoImg = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const beauticianImg = await Beautician.findOne(
        { userId: new mongoose.Types.ObjectId(id) },
        { id: 1, uid: 1, logo: 1 }
    );
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("getLogoImgSuccess"), data: beauticianImg });

});
const getWorkSpaceImg = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const workImgList = await Beautician.aggregate([
        { $match: { userId: new mongoose.Types.ObjectId(id) } },
        {
            $project: { id: 1, uid: 1, workSpaceImgs: 1 }
        }
    ]);
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("getWorkSpaceImgSuccess"), data: workImgList });

});

const updateWorkSpaceImg = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const form = formidable({ multiples: true });
    const beauticianDetails = await Beautician.findOne({ userId: id });
    form.parse(req, async (err, fields, files) => {
        if (err) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t('somethingIsWrongInImageUpload') });
        }
        const { oldImgPath } = fields;
        if (oldImgPath) {
            if (files.workspace) {
                try {
                    // for add
                    const imgName = files.workspace.originalFilename.split(".");
                    const extension = imgName[imgName.length - 1];
                    const fileName = (files.workspace.originalFilename =
                        uuidv4() + "." + extension);
                    const newPath = `${pathEndpoint.beauticianWorkSpace}${fileName}`;
                    const uploadImgRes = await uploadFile(files.workspace, newPath, extension);

                    //remove old
                    if (beauticianDetails.workSpaceImgs.includes(oldImgPath)) {
                        const removeImg = oldImgPath.includes(process.env.AWS_BUCKET_REGION) ? oldImgPath.replace(process.env.IMAGE_BASE_URL_WITH_REGION, "") : oldImgPath.replace(process.env.IMAGE_BASE_URL, "")

                        await deleteFile(removeImg)
                        beauticianDetails.workSpaceImgs.pull(oldImgPath)
                    }
                    beauticianDetails.workSpaceImgs.push(uploadImgRes.imageUrl);
                    await beauticianDetails.save();
                    return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, message: req.t('updateWorkSpaceImgSuccess') });
                } catch (error) {
                    return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: req.t('workSpaceNotUploaded') });
                }
            } else {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t('workSpaceNotFound') });
            }
        } else {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t('oldImagePathIsWrong') });
        }
    })
});

const deleteWorkSpaceImg = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { imgPath } = req.body;

    const beauticianData = await Beautician.findOneAndUpdate(
        { userId: new mongoose.Types.ObjectId(id) },
        { $pull: { workSpaceImgs: imgPath } },
        { new: true }
    );
    if (!beauticianData.workSpaceImgs.includes(imgPath)) {
        const removeImg = imgPath.includes(process.env.AWS_BUCKET_REGION) ? imgPath.replace(process.env.IMAGE_BASE_URL_WITH_REGION, "") : imgPath.replace(process.env.IMAGE_BASE_URL, "")
        await deleteFile(removeImg)
    }
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("deleteWorkSpaceImgSuccess") });
});

//Beautician Name & info module
const updateBusinessDetails = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { businessName, businessNumber, country_code, description, hourFormate, startDay, language, facebookUrl, instagramUrl, website } = req.body;
    const enumHours = [12, 24];
    const enumDays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    let calenderSetting = {}
    if (hourFormate) {
        if (!enumHours.includes(hourFormate)) {
            throw new ErrorHandler(req.t("hourFormatNotValid"), HttpStatus.BAD_REQUEST, false);
        }
        calenderSetting.formate = hourFormate;
    }

    if (startDay) {
        if (!enumDays.includes(startDay)) {
            throw new ErrorHandler(req.t("startDayNotValid"), HttpStatus.BAD_REQUEST, false);
        }
        calenderSetting.startDay = startDay;
    }
    if (businessName && businessNumber && country_code) {
        const updateObj = {
            businessName,
            businessNumber,
            country_code,
            description: description === "" ? undefined : description,
            calenderSetting: calenderSetting === {} ? undefined : calenderSetting,
            language: language === "" ? undefined : language,
            facebookUrl: facebookUrl === "" ? undefined : facebookUrl,
            instagramUrl: instagramUrl === "" ? undefined : instagramUrl,
            website: website === "" ? undefined : website
        };
        const beauticianDetails = await Beautician.findOneAndUpdate({ userId: id }, updateObj, { new: true });
        if (beauticianDetails) {
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("updateBusinessDetailsSuccess") });
        } else {
            throw new ErrorHandler(req.t("updateBusinessDetailsError"), HttpStatus.BAD_REQUEST, false);
        }
    } else {
        throw new ErrorHandler(req.t("name&Number&CodeMissing"), HttpStatus.BAD_REQUEST, false);
    }

});

//get business License details 
const getLicenseDetails = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const beauticianData = await Beautician.findOne({ userId: id }).select("isLicensed licenseImage")
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("getLicenseDetailsSuccess"), data: beauticianData });
})
// add business license 
const addBusinessLicense = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const beauticianDetails = await Beautician.findOne({ userId: id })
    const form = formidable({ multiples: true });
    form.parse(req, async (err, fields, files) => {
        if (err) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("somethingIsWrongInImageUpload") });
        }
        const { isLicensed } = fields;
        if (isLicensed) {
            if (isLicensed == 1 && !files.licenseImage) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("licencImageRequired") });
            }
            if (isLicensed == 1 || isLicensed == 0) {
                beauticianDetails.isLicensed = isLicensed;
                if (isLicensed == 0) {
                    if (beauticianDetails.licenseImage) {
                        const removeImg = beauticianDetails.licenseImage.includes(process.env.AWS_BUCKET_REGION) ? beauticianDetails.licenseImage.replace(process.env.IMAGE_BASE_URL_WITH_REGION, "") : beauticianDetails.licenseImage.replace(process.env.IMAGE_BASE_URL, "")

                        await deleteFile(removeImg)
                    }
                    beauticianDetails.licenseImage = undefined;
                }
                await beauticianDetails.save();
            } else {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("licencValueIsWrong") });
            }
        }
        if (files.licenseImage) {
            try {
                const imgName = files.licenseImage.originalFilename.split(".");
                const extension = imgName[imgName.length - 1];
                if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                    return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: req.t("ImageExtension", { extension: extension }) });
                }
                const fileName = (files.licenseImage.originalFilename =
                    uuidv4() + "." + extension);
                const newPath = `${pathEndpoint.beauticianLicense}${fileName}`;
                const uploadImgRes = await uploadFile(files.licenseImage, newPath, extension);

                if (beauticianDetails.licenseImage) {
                    const removeImg = beauticianDetails.licenseImage.includes(process.env.AWS_BUCKET_REGION) ? beauticianDetails.licenseImage.replace(process.env.IMAGE_BASE_URL_WITH_REGION, "") : beauticianDetails.licenseImage.replace(process.env.IMAGE_BASE_URL, "")
                    await deleteFile(removeImg)
                }

                await Beautician.findOneAndUpdate({ _id: beauticianDetails._id }, { licenseImage: uploadImgRes.imageUrl }, { new: true });
            } catch (error) {
                return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, error: req.t("addBusinessLicenseError") });
            }

        }
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("addBusinessLicenseSuccess") });

    })
})


module.exports = { addBusinessDetails, addBusinessType, addBeauticianServiceMethod, getLocationDetails, updateSalonLocation, addBusinessLogo, addWorkSpaceImg, getLogoImg, getWorkSpaceImg, updateWorkSpaceImg, deleteWorkSpaceImg, updateBusinessDetails, getLicenseDetails, addBusinessLicense };


