const catchAsyncError = require("../../middleware/catchAsyncError");
const ErrorHandler = require("../../utils/ErrorHandling");
const formidable = require("formidable");
const Beautician = require("../../models/Beautician");
const Employee = require("../../models/Employee");
const HttpStatus = require("../../utils/HttpStatus");
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const { pathEndpoint } = require("../../utils/Constant");
const { uploadFile } = require("../../libs/aws/uploadImg");
const { deleteFile } = require("../../libs/aws/deleteImg");

const getEmployeeDetail = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { employeeId } = req.params;

    const beauticianData = await Beautician.findOne({ userId: id });
    if (beauticianData) {
        const employeeDetail = await Employee.findOne({ beauticianId: beauticianData._id, _id: employeeId }).select("-updatedAt -createdAt -__v");
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Employee Detail.", data: employeeDetail });
    } else {
        throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST);
    }
})

const addEmployeeDetails = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const form = formidable({ multiples: true });
    const beauticianData = await Beautician.findOne({ userId: id });

    form.parse(req, async (err, fields, files) => {
        try {
            const { firstName, lastName, phoneNumber, country_code, email, title, notes, calenderColor, permissionLevel, startTime, endTime, serviceId } = fields;

            const isEmployeeExist = await Employee.findOne({ beauticianId: beauticianData._id, email })
            if (!isEmployeeExist) {
                const newEmployee = new Employee({
                    beauticianId: beauticianData._id, firstName, lastName, phoneNumber, country_code, email, title, notes, calenderColor, permissionLevel
                })
                if (serviceId?.length) {
                    newEmployee.serviceIds = serviceId.split(",")
                }
                if (startTime && endTime) {
                    newEmployee.workHours = { startTime, endTime }
                }

                if (files.profileImage) {
                    const imgName = files.profileImage.originalFilename.split(".");
                    const extension = imgName[imgName.length - 1];
                    if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: req.t("ImageExtension", { extension: extension }) });
                    }
                    const fileName = (files.profileImage.originalFilename =
                        uuidv4() + "." + extension);
                    const newPath = `${pathEndpoint.employeeProfile}${fileName}`;
                    try {
                        const uploadImgRes = await uploadFile(files.profileImage, newPath, extension);
                        newEmployee.profileImage = uploadImgRes.imageUrl;
                        await newEmployee.save();
                        beauticianData.totalEmployee = beauticianData.totalEmployee + 1;
                        await beauticianData.save();
                        return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, message: req.t("addEmployeeDetailsSuccess") });
                    } catch (error) {
                        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, error });
                    }
                } else {
                    return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("profileImageMissing") });
                }
            } else {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("employeeEmailExists") });
            }
        }
        catch (err) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: `Something went wrong : ${err}` });
        }
    })
});

const UpdateEmployeeDetails = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { employeeId } = req.params;
    const form = formidable({ multiples: true });
    const beauticianData = await Beautician.findOne({ userId: id });
    const EmployeeDetail = await Employee.findOne({ beauticianId: beauticianData._id, _id: employeeId })
    form.parse(req, async (err, fields, files) => {
        try {
            if (fields.startTime || fields.endTime) {
                fields.workHours = { startTime: fields.startTime, endTime: fields.endTime }
            }
            if (fields.serviceId) {
                fields.serviceIds = fields.serviceId.split(",")
            }
            if (files.profileImage) {
                ;
                const imgName = files.profileImage.originalFilename.split(".");
                const extension = imgName[imgName.length - 1];
                if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                    return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: req.t("ImageExtension", { extension: extension }) });
                }

                const fileName = (files.profileImage.originalFilename =
                    uuidv4() + "." + extension);
                const newPath = `${pathEndpoint.employeeProfile}${fileName}`;
                const uploadImgRes = await uploadFile(files.profileImage, newPath, extension);

                if (EmployeeDetail.profileImage) {
                    const removeImg = EmployeeDetail.profileImage.includes(process.env.AWS_BUCKET_REGION) ? EmployeeDetail.profileImage.replace(process.env.IMAGE_BASE_URL_WITH_REGION, "") : EmployeeDetail.profileImage.replace(process.env.IMAGE_BASE_URL, "")

                    await deleteFile(removeImg);
                }
                fields.profileImage = uploadImgRes.imageUrl;
            };
            await Employee.findOneAndUpdate({ beauticianId: beauticianData._id, _id: employeeId }, fields, { new: true })
            return res.status(200).json({ status: 200, success: true, message: req.t("UpdateEmployeeDetailsSuccess") });
        }
        catch (err) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: `Something went wrong : ${err}` });
        }
    })
})

const allowAddEmployee = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { subscriptionPlanType, totalEmployee } = await Beautician.findOne({ userId: id }).populate({ path: "subscriptionPlanType", select: "employeeNumber" }).exec();
    if (subscriptionPlanType.employeeNumber > totalEmployee) {
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("allowToAdd") });
    } else {
        throw new ErrorHandler(req.t("maxLimitReach"), HttpStatus.BAD_REQUEST)
    }
})
const getEmployeeList = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const beauticianData = await Beautician.findOne({ userId: id });
    if (beauticianData) {
        const employeeDetail = await Employee.find({ beauticianId: beauticianData._id, status: 1 }).select("-createdAt -updatedAt -status -__v -beauticianId");
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Employee Detail.", data: employeeDetail });
    } else {
        throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST);
    }
})
module.exports = { getEmployeeDetail, addEmployeeDetails, UpdateEmployeeDetails, allowAddEmployee, getEmployeeList }