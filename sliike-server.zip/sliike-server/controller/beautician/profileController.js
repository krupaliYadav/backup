const bcrypt = require("bcrypt");
const formidable = require("formidable");
const catchAsyncError = require("../../middleware/catchAsyncError");
const ErrorHandler = require("../../utils/ErrorHandling");
const Beautician = require("../../models/Beautician");
const User = require("../../models/User");
const HttpStatus = require("../../utils/HttpStatus");
const { pathEndpoint } = require("../../utils/Constant");
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const moment = require("moment");
const { default: mongoose } = require("mongoose");
const { deleteFile } = require("../../libs/aws/deleteImg");
const { uploadFile } = require("../../libs/aws/uploadImg");
const { validationResult } = require("express-validator");
//Get Profile data
const getBeauticianProfile = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const data = await Beautician.findOne({ userId: id })
        .populate({
            path: "address", select: '-createdAt -updatedAt -__v',
            populate: {
                path: 'province',
                model: 'Province',
                select: 'name'
            },
        })
        .populate({ path: "userId", select: "email phoneNumber isVerified roles" }).lean();

    if (data) {
        if (data.address) {
            data.address.province = data.address.province.name;
            data.address.provinceId = data.address.province._id;
        }
        if (data.stripe_id) {
            data.isStripeSetUp = true
        } else {
            data.isStripeSetUp = false
        }
        if (data.userId?.roles?.includes('user')) {
            data.isRegisterUser = true;
        } else {
            data.isRegisterUser = false;
        }
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data });
    } else {
        throw new ErrorHandler("Beautician not found", HttpStatus.BAD_REQUEST);
    }
});

// Update Beautician Details
const updateBeautician = async (req, res, next) => {
    try {
        const id = req.user;
        const form = formidable({ multiples: true });

        form.parse(req, async (err, fields, files) => {
            if (err) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("somethingIsWrongInImageUpload") });
            }
            const { firstName, lastName, country_code, phoneNumber, day, month, year, gender, newPassword, oldPassword, email } = fields;
            if ((!phoneNumber && country_code) || (phoneNumber && !country_code)) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("phone&countrycodeMissing") });
            }
            if (!email) res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("emailMissing") });
            if (!firstName || firstName === "") return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("firstNameMissing") });
            if (!lastName || lastName === "") return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("lastNameMissing") });
            if (!gender || gender === "") return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("genderMissing") });

            const beauticianData = await Beautician.findOne({ userId: id }).populate({
                path: 'userId',
                match: { email }
            });

            const user = await User.findById({ _id: id });

            if (!beauticianData) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("userNotFound") });
            }

            if (newPassword && oldPassword) {
                const verifyPassword = await bcrypt.compare(oldPassword, user.password);

                if (!verifyPassword) {
                    return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("email&PassowrdNotMatched") });
                }
                const hashedPassword = await bcrypt.hash(newPassword, 10);
                user.password = hashedPassword;
                await user.save();
            }

            if (country_code && phoneNumber) {
                user.country_code = country_code;
                user.phoneNumber = phoneNumber;
                await user.save();
            }
            if (day && month && year) {
                if (!moment(month, 'MMMM', true).isValid()) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t('invalidMonthFormat'), });

                // Check day format
                if (!moment(day, 'DD', true).isValid() && !(day > 31) && !(day < 0)) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t('invalidDayFormat') });


                // Check year format
                if (!moment(year, 'YYYY', true).isValid()) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t('invalidYearFormat'), });

                monthNumber = moment(month, 'MMMM').format('M');
                const dateObj = moment.utc([year, monthNumber - 1, day]).local().toDate();
                beauticianData.DOB = dateObj;
                await beauticianData.save();
            } else if (!(day && month && year)) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("missingValue") });
            }
            if (files.profileImage) {
                const imgName = files.profileImage.originalFilename.split(".");
                const extension = imgName[imgName.length - 1];

                if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                    return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: req.t("ImageExtension", { extension: extension }) });

                }
                const fileName = (files.profileImage.originalFilename =
                    uuidv4() + "." + extension);
                const newPath = `${pathEndpoint.beauticianProfile}${fileName}`;
                try {
                    const uploadImgRes = await uploadFile(files.profileImage, newPath, extension);
                    //remove old file
                    if (beauticianData.profileImage) {
                        const removeImg = beauticianData.profileImage.includes(process.env.AWS_BUCKET_REGION) ? beauticianData.profileImage.replace(process.env.IMAGE_BASE_URL_WITH_REGION, "") : beauticianData.profileImage.replace(process.env.IMAGE_BASE_URL, "")
                        await deleteFile(removeImg)
                    }
                    beauticianData.profileImage = uploadImgRes.imageUrl;
                    await beauticianData.save();
                } catch (error) {
                    return res.status(HttpStatus.ERROR).json({
                        status: HttpStatus.ERROR,
                        success: false,
                        message: req.t('somethingIsWrongInImageUpload'),
                    });
                }
            }
            const list = await Beautician.findOneAndUpdate({ userId: id }, { firstName, lastName, gender }, { new: true });
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("profileUpadte") });
        })
    } catch (err) {
        return res.status(HttpStatus.BAD_GATEWAY).json({ status: HttpStatus.BAD_GATEWAY, success: true, message: `Something went wrong ${err}` });
    }
}

//for get all demography data
const getDemographics = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const beauticianData = await Beautician.findOne({ userId: id });
    if (beauticianData) {
        const { demographicIds } = await beauticianData.populate({ path: 'demographicIds', select: '_id demographyName ' });
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Beautician's saved demographics", data: demographicIds });
    } else {
        throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST);
    }
});

// Add Demogrphy by Beautician for his services
const saveDemographies = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { demographicsIds } = req.body;
    if (!demographicsIds) {
        throw new ErrorHandler("DemographicsIds is missing", HttpStatus.BAD_REQUEST, false)
    }
    let isInvalidId = false;
    demographicsIds.forEach(element => {
        if (!mongoose.Types.ObjectId.isValid(element)) {
            isInvalidId = true
        }
    });
    if (isInvalidId) {
        throw new ErrorHandler("DemographicsId is wrong.", HttpStatus.BAD_REQUEST);
    }
    const beauticianData = await Beautician.findOne({ userId: id });
    if (beauticianData) {
        beauticianData.demographicIds = demographicsIds;
        await beauticianData.save();
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("saveDemographiesSuccess") });
    } else {
        throw new ErrorHandler("Beautician detail is not found.", HttpStatus.BAD_REQUEST);
    }
});
//get saved  Amenities
const getAmenities = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const beauticianData = await Beautician.findOne({ userId: id });
    if (beauticianData) {
        const { amenityIds } = await beauticianData.populate({ path: 'amenityIds', select: '_id name name_fr' });
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Beautician's saved amenities", data: amenityIds });
    } else {
        throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST);
    }
});
// Add Amenities by Beautician for his services
const saveAmenities = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { amenityIds } = req.body;
    if (!amenityIds) {
        throw new ErrorHandler("AmenityIds is missing", HttpStatus.BAD_REQUEST, false)
    }
    let isInvalidId = false;
    amenityIds.forEach(element => {
        if (!mongoose.Types.ObjectId.isValid(element)) {
            isInvalidId = true
        }
    });
    if (isInvalidId) {
        throw new ErrorHandler("AmenityId  is wrong.", HttpStatus.BAD_REQUEST);
    }
    const beauticianData = await Beautician.findOne({ userId: id });
    if (beauticianData) {
        beauticianData.amenityIds = amenityIds;
        await beauticianData.save();
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("saveAmenitiesSuccess") });
    } else {
        throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST);
    }
});
//get saved  Health and safety
const getHealthSafety = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const beauticianData = await Beautician.findOne({ userId: id });
    if (beauticianData) {
        const { healthSafety } = await beauticianData.populate({ path: 'healthSafety.healthId', select: '_id name name_fr' });
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Beautician's saved health and safety", data: healthSafety });
    } else {
        throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST);
    }
});
// Add Health and safety by Beautician for his services
const saveHealthSafety = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { healthId, detailForClient } = req.body;
    if (!healthId) {
        throw new ErrorHandler("healthId is missing", HttpStatus.BAD_REQUEST, false)
    }
    let isInvalidId = false;
    healthId.forEach(element => {
        if (!mongoose.Types.ObjectId.isValid(element)) {
            isInvalidId = true
        }
    });
    if (isInvalidId) {
        throw new ErrorHandler("Health & Safety  is wrong.", HttpStatus.BAD_REQUEST);
    }
    const beauticianData = await Beautician.findOne({ userId: id });
    if (beauticianData) {
        beauticianData.healthSafety = { healthId, detailForClient };
        await beauticianData.save();
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("saveHealthSafetySuccess") });
    } else {
        throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST);
    }
});
const getScreenStatus = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { screenStatus } = await Beautician.findOne({ userId: id });

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, data: { screenStatus }, message: `beautician is on screen ${screenStatus}` })
})
const deleteBeauticianAccount = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const beauticianDetails = await Beautician.findOne({ userId: id }).populate({
        path: 'userId',
        match: { isActiveBeautician: 1 },
        select: "isActiveBeautician"
    })
    if (beauticianDetails.userId) {
        await User.findByIdAndUpdate(beauticianDetails.userId._id, { isActiveBeautician: 0 });
        beauticianDetails.isDeleted = 1
        beauticianDetails.save()
        return res.status(HttpStatus.DELETED).json({ status: HttpStatus.DELETED, success: true, message: req.t("deleteBeauticianAccountSuccess") });

    } else {
        throw new ErrorHandler("Your account is already deleted.", HttpStatus.BAD_REQUEST, false)

    }
});

// for get beautician notification
const getBeuaticianNotification = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const beauticianData = await Beautician.findOne({ userId: id }).select("bookingEmailNotification productSalesNotification dailyStatsNotification reviewNotification onMyPostNotification onCommentNotification onBrandNotification");
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, beauticianData })
});

// get my client notification
const getMyClientsNotification = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const beauticianData = await Beautician.findOne({ userId: id }).select("onServicePromoNotification onProductPromoNotification");
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, beauticianData })
});

// for change beuatician Notifications
const changeBeuaticianNotifications = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { bookingEmailNotification, productSalesNotification, dailyStatsNotification, reviewNotification, onMyPostNotification, onCommentNotification, onBrandNotification } = req.body;
    const errors = validationResult(req);
    if (errors.errors.length !== 0) {
        throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST, false);
    };

    const beauticianData = await Beautician.findOne({ userId: id });
    if (beauticianData) {
        if (bookingEmailNotification == 1 || bookingEmailNotification == 0) {
            beauticianData.bookingEmailNotification = bookingEmailNotification;
        }
        if (productSalesNotification == 1 || productSalesNotification == 0) {
            beauticianData.productSalesNotification = productSalesNotification;
        }
        if (dailyStatsNotification == 1 || dailyStatsNotification == 0) {
            beauticianData.dailyStatsNotification = dailyStatsNotification;
        }
        if (reviewNotification == 1 || reviewNotification == 0) {
            beauticianData.reviewNotification = reviewNotification;
        }
        if (onMyPostNotification == 1 || onMyPostNotification == 0) {
            beauticianData.onMyPostNotification = onMyPostNotification;
        }
        if (onCommentNotification == 1 || onCommentNotification == 0) {
            beauticianData.onCommentNotification = onCommentNotification;
        }
        if (onBrandNotification == 1 || onBrandNotification == 0) {
            beauticianData.onBrandNotification = onBrandNotification;
        }

        await beauticianData.save();
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Settings changed successfully" });
    } else {
        throw new ErrorHandler(req.t("clientNotFound"), HttpStatus.BAD_REQUEST)
    }
});

// for change my client notification
const changeMyClientNotifications = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { onServicePromoNotification, onProductPromoNotification } = req.body;
    const errors = validationResult(req);
    if (errors.errors.length !== 0) {
        throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST, false);
    };

    const beauticianData = await Beautician.findOne({ userId: id });
    if (beauticianData) {
        if (onServicePromoNotification == 1 || onServicePromoNotification == 0) {
            beauticianData.onServicePromoNotification = onServicePromoNotification;
        }
        if (onProductPromoNotification == 1 || onProductPromoNotification == 0) {
            beauticianData.onProductPromoNotification = onProductPromoNotification;
        }
        await beauticianData.save();
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Settings changed successfully" });
    } else {
        throw new ErrorHandler(req.t("clientNotFound"), HttpStatus.BAD_REQUEST)
    }
});


// get subscription status
const getSubscriptionStatus = catchAsyncError(async (req, res, next) => {
    const id = req.user;

    const beauticianData = await Beautician.findOne({ userId: id }).select("isSubscription");
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, beauticianData });
});

// update subscription status
const changeSubscriptionStatus = catchAsyncError(async (req, res, next) => {
    const { isSubscription } = req.body
    const id = req.user;

    if (isSubscription == 1 || isSubscription == 0) {
        const beauticianData = await Beautician.findOne({ userId: id }).select({ isSubscription });
        beauticianData.isSubscription = isSubscription;
        await beauticianData.save();
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "status changed successfully" });
    } else {
        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: true, message: "Enter valid status" });
    }
});
module.exports = { updateBeautician, getDemographics, saveDemographies, getBeauticianProfile, getAmenities, saveAmenities, getHealthSafety, saveHealthSafety, getScreenStatus, deleteBeauticianAccount, getBeuaticianNotification, getMyClientsNotification, changeBeuaticianNotifications, changeMyClientNotifications, getSubscriptionStatus, changeSubscriptionStatus };

