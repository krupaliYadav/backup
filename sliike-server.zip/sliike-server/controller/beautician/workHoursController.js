const Beautician = require("../../models/Beautician");
const User = require("../../models/User")
const HttpStatus = require("../../utils/HttpStatus");
const Appointment = require("../../models/Appointment");
const BeauticianWorkHour = require("../../models/BeauticianWorkHour");
const FcmNotification = require("../../models/FcmNotification");
const catchAsyncError = require("../../middleware/catchAsyncError");
const ErrorHandler = require("../../utils/ErrorHandling");
const { validationResult } = require("express-validator");
const { notificationMSGs } = require("../../utils/Constant");
const { fcmNotification } = require("../../utils/fcmNotification");
const { sendCongratulationsMail } = require("../../utils/emailTeplates");
const { default: mongoose } = require("mongoose");
const moment = require("moment");
const { checkDurationFormate } = require("../../utils/formatTest");
const BeauticianNotification = require("../../models/BeauticianNotification");

//for work hours
const getWorkHours = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const beauticianData = await Beautician.findOne({ userId: id });
    if (beauticianData) {
        const workDetails = await BeauticianWorkHour.find({ beauticianId: beauticianData._id }).select("dayDetails");
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: workDetails, message: "Service detail." });
    } else {
        throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST);
    }
});
//Add work hours
const addWorkHours = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { dayDetails } = req.body;
    if (dayDetails) {
        const beauticianData = await Beautician.findOne({ userId: id });
        if (beauticianData) {
            const workDetailExist = await BeauticianWorkHour.findOne({ beauticianId: beauticianData._id });
            if (!workDetailExist) {
                await BeauticianWorkHour.create({ beauticianId: beauticianData._id, dayDetails })
                beauticianData.screenStatus = 7;
                await beauticianData.save();
                // push notification
                const deviceData = await FcmNotification.find({ memberId: beauticianData._id });
                const deviceIds = deviceData?.map(ele => ele.firebaseToken);
                if (deviceIds.length > 0) {
                    let message = notificationMSGs.congratsCtx;
                    await BeauticianNotification.create({
                        beauticianId: beauticianData._id,
                        title: message.title,
                        details: message.message
                    })
                    const notifications = fcmNotification({ messageCtx: message, deviceIds });
                    await Promise.all([notifications]);
                }
                const { email } = await User.findById(id).select('email');
                await sendCongratulationsMail({ email, firstName: beauticianData.firstName })
                return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, message: req.t("addWorkHoursSuccess") });
            } else {
                throw new ErrorHandler(req.t("hoursIsExists"), HttpStatus.CONFLICT);
            }
        } else {
            throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST);
        }
    } else {
        throw new ErrorHandler(req.t("dayDetailsIsMissing"), HttpStatus.BAD_REQUEST);
    }
});
//update work hour details
const updateWorkHours = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { workHoursId } = req.params;
    const { dayDetails } = req.body;

    if (dayDetails) {
        //check validation
        const validationPromises = dayDetails.map(ele => {
            return new Promise((resolve, reject) => {
                if (ele.isOpen && ele.startTime && ele.endTime) {
                    if (!checkDurationFormate(ele.startTime) || !checkDurationFormate(ele.endTime)) {
                        reject(new ErrorHandler('Invalid duration formate :startTime or endTime.', HttpStatus.BAD_REQUEST, false));
                    } else if (ele.breakStartTime && !ele.breakEndTime) {
                        reject(new ErrorHandler('Missing value of breakEndTime.', HttpStatus.BAD_REQUEST, false));
                    } else if (ele.breakStartTime && ele.breakEndTime) {
                        if (!checkDurationFormate(ele.breakStartTime) || !checkDurationFormate(ele.breakEndTime)) {
                            reject(new ErrorHandler('Invalid duration formate :breakStartTime or breakEndTime', HttpStatus.BAD_REQUEST, false));
                        }
                    }
                    resolve();
                } else if (ele.isOpen && !(ele.startTime && ele.endTime)) {
                    reject(new ErrorHandler('Missing value of startTime or endTime.', HttpStatus.BAD_REQUEST, false));
                } else {
                    resolve();
                }
            });
        });
        await Promise.all(validationPromises);// throw validation error
        const beauticianData = await Beautician.findOne({ userId: id });

        if (beauticianData) {
            const workDetailExist = await BeauticianWorkHour.findById(workHoursId);
            workDetailExist.dayDetails = dayDetails;
            await workDetailExist.save()
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("updateWorkHoursSuccess") });
        } else {
            throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST);
        }
    } else {
        throw new ErrorHandler(req.t("dayDetailsIsMissing"), HttpStatus.BAD_REQUEST);
    }

});

//add work hour on specific date
const saveCalenderAdjustment = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const beauticianData = await Beautician.findOne({ userId: id });
    const { day, date, startTime, endTime, breakStartTime, breakEndTime, isOpen } = req.body;
    const errors = validationResult(req);
    if (errors.errors.length !== 0) {
        throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST);
    };
    if (!day || !date) {
        throw new ErrorHandler('Date or Day value missing.', HttpStatus.BAD_REQUEST, false);
    }
    if (!isOpen) {
        const isAppointment = await Appointment.aggregate([
            {
                $match: {
                    beauticianId: beauticianData._id,
                    status: 1,
                    step: 2,
                    $expr: {
                        $eq: [
                            { $dateToString: { format: "%Y-%m-%d", date: "$dateTime" } },
                            date
                        ]
                    }
                }
            },
        ]);
        if (isAppointment.length) {
            throw new ErrorHandler(req.t("IsAppoimentOnDay"), HttpStatus.BAD_REQUEST, false)
        }
    }
    if (isOpen) {
        let startTimeValue = date + ' ' + startTime
        let endTimeValue = date + ' ' + endTime
        let startBreakTime = date + ' ' + breakStartTime
        let endBreakTime = date + ' ' + breakEndTime

        const isAppointment = await Appointment.aggregate([
            {
                $match: {
                    beauticianId: beauticianData._id,
                    status: 1,
                    step: 2,
                    $expr: {
                        $or: [
                            {
                                $and: [
                                    { $eq: [{ $dateToString: { format: "%Y-%m-%d", date: "$dateTime" } }, date] },
                                    { $gte: [{ $dateToString: { format: "%Y-%m-%d %H:%M", date: "$dateTime" } }, endTimeValue] }
                                ]
                            },
                            {
                                $and: [
                                    { $eq: [{ $dateToString: { format: "%Y-%m-%d", date: "$dateTime" } }, date] },
                                    { $lte: [{ $dateToString: { format: "%Y-%m-%d %H:%M", date: "$dateTime" } }, startTimeValue] }
                                ]
                            },
                            {
                                $and: [
                                    { $eq: [{ $dateToString: { format: "%Y-%m-%d", date: "$dateTime" } }, date] },
                                    { $gte: [{ $dateToString: { format: "%Y-%m-%d %H:%M", date: "$dateTime" } }, startBreakTime] }
                                ]
                            },
                            {
                                $and: [
                                    { $eq: [{ $dateToString: { format: "%Y-%m-%d", date: "$dateTime" } }, date] },
                                    { $lte: [{ $dateToString: { format: "%Y-%m-%d %H:%M", date: "$dateTime" } }, endBreakTime] }
                                ]
                            }
                        ]
                    }
                }
            }
        ]);
        if (isAppointment.length) {
            throw new ErrorHandler(req.t("IsAppoimentOnTime"), HttpStatus.BAD_REQUEST, false)
        }
    }
    const workHours = await BeauticianWorkHour.findOne({ beauticianId: beauticianData._id, "calenderSetting.date": { $ne: date } });
    if (workHours) {
        workHours.calenderSetting = workHours.calenderSetting || []
        workHours.calenderSetting.push(req.body);
        await workHours.save();
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("workHourSaved") })

    } else {
        const UpdateWorkDetails = await BeauticianWorkHour.findOne({ beauticianId: beauticianData._id, "calenderSetting.date": { $eq: date } });
        UpdateWorkDetails.calenderSetting.forEach(element => {
            const tempDate = moment(element.date).utc().format('YYYY-MM-DD');
            if (moment(tempDate).isSame(moment(date), 'day')) {
                element.day = day;
                element.date = date;
                element.startTime = startTime;
                element.endTime = endTime;
                element.breakStartTime = breakStartTime;
                element.breakEndTime = breakEndTime;
            }
        });
        await UpdateWorkDetails.save();
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("workHourAdded") })
    }
});

//time of selected date and day time function
async function getTimeOfSelectedDate(details, id) {
    const { date, day } = details;
    const pattern = /^\d{4}-\d{2}-\d{2}$/;
    const validDays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
    if (!date || !day) {
        throw new ErrorHandler("Date or Day value missing.", HttpStatus.BAD_REQUEST, false);
    }
    //check date formate
    if (!pattern.test(date)) {
        throw new ErrorHandler("Invalid date formate", HttpStatus.BAD_REQUEST, false);
    }
    // check day value
    if (!validDays.includes(day)) {
        throw new ErrorHandler("Invalid day.", HttpStatus.BAD_REQUEST, false);
    }
    const data = await BeauticianWorkHour.aggregate([
        {
            $lookup: {
                from: 'beauticians',
                foreignField: '_id',
                localField: 'beauticianId',
                as: 'beauticianData',
            }
        },
        { $match: { 'beauticianData.userId': new mongoose.Types.ObjectId(id) } },
        { $unwind: "$calenderSetting" },
        // Match the documents with the specified date and day 
        {
            $match: {
                $expr: { $eq: [{ $dateToString: { format: "%Y-%m-%d", date: "$calenderSetting.date" } }, date] },
            }
        },
        {
            $project: {
                _id: 0,
                calenderSetting: {
                    day: "$calenderSetting.day",
                    startTime: "$calenderSetting.startTime",
                    endTime: "$calenderSetting.endTime",
                    breakStartTime: "$calenderSetting.breakStartTime",
                    breakEndTime: "$calenderSetting.breakEndTime",
                    isOpen: "$calenderSetting.isOpen"
                }
            }
        }
    ]);

    if (data.length) {
        return data[0].calenderSetting
    } else {
        const dayDetails = await BeauticianWorkHour.aggregate([
            {
                $lookup: {
                    from: 'beauticians',
                    foreignField: '_id',
                    localField: 'beauticianId',
                    as: 'beauticianData',
                }
            },
            { $match: { 'beauticianData.userId': new mongoose.Types.ObjectId(id) } },
            {
                $project: {
                    _id: 0,
                    dayDetails: 1
                }
            }
        ]);
        return dayDetails?.[0]?.dayDetails.filter(ele => ele.day === day)?.[0]
    }
}
//get time vale of selected date
const getScheduleForDate = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { date, day } = req.body;
    let response = await getTimeOfSelectedDate(req.body, id);
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: response })

})
module.exports = { getWorkHours, addWorkHours, updateWorkHours, saveCalenderAdjustment, getTimeOfSelectedDate, getScheduleForDate };
