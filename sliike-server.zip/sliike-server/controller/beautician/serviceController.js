const Beautician = require("../../models/Beautician");
const HttpStatus = require("../../utils/HttpStatus");
const User = require("../../models/User");
const catchAsyncError = require("../../middleware/catchAsyncError");
const ErrorHandler = require("../../utils/ErrorHandling");
const BeauticianService = require("../../models/BeauticianService");
const { addNewService } = require("../../utils/emailTeplates");
const formidable = require("formidable");
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');
const { pathEndpoint, notificationMSGs } = require("../../utils/Constant");
const { default: mongoose } = require("mongoose");
const FcmNotification = require("../../models/FcmNotification");
const { fcmNotification } = require("../../utils/fcmNotification");
const ServiceTypeList = require("../../models/ServiceTypeList");
const { checkDurationFormate } = require("../../utils/formatTest");
const { uploadFile } = require("../../libs/aws/uploadImg");
const { deleteFile } = require("../../libs/aws/deleteImg");
const ValidationError = require("../../utils/validationError");
const BeauticianNotification = require("../../models/BeauticianNotification");

const getServiceDetails = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const beauticianData = await Beautician.findOne({ userId: id });
    if (beauticianData) {
        const serviceDetail = await BeauticianService.find({ beauticianId: beauticianData._id, isDelete: 0 })
            .populate([
                { path: 'serviceCategory', select: 'serviceCategoryName' },
                { path: 'serviceType', select: 'serviceTypeName' },
            ])
            .select("-updatedAt -createdAt -__v");

        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: serviceDetail, message: "Service detail." });
    } else {
        throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST);
    }
});
const getSingleServiceDetails = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { serviceId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(serviceId)) {
        throw new ErrorHandler("ServiceId is not valid", HttpStatus.BAD_REQUEST);
    }
    const beauticianData = await Beautician.findOne({ userId: id });
    if (beauticianData) {
        const serviceDetail = await BeauticianService.findOne({ beauticianId: beauticianData._id, _id: serviceId })
            .populate([
                { path: 'serviceCategory', select: 'serviceCategoryName' },
                { path: 'serviceType', select: 'serviceTypeName' },
            ])
            .select("-updatedAt -createdAt -__v");

        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: serviceDetail, message: "Service detail." });
    } else {
        throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST);
    }
});
const addServiceDetails = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { services } = req.body;

    if (services) {
        const beauticianData = await Beautician.findOne({ userId: id });
        if (beauticianData) {
            const userEmail = await User.findOne({ _id: beauticianData.userId });
            const businessName = beauticianData.businessName;
            const isServiceExist = await BeauticianService.findOne({ beauticianId: beauticianData._id })
            if (!isServiceExist) {
                //test duration formate
                const validationPromises = services.map(ele => {
                    return new Promise((resolve, reject) => {
                        if (!checkDurationFormate(ele.duration)) {
                            reject(new ErrorHandler('Invalid duration formate.', HttpStatus.BAD_REQUEST, false));
                        } else {
                            resolve();
                        }
                    });
                });
                await Promise.all(validationPromises);
                //add beautician id in services list
                services.forEach(element => {
                    element.beauticianId = beauticianData._id
                });
                const newService = await BeauticianService.insertMany(services);
                const serviceIds = newService.map((val) => {
                    return val._id;
                });
                beauticianData.beauticianServiceId = serviceIds;
                beauticianData.screenStatus = 6;
                await beauticianData.save();
                // send email
                if (newService && businessName) {
                    await addNewService({ email: userEmail.email, businessName });
                }
                return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, message: "Service category added successfully.." });
            } else {
                throw new ErrorHandler("Services details are already added ", HttpStatus.CONFLICT);
            }
        } else {
            throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST);
        }
    } else {
        throw new ErrorHandler("services is missing", HttpStatus.BAD_REQUEST);
    }
});
// class ValidationError extends Error {
//     constructor(message) {
//         super(message);
//         this.name = 'ValidationError';
//         this.status = HttpStatus.BAD_REQUEST;
//     }
// }
//new add service Details APi
const addServiceWithImageDetails = catchAsyncError(async (req, res, next) => {
    try {
        const id = req.user;
        const beauticianData = await Beautician.findOne({ userId: id });
        if (beauticianData) {
            const form = formidable({ multiples: true });
            const userEmail = await User.findOne({ _id: beauticianData.userId });
            const businessName = beauticianData.businessName;
            const isServiceExist = await BeauticianService.findOne({ beauticianId: beauticianData._id })
            if (!isServiceExist) {
                form.parse(req, async (err, fields, files) => {
                    const { services } = fields;
                    try {
                        if (!services.length) {
                            throw new ValidationError(req.t('servicesMissing'));
                        }
                        const uploadPromises = services.map(async (val) => {
                            if (val.description && val.description.length > 150) {
                                throw new ValidationError(req.t('descriptionIsLong'));
                            }

                            if (files.images) {
                                if (files.images.length) {
                                    await Promise.all(files.images.map(async (imgVal) => {
                                        if (val.imgName === imgVal.originalFilename) {
                                            const imgName = imgVal.originalFilename.split(".");
                                            const extension = imgName[imgName.length - 1];
                                            if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                                                return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: req.t("ImageExtension", { extension: extension }) });
                                            }
                                            const fileName = (imgVal.originalFilename =
                                                uuidv4() + "." + extension);
                                            const newPath = `${pathEndpoint.beauticianServiceImg}${fileName}`;
                                            const uploadImgRes = await uploadFile(imgVal, newPath, extension);
                                            if (uploadImgRes.status === 200) {
                                                let tempImg = [];
                                                tempImg.push(uploadImgRes.imageUrl)
                                                val.imgName = tempImg;
                                            }
                                        }
                                    }))
                                } else {
                                    if (val.imgName === files.images.originalFilename) {
                                        const imgName = files.images.originalFilename.split(".");
                                        const extension = imgName[imgName.length - 1];
                                        if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                                            return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: req.t("ImageExtension", { extension: extension }) });
                                        }
                                        const fileName = (files.images.originalFilename = uuidv4() + "." + extension);
                                        const newPath = `${pathEndpoint.beauticianServiceImg}${fileName}`;
                                        const uploadImgRes = await uploadFile(files.images, newPath, extension);
                                        if (uploadImgRes.status === 200) {
                                            let tempImg = [];
                                            tempImg.push(uploadImgRes.imageUrl)
                                            val.imgName = tempImg;
                                        }
                                    }
                                }
                            } else {
                                val.imgName = "";
                            }
                            val.beauticianId = beauticianData._id
                        })
                        await Promise.all(uploadPromises);
                        const newService = await BeauticianService.insertMany(services);
                        const serviceIds = newService.map((val) => {
                            return val._id;
                        });
                        beauticianData.beauticianServiceId = serviceIds;
                        beauticianData.screenStatus = 6;
                        await beauticianData.save();
                        // send email
                        if (newService && businessName) {
                            await addNewService({ email: userEmail.email, businessName });
                        }
                        return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, message: req.t("addServiceWithImageDetailsSuccess") });

                    } catch (error) {
                        // Handle the validation error
                        if (error instanceof ValidationError) {
                            return res.status(error.status).json({ status: error.status, success: false, message: error.message });
                        }
                    }
                });
            } else {
                return res.status(HttpStatus.CONFLICT).json({ status: HttpStatus.CONFLICT, success: false, message: req.t("serviceAlreadyAdded") });
            }
        } else {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("beauticianNotFound") });
        }
    } catch (error) {

    }
});
const updateServiceDetails = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { serviceId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(serviceId)) {
        throw new ErrorHandler("Service Id is wrong.", HttpStatus.BAD_REQUEST);
    }
    const form = formidable({ multiples: true });
    form.parse(req, async (err, fields, files) => {
        const serviceData = await BeauticianService.findById(serviceId);
        if (serviceData) {
            const { duration, priceStatus, price, description, isBookOnline, isHomeService, inBetweenInterval, noOfParallelClient, oldImageUrl } = fields;
            const checkPriceStatusValue = ["Fixed", "Seasonal"]
            if (priceStatus && !checkPriceStatusValue.includes(priceStatus)) {
                return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: req.t(`invalidPriceStatus`) });
            }
            if (duration && !checkDurationFormate(duration)) {
                return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: req.t(`invalidDuration`) });
            }
            if (inBetweenInterval && !checkDurationFormate(inBetweenInterval)) {
                return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: req.t(`invalidInterval`) });
            }
            const data = await BeauticianService.findByIdAndUpdate(serviceId, fields, { new: true });

            if (files.serviceImg) {
                files.serviceImg = Array.isArray(files.serviceImg) ? files.serviceImg : [files.serviceImg];
                if (files.serviceImg.length) {
                    await Promise.all(files.serviceImg.map(async (imgVal) => {
                        const imgName = imgVal.originalFilename.split(".");
                        const extension = imgName[imgName.length - 1];
                        if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                            return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: req.t("ImageExtension", { extension: extension }) });
                        }

                        const fileName = (imgVal.originalFilename = uuidv4() + "." + extension);
                        const newPath = `${pathEndpoint.beauticianServiceImg}${fileName}`;
                        try {
                            //upload to s3
                            const uploadImgRes = await uploadFile(imgVal, newPath, extension);
                            //remove from s3
                            // if (serviceData.imgName) { }
                            if (oldImageUrl.length) {
                                await Promise.all(oldImageUrl.map(async (ele) => {
                                    const valueToRemove = ele
                                    const indexToRemove = serviceData.imgName.indexOf(valueToRemove);
                                    if (indexToRemove !== -1) {
                                        serviceData.imgName.splice(indexToRemove, 1);
                                        const removeImg = ele.includes(process.env.AWS_BUCKET_REGION) ? ele.replace(process.env.IMAGE_BASE_URL_WITH_REGION, "") : ele.replace(process.env.IMAGE_BASE_URL, "")
                                        await deleteFile(removeImg)
                                    }
                                }))
                            }
                            serviceData.imgName.push(uploadImgRes.imageUrl);

                        } catch (error) {
                            // console.log("🚀 ~ file: serviceController.js:253 ~ form.parse ~ error:", error)
                            return res.status(HttpStatus.ERROR).json({
                                status: HttpStatus.ERROR,
                                success: false,
                                message: req.t('somethingIsWrongInImageUpload'),
                            });
                        }
                    }))
                    await serviceData.save();
                }
            }
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("updateServiceDetailsSuccess") });

        } else {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Service Id is wrong." })
        }

    });

});
const addSingleServiceDetails = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { serviceCategory, serviceType, duration, price, description } = req.body;
    if (!mongoose.Types.ObjectId.isValid(serviceType) || !mongoose.Types.ObjectId.isValid(serviceCategory)) {
        return res.status(HttpStatus.BAD_REQUEST).json({ message: "Service category ID or service Type ID is wrong.", status: HttpStatus.BAD_REQUEST, success: false });
    }
    if (!duration) {
        throw new ErrorHandler(req.t("durationMissing"), HttpStatus.BAD_REQUEST, false)
    }
    if (duration && !checkDurationFormate(duration)) {
        throw new ErrorHandler(req.t("invalidDuration"), HttpStatus.BAD_REQUEST, false)
    }
    if (!price) {
        throw new ErrorHandler(req.t("priceIsMissing"), HttpStatus.BAD_REQUEST, false)
    }
    const beauticianData = await Beautician.findOne({ userId: id });
    const isServiceExist = await BeauticianService.findOne({ beauticianId: beauticianData._id, serviceCategory, serviceType, isDelete: 0 });
    if (isServiceExist) {
        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "serviceTypeAlreadyAdded" });
    }
    const serviceData = await BeauticianService.create({
        beauticianId: beauticianData._id,
        serviceCategory,
        serviceType,
        duration,
        price,
        description,
    });
    await Beautician.findByIdAndUpdate(beauticianData._id, { $push: { beauticianServiceId: serviceData._id } }, { new: true });
    //Push notification
    const { serviceTypeName } = await ServiceTypeList.findOne({ _id: serviceType });

    const deviceData = await FcmNotification.find({ memberId: beauticianData._id });
    const deviceIds = deviceData?.map(ele => ele.firebaseToken);
    if (deviceIds.length > 0) {
        let message = notificationMSGs.addNewServiceCtx(serviceTypeName);
        await BeauticianNotification.create({
            beauticianId: beauticianData._id,
            title: message.title,
            details: message.message
        })
        const notifications = fcmNotification({ messageCtx: message, deviceIds });
        await Promise.all([notifications]);
    }
    //send Email 
    if (serviceData && beauticianData.businessName) {
        const userEmail = await User.findOne({ _id: beauticianData.userId });
        await addNewService({ email: userEmail.email, businessName: beauticianData.businessName });
    }
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("addSingleServiceDetailsSuccess") });

});
const deleteServiceDetails = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { serviceId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(serviceId)) {
        throw new ErrorHandler("ServiceId is not valid", HttpStatus.BAD_REQUEST);
    }
    const serviceDetail = await BeauticianService.findOne({ _id: serviceId, isDelete: 0 });

    if (serviceDetail) {
        serviceDetail.isDelete = 1;
        await serviceDetail.save();
        await Beautician.findOneAndUpdate({ userId: id }, { $pull: { beauticianServiceId: serviceId } }, { new: true });
        return res.status(HttpStatus.DELETED).json({ status: HttpStatus.DELETED, success: true, message: req.t("deleteServiceDetailsSuccess") })
    } else {
        throw new ErrorHandler(req.t("alredyServiceDeleted"), HttpStatus.BAD_GATEWAY);
    }
})
module.exports = { getServiceDetails, getSingleServiceDetails, addServiceDetails, updateServiceDetails, addServiceWithImageDetails, addSingleServiceDetails, deleteServiceDetails };

