const catchAsyncError = require("../../middleware/catchAsyncError");
const HttpStatus = require("../../utils/HttpStatus");
const ErrorHandler = require("../../utils/ErrorHandling");
const Beautician = require("../../models/Beautician")
const Brand = require("../../models/Brand")
const mongoose = require("mongoose");
const BrandProducts = require("../../models/BrandProducts");
const BrandCategory = require("../../models/BrandCategory");
const currentDate = new Date()

// for add brand in favorites
const addToMyFavorites = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { brandId } = req.body;

    if (!mongoose.Types.ObjectId.isValid(brandId)) throw new ErrorHandler("Please Enter Valid Brand Id", HttpStatus.BAD_REQUEST, false);

    if (brandId) {
        const BeauticianDetails = await Beautician.findOne({ userId: id });

        // check brand is exits or not 
        const isExitsBrand = await Brand.findOne({ _id: brandId, isDeleted: 0 })
        if (!isExitsBrand) {
            throw new ErrorHandler("Brand is not found", HttpStatus.BAD_REQUEST, false)
        }

        if (BeauticianDetails.favBrands.includes(brandId)) {
            throw new ErrorHandler("Brand is already added into favorites", HttpStatus.BAD_REQUEST, false)
        } else {
            BeauticianDetails.favBrands.unshift(brandId);
            await BeauticianDetails.save();
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Brand added into favorites successfully.." });
        }
    } else {
        throw new ErrorHandler("brandId is missing", HttpStatus.BAD_REQUEST, false)
    }
});

// for remove brand from favorites
const removeBrandFromFavorites = catchAsyncError(async (req, res, next) => {
    const Id = req.user;
    const { brandId } = req.body;
    if (!mongoose.Types.ObjectId.isValid(brandId)) throw new ErrorHandler("Please enter valid brand Id", HttpStatus.BAD_REQUEST, false);

    const isBrand = await Brand.findOne({ _id: brandId, isDeleted: 0 });

    if (isBrand) {
        const beauticianData = await Beautician.findOne({ userId: Id });

        if (!beauticianData.favBrands.includes(isBrand._id)) {
            throw new ErrorHandler("Brand already removed from favorites", HttpStatus.BAD_REQUEST, false);
        }

        beauticianData.favBrands.pull(isBrand._id);
        await beauticianData.save();

        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("removeBrandFromFavoritesSuccess") });
    } else {
        throw new ErrorHandler("Brand details not found", HttpStatus.BAD_REQUEST, false);
    }
});

// get fav brand list
const getFavBrandList = catchAsyncError(async (req, res, next) => {
    const Id = req.user
    let myFavBrand = [];

    const beauticianData = await Beautician.findOne({ userId: Id })
    if (beauticianData) {
        const BrandIds = beauticianData.favBrands.map((val) => { return new mongoose.Types.ObjectId(val) })
        if (BrandIds?.length > 0) {
            myFavBrand = await Brand.aggregate([
                {
                    $match: { _id: { $in: BrandIds }, endDate: { $gte: currentDate }, isDeleted: 0 }
                },
                {
                    $project: {
                        _id: 1,
                        brandName: 1,
                        brandBanner: {
                            $ifNull: ["$brandBanner", null]
                        }
                    }
                }
            ])
        }
        // else {
        //     return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Not found my fav brand details" })
        // }
        const count = myFavBrand.length
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, count, myFavBrand, message: "Fav Brand details load successfully" })
    } else {
        throw new ErrorHandler("Client details not found", HttpStatus.BAD_REQUEST, false)
    }
});

/*Get single brand details*/
const getSingleBrandDetails = catchAsyncError(async (req, res, next) => {
    const Id = req.user
    const brandId = req.params.brandId
    const beauticianData = await Beautician.findOne({ userId: Id })

    if (!mongoose.Types.ObjectId.isValid(brandId)) {
        throw new ErrorHandler("Please Enter Valid Brand Id", HttpStatus.BAD_REQUEST, false);
    }

    let brandDetails = await Brand.aggregate([
        { $match: { _id: new mongoose.Types.ObjectId(brandId), isDeleted: 0, step: 3, endDate: { $gte: currentDate } } },
        {
            $lookup: {
                from: 'brandcategorylists',
                localField: 'brandCategoryId',
                foreignField: "_id",
                as: 'brandCategory',
            },
        },
        {
            $lookup: {
                from: 'brandproducts',
                localField: '_id',
                foreignField: "brandId",
                as: 'productDetails',
                pipeline: [
                    { $project: { productImageName: 1, productName: 1, productPrice: 1 } }
                ],
            },
        },
        {
            $project: {
                _id: 1,
                brandName: 1,
                brandBanner: 1,
                brandCategory: {
                    $arrayElemAt: ['$brandCategory.brandCategoryName', 0]
                },
                brandCategory_fr: {
                    $arrayElemAt: ['$brandCategory.brandCategoryName_fr', 0]
                },
                productDetails: 1,
            }
        }
    ])

    if (brandDetails?.length > 0) {
        brandDetails.map((brand => {
            brand.isFavBrand = false;
            if (beauticianData.favBrands.includes(brand._id)) {
                brand.isFavBrand = true;
            }
            return brand.isFavBrand
        }))

    } else {
        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Brand not found" })
    }
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, brandDetails, message: "Brand details" });
});

const findBeautiBrandsProducts = catchAsyncError(async (req, res, next) => {
    const Id = req.user;
    const BeauticianData = await Beautician.findOne({ userId: Id });
    const { search } = req.body;
    let brandQuery = {
    };

    if (search) {
        brandQuery = {
            ...brandQuery,
            productName: { $regex: search, $options: 'i' }
        }
    }

    const brandData = await BrandProducts.aggregate([
        { $match: brandQuery },
        {
            $lookup: {
                from: 'brands',
                localField: 'brandId',
                foreignField: '_id',
                as: 'brandData',
                pipeline: [
                    { $match: { isDeleted: 0, step: 3, endDate: { $gte: currentDate } } },
                    { $project: { brandName: 1, brandLogo: 1 } }
                ]
            }
        },
        { $match: { brandData: { $gt: [] } } },
        { $project: { productName: 1, brandData: 1 } },
    ]);

    let productList = []
    let brandList = []
    if (brandData.length) {
        brandData.forEach(ele => {
            productList.push({ _id: ele._id, productName: ele.productName });
            ele.brandData?.forEach(vendor => {
                brandList.push(vendor)
            })
        })
    }
    if (brandList.length) {
        brandList = brandList.filter((item, index, self) => {
            return index === self.findIndex(obj => obj._id.equals(item._id));
        });
    }

    if (brandList.length) {
        if (!BeauticianData.brandSearchText.includes(search)) {
            BeauticianData.brandSearchText.unshift(search);
        }
    }

    await BeauticianData.save();

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { productList, brandList } });
});

const getBeautiFilterBrand = catchAsyncError(async (req, res, next) => {
    const Id = req.user;
    let { categoryIds, productIds } = req.body;

    const BeauticianData = await Beautician.findOne({ userId: Id });

    if (categoryIds?.length > 0) {
        for (const ele of categoryIds) {
            if (!mongoose.Types.ObjectId.isValid(ele)) {
                throw new ErrorHandler("Please pass valid service IDs.", HttpStatus.BAD_REQUEST, false);
            } else {
                const isCategoryExists = await BrandCategory.findOne({ _id: ele });
                if (!isCategoryExists) {
                    throw new ErrorHandler("Brand category Id dose not exits", HttpStatus.BAD_REQUEST, false);
                }
            }
        }
    }

    let query = { step: 3, isDeleted: 0, endDate: { $gte: currentDate } }
    if (categoryIds?.length > 0) {
        query = { ...query, brandCategoryId: { $in: categoryIds.map(id => new mongoose.Types.ObjectId(id)) } }
    }
    if (productIds) {
        if (productIds.length) {
            query = { ...query, brandProductId: { $in: productIds.map(id => new mongoose.Types.ObjectId(id)) } }
        }
    }
    const data = await Brand.aggregate([
        { $match: query },
        {
            $lookup: {
                from: 'brandcategorylists',
                localField: 'brandCategoryId',
                foreignField: "_id",
                as: 'brandCategoryId',
                pipeline: [
                    { $project: { brandCategoryName: 1, brandCategoryName_fr: 1 } }
                ]
            }
        },
        { $unwind: "$brandCategoryId" },
        {
            $project: {
                _id: 1,
                brandName: 1,
                brandCategoryId: 1,
                brandBanner: {
                    $ifNull: ["$brandBanner", null]
                },
            }
        }
    ])
    // check brand is fav or not
    if (data) {
        data?.map(val => {
            val.isFavBrand = false;
            if (BeauticianData.favBrands.includes(val._id)) {
                val.isFavBrand = true
            }
            return val.isFavBrand
        })
    }
    const count = data.length
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, count, data, message: "Details load successfully" })
});

const getBeautiRecentSearchBrand = catchAsyncError(async (req, res, next) => {
    const Id = req.user;
    let BeauticianData = await Beautician.findOne({ userId: Id });

    if (BeauticianData) {
        resData = []
        let getBrand = BeauticianData?.brandSearchText.map(async (search) => {
            return new Promise(async (resolve, reject) => {
                const newBrandList = await Brand.aggregate([
                    {
                        $match: {
                            step: 3,
                            isDeleted: 0,
                            endDate: { $gte: currentDate }
                        }
                    },
                    {
                        $lookup: {
                            from: 'brandproducts',
                            localField: 'brandProductId',
                            foreignField: "_id",
                            as: 'proData',
                            pipeline: [
                                { $match: { productName: { $regex: search, $options: 'i' } } }
                            ]
                        },
                    },
                    {
                        $lookup: {
                            from: 'brandcategorylists',
                            localField: 'brandCategoryId',
                            foreignField: "_id",
                            as: 'categoryData',
                            pipeline: [
                                { $project: { brandCategoryName: 1, brandCategoryName_fr: 1, } }
                            ]
                        },
                    },
                    { $match: { proData: { $gt: [] } } },
                    {
                        $project: {
                            _id: 1,
                            brandName: 1,
                            brandCategory: { $arrayElemAt: ["$categoryData.brandCategoryName", 0] },
                            brandCategory_fr: { $arrayElemAt: ["$categoryData.brandCategoryName_fr", 0] },
                            brandBanner: {
                                $ifNull: ["$brandBanner", null]
                            }
                        }
                    }
                ])
                resData = [...resData, ...newBrandList]
                resolve(resData)
            })
        })
        await Promise.all(getBrand);
    }
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, resData, message: "Details load successfully" })
});

// add brandProduct in fav
const beautiAddToFavoritesBrandProducts = catchAsyncError(async (req, res, next) => {
    const Id = req.user;
    const { productId } = req.body;

    if (!mongoose.Types.ObjectId.isValid(productId)) throw new ErrorHandler("Please Enter Valid Brand Id", HttpStatus.BAD_REQUEST, false);

    if (productId) {
        const BeauticianData = await Beautician.findOne({ userId: Id });

        // check brand is exits or not 
        const isExitsBrand = await BrandProducts.findOne({ _id: productId, isDeleted: 0 })
        if (!isExitsBrand) {
            throw new ErrorHandler("Brand Product is not found", HttpStatus.BAD_REQUEST, false)
        }

        if (BeauticianData.favBrandProds.includes(productId)) {
            throw new ErrorHandler("Brand product is already added into favorites", HttpStatus.BAD_REQUEST, false)
        } else {
            BeauticianData.favBrandProds.unshift(productId);
            await BeauticianData.save();
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("addToMyFavoritesBrandsSuccess") });
        }
    } else {
        throw new ErrorHandler("productId is missing", HttpStatus.BAD_REQUEST, false)
    }
});

// Get Single Product
const getSingleBaeutiBrandProduct = catchAsyncError(async (req, res, next) => {
    const Id = req.user;
    const { productId } = req.params;

    if (!mongoose.Types.ObjectId.isValid(productId)) {
        throw new ErrorHandler("Please Enter Valid Product Id", HttpStatus.BAD_REQUEST, false);
    }
    const beauticianDetails = await Beautician.findOne({ userId: Id });

    // for get single product details
    let productData = await BrandProducts.findOne({ _id: productId })
        .populate({ path: 'brandId', select: 'brandLogo websiteUrl shippingPolicyUrl returnPolicyUrl' })
        .select("uid productName productPrice productUnit productSize keyFeatures description productImageName weightUnit weightValue").lean();

    if (productData) {
        productData.isFavBrandProd = false;
        if (beauticianDetails?.favBrandProds.includes(productId)) {
            productData.isFavBrandProd = true;
        }
    }

    // for get may like products
    const allProducts = await Brand.aggregate([
        {
            $match: { brandProductId: new mongoose.Types.ObjectId(productId) }
        },
        {
            $lookup: {
                from: 'brandproducts',
                localField: 'brandProductId',
                foreignField: "_id",
                as: 'productDetails',
                pipeline: [
                    { $project: { productName: 1, productImageName: 1 } }
                ]
            }
        },
        { $project: { productDetails: 1, } },
    ]);
    if (productData) {
        // if (allProducts) {
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: false, productData, mayLikeProducts: allProducts[0]?.productDetails })
        // }
    } else {
        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Product details not found" })
    }
});

const getAllBeautiCategoryBrands = catchAsyncError(async (req, res, next) => {
    const Id = req.user;
    const beauticianData = await Beautician.findOne({ userId: Id }).select('favBrands');
    const data = await BrandCategory.aggregate([
        {
            $lookup: {
                from: 'brands',
                localField: '_id',
                foreignField: "brandCategoryId",
                as: 'brandData',
                pipeline: [
                    { $match: { isDeleted: 0 } },
                    { $project: { brandName: 1, brandLogo: 1, brandBanner: 1 } }
                ],
            },
        },
        { $project: { brandCategoryName: 1, brandData: 1 } }
    ]);
    if (data.length) {
        data.forEach((val) => {
            if (val.brandData.length) {
                val.brandData.forEach((ele) => {
                    ele.isFavBrand = false;
                    if (beauticianData.favBrands.includes(ele._id)) {
                        ele.isFavBrand = true;
                    }
                })
            }
        })
    }
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data })
});

const categoryWiseBrands = catchAsyncError(async (req, res, next) => {
    const Id = req.user;
    const { categoryId } = req.params;
    const beauticianData = await Beautician.findOne({ userId: Id })
    let brandQuery = {};
    if (categoryId === "all") {
        brandQuery = { $match: { step: 3, isDeleted: 0, endDate: { $gte: currentDate } } }
    } else {
        if (!mongoose.Types.ObjectId.isValid(categoryId)) {
            throw new ErrorHandler("Please Enter Valid category Id", HttpStatus.BAD_REQUEST, false);
        }

        brandQuery = { $match: { brandCategoryId: new mongoose.Types.ObjectId(categoryId), step: 3, isDeleted: 0, endDate: { $gte: currentDate } } }
    }

    const brandData = await Brand.aggregate([
        brandQuery,
        {
            $lookup: {
                from: 'brandcategorylists',
                localField: 'brandCategoryId',
                foreignField: "_id",
                as: 'categoryDetails',
                pipeline: [
                    { $project: { brandCategoryName: 1, brandCategoryName_fr: 1, } }
                ]
            },
        },
        { $project: { brandName: 1, brandBanner: 1, category: { $arrayElemAt: ["$categoryDetails.brandCategoryName", 0] }, category_fr: { $arrayElemAt: ["$categoryDetails.brandCategoryName_fr", 0] } } }
    ]);

    if (brandData?.length > 0) {
        brandData.map((brand => {
            brand.isFavBrand = false;
            if (beauticianData.favBrands.includes(brand._id)) {
                brand.isFavBrand = true;
            }
            return brand.isFavBrand
        }))

    }
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, brandData });
})

module.exports = {
    addToMyFavorites,
    removeBrandFromFavorites,
    getFavBrandList,
    getSingleBrandDetails,
    findBeautiBrandsProducts,
    getBeautiFilterBrand,
    getBeautiRecentSearchBrand,
    beautiAddToFavoritesBrandProducts,
    getSingleBaeutiBrandProduct,
    getAllBeautiCategoryBrands,
    categoryWiseBrands
}