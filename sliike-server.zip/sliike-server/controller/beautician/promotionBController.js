const { default: mongoose } = require("mongoose");
const catchAsyncError = require("../../middleware/catchAsyncError");
const Beautician = require("../../models/Beautician");
const Promotion = require("../../models/Promotion");
const ErrorHandler = require("../../utils/ErrorHandling");
const HttpStatus = require("../../utils/HttpStatus");
const { generateReferenceCode } = require("../../utils/generateNumericId");
const BeauticianService = require("../../models/BeauticianService");
const { validationResult } = require("express-validator");
const BeauticianProduct = require("../../models/BeauticianProduct");
const Client = require("../../models/Client");
const InvitedClient = require("../../models/InvitedClient");
const { emailMarketingFunc } = require("../../utils/emailTeplates");

const getProductList = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { beauticianId } = req.params;
    const findQuery = [
        {
            $lookup: {
                from: 'productcategorylists',
                foreignField: '_id',
                localField: 'productCategory',
                as: 'category',
                pipeline: [{ $project: { productCategoryName: 1, productCategoryName_fr: 1 } }]
            }
        },
        {
            $group: {
                _id: '$category',
                productList: { $push: { productName: '$productName', productId: '$_id' } }
            }
        },
        {
            $project: {
                'category._id': '$_id._id',
                'category.productCategoryName': '$_id.productCategoryName',
                'category.productCategoryName_fr': '$_id.productCategoryName_fr',
                'category.productList': '$productList'
            }
        },
        {
            $project: {
                'category._id': { $arrayElemAt: ['$category._id', 0] },
                'category.productCategoryName': { $arrayElemAt: ['$category.productCategoryName', 0] },
                'category.productCategoryName_fr': { $arrayElemAt: ['$category.productCategoryName_fr', 0] },
                'category.productList': 1
            }
        },
        {
            $group: {
                _id: null,
                category: { $push: '$category' }
            }
        },
        {
            $project: {
                _id: 0,
                category: 1
            }
        }
    ];
    if (id) {
        //for beautician 
        findQuery.unshift({ $match: { isDelete: 0 } },
            {
                $lookup: {
                    from: 'beauticians',
                    foreignField: '_id',
                    localField: 'beauticianId',
                    as: 'beauticianData',
                }
            },
            { $match: { 'beauticianData.userId': new mongoose.Types.ObjectId(id) } })
    } else if (beauticianId) {
        //for admin 
        findQuery.unshift({ $match: { isDelete: 0, beauticianId: new mongoose.Types.ObjectId(beauticianId) } })
    }
    const productList = await BeauticianProduct.aggregate(findQuery);
    const data = productList?.[0] || {}
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data })

});

const getServicesList = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { beauticianId } = req.params;

    const findQuery = [
        {
            $lookup: {
                from: 'servicecategorylists',
                foreignField: '_id',
                localField: 'serviceCategory',
                as: 'category',
                pipeline: [{ $project: { serviceCategoryName: 1, serviceCategoryName_fr: 1, } }]
            }
        },
        {
            $lookup: {
                from: 'servicetypelists',
                foreignField: '_id',
                localField: 'serviceType',
                as: 'serviceType',
                pipeline: [{ $project: { serviceTypeName: 1, serviceTypeName_fr: 1, serviceCategoryId: 1 } }]

            }
        },
        {
            $addFields: {
                "serviceType.bServiceId": "$_id"
            }
        },
        {
            $group: {
                _id: '$category',
                serviceType: { $push: { $arrayElemAt: ['$serviceType', 0] } }
            }
        },
        {
            $project: {
                'category._id': '$_id._id',
                'category.serviceCategoryName': '$_id.serviceCategoryName',
                'category.serviceCategoryName_fr': '$_id.serviceCategoryName_fr',
                'category.serviceType': '$serviceType'
            }
        },
        {
            $project: {
                'category._id': { $arrayElemAt: ['$category._id', 0] },
                'category.serviceCategoryName': { $arrayElemAt: ['$category.serviceCategoryName', 0] },
                'category.serviceCategoryName_fr': { $arrayElemAt: ['$category.serviceCategoryName_fr', 0] },
                // 'category.serviceType._id': 1,
                'category.serviceType.bServiceId': 1,
                'category.serviceType.serviceTypeName': 1,
                'category.serviceType.serviceTypeName_fr': 1
            }
        },
        {
            $group: {
                _id: null,
                category: { $push: '$category' }
            }
        },
        {
            $project: {
                _id: 0,
                category: 1
            }
        }
    ]
    if (id) {
        //for beautician 
        findQuery.unshift({ $match: { isDelete: 0 } },
            {
                $lookup: {
                    from: 'beauticians',
                    foreignField: '_id',
                    localField: 'beauticianId',
                    as: 'beauticianData',
                }
            },
            { $match: { 'beauticianData.userId': new mongoose.Types.ObjectId(id) } })
    } else if (beauticianId) {
        //for admin 
        findQuery.unshift({ $match: { isDelete: 0, beauticianId: new mongoose.Types.ObjectId(beauticianId) } })
    }
    const servicesList = await BeauticianService.aggregate(findQuery);
    const data = servicesList?.[0] || {}
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data })

});

const addPromotion = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { beauticianId, promotionFor, promotionTitle, subTypeId, serviceName, description, isDiscPercentage, discount, startDate, endDate, refCode } = req.body;
    const errors = validationResult(req);
    if (errors.errors.length !== 0) {
        throw new ErrorHandler(req.t(errors?.errors[0]?.msg), HttpStatus.BAD_REQUEST);
    };
    if (isDiscPercentage === 0 && subTypeId) {
        if (promotionFor === 'service') {
            const serviceData = await BeauticianService.findById(subTypeId);
            if (serviceData?.price < discount) {
                throw new ErrorHandler(req.t("serviceDiscountIsGraterThanPrice"), HttpStatus.BAD_REQUEST);
            }
        } else {
            const serviceData = await BeauticianProduct.findById(subTypeId);
            if (serviceData?.price < discount) {
                throw new ErrorHandler(req.t("productDiscountIsGraterThanPrice"), HttpStatus.BAD_REQUEST);
            }
        }
    }
    let beauticianData, createdBy, referenceCode;

    if (id) {
        //for beautician app add promotion
        beauticianData = await Beautician.findOne({ userId: id });
        // const isNameExists = await Promotion.findOne({ beauticianId: beauticianData._id, promotionTitle, promotionFor, createdBy: "beautician" })
        // if (isNameExists) {
        //     throw new ErrorHandler(req.t("promotionIsExists"), HttpStatus.BAD_REQUEST, false)
        // }
        createdBy = "beautician";
        referenceCode = generateReferenceCode(10);

    } else if (beauticianId && refCode) {
        //for admin side add promotion
        beauticianData = { _id: beauticianId };
        // const isNameExists = await Promotion.findOne({ beauticianId: beauticianData._id, promotionTitle, promotionFor, createdBy: "admin" });
        // if (isNameExists) {
        //     throw new ErrorHandler(req.t("promotionIsExists"), HttpStatus.BAD_REQUEST, false)
        // }
        createdBy = "admin";
        referenceCode = refCode
    } else {
        throw new ErrorHandler(req.t("refCodeMissing"), HttpStatus.BAD_REQUEST, false)
    }
    let subId_type = promotionFor === 'service' && "BeauticianService" || promotionFor === 'product' && "BeauticianProduct";

    const promotionData = await Promotion.aggregate([
        {
            $match: {
                $and: [
                    { beauticianId: new mongoose.Types.ObjectId(beauticianData._id) },
                    { subTypeId: new mongoose.Types.ObjectId(subTypeId) },
                    // {
                    //     startDate: {
                    //         $lte: new Date(startDate),
                    //     }
                    // },
                    // {
                    //     endDate: {
                    //         $gte: new Date(endDate),
                    //     }
                    // },
                ]
            }
        }
    ]);

    if (promotionData.length) {
        const tempDate = new Date(promotionData[0]?.startDate);
        if (tempDate >= new Date(startDate) && tempDate <= new Date(endDate)) {
            throw new ErrorHandler(req.t("inNotValidDates"), HttpStatus.BAD_REQUEST, false)
        }

        if (promotionData[0]?.startDate <= new Date(startDate) && promotionData[0]?.endDate >= new Date(endDate)) {
            throw new ErrorHandler(req.t("inNotValidDates"), HttpStatus.BAD_REQUEST, false)
        }
    }

    await Promotion.create({
        beauticianId: beauticianData._id,
        promotionFor,
        promotionTitle,
        subTypeId,
        subId_type,
        serviceName,
        description,
        isDiscPercentage,
        discount,
        startDate,
        endDate,
        referenceCode,
        createdBy
    });
    return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, message: req.t("addPromotionSuccess") })
});

const getPromotionList = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { promotionFor } = req.params;
    isValidFor = ["service", "product"]
    if (!isValidFor.includes(promotionFor)) {
        throw new ErrorHandler("Not found on server", HttpStatus.NOT_FOUND, false)
    }

    const promotionList = await Promotion.aggregate([
        {
            $match: {
                $and: [
                    { promotionFor: promotionFor },
                    { endDate: { $gte: new Date() } }
                ]
            }
        },
        {
            $lookup: {
                from: 'beauticians',
                foreignField: '_id',
                localField: 'beauticianId',
                as: 'beauticianData',
            }
        },
        { $match: { 'beauticianData.userId': new mongoose.Types.ObjectId(id) } },
        {
            $project: {
                promotionFor: 1,
                promotionTitle: 1,
                subId_type: 1,
                serviceName: 1,
                description: 1,
                isDiscPercentage: 1,
                discount: 1,
                startDate: 1,
                endDate: 1,
                referenceCode: 1,
            }
        }
    ])
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: promotionList })
});

const emailMarketing = catchAsyncError(async (req, res, next) => {
    const Id = req.user;
    const { clientIds, title, content } = req.body;
    const errors = validationResult(req);
    if (errors.errors.length !== 0) {
        throw new ErrorHandler(req.t(errors?.errors[0]?.msg), HttpStatus.BAD_REQUEST);
    };

    const beauticainData = await Beautician.findOne({ userId: Id });
    if (Array.isArray(clientIds)) {
        const isValidIDs = clientIds.some(id => !mongoose.Types.ObjectId.isValid(id));
        if (isValidIDs) {
            throw new ErrorHandler("Please Enter valid client Id", HttpStatus.BAD_REQUEST);
        }

        let tempClients = [];
        const clientId = await Promise.all(clientIds.map(async (val) => {
            const clientData = await Client.findOne({ _id: val });

            if (!clientData) return false;

            const invitedClient = await InvitedClient.findOne({
                beauticianId: beauticainData._id,
                clientId: val
            });

            if (!invitedClient) return false;

            if (clientData?.emailMarketingNotifications) {
                tempClients.push(val);
            }
        }));

        if (clientId.includes(false)) {
            throw new ErrorHandler(req.t("clientNotFound"), HttpStatus.BAD_REQUEST);
        }

        const checkClient = await InvitedClient.find({
            beauticianId: beauticainData._id,
            clientId: { $in: tempClients }
        }).populate({ path: 'clientId', select: 'email userId firstName lastName', populate: { path: 'userId', select: 'email' } });

        if (checkClient.length) {
            let temp = [];
            checkClient.forEach((val) => {
                if (val?.clientId?.userId?.email) {
                    temp.push(val.clientId.userId.email);
                }
            });

            if (temp.length) {
                const emailDetails = {
                    reciptions: temp, title, content
                }
                await emailMarketingFunc(emailDetails);
            }
        }
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("emailMarketingSuccess") });
    } else {
        throw new ErrorHandler("Please Enter valid client Id's", HttpStatus.BAD_REQUEST);
    }
})
module.exports = { addPromotion, getPromotionList, getServicesList, getProductList, emailMarketing }