//auth
module.exports.authController = require("./auth/authController");
module.exports.adminAuthController = require("./auth/adminAuthController");

// beautician
module.exports.businessController = require("./beautician/businessController");
module.exports.profileController = require("./beautician/profileController");
module.exports.serviceController = require("./beautician/serviceController");
module.exports.workHoursController = require("./beautician/workHoursController");
module.exports.employeeController = require("./beautician/employeeController");
module.exports.paymentTaxController = require("./beautician/PaymentTaxController");
module.exports.appointmentBController = require('./beautician/appointmentBController');
module.exports.promotionBController = require('./beautician/promotionBController');
module.exports.reportController = require('./beautician/reportController');
module.exports.productBController = require('./beautician/ProductController');
module.exports.clientBController = require('./beautician/clientBController');
module.exports.brandBController = require('./beautician/brandBController');


//admin
module.exports.optionController = require("./admin/OptionListController");
module.exports.demographyController = require("./admin/demography&AmenitiesController");
module.exports.packageController = require("./admin/PackageController");
module.exports.provinceController = require("./admin/ProvinceController");
module.exports.beauticianAController = require("./admin/beauticianAController");
module.exports.clientAController = require("./admin/clientAController");
module.exports.termsController = require("./admin/terms&policyController");
module.exports.serviceAcontroller = require("./admin/serviceAcontroller");
module.exports.adminprofileController = require("./admin/adminprofileController");
module.exports.helpCenterController = require("./admin/helpCenterController");
module.exports.promotionAController = require("./admin/PromotionAController");
module.exports.adminNotificationController = require("./admin/adminNotificationController");
module.exports.brandController = require("./admin/brandController")
module.exports.productController = require("./admin/productController");
module.exports.adminsController = require("./admin/adminsController");


//client
module.exports.filterServiceController = require("./client/serviceController");
module.exports.getBeauticianDetails = require("./client/serviceController");
module.exports.clientProfileController = require("./client/ProfileController");
module.exports.HomePageController = require("./client/HomePageController");
module.exports.appointmentController = require("./client/appoienmentController");
module.exports.productCController = require("./client/productCController");
module.exports.brandCController = require("./client/brandCController")

// Gist
module.exports.gistController = require("./client/gistController");


