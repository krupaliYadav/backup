const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { validationResult } = require("express-validator");
const User = require("../../models/User");
const Verification = require("../../models/Verification");
const sendEmail = require("../../utils/sendEmails");
const catchAsyncError = require("../../middleware/catchAsyncError");
const ErrorHandler = require("../../utils/ErrorHandling");
const Beautician = require("../../models/Beautician");
const Client = require("../../models/Client");
const HttpStatus = require("../../utils/HttpStatus");
const responseHandler = require("../../utils/responseHandler");
const { default: mongoose } = require("mongoose");
const FcmNotification = require("../../models/FcmNotification");
const { signupMail, forgotPasswordMail, resetSuccessfully, verifyAuthOtp, signupMailClient } = require("../../utils/emailTeplates");
const { generateBeauticianId, generateClientId } = require("../../utils/generateNumericId");
const { fcmNotification } = require("../../utils/fcmNotification");
const { notificationMSGs, referralAmount } = require("../../utils/Constant");
const BookingSetting = require("../../models/BookingSetting");
const InvitedClient = require("../../models/InvitedClient");
const moment = require("moment");
const Referral = require("../../models/Referral");

const getBusinessName = catchAsyncError(async (req, res, next) => {
    const { uid } = req.body;
    const data = await Beautician.findOne({ uid: uid, screenStatus: 7 }).select('businessName');
    if (data) {
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data });
    } else {
        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: true, message: "Beautician not found" });
    }
});

const signUpNotification = async (detail) => {
    const messageCtx = notificationMSGs.signUpUserCtx
    const deviceIds = [];
    deviceIds.push(detail.firebaseToken);
    const notifications = fcmNotification({ messageCtx, deviceIds });
    await Promise.all([notifications]);

}
//Register User
const Signup = catchAsyncError(async (req, res, next) => {
    const { firstName, lastName, email, password, phoneNumber, country, country_code, signUpType, deviceToken, firebaseToken, referral } = req.body;
    const errors = validationResult(req);
    let memberId;

    if (errors.errors.length !== 0) {
        throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST);
    };

    const userEmail = await User.findOne({ email });
    const userMobile = await User.findOne({ phoneNumber });

    // This is for Beautician count uid
    const beauticianCount = await Beautician.findOne({}).sort({ createdAt: -1 }).select({ uid: 1 });
    let tempBid = "";
    if (!beauticianCount) {
        tempBid = "SLKB-0000000"
    } else {
        tempBid = beauticianCount.uid
    }

    // This is for client count uid
    // const clientCount = await Client.count();
    const clientCount = await Client.findOne({}).sort({ createdAt: -1 }).select({ uid: 1 });
    let tempCid = "";
    if (!clientCount) {
        tempCid = "SLKC-0000000";
    } else {
        tempCid = clientCount.uid;
    }

    const Buid = generateBeauticianId(tempBid);
    const Cuid = generateClientId(tempCid);

    if (userEmail && userEmail.roles.includes(signUpType)) {
        throw new ErrorHandler("Email is already exists with this role", HttpStatus.BAD_REQUEST, false);
    }
    else if (userMobile && userMobile.roles.includes(signUpType)) {
        throw new ErrorHandler("Mobile number is already exists with this role", HttpStatus.BAD_REQUEST, false);
    }
    else if (userEmail && !userEmail.roles.includes(signUpType)) {

        userEmail.roles.push(signUpType)
        await userEmail.save();

        const existBeautician = await Beautician.findOne({ userId: userEmail.id }).exec();
        const existClient = await Client.findOne({ userId: userEmail.id }).exec();


        if (signUpType === "beautician" && !existBeautician) {
            const newBeautician = await Beautician.create({
                firstName, lastName, userId: userEmail.id, phoneNumber, country, country_code, screenStatus: 3, uid: Buid
            });
            await BookingSetting.create({
                beauticianId: newBeautician._id, confirmAuto: true, futureBookingMonths: 3
            });
            memberId = newBeautician._id;
            userEmail.isActiveBeautician = 1;
            userEmail.activateAsBeauticianDate = moment().toDate();
            await userEmail.save();
            if (deviceToken && firebaseToken && memberId) {
                const member_type = signUpType === 'user' ? 'Client' : 'Beautician';

                await FcmNotification.create({
                    memberId,
                    member_type,
                    deviceToken,
                    firebaseToken,
                });
            }
            await signupMail({ email, firstName })
            return res.status(HttpStatus.CONFLICT).json(responseHandler(HttpStatus.CONFLICT, { userId: userEmail.id }, "Email already registered.Now you can Login as Beautician."));
        } else if (signUpType === "user" && !existClient) {

            const newClient = await Client.create({
                firstName, lastName, userId: userEmail.id, country, country_code, uid: Cuid, screenStatus: 3
            });
            memberId = newClient._id;
            userEmail.isActiveUser = 1;
            userEmail.activateAsUserDate = moment().toDate();
            await userEmail.save();
            //update status in invited Client list
            await InvitedClient.updateMany({ phoneNumber }, { status: 1, clientId: newClient._id });
            await signupMailClient({ email, firstName });
            if (deviceToken && firebaseToken && memberId) {
                const member_type = signUpType === 'user' ? 'Client' : 'Beautician';
                await FcmNotification.create({
                    memberId,
                    member_type,
                    deviceToken,
                    firebaseToken,
                });
                const notificationData = {
                    id: newClient._id,
                    deviceToken,
                    firebaseToken
                }
                await signUpNotification(notificationData)
            }
            return res.status(HttpStatus.CONFLICT).json(responseHandler(HttpStatus.CONFLICT, { userId: userEmail.id }, "Email already registered.Now you can Login as user."));

        } else {
            throw new ErrorHandler("Invalid  signUpType. Only accepts either 'user' or 'beautician'.", HttpStatus.BAD_REQUEST)
        }
    }
    else {
        const hashedPassword = await bcrypt.hash(password, 10);
        if (referral) {
            const beauticianData = await Beautician.find({ uid: referral });
            if (!beauticianData.length) {
                throw new ErrorHandler("This referral code is inavalid", HttpStatus.BAD_REQUEST, false);
            }
        }
        const newUser = new User({
            email, password: hashedPassword, phoneNumber
        })
        newUser.roles.push(signUpType)
        if (referral && newUser) {
            const beauticianData = await Beautician.findOne({ uid: referral })
            const referBy = await Referral.create({ referralId: beauticianData._id, userId: newUser._id, referralCode: referral });
            newUser.referBy = referBy._id;

            const userData = await User.findOne({ _id: beauticianData.userId });
            if (userData?.roles.includes("user")) {
                const clientData = await Client.findOne({ userId: userData._id });
                // clientData.referralWallet += referralAmount;
                clientData.save();
            }
        }
        await newUser.save();
        if (signUpType === "beautician") {
            newUser.isActiveBeautician = true;
            await newUser.save();

            const newBeautician = await Beautician.create({
                firstName, lastName, userId: newUser.id, phoneNumber, country, country_code, uid: Buid
            });
            await BookingSetting.create({
                beauticianId: newBeautician._id, confirmAuto: true, futureBookingMonths: 3,
            });
            newUser.isActiveBeautician = true;
            newUser.activateAsBeauticianDate = moment().toDate();
            await newUser.save();
            await signupMail({ email, firstName })
            memberId = newBeautician._id
        } else if (signUpType === "user") {

            const newClient = await Client.create({
                firstName, lastName, userId: newUser.id, country, country_code, uid: Cuid
            })
            memberId = newClient._id;
            newUser.isActiveUser = true;
            newUser.activateAsUserDate = moment().toDate();
            await newUser.save();

            //update status in invited Client list
            await InvitedClient.updateMany({ phoneNumber }, { status: 1, clientId: newClient._id });
            // const isInvitedCustomer = await InvitedClient.findOneAndUpdate({ phoneNumber: { $regex: parseInt(phoneNumber) } }, { status: 1 }, { new: true });

            await signupMailClient({ email, firstName });
            if (deviceToken && firebaseToken) {
                const notificationData = {
                    id: newClient._id,
                    deviceToken: deviceToken,
                    firebaseToken: firebaseToken
                }
                await signUpNotification(notificationData)
            }
        } else {
            throw new ErrorHandler("Invalid  signUpType. Only accepts either 'user' or 'beautician'.", HttpStatus.BAD_REQUEST)
        }
    }

    if (deviceToken && firebaseToken && memberId) {
        const member_type = signUpType === 'user' ? 'Client' : 'Beautician';
        await FcmNotification.create({
            memberId,
            member_type,
            deviceToken,
            firebaseToken,
        });
    }
    return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, message: "Registered Successfully .." });
});

// Send Otp For Verification
const sendOtp = catchAsyncError(async (req, res, next) => {
    const { email } = req.body;

    if (!email) {
        throw new ErrorHandler("Please Enter email", HttpStatus.BAD_REQUEST);
    }
    const user = await User.findOne({ email });

    if (!user) {
        throw new ErrorHandler("Please Register from this email", HttpStatus.BAD_REQUEST);
    }
    const { _id } = user;

    var digits = '0123456789';
    let otp = '';
    for (let i = 0; i < 6; i++) {
        otp += digits[Math.floor(Math.random() * 10)];
    }

    const userEmail = user.email;

    await Verification.findOneAndRemove({ userId: _id });

    const otpExpires = Date.now() + 4 * 60 * 1000;
    await Verification.create({ userId: _id, otp, otpExpires });
    const message = `This is the code for email verification ==> ${otp}`;
    try {
        await verifyAuthOtp({ email: userEmail, otp });

        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, otp, message: "OTP send Successfully", _id });

    } catch (error) {
        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Something is wrong" });
    };
});

// Verity Valid Otp
const verifyOtp = catchAsyncError(async (req, res, next) => {
    const { UserId, otp } = req.body;

    if (!UserId) {
        throw new ErrorHandler("Please Enter User Id Verification", HttpStatus.BAD_REQUEST);
    }

    if (!otp) {
        throw new ErrorHandler("Please Enter Otp for Verification", HttpStatus.BAD_REQUEST);
    }

    const data = await Verification.findOne({ otp, userId: UserId, otpExpires: { $gt: Date.now() } });

    if (!data) {
        throw new ErrorHandler("Please Enter Valid OTP", HttpStatus.BAD_REQUEST);
    }

    const { userId, _id } = data;

    if (userId) {

        const user = await User.findById({ _id: userId });

        if (!user) {
            throw new ErrorHandler("User is not exists", HttpStatus.BAD_REQUEST);
        }
        const id = user._id;
        user.isVerified = 1;

        await user.save();

        await Verification.findByIdAndDelete({ _id: _id });
        if (user.roles.includes('beautician')) {
            await Beautician.findOneAndUpdate({ userId: id, screenStatus: 2 }, { screenStatus: 3 });
        }
        if (user.roles.includes('user')) {
            await Client.findOneAndUpdate({ userId: id, screenStatus: 2 }, { screenStatus: 3 });
        }
        const token = await jwt.sign({ _id: id }, process.env.JWT_SEC, { expiresIn: process.env.JWT_EXPIRES });

        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, token, language: user.language, message: "Verification Successfully", screenStatus: 3 })
    }

});

//Login User
const SignIn = catchAsyncError(async (req, res, next) => {
    const { email, password, role, deviceToken, firebaseToken } = req.body;
    const errors = validationResult(req);
    const accessRole = role || 'user';
    if (errors.errors.length !== 0) {
        throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST);
    };

    const user = await User.findOne({ email });

    if (user) {
        if (user.roles[0] == "user" && user.isActiveUser === 1) {
            let isClientExist = await Client.findOne({ userId: new mongoose.Types.ObjectId(user._id), isDeleted: 0 })
            if (user.isVerified) {
                if (user.password) {
                    const validPassword = await bcrypt.compare(password, user.password);
                    if (validPassword) {
                        if (isClientExist) {
                            if (deviceToken && firebaseToken) {
                                const fcmTokenExists = await FcmNotification.findOne({ memberId: isClientExist._id, deviceToken });
                                if (fcmTokenExists) {
                                    fcmTokenExists.firebaseToken = firebaseToken;
                                    await fcmTokenExists.save();
                                } else {
                                    await FcmNotification.create({
                                        memberId: isClientExist._id,
                                        member_type: 'Client',
                                        deviceToken,
                                        firebaseToken
                                    });
                                }
                            }
                            const token = await jwt.sign({ _id: user.id }, process.env.JWT_SEC, { expiresIn: process.env.JWT_EXPIRES });
                            return res.status(HttpStatus.OK).json(responseHandler(HttpStatus.OK, { type: "user", token, language: user.language, screenStatus: isClientExist.screenStatus }, "Login Successfully."));

                        } else {
                            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, message: "User details deleted" });
                        }
                    } else {
                        throw new ErrorHandler("Please Enter Valid credentials", HttpStatus.BAD_REQUEST);
                    }
                } else {
                    throw new ErrorHandler("Please Enter Valid credentials", HttpStatus.BAD_REQUEST);
                }
            } else {
                return res.status(HttpStatus.OK).json(responseHandler(HttpStatus.OK, { type: "user", token: null, screenStatus: isClientExist.screenStatus }, "Please Verified your email."));
            }
        } else if (user.roles[0] == "beautician" && user.isActiveBeautician === 1) {
            let isExistBeautician = await Beautician.findOne({ userId: new mongoose.Types.ObjectId(user._id), isDeleted: 0 })

            if (user.isVerified) {
                if (user.password) {
                    const validPassword = await bcrypt.compare(password, user.password);

                    if (validPassword) {
                        //next line for deviceToken setting 
                        if (isExistBeautician) {
                            if (isExistBeautician.screenStatus === 2) {
                                isExistBeautician.screenStatus = 3
                                await isExistBeautician.save()
                            }
                            if (deviceToken && firebaseToken) {
                                const fcmTokenExists = await FcmNotification.findOne({ memberId: isExistBeautician._id, deviceToken });
                                if (fcmTokenExists) {
                                    fcmTokenExists.firebaseToken = firebaseToken;
                                    await fcmTokenExists.save();
                                } else {
                                    await FcmNotification.create({
                                        memberId: isExistBeautician._id,
                                        member_type: 'Beautician',
                                        deviceToken,
                                        firebaseToken
                                    });
                                }
                            }
                            let data = {
                                isProvideService: isExistBeautician.isProvideService,
                                isProvideProduct: isExistBeautician.isProvideProduct,
                                phoneNumber: null,
                                country_code: null
                            };

                            if (isExistBeautician.screenStatus === 3) {
                                data.phoneNumber = user.phoneNumber,
                                    data.country_code = isExistBeautician.country_code
                            }
                            const token = await jwt.sign({ _id: user.id }, process.env.JWT_SEC, { expiresIn: process.env.JWT_EXPIRES });
                            return res.status(HttpStatus.OK).json(responseHandler(HttpStatus.OK, { type: "beautician", token, language: user.language, screenStatus: isExistBeautician.screenStatus, data }, "Login Successfully."));
                        } else {
                            throw new ErrorHandler("User details deleted", HttpStatus.BAD_REQUEST)
                        }
                    } else {
                        throw new ErrorHandler("Please Enter Valid credentials", HttpStatus.BAD_REQUEST);
                    }
                } else {
                    throw new ErrorHandler("Please Enter Valid credentials", HttpStatus.BAD_REQUEST);
                }
            } else {
                return res.status(HttpStatus.OK).json(responseHandler(HttpStatus.OK, { type: "beautician", token: null, screenStatus: isExistBeautician.screenStatus }, "Please Verified your email."));
            }
        } else {
            throw new ErrorHandler("Your account is deactivated. Please contact to Admin.", HttpStatus.BAD_REQUEST);
        }
    } else {
        throw new ErrorHandler(req.t('EmailNotFound'), HttpStatus.BAD_REQUEST);
    }
});

// Forgot Password
const forgotPassword = catchAsyncError(async (req, res, next) => {
    const { email } = req.body;

    if (!email) {
        throw new ErrorHandler("Please Enter Valid Email.", HttpStatus.BAD_REQUEST);
    }

    const user = await User.findOne({ email });

    if (user) {
        var digits = '0123456789';
        let OTP = '';
        for (let i = 0; i < 6; i++) {
            OTP += digits[Math.floor(Math.random() * 10)];
        }

        const message = `This is the code for reset password ==> ${OTP}`;
        try {
            await forgotPasswordMail({ OTP, email });

            user.resetPasswordToken = OTP;
            await user.save();
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, OTP, message: "Code has been sent to reset a new password" });

        } catch (error) {
            throw new ErrorHandler(`Something is wrong ${error}`, HttpStatus.BAD_REQUEST);
        };
    } else {
        throw new ErrorHandler("User Not Found.", HttpStatus.BAD_REQUEST);
    }
});

// Verify Reset Password
const verifyresetOtp = catchAsyncError(async (req, res, next) => {
    const { OTP } = req.body;

    if (!OTP) {
        throw new ErrorHandler("Please Enter reset password code", HttpStatus.BAD_REQUEST);
    }

    const user = await User.findOne({ resetPasswordToken: OTP });

    if (!user) {
        throw new ErrorHandler("Your OTP is Invalid.", HttpStatus.BAD_REQUEST);
    };

    const userId = user._id;

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, userId, message: "OTP is correct" });
});

//Reset Password
const resetPassword = catchAsyncError(async (req, res, next) => {
    const { userId, password } = req.body;

    if (!userId) {
        throw new ErrorHandler("Please Provide User Id", HttpStatus.BAD_REQUEST);
    }

    const user = await User.findById({ _id: userId });

    if (!user) {
        throw new ErrorHandler("User Not Found.", HttpStatus.BAD_REQUEST);
    };
    const email = user.email;

    if (!password) {
        throw new ErrorHandler("Please Enter Password..", HttpStatus.BAD_REQUEST);
    }
    const hashedPassword = await bcrypt.hash(password, 10);

    if (user) {
        user.password = hashedPassword;
        user.resetPasswordToken = null;
    }

    await user.save();
    await resetSuccessfully({ email });
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Password Reset successfully.." });

});

// Social - login
const socialLogin = catchAsyncError(async (req, res, next) => {
    const { firstName, lastName, email, phoneNumber, country, country_code, signUpType, deviceToken, firebaseToken } = req.body;
    const errors = validationResult(req);
    if (errors.errors.length !== 0) {
        throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST);
    };

    // if (signUpType !== "user" && signUpType !== "beautician") {
    //     throw new ErrorHandler("Invalid  signUpType. Only accepts either 'user' or 'beautician'.", HttpStatus.BAD_REQUEST);
    // }

    if (!email) {
        throw new ErrorHandler("Please Enter Email", HttpStatus.BAD_REQUEST);
    }

    const userData = await User.findOne({ email: email });

    // This is for Beautician count uid
    const beauticianCount = await Beautician.findOne({}).sort({ createdAt: -1 }).select({ uid: 1 });
    let tempBid = "";
    if (!beauticianCount) {
        tempBid = "SLKB-0000000"
    } else {
        tempBid = beauticianCount.uid
    }

    // This is for client count uid
    const clientCount = await Client.findOne({}).sort({ createdAt: -1 }).select({ uid: 1 });
    let tempCid = "";
    if (!clientCount) {
        tempCid = "SLKC-0000000";
    } else {
        tempCid = clientCount.uid;
    }

    const Buid = generateBeauticianId(tempBid);
    const Cuid = generateClientId(tempCid);

    // If User Email is alreday exists
    if (userData) {
        if (userData.roles.includes("user") && userData.isActiveUser === 1) {
            let isClientExist = await Client.findOne({ userId: new mongoose.Types.ObjectId(userData._id), isDeleted: 0 })
            if (userData.isVerified) {
                if (isClientExist) {
                    if (deviceToken && firebaseToken) {
                        const fcmTokenExists = await FcmNotification.findOne({ memberId: isClientExist._id, deviceToken });
                        if (fcmTokenExists) {
                            fcmTokenExists.firebaseToken = firebaseToken;
                            await fcmTokenExists.save();
                        } else {
                            await FcmNotification.create({
                                memberId: isClientExist._id,
                                member_type: 'Client',
                                deviceToken,
                                firebaseToken
                            });
                        }
                    }
                    const token = await jwt.sign({ _id: userData.id }, process.env.JWT_SEC, { expiresIn: process.env.JWT_EXPIRES });
                    return res.status(HttpStatus.OK).json(responseHandler(HttpStatus.OK, { type: "user", isRegistered: true, token, screenStatus: isClientExist.screenStatus }, "Login Successfully."));

                } else {
                    return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, message: "User details deleted" });
                }
            } else {
                return res.status(HttpStatus.OK).json(responseHandler(HttpStatus.OK, { type: "user", token: null, screenStatus: isClientExist.screenStatus }, "Please Verified your email."));
            }
        } else if (userData.roles.includes("beautician") && userData.isActiveBeautician === 1) {
            let isExistBeautician = await Beautician.findOne({ userId: new mongoose.Types.ObjectId(userData._id), isDeleted: 0 })

            if (userData.isVerified) {
                //next line for deviceToken setting 
                if (isExistBeautician) {
                    if (isExistBeautician.screenStatus === 2) {
                        isExistBeautician.screenStatus = 3
                        await isExistBeautician.save()
                    }
                    if (deviceToken && firebaseToken) {
                        const fcmTokenExists = await FcmNotification.findOne({ memberId: isExistBeautician._id, deviceToken });
                        if (fcmTokenExists) {
                            fcmTokenExists.firebaseToken = firebaseToken;
                            await fcmTokenExists.save();
                        } else {
                            await FcmNotification.create({
                                memberId: isExistBeautician._id,
                                member_type: 'Beautician',
                                deviceToken,
                                firebaseToken
                            });
                        }
                    }
                    let data = {
                        isProvideService: isExistBeautician.isProvideService,
                        isProvideProduct: isExistBeautician.isProvideProduct,
                        phoneNumber: null,
                        country_code: null
                    };

                    if (isExistBeautician.screenStatus === 3) {
                        data.phoneNumber = userData.phoneNumber,
                            data.country_code = isExistBeautician.country_code
                    }
                    const token = await jwt.sign({ _id: userData.id }, process.env.JWT_SEC, { expiresIn: process.env.JWT_EXPIRES });
                    return res.status(HttpStatus.OK).json(responseHandler(HttpStatus.OK, { type: "beautician", isRegistered: true, token, screenStatus: isExistBeautician.screenStatus, data }, "Login Successfully."));
                } else {
                    throw new ErrorHandler("User details deleted", HttpStatus.BAD_REQUEST)
                }
            } else {
                return res.status(HttpStatus.OK).json(responseHandler(HttpStatus.OK, { type: "beautician", token: null, screenStatus: isExistBeautician.screenStatus }, "Please Verified your email."));
            }
        } else {
            throw new ErrorHandler("Your account is deactivated. Please contact to Admin.", HttpStatus.BAD_REQUEST);
        }
    }
    // If User Email is not exists
    else {
        // const newUser = new User({
        //     email, phoneNumber
        // })
        // newUser.roles.push(signUpType)
        // await newUser.save();
        // if (signUpType === "beautician") {
        //     newUser.isActiveBeautician = true;
        //     await newUser.save();

        //     const newBeautician = await Beautician.create({
        //         firstName, lastName, userId: newUser.id, phoneNumber, country, country_code, uid: Buid,
        //     });
        //     await BookingSetting.create({
        //         beauticianId: newBeautician._id, confirmAuto: true, futureBookingMonths: 3,
        //     });
        //     newUser.isActiveBeautician = true;
        //     newUser.activateAsBeauticianDate = moment().toDate();
        //     await newUser.save();
        //     await signupMail({ email, firstName })
        //     memberId = newBeautician._id
        // } else if (signUpType === "user") {

        //     const newClient = await Client.create({
        //         firstName, lastName, userId: newUser.id, country, country_code, uid: Cuid
        //     })
        //     memberId = newClient._id;
        //     newUser.isActiveUser = true;
        //     newUser.activateAsUserDate = moment().toDate();
        //     await newUser.save();

        //     //update status in invited Client list
        //     await InvitedClient.updateMany({ phoneNumber }, { status: 1, clientId: newClient._id });

        //     await signupMailClient({ email, firstName });
        //     if (deviceToken && firebaseToken) {
        //         const notificationData = {
        //             id: newClient._id,
        //             deviceToken: deviceToken,
        //             firebaseToken: firebaseToken
        //         }
        //         await signUpNotification(notificationData)
        //     }
        // } else {
        //     throw new ErrorHandler("Invalid  signUpType. Only accepts either 'user' or 'beautician'.", HttpStatus.BAD_REQUEST)
        // }
        return res.status(HttpStatus.OK).json(responseHandler(HttpStatus.OK, { type: null, isRegistered: false, token: null, screenStatus: null, data: null }, "needed register"));
    }
});

//switch user account 
const switchUserAccount = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { role } = req.params;
    const { firebaseToken, deviceToken } = req.body;
    const validRole = ['beautician', 'user']
    if (!validRole.includes(role)) {
        throw new ErrorHandler("page not found on server", HttpStatus.NOT_FOUND, false);
    }
    if (!(firebaseToken && deviceToken)) {
        throw new ErrorHandler("Provide Notification details.", HttpStatus.NOT_FOUND, false);
    }
    if (role) {
        const isRoleRegister = await User.aggregate([
            { $match: { _id: new mongoose.Types.ObjectId(id) } },
            { $unwind: "$roles" },
            { $match: { "roles": role } }
        ])
        if (isRoleRegister.length > 0) {
            const userDetail = isRoleRegister[0];

            if (userDetail.isActiveBeautician === 1 && role === "beautician") {
                const isExistBeautician = await Beautician.findOne({ userId: id, isDeleted: 0 })
                if (isExistBeautician) {
                    let data = {
                        isProvideService: isExistBeautician.isProvideService,
                        isProvideProduct: isExistBeautician.isProvideProduct,
                        phoneNumber: null,
                        country_code: null
                    };

                    if (isExistBeautician.screenStatus === 3) {
                        data.phoneNumber = isRoleRegister.phoneNumber,
                            data.country_code = isExistBeautician.country_code
                    }
                    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, type: `${role}`, message: req.t("switchUserAccountSuccess", { role: role }), screenStatus: isExistBeautician.screenStatus, data });
                } else {
                    throw new ErrorHandler(req.t("switchUserAccountDeleted", { role: role }), HttpStatus.BAD_REQUEST)
                }
            } else if (userDetail.isActiveUser === 1 && role === "user") {
                const isExistClient = await Client.findOne({ userId: id, isDeleted: 0 })
                if (isExistClient) {
                    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, type: `${role}`, message: req.t("switchUserAccountSuccess", { role: role }), screenStatus: isExistClient.screenStatus });
                } else {
                    throw new ErrorHandler(req.t("switchUserAccountDeleted", { role: role }), HttpStatus.BAD_REQUEST)
                }
            } else {
                throw new ErrorHandler(req.t("switchUserAccountDeactive", { role: role }), HttpStatus.BAD_REQUEST)
            }
        }
        else {
            const userEmail = await User.findById(id);
            userEmail.roles.push(role);
            const beauticianCount = await Beautician.count();
            const clientCount = await Client.count();
            const existBeautician = await Beautician.findOne({ userId: userEmail.id }).exec();
            const existClient = await Client.findOne({ userId: userEmail.id }).exec();

            if (role === "beautician" && !existBeautician && existClient) {
                const beauticianCount = await Beautician.findOne({}).sort({ createdAt: -1 }).select({ uid: 1 });
                let tempBid = "";
                if (!beauticianCount) {
                    tempBid = "SLKB-0000000"
                } else {
                    tempBid = beauticianCount.uid
                }
                const Buid = generateBeauticianId(tempBid);
                const newBeautician = await Beautician.create({
                    firstName: existClient.firstName,
                    lastName: existClient.lastName,
                    userId: userEmail.id,
                    phoneNumber: existClient.phoneNumber,
                    country: existClient.country,
                    country_code: existClient.country_code,
                    screenStatus: 3,
                    uid: Buid
                });
                memberId = newBeautician._id;
                userEmail.isActiveBeautician = 1;
                userEmail.activateAsBeauticianDate = moment().toDate();
                await userEmail.save();
                await BookingSetting.create({
                    beauticianId: newBeautician._id, confirmAuto: true, futureBookingMonths: 3
                });
                if (deviceToken && firebaseToken && memberId) {
                    const member_type = 'Beautician';
                    await FcmNotification.create({
                        memberId,
                        member_type,
                        deviceToken,
                        firebaseToken,
                    });
                }
                await signupMail({ email: userEmail.email, firstName: newBeautician.firstName })
            } else if (role === "user" && !existClient && existBeautician) {
                const clientCount = await Client.findOne({}).sort({ createdAt: -1 }).select({ uid: 1 });
                let tempCid = "";
                if (!beauticianCount) {
                    tempCid = "SLKC-0000000";
                } else {
                    tempCid = clientCount.uid;
                }
                const Cuid = generateClientId(tempCid);
                const newClient = await Client.create({
                    firstName: existBeautician.firstName || "",
                    lastName: existBeautician.lastName,
                    userId: userEmail.id,
                    country: existBeautician.country,
                    country_code: existBeautician.country_code,
                    uid: Cuid,
                    screenStatus: 3
                })
                memberId = newClient._id;
                userEmail.isActiveUser = 1;
                userEmail.activateAsUserDate = moment().toDate();
                await userEmail.save();
                //update status in invited Client list
                await InvitedClient.updateMany({ phoneNumber: existBeautician.phoneNumber }, { status: 1, clientId: newClient._id });
                await signupMailClient({ email: userEmail.email, firstName: newClient.firstName });
                if (deviceToken && firebaseToken && memberId) {
                    const member_type = 'Client';
                    await FcmNotification.create({
                        memberId,
                        member_type,
                        deviceToken,
                        firebaseToken,
                    });
                    const notificationData = {
                        id: newClient._id,
                        deviceToken,
                        firebaseToken
                    }
                    await signUpNotification(notificationData)
                }
            } else {
                throw new ErrorHandler("Invalid  signUpType. Only accepts either 'user' or 'beautician'.", HttpStatus.BAD_REQUEST)
            }
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, type: req.t("switchUserAccountSuccess", { role: role }), screenStatus: 3 });
        }
    } else {
        throw new ErrorHandler("Role not found", HttpStatus.BAD_REQUEST);
    }
});

// For logout
const handleLogOut = catchAsyncError(async (req, res, next) => {
    const { deviceToken, role } = req.body;
    const id = req.user;
    let memberDetails = {};
    if (role === "user") {
        memberDetails = await Client.findOne({ userId: id });
    } else if (role === "beautician") {
        memberDetails = await Beautician.findOne({ userId: id });
    } else {
        throw new ErrorHandler("Role is missing", HttpStatus.BAD_REQUEST);
    }
    await FcmNotification.findOneAndUpdate({ memberId: memberDetails._id, deviceToken }, { firebaseToken: null });
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, message: "user logout successfully." });

});

module.exports = { getBusinessName, Signup, sendOtp, verifyOtp, SignIn, forgotPassword, verifyresetOtp, resetPassword, socialLogin, switchUserAccount, handleLogOut }