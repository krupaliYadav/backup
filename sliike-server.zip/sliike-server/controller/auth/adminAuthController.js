const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { validationResult } = require("express-validator");
const catchAsyncError = require("../../middleware/catchAsyncError");
const ErrorHandler = require("../../utils/ErrorHandling");
const HttpStatus = require("../../utils/HttpStatus");
const Admin = require("../../models/Admin");
const { generateNumericId } = require("../../utils/generateNumericId");

//super-admin signUp
const adminSingUp = catchAsyncError(async (req, res, next) => {
    const { firstName, lastName, email, password, role, phoneNumber } = req.body;
    const uid = generateNumericId(7);
    const errors = validationResult(req);

    if (errors.errors.length !== 0) {
        throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST);
    };
    const isEmailExists = await Admin.findOne({ email });
    if (!isEmailExists) {
        const hashedPassword = await bcrypt.hash(password, 10);
        const NewAdmin = await Admin.create({ firstName, lastName, role, phoneNumber, email, password: hashedPassword, uid: `SLKA${uid}` });
        return res.status(201).json({ status: 201, success: true, message: "Admin registered successfully.." });
    } else {
        throw new ErrorHandler("Email is already exists.", HttpStatus.CONFLICT);
    }
});

//super-admin signin
const adminSignIn = catchAsyncError(async (req, res, next) => {

    const { email, password } = req.body;
    const errors = validationResult(req);

    if (errors.errors.length !== 0) {
        throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST);
    };

    const admin = await Admin.findOne({ email });
    if (admin) {
        const validPassword = await bcrypt.compare(password, admin.password);

        if (validPassword) {
            const token = await jwt.sign({ _id: admin.id }, process.env.JWT_SEC, { expiresIn: process.env.JWT_EXPIRES });
            return res.status(HttpStatus.OK).json({
                status: HttpStatus.OK,
                success: true,
                token,
                settings: {
                    dashboardSettings: admin.dashboardSettings,
                    beauticianSettings: admin.beauticianSettings,
                    clientSettings: admin.clientSettings,
                    productSettings: admin.productSettings,
                    brandSettings: admin.brandSettings,
                    gistSettings: admin.gistSettings,
                    promotionSettings: admin.promotionSettings,
                    adminSettings: admin.adminSettings,
                },
                message: "Login Successfully."
            });
        } else {
            throw new ErrorHandler("Email and password does not match.", HttpStatus.BAD_REQUEST);
        }
    } else {
        throw new ErrorHandler("Please Enter Valid Email", HttpStatus.BAD_REQUEST);
    }
});

module.exports = { adminSingUp, adminSignIn }