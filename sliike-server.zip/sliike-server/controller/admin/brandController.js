const catchAsyncError = require("../../middleware/catchAsyncError");
const HttpStatus = require("../../utils/HttpStatus");
const formidable = require("formidable");
const ValidationError = require("../../utils/validationError");
const { brandValidation, brandProductValidation } = require("../../middleware/validations")
const { pathEndpoint } = require("../../utils/Constant");
const Brand = require("../../models/Brand");
const ServiceCategory = require("../../models/ServiceCategoryList")
const Demography = require("../../models/Demography")
const { uploadFile } = require("../../libs/aws/uploadImg");
const { deleteFile } = require("../../libs/aws/deleteImg");
const { v4: uuidv4 } = require('uuid');
const ErrorHandler = require("../../utils/ErrorHandling");
const { generateBrandId, generateBrandProductId } = require("../../utils/generateNumericId")
const mongoose = require("mongoose");
const BrandProducts = require("../../models/BrandProducts");
const BrandCategory = require("../../models/BrandCategory");
const moment = require("moment");
const Province = require("../../models/Province");

/*add Brand*/
const addBrand = catchAsyncError(async (req, res, next) => {
    const form = formidable({ multiples: true });
    form.parse(req, async (err, fields, files) => {
        const { brandName, brandCategoryId, brandOwner, email, phoneNumber, country, address, city, province, postalCode, targetAudience, targetDemographicId, registeredDate, sliikePlan, contractType, startDate, endDate, contractDuration, plateFormFee, discount, discountAmount, HSTOrGST, QSTOrPST, totalFeeCharge, websiteUrl, shippingPolicyUrl, returnPolicyUrl, brandProducts } = fields
        try {
            // validation
            const validation = brandValidation.filter(field => !fields[field]);
            if (validation.length > 0) {
                throw new ValidationError(`${validation.join(', ')} is required`);
            }

            // _ids validation
            if (!mongoose.Types.ObjectId.isValid(brandCategoryId)) {
                throw new ErrorHandler("Please Enter Valid Brand category Id", HttpStatus.BAD_REQUEST, false);
            }
            if (!mongoose.Types.ObjectId.isValid(targetDemographicId)) {
                throw new ErrorHandler("Please Enter Valid target demography Id", HttpStatus.BAD_REQUEST, false);
            }

            // check category and demography exits or not
            const isCategoryExits = await BrandCategory.findOne({ _id: brandCategoryId })
            if (!isCategoryExits) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: 'Brand category Type dose not exits..!' })
            }
            const isDemographyExits = await Demography.findOne({ _id: targetDemographicId, status: 1 })
            if (!isDemographyExits) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: 'Target Demography Type dose not exits..!' })
            }

            if (startDate < moment(new Date()).format('YYYY-MM-DD')) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: 'Please Enter valid start date' })
            }

            // This is for brand count uid
            const brandCount = await Brand.findOne({}).sort({ createdAt: -1 }).select({ uid: 1 });
            let tempId = "";
            if (!brandCount) {
                tempId = "SLKB-0000000";
            } else {
                tempId = brandCount.uid;
            }
            const BrandUid = generateBrandId(tempId);

            let isBrandExist = await Brand.findOne({ brandName: fields.brandName, isDeleted: 0 })
            if (!isBrandExist) {
                let tempBrandBanner = "";
                let tempBrandLogo = "";
                if (!files?.brandBanner) {
                    return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Brand Banner is missing." });
                } else {
                    const imgName = files?.brandBanner?.originalFilename.split(".");
                    const extension = imgName[imgName.length - 1];
                    if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: `${extension} is not allowed..` });

                    }
                    const fileName = (files.brandBanner.originalFilename = uuidv4() + "." + extension);
                    const newPath = `${pathEndpoint.adminBrandBanner}${fileName}`;
                    try {
                        const uploadImgRes = await uploadFile(files.brandBanner, newPath, extension);
                        tempBrandBanner = uploadImgRes.imageUrl;
                    } catch (error) {
                        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, error });
                    }
                }

                if (!files.brandLogo) {
                    return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Brand Logo is missing." });

                } else {
                    const imgName = files.brandLogo.originalFilename.split(".");
                    const extension = imgName[imgName.length - 1];
                    if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: `${extension} is not allowed..` });
                    }
                    const fileName = (files.brandLogo.originalFilename = uuidv4() + "." + extension);
                    const newPath = `${pathEndpoint.adminBrandLogo}${fileName}`;
                    try {
                        const uploadImgRes = await uploadFile(files.brandLogo, newPath, extension);
                        tempBrandLogo = uploadImgRes.imageUrl;
                    } catch (error) {
                        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, error });
                    }
                }

                const newBrand = await new Brand({
                    brandName, uid: BrandUid, brandCategoryId, brandOwner, email, phoneNumber, country, address, city, province, postalCode, targetAudience,
                    targetDemographicId, registeredDate, sliikePlan, contractType, startDate, endDate, contractDuration, plateFormFee, brandLogo: tempBrandLogo,
                    brandBanner: tempBrandBanner, discount, discountAmount, HSTOrGST, QSTOrPST, totalFeeCharge, websiteUrl, shippingPolicyUrl, returnPolicyUrl
                });
                await newBrand.save();
                return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, brandId: newBrand._id, message: "Brand Details saved successfully." });

            } else {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Brand name is already exist" });
            }

        } catch (error) {
            // Handle the validation error
            if (error instanceof ValidationError) {
                return res.status(error.status).json({ status: error.status, success: false, message: error.message });
            } else {
                return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
            }
        }
    });
});

const addBrandProducts = catchAsyncError(async (req, res, next) => {
    try {
        const form = formidable({ multiples: true });
        form.parse(req, async (err, fields, files) => {
            const { brandId, products } = fields;
            const brandData = await Brand.findOne({ _id: brandId });
            if (brandData) {
                // if (brandData.step == 1) {
                try {
                    if (products == undefined) {
                        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Prodcts is missing" });
                    }
                    if (!products.length) {
                        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Prodcts is missing" });
                    }
                    const uploadPromises = await Promise.all(products.map(async (val) => {
                        if (!val?.productName) {
                            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Product name missing" });
                        }
                        if (!val?.productPrice) {
                            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Product price missing" });
                        }
                        if (!val?.productSize) {
                            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Product size missing" });
                        }
                        if (!val?.description) {
                            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Product description missing" });
                        }


                        if (files.images) {
                            if (files.images.length) {
                                await Promise.all(files.images.map(async (imgVal) => {
                                    if (val.productImageName === imgVal.originalFilename) {
                                        const imgName = imgVal.originalFilename.split(".");
                                        const extension = imgName[imgName.length - 1];
                                        if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                                            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("ImageExtension", { extension: extension }) });
                                        }
                                        const fileName = (imgVal.originalFilename = uuidv4() + "." + extension);
                                        const newPath = `${pathEndpoint.adminBrandProductImage}${fileName}`;
                                        const uploadImgRes = await uploadFile(imgVal, newPath, extension);
                                        if (uploadImgRes.status === 200) {
                                            val.productImageName = uploadImgRes.imageUrl;
                                        }
                                    }
                                }))
                            } else {
                                if (val.productImageName === files.images.originalFilename) {
                                    const imgName = files.images.originalFilename.split(".");
                                    const extension = imgName[imgName.length - 1];
                                    if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                                        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("ImageExtension", { extension: extension }) });
                                    }
                                    const fileName = (files.images.originalFilename = uuidv4() + "." + extension);
                                    const newPath = `${pathEndpoint.adminBrandProductImage}${fileName}`;
                                    const uploadImgRes = await uploadFile(files.images, newPath, extension);
                                    if (uploadImgRes.status === 200) {
                                        val.productImageName = uploadImgRes.imageUrl;
                                    }
                                }
                            }
                        } else {
                            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: true, message: "Images are required" })
                        }
                        const brandProductCount = await BrandProducts.findOne({}).sort({ createdAt: -1 }).select({ uid: 1 });
                        let tempPId = "";
                        if (!brandProductCount) {
                            tempPId = "SLKU-0000000"
                        } else {
                            tempPId = brandProductCount.uid
                        }
                        const uid = generateBrandProductId(tempPId);
                        val.uid = uid;
                        val.brandId = brandId;
                    }))
                    await Promise.all(uploadPromises);
                    const newProduct = await BrandProducts.insertMany(products);
                    const productIds = newProduct.map((val) => {
                        return val._id;
                    });
                    brandData.brandProductId = productIds;
                    brandData.step = 2;
                    await brandData.save();

                    return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, brandId: brandData._id, message: "Products added successfully" });

                } catch (error) {
                    return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "something" });
                    // Handle the validation error
                    // if (error instanceof ValidationError) {
                    //     return res.status(error.status).json({ status: error.status, success: false, message: error.message });
                    // }
                }
                // } else {
                //     return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "You alreday added product for this brand" });
                // }
            } else {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Brand details not found" });
            }
        });
    } catch (error) { return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Something is wrong in Images" }); }
});

const getBrandDetails = catchAsyncError(async (req, res, next) => {
    const { brandId } = req.params;

    const data = await Brand.aggregate([
        { $match: { _id: new mongoose.Types.ObjectId(brandId), step: 2 } },
        {
            $lookup: {
                from: 'brandproducts',
                localField: 'brandProductId',
                foreignField: "_id",
                as: 'productDeatils',
                pipeline: [
                    { $project: { productName: 1, productPrice: 1, productImageName: 1 } }
                ]
            },
        },
        {
            $project: { brandLogo: 1, brandBanner: 1, productDeatils: 1, }
        }
    ]);

    if (data.length) {
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data });
    } else {
        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: true, message: "Please complete steps" });
    }

});

const completeBrandSteps = catchAsyncError(async (req, res, next) => {
    const { brandId } = req.body;

    const brandData = await Brand.findOne({ _id: brandId });

    if (brandData) {
        if (brandData.step == 2) {
            brandData.step = 3;
            await brandData.save();
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Brand steps completed" });
        } else {
            throw new ErrorHandler("Please check brand steps", HttpStatus.BAD_REQUEST, false);
        }
    } else {
        throw new ErrorHandler("Brand details not found", HttpStatus.BAD_REQUEST, false);
    }
});

/*get brand list
*in this we can able search by brand name
*Filter by category
*/
const getBrandList = catchAsyncError(async (req, res, next) => {
    const brandData = await Brand.find({
        // isDeleted: 0,
        step: { $ne: 3 }
    });

    // if (brandData?.length) {
    //     return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, step: brandData[0].step, brandId: brandData[0]._id, message: "This brand is incomplete please complete it", });
    // } else {
    try {
        let { search, brandCategoryId, limit, offset } = req.query
        const limitData = parseInt(limit, 10) || 10;
        const offsetData = parseInt(offset, 10) || 0;
        let query = { step: 3, isDeleted: 0 }

        if (search) {
            query.brandName = { $regex: search, $options: "i" }
        }
        if (brandCategoryId) {
            query = { ...query, brandCategoryId: new mongoose.Types.ObjectId(brandCategoryId) }
        }

        let brand = await Brand.aggregate([
            { $match: query },
            {
                $lookup: {
                    from: 'brandcategorylists',
                    localField: 'brandCategoryId',
                    foreignField: "_id",
                    as: 'brandCategoryId',
                    pipeline: [
                        { $project: { brandCategoryName: 1, brandCategoryName_fr: 1, } }
                    ]
                },
            },
            { $unwind: "$brandCategoryId" },
            {
                $lookup: {
                    from: 'demographies',
                    localField: 'targetDemographicId',
                    foreignField: "_id",
                    as: 'targetDemographicId',
                    pipeline: [
                        { $project: { demographyName: 1, demographyName_fr: 1 } }
                    ]
                },
            },
            { $unwind: "$targetDemographicId" },
            { $sort: { createdAt: 1 } },
            {
                $project: {
                    _id: 1,
                    brandName: 1,
                    uid: 1,
                    category: "$brandCategoryId.brandCategoryName",
                    category_fr: "$brandCategoryId.brandCategoryName_fr",
                    status: 1,
                    address: 1,
                    city: 1,
                    province: 1,
                    postalCode: 1,
                    startDate: 1,
                    endDate: 1,
                    sliikePlan: 1,
                    brandBanner: {
                        $ifNull: ["$brandBanner", null]
                    },
                }
            }
        ])
        const totalBrand = brand.length
        brand = brand.slice(offsetData, limitData + offsetData);
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Brand List load successfully", totalBrand, data: brand });
    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
    // }

});

/*UPDATE BRAND DETAILS*/
const updateBrand = catchAsyncError(async (req, res, next) => {
    const brandId = req.params.brandId
    if (!mongoose.Types.ObjectId.isValid(brandId)) {
        throw new ErrorHandler("Please Enter Valid Brand Id", HttpStatus.BAD_REQUEST, false);
    }
    const form = formidable({ multiples: true });
    form.parse(req, async (err, fields, files) => {
        try {
            const brandDetails = await Brand.findOne({ _id: brandId, isDeleted: 0 })
            if (!brandDetails) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: 'Brand not found' });
            }

            // validation
            const validation = brandValidation.filter(field => !fields[field]);
            if (validation.length > 0) {
                throw new ValidationError(`${validation.join(', ')} is required`);
            }
            if (!mongoose.Types.ObjectId.isValid(fields.brandCategoryId)) {
                throw new ErrorHandler("Please Enter Valid brand category Id", HttpStatus.BAD_REQUEST, false);
            }
            if (!mongoose.Types.ObjectId.isValid(fields.targetDemographicId)) {
                throw new ErrorHandler("Please Enter Valid target demography Id", HttpStatus.BAD_REQUEST, false);
            }

            // check for brand name is already exits or not
            const isBrandExist = await Brand.findOne({ brandName: fields.brandName })
            if (!isBrandExist) {
                // check category and demography exits or not
                const isCategoryExits = await ServiceCategory.findOne({ _id: fields.brandCategoryId })
                if (!isCategoryExits) {
                    return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: 'Brand category Type dose not exits..!' })
                }
                const isDemographyExits = await Demography.findOne({ _id: fields.targetDemographicId })
                if (!isDemographyExits) {
                    return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: 'Target Demography Type dose not exits..!' })
                }

                if (files.brandBanner) {
                    const imgName = files.brandBanner.originalFilename.split(".");
                    const extension = imgName[imgName.length - 1];
                    if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: `${extension} is not allowed..` });
                    }
                    const fileName = (files.brandBanner.originalFilename =
                        uuidv4() + "." + extension);
                    const newPath = `${pathEndpoint.adminBrandBanner}${fileName}`;
                    const uploadImgRes = await uploadFile(files.brandBanner, newPath, extension);

                    if (brandDetails?.brandBanner) {
                        const removeImg = brandDetails?.brandBanner.includes(process.env.AWS_BUCKET_REGION) ? brandDetails?.brandBanner.replace(process.env.IMAGE_BASE_URL_WITH_REGION, "") : brandDetails?.brandBanner.replace(process.env.IMAGE_BASE_URL, "")

                        await deleteFile(removeImg);
                    }
                    fields.brandBanner = uploadImgRes.imageUrl;
                };


                if (files.brandLogo) {
                    const imgName = files.brandLogo.originalFilename.split(".");
                    const extension = imgName[imgName.length - 1];
                    if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: `${extension} is not allowed..` });
                    }

                    const fileName = (files.brandLogo.originalFilename =
                        uuidv4() + "." + extension);
                    const newPath = `${pathEndpoint.adminBrandLogo}${fileName}`;
                    const uploadImgRes = await uploadFile(files.brandLogo, newPath, extension);

                    if (brandDetails?.brandLogo) {
                        const removeImg = brandDetails?.brandLogo.includes(process.env.AWS_BUCKET_REGION) ? brandDetails?.brandLogo.replace(process.env.IMAGE_BASE_URL_WITH_REGION, "") : brandDetails?.brandLogo.replace(process.env.IMAGE_BASE_URL, "")
                        await deleteFile(removeImg);
                    }
                    fields.brandLogo = uploadImgRes.imageUrl;
                };

                await Brand.findOneAndUpdate({ _id: brandId, isDeleted: 0 }, fields, { new: true })
                return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Brand Details updated successfully." });
            } else {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "This brand name is already exits" })
            }
        } catch (error) {
            // Handle the validation error
            if (error instanceof ValidationError) {
                return res.status(error.status).json({ status: error.status, success: false, message: error.message });
            } else {
                return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
            }
        }
    });
});

/* UPDATE BRAND STATUS*/
const updateStatus = catchAsyncError(async (req, res, next) => {
    const brandId = req.params.brandId
    const { status } = req.body
    try {
        //  id validation
        if (!mongoose.Types.ObjectId.isValid(brandId)) {
            throw new ErrorHandler("Please Enter Valid Brand Id", HttpStatus.BAD_REQUEST, false);
        }

        const brandDetails = await Brand.findOne({ _id: brandId, isDeleted: 0 })
        if (!brandDetails) {
            return res.status(HttpStatus.NOT_FOUND).json({ status: HttpStatus.NOT_FOUND, success: false, message: 'Brand not found' });
        }

        if (status != 0 && status != 1) {
            throw new ErrorHandler("Please Enter valid status type", HttpStatus.BAD_REQUEST);
        }
        await Brand.findByIdAndUpdate({ _id: brandId, isDeleted: 0 }, { status });
        return res.status(200).json({ status: 200, success: true, message: "Brand Details updated successfully." });

    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});

const deleteBrand = catchAsyncError(async (req, res, next) => {
    const brandId = req.params.brandId
    try {
        //  id validation
        if (!mongoose.Types.ObjectId.isValid(brandId)) {
            throw new ErrorHandler("Please Enter Valid Brand Id", HttpStatus.BAD_REQUEST, false);
        }

        const brandDetails = await Brand.findOne({ _id: brandId, isDeleted: 0 })
        if (!brandDetails) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: 'Brand not found' });
        }

        await Brand.findByIdAndUpdate({ _id: brandId, isDeleted: 0 }, { isDeleted: 1 });
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Brand delete successfully." });

    } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: error.message });
    }
});

// get brand dashboard
const getBrandDashboard = catchAsyncError(async (req, res, next) => {
    const { brandId } = req.body;

    if (!mongoose.Types.ObjectId.isValid(brandId)) {
        throw new ErrorHandler("Please Enter Valid Brand Id", HttpStatus.BAD_REQUEST, false);
    }

    const brandData = await Brand.aggregate([
        { $match: { _id: new mongoose.Types.ObjectId(brandId) } },
        {
            $lookup: {
                from: 'brandcategorylists',
                localField: 'brandCategoryId',
                foreignField: "_id",
                as: 'categoryDetails',
                pipeline: [
                    { $project: { brandCategoryName: 1, brandCategoryName_fr: 1, } }
                ]
            },
        },
        {
            $addFields: {
                numOfBuyClick: {
                    $size: "$buyerId"
                }
            }
        },
        {
            $lookup: {
                from: 'clients',
                localField: 'buyerId',
                foreignField: '_id',
                as: 'clientsData',
                pipeline: [
                    { $project: { gender: { $ifNull: ['$gender', null] }, address: 1 } },
                ]
            }
        },
        {
            $lookup: {
                from: 'beauticians',
                localField: 'buyerId',
                foreignField: '_id',
                as: 'beauticiansData',
                pipeline: [
                    { $project: { gender: { $ifNull: ['$gender', null] }, address: 1 } },
                ]
            }
        },
        {
            $lookup: {
                from: 'addresses',
                localField: 'clientsData.address.addressId',
                foreignField: '_id',
                as: 'clientAddress',
                pipeline: [
                    { $project: { province: 1 } },
                ]
            }
        },
        {
            $lookup: {
                from: 'addresses',
                localField: 'beauticiansData.address',
                foreignField: '_id',
                as: 'beauticianAddress',
                pipeline: [
                    { $project: { province: 1 } },
                ]
            }
        },
        {
            $addFields: {
                buyerDetails: {
                    $concatArrays: ['$clientsData', '$beauticiansData']
                }
            },
        },
        {
            $addFields: {
                buyerAddress: {
                    $concatArrays: ['$clientAddress', '$beauticianAddress']
                }
            },
        },
        {
            $project: {
                brandName: 1, uid: 1, email: 1, phoneNumber: 1, country: 1, address: 1, city: 1, startDate: 1, endDate: 1, shareClick: 1,
                brandLogo: 1, brandBanner: 1, status: 1, numOfViews: 1, numOfBuyClick: 1, buyerId: 1, viewer_type: 1,
                categoryName: { $arrayElemAt: ['$categoryDetails.brandCategoryName', 0] },
                categoryName_fr: { $arrayElemAt: ['$categoryDetails.brandCategoryName_fr', 0] },
                // clientAddress: 1, beauticianAddress: 1,
                buyerAddress: 1,
                buyerDetails: 1,
            }
        }
    ]);

    const provinceData = await Province.find({ status: 1 }).select("name").lean();

    const genderCounts = brandData[0].buyerDetails.reduce((acc, buyer) => {
        if (buyer.gender) {
            const gender = buyer.gender;
            acc[gender] = (acc[gender] || 0) + 1;
        }
        return acc;
    }, {});

    provinceData.map((val) => {
        val.count = 0
        if (brandData.length) {
            brandData[0].buyerAddress.map((ele) => {
                if (val._id.toString() === ele.province.toString()) {
                    val.count += 1;
                }
            })
        }
    });

    brandData[0].genderCounts = genderCounts;
    brandData[0].provinceCounts = provinceData;
    delete brandData[0].buyerDetails;
    delete brandData[0].buyerAddress;

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, brandData });
});

module.exports = {
    addBrand,
    addBrandProducts,
    getBrandDetails,
    completeBrandSteps,
    getBrandList,
    updateBrand,
    updateStatus,
    deleteBrand,
    getBrandDashboard
}