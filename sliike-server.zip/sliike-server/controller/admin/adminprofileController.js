const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { validationResult } = require("express-validator");
const catchAsyncError = require("../../middleware/catchAsyncError");
const ErrorHandler = require("../../utils/ErrorHandling");
const HttpStatus = require("../../utils/HttpStatus");
const Admin = require("../../models/Admin");
const formidable = require("formidable");
const { v4: uuidv4 } = require('uuid');
const { pathEndpoint, AppId, AppStoreId } = require("../../utils/Constant");
const fs = require("fs");
const Beautician = require("../../models/Beautician");
const BeauticianService = require("../../models/BeauticianService");
const ServiceCategoryList = require("../../models/ServiceCategoryList");
const Client = require("../../models/Client");
const Province = require("../../models/Province");
const Payment = require("../../models/Payment");
const Appointment = require("../../models/Appointment");
const { default: mongoose } = require("mongoose");
const platform_fees = process.env.PLATFORM_FEES || 0.10;
const moment = require("moment");
const { uploadFile } = require("../../libs/aws/uploadImg");
const { deleteFile } = require("../../libs/aws/deleteImg");
const User = require("../../models/User");
const appStore = require('app-store-scraper');
const https = require('https');
const ProductCategoryList = require("../../models/ProductCategoryList");
const Order = require("../../models/Order");
const BeauticianProdduct = require("../../models/BeauticianProduct");
const Brand = require("../../models/Brand");

const monthCounts = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nav",
  "Dec",
];
const getSingleAdmin = catchAsyncError(async (req, res, next) => {
  const Id = req.admin;
  const data = await Admin.findOne(
    { _id: Id }
  )
    .select({ 'firstName': 1, 'lastName': 1, 'email': 1, 'phoneNumber': 1, 'role': 1, 'isDeleted': 1, 'status': 1, 'profileImage': 1 });
  return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data });
});

const updateAdminProfile = catchAsyncError(async (req, res, next) => {

  const form = formidable({ multiples: true });

  form.parse(req, async (err, fields, files) => {
    const { Id, firstName, lastName, email, phoneNumber, oldEmail } = fields;

    if (email !== oldEmail) {
      const isEmailExists = await Admin.findOne({ email });
      if (isEmailExists) {
        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, message: "Email is alredy exist" })
      }
    }
    if (err) {
      throw new ErrorHandler("Something is wrong with Image Uploading", HttpStatus.BAD_REQUEST);
    }
    const adminData = await Admin.findOne({ _id: Id, email: oldEmail });

    if (!adminData) {
      return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: `admin is not exists` });
    }

    if (files.profileImage) {
      const { mimetype } = files.profileImage;
      const img = mimetype.split("/");
      const extension = img[1].toLowerCase();

      if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: `${extension} is not allowed..` });
      }

      const fileName = (files.profileImage.originalFilename = uuidv4() + "." + extension);

      const newPath = `${pathEndpoint.adminProfile}${fileName}`;

      try {
        const uploadImgRes = await uploadFile(files.profileImage, newPath, extension);
        if (adminData.profileImage) {
          const removeImg = adminData.profileImage.includes(process.env.AWS_BUCKET_REGION) ? adminData.profileImage.replace(process.env.IMAGE_BASE_URL_WITH_REGION, "") : adminData.profileImage.replace(process.env.IMAGE_BASE_URL, "")
          await deleteFile(removeImg)
        }
        adminData.profileImage = uploadImgRes.imageUrl;
        await adminData.save();
        return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, message: "Logo added successfully." });
      } catch (error) {
        return res.status(HttpStatus.ERROR).json({
          status: HttpStatus.ERROR,
          success: false,
          message: 'Something went wrong in Image upload. Please try again',
        });
      }
    }
    await Admin.findOneAndUpdate({ _id: Id }, { firstName, lastName, phoneNumber, email });
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Profile Updated Successfully" });
  });
});

const changePasswordAdmin = catchAsyncError(async (req, res, next) => {
  const Id = req.admin;
  const { oldPassword, newPassword, confirmPassword } = req.body;

  const adminData = await Admin.findOne({ _id: Id });

  if (adminData) {
    const verifyPassword = await bcrypt.compare(oldPassword, adminData.password);

    if (!verifyPassword) {
      throw new ErrorHandler("Please Enter valid credentials", HttpStatus.BAD_REQUEST);
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);

    if (newPassword !== confirmPassword) {
      throw new ErrorHandler("Confirm password not matched", HttpStatus.BAD_REQUEST);
    }
    adminData.password = hashedPassword;
    await adminData.save();
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Password changed successfully" });
  } else {
    throw new ErrorHandler("Admin data not found", HttpStatus.BAD_REQUEST);
  }
});
//admin panel dashboard pie chart
const dashbordSummary = catchAsyncError(async (req, res, next) => {
  const { startDate, endDate } = req.query;
  let chartFilter = {};
  let provinceData = [];
  let totalPlayStoreDownloads = 0;
  let totalAppStoreDownloads = 0;
  let totalNumberofBusiness = 0;
  let totalNumberofProductSales = 0;

  // for chart 
  if (startDate && endDate) {
    if (startDate !== "" && endDate !== "") {
      chartFilter = {
        $expr: {
          $and: [
            {
              $gte: [
                { $toDate: '$createdAt' },
                { $toDate: startDate }
              ]
            },
            {
              $lte: [
                { $toDate: '$createdAt' },
                { $toDate: endDate }
              ]
            }
          ]
        },
      }
    }
  }
  // It returns total service transction
  const serviceTransction = await Payment.aggregate([
    { $match: { paymentStatus: 1 } },
    { $match: chartFilter },
    {
      $addFields: {
        sliikFee: 0,
        sliikFeeGST: 0,
        sliikFeePST: 0,
        // sliikFee: { $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees)] }, 2] },
        // sliikFeeGST: { $sum: [{ $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees), "$GstInPer", 0.01] }, 2] }, { $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees), "$HstInPer", 0.01] }, 2] }] },
        // sliikFeePST: { $sum: [{ $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees), "$PstInPer", 0.01] }, 2] }, { $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees), "$QstInPer", 0.01] }, 2] }] },
        gstORhst: { $sum: [{ $round: [{ $multiply: ["$subTotal", "$GstInPer", 0.01] }, 2] }, { $round: [{ $multiply: ["$subTotal", "$HstInPer", 0.01] }, 2] }] },
        pstORqst: { $sum: [{ $round: [{ $multiply: ["$subTotal", "$PstInPer", 0.01] }, 2] }, { $round: [{ $multiply: ["$subTotal", "$QstInPer", 0.01] }, 2] }] },
        discount: { $round: [{ $multiply: ["$subTotal", "$discount", 0.01] }, 2] }
      }
    },
    {
      $group: {
        _id: null,
        totalSubTotal: { $sum: "$subTotal" },
        totalGSTORHST: { $sum: "$gstORhst" },
        totalPSTORQST: { $sum: "$pstORqst" },
        totalSliikFees: { $sum: "$sliikFee" },
        totalsliikFeeGST: { $sum: "$sliikFeeGST" },
        totalsliikFeePST: { $sum: "$sliikFeePST" },
        discount: { $sum: '$discount' }
      }
    }
  ]);

  if (serviceTransction.length > 0) {
    serviceTransction[0].totalSliikRevenue = serviceTransction[0].totalSliikFees + serviceTransction[0].totalsliikFeeGST + serviceTransction[0].totalsliikFeePST
  }

  // I t returns product transctions
  const productTransction = await Order.aggregate([
    { $match: { paymentStatus: 1 } },
    { $match: chartFilter },
    {
      $addFields: {
        sliikFee: 0,
        sliikFeeGST: 0,
        sliikFeePST: 0,
        // sliikFee: { $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees)] }, 2] },
        // sliikFeeGST: { $sum: [{ $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees), "$GstInPer", 0.01] }, 2] }, { $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees), "$HstInPer", 0.01] }, 2] }] },
        // sliikFeePST: { $sum: [{ $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees), "$PstInPer", 0.01] }, 2] }, { $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees), "$QstInPer", 0.01] }, 2] }] },
        gstORhst: { $sum: [{ $round: [{ $multiply: ["$subTotal", "$GstInPer", 0.01] }, 2] }, { $round: [{ $multiply: ["$subTotal", "$HstInPer", 0.01] }, 2] }] },
        pstORqst: { $sum: [{ $round: [{ $multiply: ["$subTotal", "$PstInPer", 0.01] }, 2] }, { $round: [{ $multiply: ["$subTotal", "$QstInPer", 0.01] }, 2] }] },
        // discount: { $sum: "$discount" }
      }
    },
    {
      $group: {
        _id: null,
        totalSubTotal: { $sum: "$subTotal" },
        totalGSTORHST: { $sum: "$gstORhst" },
        totalPSTORQST: { $sum: "$pstORqst" },
        totalSliikFees: { $sum: "$sliikFee" },
        totalsliikFeeGST: { $sum: "$sliikFeeGST" },
        totalsliikFeePST: { $sum: "$sliikFeePST" },
        discount: { $sum: '$discount' }
      }
    }
  ]);

  if (productTransction?.length > 0) {
    productTransction[0].totalProductRevenue = productTransction[0].totalSliikFees + productTransction[0].totalsliikFeeGST + productTransction[0].totalsliikFeePST
  }

  // It returns total number of business (beauty services)
  const numberOfBusiness = await ServiceCategoryList.aggregate([

    {
      $lookup: {
        from: 'beauticianservices',
        localField: '_id',
        foreignField: "serviceCategory",
        as: 'serviceDetails',
        pipeline: [
          { $match: chartFilter },
        ]
      },
    },
    { $addFields: { services: { $size: "$serviceDetails" } } },
    { $project: { serviceDetails: 0, createdAt: 0, updatedAt: 0, __v: 0, imgPath: 0 } }
  ]);

  // It returns total number of products (beauty products)
  const numberOfProducts = await ProductCategoryList.aggregate([
    { $match: { status: 1 } },
    {
      $lookup: {
        from: 'beauticianproducts',
        localField: '_id',
        foreignField: "productCategory",
        as: 'productDetails',
        pipeline: [
          { $match: { status: 1 } },
          { $match: chartFilter },
        ]
      },
    },
    { $addFields: { productSales: { $size: "$productDetails" } } },
    { $project: { productDetails: 0, createdAt: 0, updatedAt: 0, __v: 0 } }
  ]);

  // It returns total number of gender (client wise)
  const Gender = await Client.aggregate([
    { $match: chartFilter },
    {
      $project: {
        Female: { $cond: [{ $eq: ["$gender", "Female"] }, 1, 0] },
        Male: { $cond: [{ $eq: ["$gender", "Male"] }, 1, 0] },
        Transgender: { $cond: [{ $eq: ["$gender", "Transgender"] }, 1, 0] },
        other: { $cond: [{ $eq: ["$gender", "other"] }, 1, 0] },
      },
    },
    {
      $group: {
        _id: null,
        Female: { $sum: "$Female" },
        Male: { $sum: "$Male" },
        Transgender: { $sum: "$Transgender" },
        Other: { $sum: "$Other" },
        total: { $sum: 1 }
      }
    },
  ]);

  // It returns age wise data (client wise)
  const ageRange = await Client.aggregate([
    { $match: chartFilter },
    {
      $addFields: {
        age: {
          $divide: [
            { $subtract: [new Date(), "$DOB"] },
            31557600000 // Number of milliseconds in a year (365.25 * 24 * 60 * 60 * 1000)
          ]
        }
      }
    },
    {
      $group: {
        _id: {
          $switch: {
            branches: [
              { case: { $and: [{ $gte: ["$age", 0] }, { $lt: ["$age", 18] }] }, then: "Less than 18" },
              { case: { $and: [{ $gte: ["$age", 18] }, { $lte: ["$age", 25] }] }, then: "18 - 25" },
              { case: { $and: [{ $gte: ["$age", 26] }, { $lte: ["$age", 30] }] }, then: "26 - 30" },
              { case: { $and: [{ $gte: ["$age", 31] }, { $lte: ["$age", 40] }] }, then: "31 - 40" },
              { case: { $and: [{ $gte: ["$age", 41] }, { $lte: ["$age", 50] }] }, then: "41 - 50" },
              { case: { $gte: ["$age", 50] }, then: "50+" }
            ],
            default: "Unknown"
          }
        },
        count: { $sum: 1 }
      }
    },
    {
      $group: {
        _id: null,
        ageRange: {
          $push: {
            _id: "$_id",
            count: "$count"
          }
        }
      }
    },
    {
      $unwind: "$ageRange"
    },
    {
      $group: {
        _id: "$ageRange._id",
        count: { $sum: "$ageRange.count" }
      }
    },
    {
      $group: {
        _id: null,
        ageRange: { $push: { _id: "$_id", count: "$count" } }
      }
    },
    {
      $unwind: "$ageRange"
    },
    {
      $replaceRoot: { newRoot: "$ageRange" }
    }
  ]);

  // It returns province wise data (client wise)
  const provinceRange = await Client.aggregate([

    {
      $lookup: {
        from: 'addresses',
        localField: 'address.addressId',
        foreignField: "_id",
        as: 'addDetails',
        pipeline: [{ $match: chartFilter }]
      },
    },
    {
      $lookup: {
        from: 'provinces',
        localField: 'addDetails.province',
        foreignField: "_id",
        as: 'proDetails',
        pipeline: [
          {
            $project: { name: 1, name_fr: 1, colorCode: 1 }
          }
        ]

      },
    },
    {
      $project: {
        proDetails: {
          $first: '$proDetails'
        },
        addDetails: { $first: '$addDetails' }
      }
    },
    {
      $group: {
        _id: null,
        proDetails: { $push: '$proDetails' },
        addDetails: { $push: '$addDetails' }
      }
    },
    { $project: { provinceDetails: 0, createdAt: 0, updatedAt: 0, __v: 0, imgPath: 0, subType: 0 } }
  ]);

  const provinceDetails = await Province.find({ status: 1 }).select('name colorCode').lean();

  provinceRange[0]?.proDetails?.forEach(ele => {
    const address = provinceRange[0].addDetails.filter(addEle => {
      return addEle.province.equals(ele._id)
    });
    let tempData = {};
    tempData.id = ele._id;
    tempData.name = ele.name;
    tempData.colorCode = ele.colorCode;

    tempData.count = address.length;

    let isalredypushed = provinceData.filter(newTemp => { return newTemp.name === tempData.name })
    if (!isalredypushed.length) provinceData.push(tempData);
  });

  provinceDetails?.forEach((val) => {
    val.count = 0
    if (provinceData) {
      provinceData?.forEach((ele) => {
        if (ele.name === val.name) {
          val.count = ele.count;
        }
      })
    }
  });
  provinceData = provinceDetails;

  // It returns app downloads ios and play store
  await import('google-play-scraper').then(async (val) => {

    await val?.default?.app({ appId: AppId })
      .then(appInfo => {
        totalPlayStoreDownloads = appInfo?.minInstalls;
      })
      .catch(error => {
        console.error('Error:', error);
      })
  });
  try {
    const appInfo = await appStore.app({ id: AppStoreId });
    totalAppStoreDownloads = appInfo.score;
  } catch (error) { }


  if (numberOfBusiness?.length) {
    numberOfBusiness.forEach(val => {
      totalNumberofBusiness += val.services;
    })
  }

  if (numberOfProducts?.length) {
    numberOfProducts?.forEach((val) => {
      totalNumberofProductSales += val.productSales
    })
  }
  return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, productTransction, totalPlayStoreDownloads, totalAppStoreDownloads, provinceData, serviceTransction, ageRange, Gender, totalNumberofBusiness, numberOfBusiness, totalNumberofProductSales, numberOfProducts, })
});

//admin panel dashboard bar chart
//chart 1
const getPeriodicBusinessBarChart = catchAsyncError(async (req, res, next) => {
  const { year } = req.query;
  const appointments = await Appointment.aggregate([
    { $match: { step: 2, status: { $ne: 0 } } }
  ]);

  const orderData = await Order.aggregate([
    { $match: { paymentStatus: 1 } }
  ]);

  if (appointments.length || orderData.length) {
    const currentYear = year || moment().year();
    let servicesValue = [], productValue = [], brandValue = [];
    for (let month = 0; month < 12; month++) {
      const startDate = moment().year(currentYear).month(month).startOf('month').format('YYYY-MM-DD');
      const endDate = moment().year(currentYear).month(month).endOf('month').format('YYYY-MM-DD');

      // Filter appointments within the current month
      const appointmentsData = appointments.filter(ele => {
        let formateDate = moment(ele.dateTime).format("YYYY-MM-DD")
        return formateDate >= startDate && formateDate <= endDate
      });

      // filter orders within the current month
      const orderCount = orderData.filter((val) => {
        let formateDate = moment(val.createdAt).format("YYYY-MM-DD")
        return formateDate >= startDate && formateDate <= endDate
      })

      // Count the appointments for the current month
      const count = appointmentsData.length;
      const productCount = orderCount.length;
      // Store the count in the servicesValue array
      servicesValue.push(count);
      productValue.push(productCount);
    }

    const responseData = monthCounts.map((ele, i) => {
      return {
        month: ele,
        services: servicesValue[i],
        product: productValue[i] || 0,
        brand: brandValue[i] || 0
      }
    });
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: responseData })
  }

});
//chart 2
const getRegisteredBarChart = catchAsyncError(async (req, res, next) => {
  const { year } = req.query;
  const currentYear = year || moment().year();
  let servicesValue = [], productValue = [], brandValue = [];
  for (let month = 0; month < 12; month++) {
    const startDate = moment().year(currentYear).month(month).startOf('month');
    const endDate = moment().year(currentYear).month(month).endOf('month');

    //for registered service
    const serviceList = await BeauticianService.find({
      createdAt: { $gte: startDate, $lte: endDate }
    });

    // for registred product
    const productList = await BeauticianProdduct.find({
      createdAt: { $gte: startDate, $lte: endDate }
    });

    // for registred brand
    const BrandList = await Brand.find({
      step: 3,
      createdAt: { $gte: startDate, $lte: endDate }
    });

    const count = serviceList.length;
    const productCount = productList.length;
    const brandCount = BrandList.length;
    // Store the count in the servicesValue array
    servicesValue.push(count);
    productValue.push(productCount);
    brandValue.push(brandCount);
  }

  const responseData = monthCounts.map((ele, i) => {
    return {
      month: ele,
      services: servicesValue[i],
      product: productValue[i] || 0,
      brand: brandValue[i] || 0
    }
  });
  return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: responseData })

});
//chart 3 Financial
const getPeriodicFinancialBarChart = catchAsyncError(async (req, res, next) => {
  const { year } = req.query;
  const currentYear = year || moment().year();
  let servicesValue = [], productValue = [];
  for (let month = 0; month < 12; month++) {
    const startDate = moment().year(currentYear).month(month).startOf('month').toDate();
    const endDate = moment().year(currentYear).month(month).endOf('month').toDate();

    //for registered service
    const serviceList = await Payment.aggregate([
      {
        $match: {
          paymentStatus: 1,
          createdAt: { $gte: startDate, $lte: endDate }
        }
      },
      {
        $addFields: {
          sliikFee: 0,
          // sliikFee: { $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees)] }, 2] },
          sliikFeeGST: 0,
          sliikFeePST: 0,
          // sliikFeeGST: { $sum: [{ $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees), "$GstInPer", 0.01] }, 2] }, { $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees), "$HstInPer", 0.01] }, 2] }] },
          // sliikFeePST: { $sum: [{ $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees), "$PstInPer", 0.01] }, 2] }, { $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees), "$QstInPer", 0.01] }, 2] }] },
          gstORhst: { $sum: [{ $round: [{ $multiply: ["$subTotal", "$GstInPer", 0.01] }, 2] }, { $round: [{ $multiply: ["$subTotal", "$HstInPer", 0.01] }, 2] }] },
          gstORhst: { $sum: [{ $round: [{ $multiply: ["$subTotal", "$PstInPer", 0.01] }, 2] }, { $round: [{ $multiply: ["$subTotal", "$QstInPer", 0.01] }, 2] }] },

          discount: { $round: [{ $multiply: ["$subTotal", "$discount", 0.01] }, 2] }
        }
      },
      {
        $group: {
          _id: null,
          totalSubTotal: { $sum: "$subTotal" },
          totalGSTORHST: { $sum: "$gstORhst" },
          totalPSTORQST: { $sum: "$pstORqst" },
          totalSliikFees: { $sum: "$sliikFee" },
          totalsliikFeeGST: { $sum: "$sliikFeeGST" },
          totalsliikFeePST: { $sum: "$sliikFeePST" },
          discount: { $sum: '$discount' }
        }
      }
    ]);
    let value = serviceList?.[0]
    if (value) {
      const totalRevenue = value.totalSubTotal + value.totalGSTORHST + value.totalPSTORQST - value.discount - value.totalSliikFees;
      // Store the count in the servicesValue array
      servicesValue.push(totalRevenue.toFixed(2));
    } else {
      servicesValue.push(0)
    }

    // for product finacial summary
    const productList = await Order.aggregate([
      {
        $match:
        {
          paymentStatus: 1,
          createdAt: { $gte: startDate, $lte: endDate }
        }
      },
      {
        $addFields: {
          sliikFee: 0,
          // sliikFee: { $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees)] }, 2] },
          sliikFeeGST: 0,
          sliikFeePST: 0,
          // sliikFeeGST: { $sum: [{ $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees), "$GstInPer", 0.01] }, 2] }, { $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees), "$HstInPer", 0.01] }, 2] }] },
          // sliikFeePST: { $sum: [{ $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees), "$PstInPer", 0.01] }, 2] }, { $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees), "$QstInPer", 0.01] }, 2] }] },
          gstORhst: { $sum: [{ $round: [{ $multiply: ["$subTotal", "$GstInPer", 0.01] }, 2] }, { $round: [{ $multiply: ["$subTotal", "$HstInPer", 0.01] }, 2] }] },
          gstORhst: { $sum: [{ $round: [{ $multiply: ["$subTotal", "$PstInPer", 0.01] }, 2] }, { $round: [{ $multiply: ["$subTotal", "$QstInPer", 0.01] }, 2] }] },

          // discount: { $round: [{ $multiply: ["$subTotal", "$discount", 0.01] }, 2] }
        }
      },
      {
        $group: {
          _id: null,
          totalSubTotal: { $sum: "$subTotal" },
          totalGSTORHST: { $sum: "$gstORhst" },
          totalPSTORQST: { $sum: "$pstORqst" },
          totalSliikFees: { $sum: "$sliikFee" },
          totalsliikFeeGST: { $sum: "$sliikFeeGST" },
          totalsliikFeePST: { $sum: "$sliikFeePST" },
          discount: { $sum: '$discount' }
        }
      }
    ]);

    let tempvalue = productList?.[0]
    if (tempvalue) {
      const totalRevenue = tempvalue.totalSubTotal + tempvalue.totalGSTORHST + tempvalue.totalPSTORQST - tempvalue.discount - tempvalue.totalSliikFees;
      productValue.push(totalRevenue.toFixed(2));
    } else {
      productValue.push(0);
    }
  }

  const responseData = monthCounts.map((ele, i) => {
    return {
      month: ele,
      services: servicesValue[i],
      product: productValue[i] || 0,
    }
  });
  return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: responseData })
})
//chart 4 and 5 active and inactive
const getActiveInactiveData = catchAsyncError(async (req, res, next) => {
  const { type } = req.params;
  const { year } = req.query;
  const chartForYear = year || moment().format("YYYY");
  const startOfYear = moment(chartForYear, 'YYYY').startOf('year').toDate();
  const endOfYear = moment(chartForYear, 'YYYY').endOf('year').toDate();
  let dataList = [];

  if (type === "client") {
    dataList = await User.aggregate([
      {
        $facet: {
          activate: [
            {
              $match: {
                activateAsUserDate: {
                  $gte: startOfYear,
                  $lte: endOfYear
                }
              }
            }
          ],
          deactivate: [
            {
              $match: {
                inActivateUserDate: {
                  $gte: startOfYear,
                  $lte: endOfYear
                }
              }
            }
          ]
        }
      }
    ]);

  } else if (type === "beautician") {
    dataList = await User.aggregate([
      {
        $facet: {
          activate: [
            {
              $match: {
                activateAsBeauticianDate: {
                  $gte: startOfYear,
                  $lte: endOfYear
                }
              }
            }
          ],
          deactivate: [
            {
              $match: {
                inActivateBeauticianDate: {
                  $gte: startOfYear,
                  $lte: endOfYear
                }
              }
            }
          ]
        }
      }
    ]);
  } else {
    throw new ErrorHandler("page not found on server", HttpStatus.NOT_FOUND, false);
  }
  let monthCount = []
  if (dataList.length) {
    const currentYear = chartForYear || moment().year();
    for (let month = 0; month < 12; month++) {
      const startDate = moment().year(currentYear).month(month).startOf('month').format('YYYY-MM-DD');
      const endDate = moment().year(currentYear).month(month).endOf('month').format('YYYY-MM-DD');
      // Filter PaymentList within the current month
      const activated = dataList[0].activate.filter(ele => {
        let formateDate = moment(ele.activateAsUserDate).format("YYYY-MM-DD")
        return formateDate >= startDate && formateDate <= endDate
      })
      const deActivated = dataList[0].deactivate.filter(ele => {
        let formateDate = moment(ele.inActivateUserDate).format("YYYY-MM-DD")
        return formateDate >= startDate && formateDate <= endDate
      })
      // Store the count in the monthCount array
      monthCount.push({ month: monthCounts[month], activate: activated.length, deActivate: deActivated.length });
    }
  }
  return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: monthCount })
});
module.exports = { getSingleAdmin, updateAdminProfile, changePasswordAdmin, dashbordSummary, getPeriodicBusinessBarChart, getRegisteredBarChart, getPeriodicFinancialBarChart, getActiveInactiveData }