const catchAsyncError = require("../../middleware/catchAsyncError");
const Province = require("../../models/Province");
const ErrorHandler = require("../../utils/ErrorHandling");
const HttpStatus = require("../../utils/HttpStatus");
const mongoose = require("mongoose")

const addProvince = catchAsyncError(async (req, res, next) => {
    const { name, name_fr, subType, colorCode, language } = req.body;
    let tempLanguage = "en"
    if (language === "en" || language === "fr") {
        tempLanguage = language;
    }

    const provinceData = await Province.findOne({ name: name, name_fr: name_fr, status: 1 });
    if (provinceData) {
        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "This province already added" });
    }

    if (subType && colorCode) {
        await Province.create({ name, name_fr: name_fr, subType, colorCode, language: tempLanguage });
        return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, message: "Province added successfully." });
    } else {
        throw new ErrorHandler("Subtype and colorCode are required", HttpStatus.BAD_REQUEST, false)
    }
});
const getProvinceList = catchAsyncError(async (req, res, next) => {
    const language = req.get('Accept-Language') || "en";
    const provinceList = await Province.find({ status: 1 }).select("-createdAt -updatedAt -__v").sort({ name: 1 });
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: provinceList, message: "Province List" });
});

const updateProvinceList = catchAsyncError(async (req, res, next) => {
    const { ProvinceId, name, name_fr, subType, colorCode } = req.body;
    if (!ProvinceId) {
        throw new ErrorHandler("Please enter Province id", HttpStatus.BAD_REQUEST, false)
    }
    const provinceData = await Province.findOne({ _id: ProvinceId });
    if (!provinceData) {
        throw new ErrorHandler("Province not found", HttpStatus.BAD_REQUEST, false)
    }
    if (subType && name) {
        let updateValue = { subType };
        if (colorCode) updateValue.colorCode = colorCode;
        const updatedValue = await Province.findOneAndUpdate({ _id: ProvinceId, name, name_fr: name_fr, }, updateValue, { new: true });
        if (updatedValue) {
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Province updated successfully." });
        }
        else { new ErrorHandler("Something went wrong : Name is not found.", HttpStatus.BAD_REQUEST, false) }
    } else {
        throw new ErrorHandler("SubTypes or name is not found", HttpStatus.BAD_REQUEST, false)
    }
});

const deleteProvince = catchAsyncError(async (req, res, next) => {
    const { provinceId } = req.body;

    if (mongoose.Types.ObjectId.isValid(provinceId)) {
        const provinceData = await Province.findOne({ _id: provinceId, status: 1 });

        if (provinceData) {
            provinceData.status = 0;
            await provinceData.save();
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Province deleted successfully" });
        } else {
            throw new ErrorHandler("Province not found", HttpStatus.BAD_REQUEST, false)
        }
    } else {
        throw new ErrorHandler("Please enter valid province Id", HttpStatus.BAD_REQUEST, false)
    }
});

module.exports = { addProvince, getProvinceList, updateProvinceList, deleteProvince }
