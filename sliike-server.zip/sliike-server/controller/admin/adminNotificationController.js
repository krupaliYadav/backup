const { validationResult } = require("express-validator");
const catchAsyncError = require("../../middleware/catchAsyncError");
const AdminNotification = require("../../models/AdminNotification");
const ErrorHandler = require("../../utils/ErrorHandling");
const HttpStatus = require("../../utils/HttpStatus");
const FcmNotification = require("../../models/FcmNotification");
const { fcmNotification } = require("../../utils/fcmNotification");
const { default: mongoose } = require("mongoose");
const Beautician = require("../../models/Beautician");
const Client = require("../../models/Client");
const Discount = require("../../models/Discount");

// Push notification to particular beautican or client
const addNotification = catchAsyncError(async (req, res, next) => {
    const { sendTo, title, message } = req.body;

    const errors = validationResult(req);
    if (errors.errors.length !== 0) {
        throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST);
    };

    if (sendTo !== "Beautician" && sendTo !== "Client") {
        throw new ErrorHandler("Please enter beautician or client for send to", HttpStatus.BAD_REQUEST, false)
    } else {
        await AdminNotification.create({
            sendTo, title, message
        });

        const deviceData = await FcmNotification.aggregate([
            { $match: { member_type: sendTo } }
        ]);

        if (deviceData.length > 0) {
            deviceData.map(async (val) => {
                const messageCtx = {
                    title: title,
                    message: message,
                    content: 'ADMIN_NOTFICATION'
                }
                if (val.firebaseToken) {
                    let deviceIds = [];
                    deviceIds.push(val.firebaseToken);
                    const notifications = await fcmNotification({ messageCtx: messageCtx, deviceIds });
                    await Promise.all([notifications]);
                }
            });
        }
        return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, message: "Notifican sended successfully" });
    }
});

// Get all Notification list
const getNotifications = catchAsyncError(async (req, res, next) => {
    const { type, limit, offset, startDate, endDate } = req.body;

    const limitData = parseInt(limit, 10) || 10;
    const offsetData = parseInt(offset, 10) || 0;

    if (!type) {
        throw new ErrorHandler("Please Enter type for get notification", HttpStatus.BAD_REQUEST);
    }

    if (type !== "Beautician" && type !== "Client") {
        throw new ErrorHandler("Please Enter Beautician or Client", HttpStatus.BAD_REQUEST);
    }
    let dateFilter = {};
    if (type) {
        dateFilter = {
            sendTo: type
        };
    }
    if (startDate && endDate) {
        if (startDate !== "" && endDate !== "") {
            dateFilter = {
                ...dateFilter,
                $expr: {
                    $and: [
                        {
                            $gte: [
                                { $toDate: '$createdAt' },
                                { $toDate: startDate }
                            ]
                        },
                        {
                            $lte: [
                                { $toDate: '$createdAt' },
                                { $toDate: endDate }
                            ]
                        }
                    ]
                },
            }
        }
    }

    let notificationData = await AdminNotification.aggregate([
        { $match: dateFilter },
        { $sort: { createdAt: -1 } }
    ]);

    const count = notificationData.length;
    notificationData = notificationData.slice(offsetData, offsetData + limitData);

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { count, notificationData } });
});

// Update Notification 
const updateNotification = catchAsyncError(async (req, res, next) => {
    const { Id, sendTo, title, message } = req.body;

    if (!Id) {
        throw new ErrorHandler("Please Enter valid Id", HttpStatus.BAD_REQUEST);
    }

    if (!new mongoose.Types.ObjectId(Id)) {
        throw new ErrorHandler("Please Enter valid Id", HttpStatus.BAD_REQUEST);
    }

    if (sendTo !== "Beautician" && sendTo !== "Client") {
        throw new ErrorHandler("Please enter beautician or client for send to", HttpStatus.BAD_REQUEST, false)
    } else {
        const data = await AdminNotification.findOne({ _id: Id });
        if (data) {
            data.sendTo = sendTo;
            data.title = title;
            data.message = message;
            await data.save();

            const deviceData = await FcmNotification.aggregate([
                { $match: { member_type: sendTo } }
            ]);

            if (deviceData.length > 0) {
                deviceData.map(async (val) => {
                    const messageCtx = {
                        title: title,
                        message: message,
                        content: 'ADMIN_NOTFICATION'
                    }
                    if (val.firebaseToken) {
                        let deviceIds = [];
                        deviceIds.push(val.firebaseToken);
                        const notifications = fcmNotification({ messageCtx: messageCtx, deviceIds });
                        await Promise.all([notifications]);
                    }
                });
            }

            return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, message: "Notifican updated successfully" });
        } else {
            throw new ErrorHandler("Notification Deatils not found", HttpStatus.BAD_REQUEST, false)
        }
    }
});

// This for Journy list
const getUserJourneyList = catchAsyncError(async (req, res, next) => {
    const { Id, type, limit, offset } = req.query;
    const limitData = parseInt(limit, 10) || 10;
    const offsetData = parseInt(offset, 10) || 0;

    if (type !== "Beautician" && type !== "Client") throw new ErrorHandler("Please Enter Beautician or User type", HttpStatus.BAD_REQUEST);

    if (type === "Beautician") {

        let journeyData = await Beautician.aggregate([
            {
                $lookup: {
                    from: 'invitedclients',
                    localField: '_id',
                    foreignField: "beauticianId",
                    as: 'InvitedClient',
                },
            },
            {
                $addFields: {
                    serviceCount: {
                        $size: "$beauticianServiceId"
                    }
                }
            },
            {
                $addFields: {
                    countInvitaion: {
                        $size: "$InvitedClient"
                    }
                }
            },
            { $sort: { createdAt: -1 } },
            {
                $project: {
                    stripe_id: {
                        $ifNull: ["$stripe_id", null]
                    },
                    taxProvinceDetails: {
                        $ifNull: ["$taxProvinceDetails", null]
                    },
                    logo: {
                        $ifNull: ["$logo", null]
                    },
                    profileImage: {
                        $ifNull: ["$profileImage", null]
                    },
                    uid: 1, businessName: 1, screenStatus: 1, isLicensed: 1, countInvitaion: 1, serviceCount: 1,
                }
            }
        ]);

        const count = journeyData.length;
        journeyData = journeyData.slice(offsetData, limitData + offsetData);
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { count, journeyData } });

    } else if (type === "Client") {

        let journeyData = await Client.aggregate([
            {
                $lookup: {
                    from: 'beautician',
                    localField: '_id',
                    foreignField: "beauticianId",
                    as: 'InvitedClient',
                },
            },
            {
                $addFields: {
                    addressValue: {
                        $size: "$address"
                    }
                }
            },
            {
                $lookup: {
                    from: 'appointments',
                    localField: '_id',
                    foreignField: "clientId",
                    as: 'appoimentDetails',
                    pipeline: [
                        { $project: { status: 1, serviceId: 1 } },
                        { $match: { status: 5 } }
                    ]
                },
            },
            {
                $lookup: {
                    from: 'beauticianservices',
                    localField: 'appoimentDetails.serviceId',
                    foreignField: "_id",
                    as: 'serviceDetails',
                    pipeline: [
                        { $project: { serviceType: 1 } }
                    ]
                },
            },
            {
                $lookup: {
                    from: 'servicetypelists',
                    localField: 'serviceDetails.serviceType',
                    foreignField: "_id",
                    as: 'serviceType',
                    pipeline: [
                        { $project: { serviceTypeName: 1, serviceTypeName_fr: 1 } }
                    ]
                },
            },
            { $sort: { createdAt: -1 } },
            {
                $project: {
                    DOB: {
                        $ifNull: ["$DOB", null]
                    },
                    gender: {
                        $ifNull: ["$gender", null]
                    },
                    profileImage: {
                        $ifNull: ["$profileImage", null]
                    },
                    uid: 1, firstName: 1, lastName: 1, addressValue: 1, unSuccessfulSearch: 1, serviceType: 1
                }
            },
        ]);

        const count = journeyData.length;
        journeyData = journeyData.slice(offsetData, limitData + offsetData);
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { count, journeyData } });
    } else {
        throw new ErrorHandler("Please Enter Beautician or User type", HttpStatus.BAD_REQUEST);
    }
});

// This for get all User and Beautician data
const getAllData = catchAsyncError(async (req, res, next) => {
    const { type, offset, limit } = req.query;
    const limitData = parseInt(limit, 10) || 10;
    const offsetData = parseInt(offset, 10) || 0;

    if (type === "Beautician") {
        let allData = await Beautician.aggregate([
            {
                $lookup: {
                    from: 'users',
                    localField: 'userId',
                    foreignField: "_id",
                    as: 'userDeatils',
                    pipeline: [
                        { $project: { email: 1, phoneNumber: 1, createdAt: 1 } }
                    ]
                },
            },
            {
                $lookup: {
                    from: 'addresses',
                    localField: 'address',
                    foreignField: "_id",
                    as: 'addressDeatils',
                    pipeline: [
                        { $project: { address: 1, street: 1, apartment: 1, city: 1, zipCode: 1, province: 1 } }
                    ]
                },
            },
            {
                $lookup: {
                    from: 'provinces',
                    localField: 'addressDeatils.province',
                    foreignField: "_id",
                    as: 'provinceDetails',
                    pipeline: [
                        { $project: { name: 1, name_fr: 1 } }
                    ]
                },
            },
            {
                $lookup: {
                    from: 'beauticianservices',
                    localField: 'beauticianServiceId',
                    foreignField: "_id",
                    as: 'serviceDetails',
                    pipeline: [
                        { $project: { serviceCategory: 1, serviceType: 1 } }
                    ]
                },
            },
            {
                $lookup: {
                    from: 'servicecategorylists',
                    localField: 'serviceDetails.serviceCategory',
                    foreignField: "_id",
                    as: 'categoryDetails',
                    pipeline: [
                        { $project: { serviceCategoryName: 1, serviceCategoryName_fr: 1, } }
                    ]
                },
            },
            {
                $lookup: {
                    from: 'servicetypelists',
                    localField: 'serviceDetails.serviceType',
                    foreignField: "_id",
                    as: 'typeDetails',
                    pipeline: [
                        { $project: { serviceTypeName: 1, serviceTypeName_fr: 1 } }
                    ]
                },
            },
            {
                $lookup: {
                    from: 'invitedclients',
                    localField: '_id',
                    foreignField: "beauticianId",
                    as: 'clientDetails',
                },
            },

            {
                $addFields: {
                    numOfService: {
                        $size: "$beauticianServiceId"
                    }
                }
            },
            {
                $addFields: {
                    numOfClient: {
                        $size: "$clientDetails"
                    }
                }
            },
            {
                $project: {
                    uid: 1, firstName: 1, lastName: 1, country: 1, country_code: 1, beauticianServiceId: 1, isProvideService: 1, isProvideProduct: 1,
                    businessName: {
                        $ifNull: ["$businessName", null]
                    },
                    gender: {
                        $ifNull: ["$gender", null]
                    },
                    taxProvinceDetails: {
                        $ifNull: ["$taxProvinceDetails", null]
                    },
                    GSTNumber: {
                        $ifNull: ["$taxProvinceDetails.GSTNumber", null]
                    },
                    PSTNumber: {
                        $ifNull: ["$taxProvinceDetails.PSTNumber", null]
                    },
                    HSTNumber: {
                        $ifNull: ["$taxProvinceDetails.HSTNumber", null]
                    },
                    QSTNumber: {
                        $ifNull: ["$taxProvinceDetails.QSTNumber", null]
                    },
                    hasShop: 1, isLicensed: 1, screenStatus: 1, createdAt: 1, businessNumber: 1, stripe_id: 1, logo: 1,
                    userDeatils: 1, addressDeatils: 1, categoryDetails: 1, typeDetails: 1, appoiemntDetails: 1, numOfClient: 1, provinceDetails: 1, numOfService: 1,
                }
            }
        ]);

        const count = allData.length;
        allData = allData.slice(offsetData, offsetData + limitData);
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { count, allData } });
    } else if (type === "Client") {
        let allData = await Client.aggregate([
            {
                $lookup: {
                    from: 'users',
                    localField: 'userId',
                    foreignField: "_id",
                    as: 'userDeatils',
                    pipeline: [
                        { $project: { email: 1, phoneNumber: 1, createdAt: 1 } }
                    ]
                },
            },
            {
                $lookup: {
                    from: 'addresses',
                    let: { address: '$address' },
                    pipeline: [
                        { $match: { $expr: { $in: ['$_id', '$$address.addressId'] } } },
                        { $project: { _id: 0, createdAt: 0, updatedAt: 0, __v: 0 } },
                    ],
                    as: 'addressDetails'
                },
            },
            {
                $lookup: {
                    from: 'provinces',
                    localField: 'addressDetails.province',
                    foreignField: "_id",
                    as: 'provinceDeatils',
                    pipeline: [
                        { $project: { name: 1, name_fr: 1, } }
                    ]
                },
            },
            {
                $lookup: {
                    from: 'appointments',
                    localField: '_id',
                    foreignField: "clientId",
                    as: 'appoimentDetails',
                    pipeline: [
                        { $project: { status: 1 } }
                    ]
                },
            },
            {
                $addFields: {
                    numOfServiceBooked: {
                        $size: "$appoimentDetails"
                    }
                }
            },
            {
                $project: {
                    userId: 1, uid: 1, createdAt: 1, firstName: 1, lastName: 1, country: 1,
                    profileImage: {
                        $ifNull: ["$profileImage", null]
                    },
                    DOB: {
                        $ifNull: ["$DOB", null]
                    },
                    gender: {
                        $ifNull: ["$gender", null]
                    },
                    userDeatils: 1, addressDetails: 1, provinceDeatils: 1, numOfServiceBooked: 1,
                }
            }
        ]);
        const count = allData.length;
        allData = allData.slice(offsetData, offsetData + limitData);
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { count, allData } });
    } else {
        throw new ErrorHandler("Please Enter Beautician or User type", HttpStatus.BAD_REQUEST);
    }
});

// This for get client list for promotion
const getClientList = catchAsyncError(async (req, res, next) => {
    const { search } = req.query;
    let searchQuery = {};

    if (search) {
        if (search !== "") {
            searchQuery = {
                $or: [
                    { firstName: { $regex: search, $options: 'i' } },
                    { lastName: { $regex: search, $options: 'i' } },
                ]
            }
        }
    }

    const clientData = await Client.aggregate([
        {
            $match: searchQuery
        },
        { $project: { firstName: 1, lastName: 1 } }
    ]);
    let count = 0;
    if (clientData.length) {
        count = clientData.length;
    }
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { count, clientData } });
});

// This for add discount for particular client
const addDiscount = catchAsyncError(async (req, res, next) => {
    const { clientIds, promotionTitle, description, isDiscPercentage, discount, startDate, endDate, discountCode } = req.body;

    const errors = validationResult(req);
    if (errors.errors.length !== 0) {
        throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST);
    };

    // This is for check entered client's Id is valid and exists
    if (clientIds.length) {
        const isValidIDs = clientIds.some(id => !mongoose.Types.ObjectId.isValid(id));
        if (isValidIDs) {
            throw new ErrorHandler("Please Enter valid client Id", HttpStatus.BAD_REQUEST);
        }
        const clientId = await Promise.all(clientIds.map(async (val) => {
            const clientData = await Client.findOne({ _id: val });
            if (!clientData) {
                return false
            }
        }));
        if (clientId.includes(false)) {
            throw new ErrorHandler("Client Details not founded", HttpStatus.BAD_REQUEST);
        }
    } else {
        throw new ErrorHandler("Please Enter client Ids", HttpStatus.BAD_REQUEST);
    }

    // This is for check titleName is alreday exists
    const isNameExists = await Discount.findOne({ promotionTitle, });
    if (isNameExists) {
        throw new ErrorHandler("Discount Title already exists.", HttpStatus.BAD_REQUEST, false)
    }

    // This is check for end date is not bigger than start date
    if (endDate < startDate) {
        throw new ErrorHandler("end date is greater than start date", HttpStatus.BAD_REQUEST);
    }

    // This is for check is discount percentage
    if (isDiscPercentage != 0 && isDiscPercentage != 1) {
        throw new ErrorHandler("Please Enter valid Discount type", HttpStatus.BAD_REQUEST);
    }

    const clientId = clientIds.map(id => new mongoose.Types.ObjectId(id));
    const discountData = await Discount.aggregate([
        {
            $match: {
                $and: [
                    { clientIds: { $in: clientId } },
                    { startDate: new Date(startDate) },
                    { endDate: new Date(endDate) }
                ]
            }
        }
    ]);

    if (discountData.length) {
        throw new ErrorHandler("For this client discount alreday added at this time", HttpStatus.BAD_REQUEST);
    }

    if (isDiscPercentage == 1) {
        if (discount >= 99) {
            throw new ErrorHandler("Please enter valid discount percentage", HttpStatus.BAD_REQUEST);
        }
    }

    await Discount.create({
        clientIds, promotionTitle, description, isDiscPercentage, discount, startDate, endDate, discountCode
    });
    return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, message: "Discount added successfully" });
});

// This for get all discount details
const getDiscountList = catchAsyncError(async (req, res, next) => {
    const { startDate, endDate } = req.query;

    let dateFilter = {}
    if (startDate && endDate) {
        if (startDate !== "" && endDate !== "") {
            dateFilter = {
                ...dateFilter,
                $expr: {
                    $and: [
                        {
                            $gte: [
                                { $toDate: '$createdAt' },
                                { $toDate: startDate }
                            ]
                        },
                        {
                            $lte: [
                                { $toDate: '$createdAt' },
                                { $toDate: endDate }
                            ]
                        }
                    ]
                },
            }
        }
    }
    const discountData = await Discount.aggregate([
        { $match: dateFilter },
        {
            $lookup: {
                from: 'clients',
                localField: 'clientIds',
                foreignField: "_id",
                as: 'clientDetails',
                pipeline: [
                    { $project: { firstName: 1, lastName: 1 } }
                ]
            },
        },
        { $project: { __v: 0, updatedAt: 0 } }
    ]);

    let count = 0;
    if (discountData.length) {
        count = discountData.length;
    }
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { count, discountData } });
});

module.exports = { addNotification, getNotifications, updateNotification, getUserJourneyList, getAllData, getClientList, addDiscount, getDiscountList }