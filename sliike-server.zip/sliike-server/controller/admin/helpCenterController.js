const catchAsyncError = require("../../middleware/catchAsyncError");
const Faq = require("../../models/Faq");
const FeedBack = require("../../models/FeedBack");
const ErrorHandler = require("../../utils/ErrorHandling");
const HttpStatus = require("../../utils/HttpStatus");
const Client = require("../../models/Client");
const Beautician = require("../../models/Beautician");
const HelpContactList = require("../../models/HelpContactList");
const User = require("../../models/User");
const { customerCare, addFeedbackMail } = require("../../utils/emailTeplates");



//FAQ section
const addFAQ = catchAsyncError(async (req, res, next) => {
    const { useFor, question, answer, faqId } = req.body;
    if (faqId) {
        const oldFAQData = await Faq.findOne({ _id: faqId, useFor });
        if (oldFAQData) {
            oldFAQData.question = question;
            oldFAQData.answer = answer;
            await oldFAQData.save();
            res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, message: "FAQ updated successfully." });
        } else {
            throw new ErrorHandler("FAQ is not found.", HttpStatus.BAD_REQUEST, false)
        }
    } else {
        await Faq.create({
            useFor,
            question,
            answer
        });
        res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, message: "FAQ added successfully." })
    }
});

const getFAQList = catchAsyncError(async (req, res, next) => {
    const { useFor } = req.params;
    const faqList = await Faq.find({ useFor: useFor }).select("-updatedAt -createdAt -__v");
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: faqList, message: "List of FAQ fetched." })
});
const deleteFAQ = catchAsyncError(async (req, res, next) => {
    const { faqId } = req.params;
    await Faq.deleteOne({ _id: faqId });
    return res.status(HttpStatus.DELETED).json({ status: HttpStatus.DELETED, success: true, message: "FAQ is deleted successfully." })
})

//feedback section 

const addFeedback = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const userData = await User.findOne({_id:id});
    const { useFor } = req.params;
    const { subject, description } = req.body;
    let member_type, memberId,firstName,lastName,email,phoneNumber;
    if (useFor === "client") {
        const isClient = await Client.findOne({ userId: id });
        if(isClient){
            memberId = isClient._id;
            member_type = "Client";
            firstName = isClient.firstName;
            lastName = isClient.lastName;
            email = userData.email;
            phoneNumber = userData.phoneNumber;
        }else{
            throw new ErrorHandler("Client Details not found", HttpStatus.BAD_REQUEST, false)
        }
    } else if (useFor === "beautician") {
        const isBeautician = await Beautician.findOne({ userId: id });
        if(isBeautician){
            memberId = isBeautician._id;
            member_type = "Beautician";
            firstName = isBeautician.firstName;
            lastName = isBeautician.lastName;
            email = userData.email;
            phoneNumber = userData.phoneNumber;
        }else{
            throw new ErrorHandler("Beautician Details not found", HttpStatus.BAD_REQUEST, false)
        }
    } else {
        throw new ErrorHandler("Page not found on server", HttpStatus.NOT_FOUND, false)
    }
    if (subject && description) {
        await FeedBack.create({
            member_type, memberId, subject, description
        });

        const emailDetails = {
            firstName,lastName,email,subject,description,phoneNumber
        }
        await addFeedbackMail(emailDetails);
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Feedback added successfully." })
    } else {
        throw new ErrorHandler("Subject or description is missing.", HttpStatus.BAD_REQUEST, false)
    }

});
const getFeedBackList = catchAsyncError(async (req, res, next) => {
    const { useFor } = req.params;
    let member_type, memberFrom
    if (useFor === 'client') {
        memberFrom = 'clients'
        member_type = 'Client'
    } else if (useFor === "beautician") {
        memberFrom = 'beauticians'
        member_type = 'Beautician'
    } else {
        throw new ErrorHandler("Page not found on server", HttpStatus.NOT_FOUND, false)
    }
    const feedBackList = await FeedBack.aggregate([
        { $match: { member_type: member_type } },
        {
            $lookup: {
                from: memberFrom,
                localField: 'memberId',
                foreignField: '_id',
                as: 'memberDetails',
                pipeline: [
                    { $project: { userId: 1, firstName: 1, lastName: 1, uid: 1 } }
                ]
            }
        },
        {
            $lookup: {
                from: 'users',
                localField: 'memberDetails.userId',
                foreignField: '_id',
                as: 'userData',
                pipeline: [
                    { $project: { email: 1, phoneNumber: 1 } }
                ]
            }
        },
        {
            $project: {
                subject: 1,
                description: 1,
                memberDetails: {
                    $arrayElemAt: [
                        {
                            $map: {
                                input: "$memberDetails",
                                as: "member",
                                in: {
                                    uid: "$$member.uid",
                                    firstName: "$$member.firstName",
                                    lastName: "$$member.lastName",
                                    email: { $arrayElemAt: ["$userData.email", 0] },
                                    phoneNumber: { $arrayElemAt: ["$userData.phoneNumber", 0] }
                                }
                            }
                        },
                        0
                    ]
                },
            }
        },
    ])
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: feedBackList })

});

// contact us section 
const getContactUserList = catchAsyncError(async (req, res, next) => {
    const { useFor } = req.params;
    let member_type, memberFrom
    if (useFor === 'client') {
        memberFrom = 'clients'
        member_type = 'Client'
    } else if (useFor === "beautician") {
        memberFrom = 'beauticians'
        member_type = 'Beautician'
    } else {
        throw new ErrorHandler("Page not found on server", HttpStatus.NOT_FOUND, false)
    }
    const data = await HelpContactList.aggregate([
        { $match: { member_type: member_type } },
        {
            $lookup: {
                from: memberFrom,
                localField: 'memberId',
                foreignField: '_id',
                as: 'memberDetails',
                pipeline: [
                    { $project: { userId: 1, firstName: 1, lastName: 1, uid: 1 } }
                ]
            }
        },
        {
            $lookup: {
                from: 'users',
                localField: 'memberDetails.userId',
                foreignField: '_id',
                as: 'userData',
                pipeline: [
                    { $project: { email: 1, phoneNumber: 1 } }
                ]
            }
        },
        {
            $project: {
                createdAt: 1,
                memberDetails: {
                    $arrayElemAt: [
                        {
                            $map: {
                                input: "$memberDetails",
                                as: "member",
                                in: {
                                    uid: "$$member.uid",
                                    firstName: "$$member.firstName",
                                    lastName: "$$member.lastName",
                                    email: { $arrayElemAt: ["$userData.email", 0] },
                                    phoneNumber: { $arrayElemAt: ["$userData.phoneNumber", 0] }
                                }
                            }
                        },
                        0
                    ]
                },
            }
        },
    ])
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data })

});

const addHelpContact = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { useFor } = req.params;
    let member_type, memberId;
    if (useFor === "client") {
        const isClient = await Client.findOne({ userId: id });
        memberId = isClient._id;
        member_type = "Client";
    } else if (useFor === "beautician") {
        const isBeautician = await Beautician.findOne({ userId: id });
        memberId = isBeautician._id;
        member_type = "Beautician";
    } else {
        throw new ErrorHandler("Page not found on server", HttpStatus.NOT_FOUND, false)
    }
    await HelpContactList.create({
        member_type, memberId
    });
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Thank you for reaching out!" })

});

const callToCustomerCare = catchAsyncError(async (req, res, next) => {
    const Id = req.user;
    const { useFor } = req.params;
    const userData = await User.findOne({ _id: Id });

    if (useFor === "beautician") {
        if (userData.isActiveBeautician == 1) {
            const beauticianData = await Beautician.findOne({ userId: Id }).populate({ path: 'userId', select: 'email phoneNumber' })

            const emailDetails = {
                firstName: beauticianData.firstName,
                lastName: beauticianData.lastName,
                email: beauticianData.userId.email,
                phoneNumber: beauticianData.userId.phoneNumber
            }
            await customerCare(emailDetails);
        } else {
            return res.status(HttpStatus.UNAUTHORIZED).json({ status: HttpStatus.UNAUTHORIZED, success: false, message: "You are Not authorized as beautician to send request." })
        }
    } else if (useFor === "client") {
        
        if (userData.isActiveUser == 1) {
            const clientData = await Client.findOne({ userId: Id }).populate({ path: 'userId', select: 'email phoneNumber' })

            const emailDetails = {
                firstName: clientData.firstName,
                lastName: clientData.lastName,
                email: clientData.userId.email,
                phoneNumber: clientData.userId.phoneNumber
            }
            await customerCare(emailDetails);
        } else {
            return res.status(HttpStatus.UNAUTHORIZED).json({ status: HttpStatus.UNAUTHORIZED, success: false, message: "You are Not authorized as client request." })
        }
    } else {
        throw new ErrorHandler("Please enter beautician or client for customer care", HttpStatus.NOT_FOUND, false)
    }
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Request sended successfully" });
})
module.exports = { addFAQ, getFAQList, deleteFAQ, addFeedback, getFeedBackList, getContactUserList, addHelpContact, callToCustomerCare }