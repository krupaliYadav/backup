const { validationResult } = require("express-validator");
const catchAsyncError = require("../../middleware/catchAsyncError");
const Beautician = require("../../models/Beautician");
const BeauticianWorkHour = require("../../models/BeauticianWorkHour");
const User = require("../../models/User");
const Client = require("../../models/Client");
const ErrorHandler = require("../../utils/ErrorHandling");
const HttpStatus = require("../../utils/HttpStatus");
const { default: mongoose } = require("mongoose");
const Appointment = require("../../models/Appointment");
const Invation = require("../../models/Invation");
const { sendInvtaionMail, sendBeauticainInvtaionMail } = require("../../utils/emailTeplates");
const { generateBeauticianId } = require("../../utils/generateNumericId");
const BookingSetting = require("../../models/BookingSetting");
const platform_fees = process.env.PLATFORM_FEES || 0.10;
const moment = require("moment");
const Address = require("../../models/Address");
const BeauticianService = require("../../models/BeauticianService");
const Province = require("../../models/Province");
const formidable = require("formidable");
const ValidationError = require("../../utils/validationError");
const ServiceCategoryList = require("../../models/ServiceCategoryList");
const ServiceTypeList = require("../../models/ServiceTypeList");
const { v4: uuidv4 } = require('uuid');
const { uploadFile } = require("../../libs/aws/uploadImg");
const { pathEndpoint } = require("../../utils/Constant");
const Order = require("../../models/Order");

// Change Status of Client and Beautician both
const changeStatus = catchAsyncError(async (req, res, next) => {
  const { Id, type, status } = req.body;

  if (!Id) {
    throw new ErrorHandler("Please Enter Id", HttpStatus.BAD_REQUEST);
  }

  if (status != 0 && status != 1) {
    throw new ErrorHandler("Please Enter valid status", HttpStatus.BAD_REQUEST);
  }

  if (type === "client") {
    const client = await Client.findOne({ _id: new mongoose.Types.ObjectId(Id) });
    if (!client) {
      throw new ErrorHandler("Client not found", HttpStatus.BAD_REQUEST);
    }
    const user = client.userId;
    let updateData = { isActiveUser: status }
    if (status === 0) { updateData.$set = { inActivateUserDate: new Date() } }
    if (status === 1) { updateData.$unset = { inActivateUserDate: 1 } }
    const data = await User.findByIdAndUpdate({ _id: user }, updateData);

  } else if (type === "beautician") {
    const beautician = await Beautician.findOne({ _id: new mongoose.Types.ObjectId(Id) });
    if (!beautician) {
      throw new ErrorHandler("Beautician not found", HttpStatus.BAD_REQUEST);
    }
    const user = beautician.userId;
    let updateData = { isActiveBeautician: status }
    if (status === 0) { updateData.$set = { inActivateBeauticianDate: new Date() } }
    if (status === 1) { updateData.$unset = { inActivateBeauticianDate: 1 } }
    const data = await User.findByIdAndUpdate({ _id: user }, updateData);
  } else {
    throw new ErrorHandler("Please Enter client or beautician type", HttpStatus.BAD_REQUEST);
  }

  return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Status change successfully" });
});

// Change Archiv for both client and beautician
const changeArchive = catchAsyncError(async (req, res, next) => {
  const { Id, type, isDeleted } = req.body;

  if (!Id) {
    throw new ErrorHandler("Please Enter Id", HttpStatus.BAD_REQUEST);
  }

  if (isDeleted != 0 && isDeleted != 1) {
    throw new ErrorHandler("Please Enter valid delete type", HttpStatus.BAD_REQUEST);
  }

  if (type === "client") {

    const client = await Client.findOne({ _id: new mongoose.Types.ObjectId(Id) });
    if (!client) {
      throw new ErrorHandler("Client not found", HttpStatus.BAD_REQUEST);
    }
    const data = await Client.findByIdAndUpdate({ _id: Id }, { isDeleted });

  } else if (type === "beautician") {
    const beautician = await Beautician.findOne({ _id: new mongoose.Types.ObjectId(Id) });
    if (!beautician) {
      throw new ErrorHandler("Beautician not found", HttpStatus.BAD_REQUEST);
    }
    const data = await Beautician.findByIdAndUpdate({ _id: Id }, { isDeleted });
  } else {
    throw new ErrorHandler("Please Enter client or beautician type", HttpStatus.BAD_REQUEST);
  }
  return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Change successfully" });

});

// add multiple beautician to archive and unarchive
const changeMultipleStatus = catchAsyncError(async (req, res, next) => {
  const { Ids, isDeleted } = req.body;
  if (isDeleted != 0 && isDeleted != 1) {
    throw new ErrorHandler("Please Enter valid delete type", HttpStatus.BAD_REQUEST);
  }
  if (Ids && Ids.length > 0) {
    await Beautician.updateMany(
      { _id: { $in: Ids } },
      { isDeleted }
    );
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Beautician deleted successfully" });
  } else {
    throw new ErrorHandler("Please Enter Ids in list.", HttpStatus.BAD_REQUEST);
  }
})
// Get All Beautician details
const getAllBeautician = catchAsyncError(async (req, res, next) => {

  const { search, limit, offset, type, status } = req.body;
  const limitData = parseInt(limit, 10) || 10;
  const offsetData = parseInt(offset, 10) || 0;

  let matchQuery = {};
  let statusQuery = {}

  if (parseInt(status) === 1) {
    statusQuery = {
      isActiveBeautician: 1
    }
  }

  if (parseInt(status) === 0) {
    statusQuery = {
      isActiveBeautician: 0
    }
  }

  if (!type) {
    matchQuery = { isDeleted: 0 };
  }
  if (type === "archive") {
    matchQuery = { isDeleted: 1 };
  }
  if (type === "unarchive") {
    matchQuery = { isDeleted: 0 };
  }

  if (search) {
    matchQuery.$or = [
      { businessName: { $regex: search, $options: 'i' } },
    ];
  }
  let tempData = [
    { $match: matchQuery },
    {
      $lookup: {
        from: 'users',
        let: { userId: '$userId' },
        as: 'userDetails',
        pipeline: [
          {
            $match:
              { $expr: { $eq: ['$_id', '$$userId'] } }
          },
          {
            $match: statusQuery
          },
          { $project: { _id: 1, email: 1, phoneNumber: 1, isActiveBeautician: 1 } },
        ],
      },
    },
    { $match: { userDetails: { $gt: {} } } },
    {
      $lookup: {
        from: 'addresses',
        let: { address: '$address' },
        pipeline: [
          { $match: { $expr: { $eq: ['$_id', '$$address'] } } },
          { $project: { _id: 0, createdAt: 0, updatedAt: 0, __v: 0 } },
        ],
        as: 'address'
      },
    },
    {
      $lookup: {
        from: 'provinces',
        localField: 'address.province',
        foreignField: '_id',
        pipeline: [
          { $project: { name: 1, name_fr: 1, } },
        ],
        as: 'provinceDetails'
      }
    },
    {
      $addFields: {
        address: {
          $map: {
            input: '$address',
            as: 'addr',
            in: {
              $mergeObjects: [
                '$$addr',
                {
                  provinceName: {
                    $arrayElemAt: ['$provinceDetails.name', 0]
                  },
                  provinceName_fr: {
                    $arrayElemAt: ['$provinceDetails.name_fr', 0]
                  }
                }
              ]
            }
          }
        }
      }
    },
    {
      $lookup: {
        from: "beauticianworkhours",
        localField: "_id",
        foreignField: "beauticianId",
        pipeline: [
          { $project: { _id: 0, dayDetails: 1 } },
        ],
        as: "workHours"
      }
    },
    { $unwind: { path: '$userDetails', preserveNullAndEmptyArrays: true } },
    { $unwind: { path: '$address', preserveNullAndEmptyArrays: true } },
    { $unwind: { path: '$workHours', preserveNullAndEmptyArrays: true } },

    { $sort: { createdAt: -1 } },
    {
      $project: {
        _id: 1,
        profileImage: 1,
        businessName: 1,
        uid: 1,
        address: 1,
        userDetails: 1,
        workHours: 1,
        isRecommended: 1,
        status: 1,
        screenStatus: 1,
        isDeleted: 1,
        isActiveBeautician: 1,
      }
    },
  ]
  const tempBeautician = await Beautician.aggregate(tempData);
  const count = tempBeautician.length;

  let journeyData = await Beautician.aggregate([
    {
      $lookup: {
        from: 'invitedclients',
        localField: '_id',
        foreignField: "beauticianId",
        as: 'InvitedClient',
      },
    },
    {
      $addFields: {
        serviceCount: {
          $size: "$beauticianServiceId"
        }
      }
    },
    {
      $addFields: {
        countInvitaion: {
          $size: "$InvitedClient"
        }
      }
    },
    { $sort: { createdAt: -1 } },
    {
      $project: {
        stripe_id: {
          $ifNull: ["$stripe_id", null]
        },
        taxProvinceDetails: {
          $ifNull: ["$taxProvinceDetails", null]
        },
        logo: {
          $ifNull: ["$logo", null]
        },
        profileImage: {
          $ifNull: ["$profileImage", null]
        },
        uid: 1, businessName: 1, screenStatus: 1, isLicensed: 1, countInvitaion: 1, serviceCount: 1,
      }
    }
  ]);

  tempData.push({ $skip: offsetData }, { $limit: limitData });
  let allBeautician = await Beautician.aggregate(tempData);
  if (allBeautician.length) {
    if (journeyData.length) {
      allBeautician.forEach((val) => {
        journeyData.forEach((ele) => {
          if (val._id.toString() === ele._id.toString()) {
            val.isLicensed = ele.isLicensed;
            val.screenStatus = ele.screenStatus;
            val.serviceCount = ele.serviceCount;
            val.countInvitaion = ele.countInvitaion;
            val.stripe_id = ele.stripe_id;
            val.taxProvinceDetails = ele.taxProvinceDetails;
            val.logo = ele.logo;
            val.profileImage = ele.profileImage;
          }
        })
      })
    }
  }
  return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, message: "All beautician detail", data: { count, allBeautician } });
});

// Get Single Beautician 
const getSingleBeautician = catchAsyncError(async (req, res, next) => {
  const { beauticianId } = req.params;
  const beautician = await Beautician.aggregate([
    { $match: { _id: new mongoose.Types.ObjectId(beauticianId) } },
    {
      $lookup: {
        from: "users",
        localField: "userId",
        foreignField: "_id",
        pipeline: [
          { $project: { email: 1, phoneNumber: 1, isActiveBeautician: 1 } },
        ],
        as: "User"
      }
    },
    { $lookup: { from: 'beauticianservices', localField: 'beauticianServiceId', foreignField: '_id', as: 'serviceDetails' }, },
    {
      $lookup:
      {
        from: 'servicecategorylists',
        localField: 'serviceDetails.serviceCategory',
        foreignField: '_id',
        as: 'serviceCategory',
        pipeline: [
          { $project: { serviceCategoryName: 1, serviceCategoryName_fr: 1, colorCode: 1, } },
        ],
      },
    },
    // { $lookup: { from: 'demographies', localField: 'demographicIds', foreignField: '_id', as: 'demographys' } },
    { $lookup: { from: 'amenities', localField: 'amenityIds', foreignField: '_id', as: 'amenities', pipeline: [{ $project: { name: 1, name_fr: 1, } }] } },
    { $lookup: { from: 'packages', localField: 'subscriptionPlanType', foreignField: '_id', as: 'planDetail', pipeline: [{ $project: { name: 1 } }] } },

    {
      $lookup: {
        from: 'addresses', localField: 'address', foreignField: '_id', as: 'beauticianAddress',
        pipeline: [
          { $project: { _id: 0, address: 1, province: 1, apartment: 1, city: 1, zipCode: 1 } },
          {
            $addFields: {
              provinceName: null
            }
          }
        ],
      }
    },
    {
      $lookup: {
        from: 'provinces',
        localField: 'beauticianAddress.province',
        foreignField: '_id',
        pipeline: [
          { $project: { name: 1, name_fr: 1 } },
        ],
        as: 'provinceDetails'
      }
    },
    {
      $addFields: {
        beauticianAddress: {
          $map: {
            input: '$beauticianAddress',
            as: 'addr',
            in: {
              $mergeObjects: [
                '$$addr',
                {
                  provinceName: {
                    $arrayElemAt: ['$provinceDetails.name', 0]
                  },
                  provinceName_fr: {
                    $arrayElemAt: ['$provinceDetails.name_fr', 0]
                  }
                }
              ]
            }
          }
        }
      }
    },
    {
      $lookup: {
        from: "beauticianworkhours",
        localField: "_id",
        foreignField: "beauticianId",
        pipeline: [
          { $project: { _id: 0, dayDetails: 1 } },
        ],
        as: "workHours"
      }
    },
    {
      $lookup: {
        from: "employees",
        localField: "_id",
        foreignField: "beauticianId",
        pipeline: [
          { $project: { title: 1, firstName: 1, lastName: 1, profileImage: 1 } },
        ],
        as: "Employees"
      }
    },
    {
      $project: {
        _id: 1, firstName: 1, lastName: 1, country: 1, country_code: 1, isProvideService: 1, isProvideProduct: 1, totalEmployee: 1, demographicIds: 1, uid: 1,
        hasShop: 1, IsServeAtClient: 1, IsServeAtOwnPlace: 1, screenStatus: 1, isDeleted: 1, createdAt: 1, updatedAt: 1, profileImage: 1, DOB: 1, gender: 1,
        logo: 1, User: 1,
        serviceCategory: 1,
        isLicensed: 1,
        taxProvinceDetails: {
          $ifNull: ["$taxProvinceDetails", null]
        },
        licenseImage: {
          $ifNull: ["$licenseImage", null]
        },
        rating: 1,
        noOfReviews: 1,
        facebookUrl: 1,
        instagramUrl: 1,
        website: 1,
        planDetail: 1,
        description: 1,
        amenities: 1,
        beauticianAddress: 1, workHours: 1, Employees: 1,
        workSpaceImgs: 1
      }
    }
  ]);

  if (!beautician) {
    throw new ErrorHandler("Beautician not found", HttpStatus.BAD_REQUEST);
  }

  return res.status(200).json({ status: HttpStatus.OK, success: true, beautician });
});

// Delete Beautician
const deleteBeautician = catchAsyncError(async (req, res, next) => {
  const { beauticianId } = req.params;

  const beautician = await Beautician.findOne({ _id: beauticianId });

  if (!beautician) {
    throw new ErrorHandler("Beautician not found", HttpStatus.BAD_REQUEST);
  }

  await Beautician.findByIdAndDelete({ _id: beauticianId });

  return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Beautician deleted successfully" });
});

const updateRecomandedStatus = catchAsyncError(async (req, res, next) => {
  const { Id, isRecommended } = req.body;

  if (!Id) {
    throw new ErrorHandler("Plaese Enter Id", HttpStatus.BAD_REQUEST);
  }
  const beautician = await Beautician.findOne({ _id: new mongoose.Types.ObjectId(Id) });
  if (!beautician) {
    throw new ErrorHandler("Beautician not found", HttpStatus.BAD_REQUEST);
  }

  const data = await Beautician.findByIdAndUpdate({ _id: Id }, { isRecommended });
  return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Chnaged successfully" });
});

// send Invitation
const sendInvtaion = catchAsyncError(async (req, res, next) => {
  //  password:default, signUpType:beauticians  
  const { email, phoneNumber, firstName, lastName, country, country_code, } = req.body;
  const signUpType = "beautician";

  const errors = validationResult(req);
  if (errors.errors.length !== 0) {
    throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST);
  };

  const beauticianCount = await Beautician.findOne({}).sort({ createdAt: -1 }).select({ uid: 1 });
  let tempBid = "";
  if (!beauticianCount) {
    tempBid = "SLKB-0000000"
  } else {
    tempBid = beauticianCount.uid;
  }

  const Buid = generateBeauticianId(tempBid);
  const userEmail = await User.findOne({ email });
  const userMobile = await User.findOne({ phoneNumber });

  if (userEmail && userEmail.roles.includes(signUpType)) {
    throw new ErrorHandler("Email is already exists with this role", HttpStatus.BAD_REQUEST, false);
  }
  else if (userMobile && userMobile.roles.includes(signUpType)) {
    throw new ErrorHandler("Mobile number is already exists with this role", HttpStatus.BAD_REQUEST, false);
  }

  const hashedPassword = "$2b$10$9jcEWi3LbluNBfkoOJes..CjMqE6AKeiSVmlBG0P.ZOPzZZbcoqe.";

  const newUser = await new User({
    email, password: hashedPassword, phoneNumber, isVerified: 1
  });

  const newBeautician = await Beautician.create({
    firstName, lastName, userId: newUser.id, phoneNumber, country, country_code, uid: Buid, createdBy: "admin"
  });
  await BookingSetting.create({
    beauticianId: newBeautician._id, confirmAuto: true, futureBookingMonths: 3,
  });

  newUser.roles.push(signUpType)
  newUser.isActiveBeautician = true;
  newUser.activateAsBeauticianDate = moment().toDate();
  await newUser.save();

  return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Basic details added successfully", beauticianId: newBeautician._id })
});

//Reports of all beauticians
const beauticianReports = catchAsyncError(async (req, res, next) => {
  const { Id } = req.body;
  if (!mongoose.Types.ObjectId.isValid(Id)) {
    throw new ErrorHandler("Plaese Enter Beautician Id", HttpStatus.BAD_REQUEST);
  }
  const data = await Appointment.aggregate([
    {
      $match:
        { beauticianId: new mongoose.Types.ObjectId(Id), step: 2 }
    }
  ]);

  const count = data.length;
  return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, count, data });
});
// function for getting beautician data and service financial values
const getServiceFinancialAndDetails = async (beauticianId, chartSDate, chartEDate) => {
  let chartFilter = {};
  if (chartSDate && chartEDate) {
    if (chartSDate !== "" && chartEDate !== "") {
      chartFilter = {
        $expr: {
          $and: [
            {
              $gte: [
                { $toDate: '$createdAt' },
                { $toDate: chartSDate }
              ]
            },
            {
              $lte: [
                { $toDate: '$createdAt' },
                { $toDate: chartEDate }
              ]
            }
          ]
        },
      }
    }
  }
  const beauticiandata = await Beautician.aggregate([
    { $match: { _id: new mongoose.Types.ObjectId(beauticianId) } },
    {

      $lookup: {
        from: 'users',
        localField: 'userId',
        foreignField: "_id",
        pipeline: [
          { $project: { email: 1, phoneNumber: 1, isActiveUser: 1, isActiveBeautician: 1 } }
        ],
        as: 'userDetails',
      },
    },
    {

      $lookup: {
        from: 'addresses',
        localField: 'address',
        foreignField: "_id",
        pipeline: [
          { $project: { address: 1, street: 1, apartment: 1, province: 1, city: 1, zipCode: 1 } }
        ],
        as: 'beauticianAddress',
      },
    },
    {

      $lookup: {
        from: 'packages',
        localField: 'subscriptionPlanType',
        foreignField: "_id",
        pipeline: [
          { $project: { name: 1 } }
        ],
        as: 'plan',
      },
    },
    {
      $project: {
        logo: 1,
        uid: 1,
        firstName: 1,
        lastName: 1,
        workSpaceImgs: 1,
        userDetails: 1,
        profileImage: 1,
        country: 1,
        country_code: 1,
        isDeleted: 1,
        screenStatus: 1,
        businessName: 1,
        businessNumber: 1,
        description: 1,
        facebookUrl: 1,
        instagramUrl: 1,
        createdAt: 1,
        nubOfShareClicked: 1,
        beauticianAddress: 1,
        plan: { $first: '$plan' }
      }
    }
  ]);
  const serviceFinacial = await Appointment.aggregate([
    { $match: { beauticianId: new mongoose.Types.ObjectId(beauticianId), step: 2 } },
    {
      $lookup: {
        from: 'beauticianservices',
        localField: 'serviceId',
        foreignField: "_id",
        pipeline: [
          { $project: { serviceCategory: 1, beauticianId: 1, serviceType: 1, price: 1, duration: 1 } }
        ],
        as: 'serviceDetails',
      },
    },
    {
      $lookup: {
        from: 'payments',
        localField: 'paymentDetails',
        foreignField: "_id",
        pipeline: [
          { $match: chartFilter },
          {
            $project: {
              createdAt: 1, BookingId: 1, subTotal: 1, GstInPer: 1, PstInPer: 1, QstInPer: 1, HstInPer: 1,
              discount: 1, GST: 1, PST: 1, QST: 1, HST: 1, TotalPrice: 1,
            }
          }
        ],
        as: 'paymentDetails',
      },

    },
    { $match: { paymentDetails: { $gt: [] } } },
    {
      $addFields: {
        sliikFee: 0,
        sliikFeeGST: 0,
        sliikFeePST: 0,
        // sliikFee: { $round: [{ $multiply: ["$price", parseFloat(platform_fees)] }, 2] },
        // sliikFeeGST: { $sum: [{ $round: [{ $multiply: ['$price', parseFloat(platform_fees), { $first: "$paymentDetails.GstInPer" }, 0.01] }, 2] }, { $round: [{ $multiply: ['$price', parseFloat(platform_fees), { $first: "$paymentDetails.HstInPer" }, 0.01] }, 2] }] },
        // sliikFeePST: { $sum: [{ $round: [{ $multiply: ['$price', parseFloat(platform_fees), { $first: "$paymentDetails.PstInPer" }, 0.01] }, 2] }, { $round: [{ $multiply: ['$price', parseFloat(platform_fees), { $first: "$paymentDetails.QstInPer" }, 0.01] }, 2] }] },
        discount: { $round: [{ $multiply: ["$price", { $first: "$paymentDetails.discount" }, 0.01] }, 2] },
        gstORhst: { $sum: [{ $round: [{ $multiply: ['$price', { $first: "$paymentDetails.GstInPer" }, 0.01] }, 2] }, { $round: [{ $multiply: ['$price', { $first: "$paymentDetails.HstInPer" }, 0.01] }, 2] }] },
        pstORqst: { $sum: [{ $round: [{ $multiply: ['$price', { $first: "$paymentDetails.PstInPer" }, 0.01] }, 2] }, { $round: [{ $multiply: ['$price', { $first: "$paymentDetails.QstInPer" }, 0.01] }, 2] }] },
      }
    },

    {
      $group: {
        _id: null,
        totalSubTotal: { $sum: "$price" },
        totalGSTORHST: { $sum: "$gstORhst" },
        totalPSTORQST: { $sum: "$pstORqst" },
        totalSliikFees: { $sum: "$sliikFee" },
        totalsliikFeeGST: { $sum: "$sliikFeeGST" },
        totalsliikFeePST: { $sum: "$sliikFeePST" },
        discount: { $sum: '$discount' }
      }
    }
  ]);
  if (serviceFinacial.length) {
    const totalTemp = serviceFinacial[0].totalSubTotal + serviceFinacial[0].totalGSTORHST + serviceFinacial[0].totalPSTORQST - serviceFinacial[0].totalSliikFees - serviceFinacial[0].totalsliikFeeGST - serviceFinacial[0].totalsliikFeePST - serviceFinacial[0].discount
    serviceFinacial[0].totalEarned = totalTemp;
    serviceFinacial[0].totalSliikRevenue = serviceFinacial[0].totalSliikFees + serviceFinacial[0].totalsliikFeeGST + serviceFinacial[0].totalsliikFeePST
  }
  return { beauticiandata, serviceFinacial }
}
// Beautician Dashboard Reports 
const beauticianDashboard = catchAsyncError(async (req, res, next) => {
  const { beauticianId, categoryId, startDate, endDate, appointmentStatus, search, provinceId, limit, offset, chartSDate, chartEDate, gender, } = req.body;

  if (!mongoose.Types.ObjectId.isValid(beauticianId)) {
    throw new ErrorHandler("Plaese Enter Beautician Id", HttpStatus.BAD_REQUEST);
  }
  const limitData = parseInt(limit, 10) || 10;
  const offsetData = parseInt(offset, 10) || 0;

  // for get finacial summary data of services
  const { beauticiandata, serviceFinacial } = await getServiceFinancialAndDetails(beauticianId, chartSDate, chartEDate);

  let chartFilter = {};
  if (chartSDate && chartEDate) {
    if (chartSDate !== "" && chartEDate !== "") {
      chartFilter = {
        $expr: {
          $and: [
            {
              $gte: [
                { $toDate: '$createdAt' },
                { $toDate: chartSDate }
              ]
            },
            {
              $lte: [
                { $toDate: '$createdAt' },
                { $toDate: chartEDate }
              ]
            }
          ]
        },
      }
    }
  }

  // for get product finacial summary data
  const productFinacial = await Order.aggregate([
    { $match: { "productData.beauticianId": new mongoose.Types.ObjectId(beauticianId) } },
    { $match: { paymentStatus: 1 } },
    { $match: chartFilter },
    {
      $addFields: {
        sliikFee: 0,
        sliikFeeGST: 0,
        sliikFeePST: 0,
        // sliikFee: { $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees)] }, 2] },
        // sliikFeeGST: { $sum: [{ $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees), "$GstInPer", 0.01] }, 2] }, { $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees), "$HstInPer", 0.01] }, 2] }] },
        // sliikFeePST: { $sum: [{ $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees), "$PstInPer", 0.01] }, 2] }, { $round: [{ $multiply: ["$subTotal", parseFloat(platform_fees), "$QstInPer", 0.01] }, 2] }] },
        gstORhst: { $sum: [{ $round: [{ $multiply: ["$subTotal", "$GstInPer", 0.01] }, 2] }, { $round: [{ $multiply: ["$subTotal", "$HstInPer", 0.01] }, 2] }] },
        pstORqst: { $sum: [{ $round: [{ $multiply: ["$subTotal", "$PstInPer", 0.01] }, 2] }, { $round: [{ $multiply: ["$subTotal", "$QstInPer", 0.01] }, 2] }] },
        // discount: { $sum: "$discount" }
      }
    },
    {
      $group: {
        _id: null,
        totalSubTotal: { $sum: "$subTotal" },
        totalGSTORHST: { $sum: "$gstORhst" },
        totalPSTORQST: { $sum: "$pstORqst" },
        totalSliikFees: { $sum: "$sliikFee" },
        totalsliikFeeGST: { $sum: "$sliikFeeGST" },
        totalsliikFeePST: { $sum: "$sliikFeePST" },
        discount: { $sum: '$discount' }
      }
    }
  ]);

  // for get total summary data of both (service and product)
  const summaryFinacials = [
    {
      "totalBusinessRevenue": (productFinacial[0]?.totalSubTotal || 0) + (serviceFinacial[0]?.totalSubTotal || 0),
      "totalGSTORHST": (productFinacial[0]?.totalGSTORHST || 0) + (serviceFinacial[0]?.totalGSTORHST || 0),
      "totalPSTORQST": (productFinacial[0]?.totalPSTORQST || 0) + (serviceFinacial[0]?.totalPSTORQST || 0),
      "totalSllikRevenue": 0,
      "totalShippingGSTORHST": 0,
      "totalShippingQSTORPST": 0,
      "totalTransctionAmt": (productFinacial[0]?.totalSubTotal || 0) + (serviceFinacial[0]?.totalSubTotal || 0) + (productFinacial[0]?.totalGSTORHST || 0) + (serviceFinacial[0]?.totalGSTORHST || 0) + (productFinacial[0]?.totalPSTORQST || 0) + (serviceFinacial[0]?.totalPSTORQST || 0)
    }
  ]

  let categoryWhere = {};
  let appoiementWhere = {};
  let matchQuery = {};
  let dateSearch = {};
  let provinceWhere = {};
  if (categoryId) {
    if (categoryId !== "") {
      categoryWhere = { serviceCategory: new mongoose.Types.ObjectId(categoryId) }
    }
  }
  const today = new Date();

  // 1 = upcomming,2 = completed, 3 = cancelled ,4= client no show
  if (appointmentStatus) {
    if (appointmentStatus !== "") {
      appoiementWhere = { status: appointmentStatus }
      if (appointmentStatus == 1) {// filter for upcoming
        appoiementWhere = { dateTime: { $gte: today } }
      } else if (appointmentStatus == 2) {//filter for completed 
        appoiementWhere = { status: 2 }
      } else if (appointmentStatus == 3) { // filter for cancel
        appoiementWhere = { status: { $in: [3, 4] } }
      } else if (appointmentStatus == 4) { //check for no-show
        appoiementWhere = { status: 5 }
      }
    }
  }
  if (search) {
    if (search !== "") {
      matchQuery.$or = [
        { firstName: { $regex: search, $options: 'i' } },
        { lastName: { $regex: search, $options: 'i' } },
      ];
    }
  }
  if (gender) {

    if (gender !== "" && (gender === 'Male' || gender === 'Female')) matchQuery.gender = gender
  }
  if (startDate && endDate) {
    if (startDate !== "" && endDate !== "") {
      dateSearch = {
        $expr: {
          $and: [
            {
              $gte: [
                { $toDate: '$dateTime' },
                { $toDate: startDate }
              ]
            },
            {
              $lte: [
                { $toDate: '$dateTime' },
                { $toDate: endDate }
              ]
            }
          ]
        }
      }
    }
  }
  if (provinceId) {
    if (provinceId !== "") {
      provinceWhere = {
        province: new mongoose.Types.ObjectId(provinceId)
      }
    }
  }


  // for get service sales summary
  let tempData = [
    { $match: { beauticianId: new mongoose.Types.ObjectId(beauticianId), step: 2 } },
    { $match: dateSearch },
    { $match: appoiementWhere },
    {
      $lookup: {
        from: 'clients',
        localField: 'clientId',
        foreignField: "_id",
        pipeline: [
          { $match: matchQuery },
          { $project: { firstName: 1, lastName: 1, country: 1 } }
        ],
        as: 'clientDetails',
      },
    },
    { $match: { clientDetails: { $gt: {} } } },
    {
      $lookup: {
        from: 'beauticianservices',
        localField: 'serviceId',
        foreignField: "_id",
        pipeline: [
          { $match: categoryWhere },
          { $project: { serviceCategory: 1, beauticianId: 1, serviceType: 1, price: 1, duration: 1 } }
        ],
        as: 'serviceDetails',
      },
    },
    { $match: { serviceDetails: { $gt: {} } } },
    {
      $lookup: {
        from: 'servicetypelists',
        localField: 'serviceDetails.serviceType',
        foreignField: "_id",
        pipeline: [
          { $project: { serviceTypeName: 1, serviceTypeName_fr: 1, } }
        ],
        as: 'serviceTypeDetails',
      },
    },
    {
      $lookup: {
        from: 'payments',
        localField: 'paymentDetails',
        foreignField: "_id",
        pipeline: [
          {
            $project: {
              BookingId: 1, subTotal: 1, GstInPer: 1, PstInPer: 1, QstInPer: 1, HstInPer: 1,
              discount: 1, GST: 1, PST: 1, QST: 1, HST: 1, TotalPrice: 1, addressId: 1,
              sliikFee: { $divide: ["$subTotal", 10] },
            }
          }
        ],
        as: 'paymentData',
      },
    },
    {
      $lookup: {
        from: 'addresses',
        localField: 'paymentData.addressId',
        foreignField: "_id",
        pipeline: [
          { $match: provinceWhere },
          { $project: { province: 1 } }
        ],
        as: 'paymentAddress',
      },
    },
    { $match: { paymentAddress: { $gt: {} } } },
  ]
  const tempService = await Appointment.aggregate(tempData);
  const count = tempService.length;

  tempData.push({ $skip: offsetData }, { $limit: limitData });
  const serviceSales = await Appointment.aggregate(tempData);

  if (serviceSales.length) {
    await serviceSales.forEach(async (val) => {
      if (val.paymentData.length) {
        const GSTTAX = val?.paymentData[0]?.GstInPer;
        const PSTTAX = val?.paymentData[0]?.PstInPer;
        const HSTTAX = val?.paymentData[0]?.HstInPer;
        const QSTTAX = val?.paymentData[0]?.QstInPer;

        const total = val.price + val.price * (GSTTAX / 100) + val.price * (HSTTAX / 100) + val.price * (QSTTAX / 100) + val.price * (PSTTAX / 100) - val.discount;
        const sllikFee = (val.price - val.discount) / 10;

        val.paymentData[0].TotalPrice = total;
        val.paymentData[0].subTotal = val.price;
        val.paymentData[0].sliikFee = sllikFee;
        val.paymentData[0].GST = (val.price * (GSTTAX / 100))
        val.paymentData[0].PST = (val.price * (PSTTAX / 100))
        val.paymentData[0].HST = (val.price * (HSTTAX / 100))
        val.paymentData[0].QST = (val.price * (QSTTAX / 100))
        val.paymentData[0].discount = parseInt(val.discount);
      }
    });
  }
  return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { count, serviceFinacial, productFinacial, summaryFinacials, serviceSales, beauticiandata } });
});

// add businessDetails 
const addBeauticianBusinessDetails = catchAsyncError(async (req, res, next) => {
  const { beauticianId, businessName, businessNumber, address, country, province, street_address, apartment, city, post_code, coordinates } = req.body;
  const errors = validationResult(req);
  if (errors.errors.length !== 0) {
    throw new ErrorHandler(req.t(errors?.errors[0]?.msg), HttpStatus.BAD_REQUEST);
  };
  if (!country) {
    throw new ErrorHandler("country is required", HttpStatus.BAD_REQUEST);
  }

  if (!mongoose.Types.ObjectId.isValid(beauticianId)) {
    throw new ErrorHandler("Plaese enter valid beautician Id", HttpStatus.BAD_REQUEST);
  }

  if (!mongoose.Types.ObjectId.isValid(province)) {
    throw new ErrorHandler("Plaese enter valid province Id", HttpStatus.BAD_REQUEST);
  }

  const provinceData = await Province.findOne({ _id: province, status: 1 });
  if (!provinceData) {
    throw new ErrorHandler("Enter wrong province Id", HttpStatus.BAD_REQUEST);
  }

  if (!coordinates?.length) {
    throw new ErrorHandler(req.t("validLocation"), HttpStatus.BAD_REQUEST);
  }

  const beauticianData = await Beautician.findOne({ _id: beauticianId });
  if (beauticianData?.address) {
    throw new ErrorHandler("Address alreday added", HttpStatus.BAD_REQUEST);
  }

  if (beauticianData) {
    const newAddress = await Address.create({ address, country, province, street: street_address, apartment, city, zipCode: post_code });
    const coordinates_new = [coordinates[1], coordinates[0]];
    beauticianData.businessName = businessName;
    beauticianData.businessNumber = businessNumber;
    beauticianData.country = country;
    beauticianData.address = newAddress._id;
    beauticianData.screenStatus = 4;
    beauticianData.location = { type: 'Point', coordinates: coordinates_new };
    await beauticianData.save();
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Business details added successfully", beauticianId: beauticianData._id });
  } else {
    throw new ErrorHandler("Beautician details not found", HttpStatus.BAD_REQUEST);
  }
});

// add Business Type
const addBeauticianBusinessType = catchAsyncError(async (req, res, next) => {
  const { beauticianId, isProvideProduct, isProvideService } = req.body;

  const beauticianData = await Beautician.findOne({ _id: beauticianId });

  if (beauticianData) {
    if (isProvideProduct === 1) {
      beauticianData.isProvideProduct = isProvideProduct;
    } else if (isProvideService === 1) {
      beauticianData.isProvideService = isProvideService;
    } else {
      throw new ErrorHandler("Please enter valid isProvideProduct or isProvideService", HttpStatus.BAD_REQUEST);
    }
    beauticianData.screenStatus = 5;
    await beauticianData.save();

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Buisness type added successfully", beauticianId: beauticianData._id });
  } else {
    throw new ErrorHandler("Beautician details not found", HttpStatus.BAD_REQUEST);
  }
});

// add beautician services
const addBeauticianServices = catchAsyncError(async (req, res, next) => {
  try {
    const form = formidable({ multiples: true });
    form.parse(req, async (err, fields, files) => {
      const { beauticianId, services } = fields;
      const beauticianData = await Beautician.findOne({ _id: beauticianId })
      if (beauticianData) {
        const isServiceExist = await BeauticianService.findOne({ beauticianId: beauticianData._id })
        if (!isServiceExist) {
          if (!services) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "services is missing" });
          }

          try {
            if (!services.length) {
              return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "services is missing" });
            }
            const uploadPromises = services.map(async (val) => {
              if (!val.serviceCategory) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "service category is missing" });
              if (!val.serviceType) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "service type is missing" });
              if (!val.duration) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "duration is missing" });
              if (!val.price) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "price is missing" });

              const categoryData = await ServiceCategoryList.findOne({ _id: val.serviceCategory, status: 1 });
              const typeData = await ServiceTypeList.findOne({ _id: val.serviceType, status: 1 });

              if (!categoryData) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Enter valid service category Id" });
              if (!typeData) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Enter valid service type Id" });

              if (val.description && val.description.length > 150) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Description is to long" });
              }

              if (files.images) {
                if (files.images.length) {
                  await Promise.all(files.images.map(async (imgVal) => {
                    if (val.imgName === imgVal.originalFilename) {
                      const imgName = imgVal.originalFilename.split(".");
                      const extension = imgName[imgName.length - 1];
                      if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("ImageExtension", { extension: extension }) });
                      }
                      const fileName = (imgVal.originalFilename = uuidv4() + "." + extension);
                      const newPath = `${pathEndpoint.beauticianServiceImg}${fileName}`;
                      const uploadImgRes = await uploadFile(imgVal, newPath, extension);
                      if (uploadImgRes.status === 200) {
                        val.imgName = uploadImgRes.imageUrl
                      }
                    }
                  }))
                } else {
                  if (val.imgName === files.images.originalFilename) {
                    const imgName = files.images.originalFilename.split(".");
                    const extension = imgName[imgName.length - 1];
                    if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                      return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("ImageExtension", { extension: extension }) });
                    }
                    const fileName = (files.images.originalFilename = uuidv4() + "." + extension);
                    const newPath = `${pathEndpoint.beauticianServiceImg}${fileName}`;
                    const uploadImgRes = await uploadFile(files.images, newPath, extension);
                    if (uploadImgRes.status === 200) {
                      val.imgName = uploadImgRes.imageUrl;
                    }
                  }
                }
              } else {
                val.imgName = "";
              }
              val.beauticianId = beauticianData._id
            })
            await Promise.all(uploadPromises);
            const newService = await BeauticianService.insertMany(services);
            const serviceIds = newService.map((val) => {
              return val._id;
            });
            beauticianData.beauticianServiceId = serviceIds;
            beauticianData.screenStatus = 6;
            await beauticianData.save();

            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("addServiceWithImageDetailsSuccess"), beauticianId: beauticianData._id });

          } catch (error) {
            // console.log("🚀 ~ file: beauticianAController.js:1038 ~ form.parse ~ error:", error)
            // Handle the validation error
            // if (error instanceof ValidationError) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "something is wrong" });
            // }
          }
        } else {
          return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: req.t("serviceAlreadyAdded") });
        }
      } else {
        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "beautician details not found" });
      }
    });

  } catch (error) {
    // console.log("🚀 ~ file: beauticianAController.js:1034 ~ addBeauticianServices ~ error:", error)
    return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "something is wrong" })
  }
});

// add beautician working hours
const addBeauticianWorkingHours = catchAsyncError(async (req, res, next) => {
  const { beauticianId, dayDetails } = req.body;
  if (dayDetails || dayDetails?.length) {
    if (!mongoose.Types.ObjectId.isValid(beauticianId)) {
      throw new ErrorHandler("Please enter valid beautician Id", HttpStatus.BAD_REQUEST);
    }
    const beauticianData = await Beautician.findOne({ _id: beauticianId });
    if (beauticianData) {
      const workDetailExist = await BeauticianWorkHour.findOne({ beauticianId: beauticianData._id });
      if (!workDetailExist) {
        dayDetails.map((val) => {
          if (val.day !== "Monday" && val.day !== "Tuesday" && val.day !== "Wednesday" && val.day !== "Thursday" && val.day !== "Friday" && val.day !== "Saturday" && val.day !== "Sunday") {
            throw new ErrorHandler("Enter worng day", HttpStatus.BAD_REQUEST);
          }
        })
        await BeauticianWorkHour.create({ beauticianId: beauticianData._id, dayDetails })
        beauticianData.screenStatus = 7;
        await beauticianData.save();

        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("addWorkHoursSuccess"), beauticianId: beauticianData._id });
      } else {
        throw new ErrorHandler(req.t("hoursIsExists"), HttpStatus.BAD_REQUEST);
      }
    } else {
      throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST);
    }
  } else {
    throw new ErrorHandler(req.t("dayDetailsIsMissing"), HttpStatus.BAD_REQUEST);
  }
});

// get product sales summary
const productSalesReports = catchAsyncError(async (req, res, next) => {
  const { beauticianId, limit, offset, productStartDate, productEndDate, productProvinceId, minPrice, maxPrice, serachClient, orderStatus } = req.body;

  const productLimitData = parseInt(limit, 10) || 10;
  const productOffsetData = parseInt(offset, 10) || 0;
  let productProviceQuery = {};
  let clientQuery = {};
  let productQuery = {
    "productData.beauticianId": new mongoose.Types.ObjectId(beauticianId)
  }

  // this query is for province find
  if (productProvinceId) {
    if (productProvinceId !== "") {
      productProviceQuery = {
        province: new mongoose.Types.ObjectId(productProvinceId)
      }
    }
  }

  // This query is for serch client 
  if (serachClient) {
    if (serachClient !== "") {
      clientQuery.$or = [
        { firstName: { $regex: serachClient, $options: 'i' } },
        { lastName: { $regex: serachClient, $options: 'i' } },
      ];
    }
  }

  // This query is for product data between two dates
  if (productStartDate && productEndDate) {
    if (productStartDate !== "" && productEndDate !== "") {
      productQuery = {
        ...productQuery,
        $expr: {
          $and: [
            {
              $gte: [
                { $toDate: '$createdAt' },
                { $toDate: productStartDate }
              ]
            },
            {
              $lte: [
                { $toDate: '$createdAt' },
                { $toDate: productEndDate }
              ]
            }
          ]
        }
      }
    }
  }

  let productSales = await Order.aggregate([
    { $match: { "productData.beauticianId": new mongoose.Types.ObjectId(beauticianId) } },
    { $match: productQuery },
    {
      $unwind: "$productData",
    },
    {
      $lookup: {
        from: 'beauticianproducts',
        localField: 'productData.productId',
        foreignField: "_id",
        pipeline: [
          { $project: { productName: 1 } }
        ],
        as: 'productDetails',
      },
    },
    {
      $lookup: {
        from: 'clients',
        localField: 'clientId',
        foreignField: "_id",
        pipeline: [
          { $match: clientQuery },
          { $project: { firstName: 1, lastName: 1 } }
        ],
        as: 'clientDetails',
      },
    },
    { $match: { clientDetails: { $gt: {} } } },
    {
      $lookup: {
        from: 'addresses',
        localField: 'shippingAddressId',
        foreignField: "_id",
        pipeline: [
          {
            $project: {
              address: { $ifNull: ["$address", null] },
              street: { $ifNull: ["$street", null] },
              apartment: { $ifNull: ["$apartment", null] },
              city: { $ifNull: ["$city", null] },
              zipCode: { $ifNull: ["$zipCode", null] },
            }
          }
        ],
        as: 'addressDetails',
      },
    },
    {
      $lookup: {
        from: 'addresses',
        localField: 'shippingAddressId',
        foreignField: "_id",
        pipeline: [
          { $match: productProviceQuery },
          { $project: { province: 1 } }
        ],
        as: 'paymentAddress',
      },
    },
    { $match: { paymentAddress: { $gt: {} } } },
    { $sort: { createdAt: -1 } },
    {
      $project: {
        beauticianId: { $ifNull: ["$productData.beauticianId", 0] },
        productName: { $arrayElemAt: ['$productDetails.productName', 0] },
        clientFirstName: { $arrayElemAt: ['$clientDetails.firstName', 0] },
        clientLastName: { $arrayElemAt: ['$clientDetails.lastName', 0] },
        productPrice: { $ifNull: ["$productData.price", 0] },
        totalQuantity: { $ifNull: ["$productData.totalQuantity", 0] },
        productDiscount: { $ifNull: ["$productData.discount", 0] },
        productPurchaseDate: { $ifNull: ["$createdAt", 0] },
        deliveredDate: { $ifNull: ["$createdAt", 0] },
        orderStatus: { $ifNull: ["$orderStatus", "pending"] },
        addressDetails: 1,
        shippingCharge: { $ifNull: ["$shippingCharge", 0] },
        GstInPer: 1, PstInPer: 1, HstInPer: 1, QstInPer: 1,
      }
    }
  ]);

  if (productSales.length) {
    await productSales.forEach(async (val) => {
      const GSTTAX = val?.GstInPer;
      const PSTTAX = val?.PstInPer;
      const HSTTAX = val?.HstInPer;
      const QSTTAX = val?.QstInPer;

      let tempPrice = val.productPrice * val.totalQuantity;
      tempPrice = tempPrice - val.productDiscount;

      const total = tempPrice + tempPrice * (GSTTAX / 100) + tempPrice * (HSTTAX / 100) + tempPrice * (QSTTAX / 100) + tempPrice * (PSTTAX / 100);
      // const sllikFee = (tempPrice - val.discount) / 10;

      val.TotalPrice = total;
      val.subTotal = val.productPrice;
      val.sliikFee = 0;
      val.sliikFeeGST = 0;
      val.sliikFeePST = 0;
      val.sliikFeeHST = 0;
      val.sliikFeeQST = 0;
      val.GST = (tempPrice * (GSTTAX / 100))
      val.PST = (tempPrice * (PSTTAX / 100))
      val.HST = (tempPrice * (HSTTAX / 100))
      val.QST = (tempPrice * (QSTTAX / 100))
    });
  }

  if (maxPrice && minPrice) {
    if (maxPrice !== null && minPrice !== null) {
      if (productSales.length) {
        productSales = productSales.filter((val) => {
          if (val.subTotal >= parseInt(minPrice) && val.subTotal <= parseInt(maxPrice)) {
            if (val !== null) {
              return val;
            }
          }
        });
      }
    }
  }

  const productCount = productSales.length;
  productSales = productSales.slice(productOffsetData, productOffsetData + productLimitData);
  return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { productCount, productSales } });
});

// Get Single Beautician deatils for update profile
const getDetailsOfBeautician = catchAsyncError(async (req, res, next) => {
  const { beauticianId } = req.params;
  const beautician = await Beautician.aggregate([
    { $match: { _id: new mongoose.Types.ObjectId(beauticianId), isDeleted: 0 } },
    {
      $lookup: {
        from: "users",
        localField: "userId",
        foreignField: "_id",
        pipeline: [
          { $project: { email: 1, phoneNumber: 1, isActiveBeautician: 1 } },
        ],
        as: "User"
      }
    },
    { $unwind: "$User" },

    {
      $lookup: {
        from: 'addresses', localField: 'address', foreignField: '_id', as: 'beauticianAddress',
        pipeline: [
          { $project: { address: 1, province: 1, apartment: 1, city: 1, zipCode: 1 } },
          {
            $addFields: {
              provinceName: null
            }
          }
        ],
      }
    },
    {
      $lookup: {
        from: 'provinces',
        localField: 'beauticianAddress.province',
        foreignField: '_id',
        pipeline: [
          { $project: { name: 1, name_fr: 1 } },
        ],
        as: 'provinceDetails'
      }
    },
    {
      $addFields: {
        beauticianAddress: {
          $map: {
            input: '$beauticianAddress',
            as: 'addr',
            in: {
              $mergeObjects: [
                '$$addr',
                {
                  provinceName: {
                    $arrayElemAt: ['$provinceDetails.name', 0]
                  },
                  provinceName_fr: {
                    $arrayElemAt: ['$provinceDetails.name_fr', 0]
                  }
                }
              ]
            }
          }
        }
      }
    },
    {
      $project: {
        _id: 1,
        firstName: 1,
        lastName: 1,
        email: 1,
        phoneNumber: 1,
        businessName: 1,
        businessNumber: 1,
        country: 1,
        location: 1,
        User: 1,
        beauticianAddress: 1
      }
    }
  ]);

  if (!beautician.length) {
    throw new ErrorHandler("Beautician not found", HttpStatus.BAD_REQUEST);
  }
  return res.status(200).json({ status: HttpStatus.OK, success: true, beautician });
});

const updateBeautician = catchAsyncError(async (req, res, next) => {
  const { beauticianId } = req.params;
  const { firstName, lastName, email, phoneNumber, businessName, businessNumber, coordinates, country, province, address, apartment, city, pinCode } = req.body;
  if (!mongoose.Types.ObjectId.isValid(beauticianId)) {
    throw new ErrorHandler("Please Enter Valid beautician Id", HttpStatus.BAD_REQUEST, false);
  }
  const errors = validationResult(req);
  if (errors.errors.length !== 0) {
    throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST);
  };

  const isProvinceExits = await Province.findOne({ _id: province })
  if (!isProvinceExits) throw new ErrorHandler("Province is not exist.", HttpStatus.BAD_REQUEST, false);

  const beautician = await Beautician.findOne({ _id: beauticianId })
  if (beautician) {
    const userData = await User.findOne({ _id: beautician.userId })
    if (userData) {
      if (email) {
        const isExitsMail = await User.findOne({ email });
        if (isExitsMail !== null && isExitsMail?._id.toString() !== beautician.userId.toString()) {
          throw new ErrorHandler("Email is already exist.", HttpStatus.BAD_REQUEST, false);
        } else {
          userData.email = email
        }
      }

      if (email) {
        const isExitsPhoneNumber = await User.findOne({ phoneNumber });
        if (isExitsPhoneNumber !== null && isExitsPhoneNumber?._id.toString() !== beautician.userId.toString()) {
          throw new ErrorHandler("Mobile number is already exists.", HttpStatus.BAD_REQUEST, false);
        } else {
          userData.phoneNumber = phoneNumber
        }
      }
      await userData.save();
    }

    const coordinates_new = [coordinates[1], coordinates[0]]
    beautician.firstName = firstName,
      beautician.lastName = lastName
    beautician.businessName = businessName;
    beautician.businessNumber = businessNumber;
    beautician.country = country,
      beautician.location = { type: 'Point', coordinates: coordinates_new }
    await beautician.save();

    const addressData = await Address.findOne({ _id: beautician.address });
    if (addressData) {
      addressData.address = address;
      addressData.country = country;
      addressData.province = province;
      addressData.apartment = apartment;
      addressData.city = city;
      addressData.zipCode = pinCode;
      await addressData.save();
    }
    return res.status(200).json({ status: HttpStatus.OK, success: true, message: "Beautician updated successfully" });
  } else {
    throw new ErrorHandler("Beautician details not found.", HttpStatus.BAD_REQUEST, false);
  }
});

module.exports = { getAllBeautician, getSingleBeautician, changeStatus, changeArchive, deleteBeautician, beauticianReports, sendInvtaion, updateRecomandedStatus, getServiceFinancialAndDetails, beauticianDashboard, changeMultipleStatus, addBeauticianBusinessDetails, addBeauticianBusinessType, addBeauticianServices, addBeauticianWorkingHours, productSalesReports, getDetailsOfBeautician, updateBeautician }