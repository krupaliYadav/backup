const { default: mongoose } = require("mongoose");
const catchAsyncError = require("../../middleware/catchAsyncError");
const Beautician = require("../../models/Beautician");
const ErrorHandler = require("../../utils/ErrorHandling");
const HttpStatus = require("../../utils/HttpStatus");
const Order = require("../../models/Order");
const moment = require("moment");
const BeauticianProduct = require("../../models/BeauticianProduct");

const monthCounts = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nav",
  "Dec",
];

const updateProductRecomandedStatus = catchAsyncError(async (req, res, next) => {
  const { Id, isRecommended } = req.body;

  if (!Id) {
    throw new ErrorHandler("Plaese Enter Id", HttpStatus.BAD_REQUEST);
  }
  const beautician = await BeauticianProduct.findOne({ _id: new mongoose.Types.ObjectId(Id) });
  if (!beautician) {
    throw new ErrorHandler("Beautician not found", HttpStatus.BAD_REQUEST);
  }

  const data = await Beautician.findByIdAndUpdate({ _id: Id }, { isRecommended });
  return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Chnaged successfully" });
})

// For get all vendors with products
const getProductDashord = catchAsyncError(async (req, res, next) => {
  const { limit, offset, search, category, type, chartSDate, chartEDate } = req.body;
  let categoryQuery = {};
  let matchQuery = { $and: [{ screenStatus: 7 }] };
  const limitData = parseInt(limit, 10) || 10;
  const offsetData = parseInt(offset, 10) || 0;

  if (category && category !== "") {
    categoryQuery = { $and: [{ _id: new mongoose.Types.ObjectId(category) },] }
    // categoryQuery1 = { serviceName: { $gt: [] } }
  }

  if (search && search !== "") {
    matchQuery.$and = [...matchQuery.$and,
    { businessName: { $regex: search, $options: 'i' } },
    ];
  }

  if (type == "") {
    matchQuery.$and = [...matchQuery.$and,
    { isDeleted: 0 },
    ];
  }
  if (type === "archive") {
    matchQuery.$and = [...matchQuery.$and,
    { isDeleted: 1 },
    ];
  }
  if (type === "unarchive") {
    matchQuery.$and = [...matchQuery.$and,
    { isDeleted: 0 },
    ];
  }

  let vendorData = await Beautician.aggregate([
    {
      $match: matchQuery
    },
    {
      $lookup: {
        from: 'beauticianproducts',
        localField: '_id',
        foreignField: "beauticianId",
        as: 'productDeatils',
      },
    },
    { $match: { productDeatils: { $gt: [] } } },
    {
      $addFields: {
        totalNoPrdoucts: {
          $size: "$productDeatils"
        }
      }
    },
    {
      $lookup: {
        from: 'productcategorylists',
        localField: 'productDeatils.productCategory',
        foreignField: "_id",
        as: 'categoryName',
        pipeline: [
          { $match: categoryQuery },
          { $project: { productCategoryName: 1, productCategoryName_fr: 1, } }
        ]
      }
    },
    { $match: { categoryName: { $gt: [] } } },
    {
      $project: {
        uid: 1,
        createdAt: 1,
        isDeleted: 1,
        // productDeatils: 1,
        categoryName: 1,
        logo: { $ifNull: ["$logo", null] },
        businessName: 1,
        totalNoPrdoucts: 1,
        pending: { $ifNull: ["$pending", 0] },
        purchased: { $ifNull: ["$purchased", 0] },
        cancelled: { $ifNull: ["$cancelled", 0] },
      }
    }
  ]);

  let chartFilter = { paymentStatus: 1 };
  if (chartSDate && chartEDate) {
    if (chartSDate !== "" && chartEDate !== "") {
      chartFilter.$expr = {
        $and: [
          {
            $gte: [
              { $toDate: '$createdAt' },
              { $toDate: chartSDate }
            ]
          },
          {
            $lte: [
              { $toDate: '$createdAt' },
              { $toDate: chartEDate }
            ]
          }
        ]
      };
    }
  }

  const productFinacial = await Order.aggregate([
    { $match: chartFilter },
    {
      $addFields: {
        GSTSum: { $sum: "$GST" },
        PSTSum: { $sum: "$PST" },
        QSTSum: { $sum: "$QST" },
        HSTSum: { $sum: "$HST" },
        discount: { $sum: "$discount" },
        sliikFee: 0,
        sliikFeeGST: 0,
        sliikFeePST: 0,
        shipping: 0,
      }
    },
    {
      $addFields: {
        totalPSTORQST: {
          $add: ["$PSTSum", "$QSTSum"]
        },
        totalGSTORHST: { $sum: ["$GSTSum", "$HSTSum"] },
      }
    },
    {
      $group: {
        _id: null,
        discount: { $sum: "$discount" },
        productSales: { $sum: "$subTotal" },
        totalGSTORHST: { $sum: '$totalGSTORHST' },
        totalPSTORQST: { $sum: "$totalPSTORQST" },
        totalSliikFees: { $sum: "$sliikFee" },
        totalsliikFeeGST: { $sum: "$sliikFeeGST" },
        totalsliikFeePST: { $sum: "$sliikFeePST" },
        totalShipping: { $sum: "$shipping" },
      }
    }
  ]);

  if (productFinacial.length) {
    productFinacial[0].totalAmountEarned = productFinacial[0].productSales + productFinacial[0].totalGSTORHST + productFinacial[0].totalPSTORQST + productFinacial[0].totalSliikFees + productFinacial[0].totalsliikFeeGST + productFinacial[0].totalsliikFeePST - productFinacial[0].discount;
    productFinacial[0].sllikrevnue = 0
  }

  const count = vendorData.length;
  vendorData = vendorData.slice(offsetData, offsetData + limitData);

  return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, productFinacial, count, vendorData });
});

// For get single product details
const getSingleProductDashboard = catchAsyncError(async (req, res, next) => {
  const { limit, offset, beauticianId, year, startDate, endDate, serach, status, provincId, maxPrice, minPrice, chartSDate, chartEDate } = req.body;
  let proviceQuery = {};
  let productQuery = {};
  let clientQuery = {};

  const limitData = parseInt(limit, 10) || 10;
  const offsetData = parseInt(offset, 10) || 0;

  if (!mongoose.Types.ObjectId.isValid(beauticianId)) {
    throw new ErrorHandler("Plaese enter beautician Id", HttpStatus.BAD_REQUEST);
  }

  // This is for beautician details
  const beauticianData = await Beautician.aggregate([
    { $match: { _id: new mongoose.Types.ObjectId(beauticianId) } },
    {
      $lookup: {
        from: "users",
        localField: "userId",
        foreignField: "_id",
        as: "userDetails",
        pipeline: [
          { $project: { phoneNumber: 1, email: 1, isActiveBeautician: 1, } }
        ],
      }
    },
    {
      $lookup: {
        from: "addresses",
        localField: "address",
        foreignField: "_id",
        as: "addressDetails",
        pipeline: [
          {
            $project: {
              address: { $ifNull: ["$address", null] },
              street: { $ifNull: ["$street", null] },
              apartment: { $ifNull: ["$apartment", null] },
              city: { $ifNull: ["$city", null] },
              zipCode: { $ifNull: ["$zipCode", null] },
            }
          }
        ],
      }
    },
    {
      $project: {
        uid: 1, businessName: 1, createdAt: 1,
        logo: { $ifNull: ["$logo", null] },
        email: { $arrayElemAt: ["$userDetails.email", 0] },
        phoneNumber: { $arrayElemAt: ["$userDetails.phoneNumber", 0] },
        status: { $arrayElemAt: ["$userDetails.isActiveBeautician", 0] },
        address: { $arrayElemAt: ["$addressDetails.address", 0] },
        street: { $arrayElemAt: ["$addressDetails.street", 0] },
        apartment: { $arrayElemAt: ["$addressDetails.apartment", 0] },
        city: { $arrayElemAt: ["$addressDetails.city", 0] },
        zipCode: { $arrayElemAt: ["$addressDetails.zipCode", 0] },
      }
    }
  ]);

  // This is for finacial summary
  const finacialSummary = await Order.aggregate([
    { $match: { "productData.beauticianId": new mongoose.Types.ObjectId(beauticianId) } },
    {
      $addFields: {
        GSTSum: { $sum: "$GST" },
        PSTSum: { $sum: "$PST" },
        QSTSum: { $sum: "$QST" },
        HSTSum: { $sum: "$HST" },
        discount: { $sum: "$discount" },
        sliikFee: 0,
        sliikFeeGST: 0,
        sliikFeePST: 0,
        shipping: 0,
      }
    },
    {
      $addFields: {
        totalPSTORQST: {
          $add: ["$PSTSum", "$QSTSum"]
        },
        totalGSTORHST: { $sum: ["$GSTSum", "$HSTSum"] },
      }
    },
    {
      $group: {
        _id: null,
        discount: { $sum: "$discount" },
        productSales: { $sum: "$subTotal" },
        totalGSTORHST: { $sum: '$totalGSTORHST' },
        totalPSTORQST: { $sum: "$totalPSTORQST" },
        totalSliikFees: { $sum: "$sliikFee" },
        totalsliikFeeGST: { $sum: "$sliikFeeGST" },
        totalsliikFeePST: { $sum: "$sliikFeePST" },
        totalShipping: { $sum: "$shipping" },
      }
    }
  ]);

  if (finacialSummary.length) {
    finacialSummary[0].totalAmountEarned = finacialSummary[0].productSales + finacialSummary[0].totalGSTORHST + finacialSummary[0].totalPSTORQST + finacialSummary[0].totalSliikFees + finacialSummary[0].totalsliikFeeGST + finacialSummary[0].totalsliikFeePST - finacialSummary[0].discount;
    finacialSummary[0].sllikrevnue = 0
  }

  // This is for periodic Statics
  const statics = await BeauticianProduct.aggregate([
    { $match: { beauticianId: new mongoose.Types.ObjectId(beauticianId) } },
    { $project: { numOfShare: 1, numOfAddToCart: 1, numOfViews: 1, } }
  ]);

  const periodicStatics = {
    numOfShare: 0,
    numOfAddToCart: 0,
    numOfViews: 0
  }

  if (statics?.length) {
    statics?.map((val) => {
      if (val.numOfShare) periodicStatics.numOfShare += val.numOfShare;
      if (val.numOfAddToCart) periodicStatics.numOfAddToCart += val.numOfAddToCart;
      if (val.numOfViews) periodicStatics.numOfViews += val.numOfViews;
    })
  }

  //for top Producrts
  let TopProducts = await BeauticianProduct.aggregate([
    {
      $match: { beauticianId: new mongoose.Types.ObjectId(beauticianId) },
    },
    {
      $lookup: {
        from: 'orders',
        localField: '_id',
        foreignField: 'productData.productId',
        as: 'orderDetails',
        pipeline: [
          { $match: { $nor: [{ createdBy: "client", status: 0 }] } },
          { $project: { dateTime: 1, serviceId: 1 } }
        ]
      }
    },
    { $project: { _id: 1, orderDetails: 1, productName: 1, imgName: 1 } }
  ]);

  if (TopProducts.length) {

    const currentMonthStart = moment().startOf('month').format('YYYY-MM-DD');
    const currentMonthEnd = moment().endOf('month').format('YYYY-MM-DD');
    const lastMonthStart = moment().subtract(1, 'months').startOf('month').format('YYYY-MM-DD');
    const lastMonthEnd = moment().subtract(1, 'months').endOf('month').format('YYYY-MM-DD');
    TopProducts = TopProducts.map(product => {
      product.currentMonth = 0;
      product.lastMonth = 0;
      product.orderDetails?.forEach(ele => {
        let formateDate = moment(ele.dateTime).format("YYYY-MM-DD")
        if (formateDate >= currentMonthStart && formateDate <= currentMonthEnd) {
          product.currentMonth = product.currentMonth + 1
        }
        if (formateDate >= lastMonthStart && formateDate <= lastMonthEnd) {
          product.lastMonth = product.lastMonth + 1
        }
      });
      return {
        id: product._id,
        productName: product.productName,
        currentMonth: product.currentMonth,
        lastMonth: product.lastMonth,
        imgName: product.imgName,
      }
    }).sort((a, b) => {
      return (b.currentMonth + b.lastMonth) - (a.currentMonth + a.lastMonth);
    }).slice(0, 4);
  }

  if (startDate && endDate) {
    if (startDate !== "" && endDate !== "") {
      productQuery = {
        $expr: {
          $and: [
            {
              $gte: [
                { $toDate: '$createdAt' },
                { $toDate: startDate }
              ]
            },
            {
              $lte: [
                { $toDate: '$createdAt' },
                { $toDate: endDate }
              ]
            }
          ]
        }
      }
    }
  }

  if (serach) {
    if (serach !== "") {
      clientQuery.$or = [
        { firstName: { $regex: serach, $options: 'i' } },
        { lastName: { $regex: serach, $options: 'i' } },
      ];
    }
  }

  if (provincId) {
    if (provincId !== "") {
      proviceQuery = {
        province: new mongoose.Types.ObjectId(provincId)
      }
    }
  }
  // This is for product sales reports
  let productSales = await Order.aggregate([
    { $match: { "productData.beauticianId": new mongoose.Types.ObjectId(beauticianId) } },
    { $match: productQuery },
    {
      $unwind: "$productData",
    },
    {
      $lookup: {
        from: 'beauticianproducts',
        localField: 'productData.productId',
        foreignField: "_id",
        as: 'productDetails',
        pipeline: [
          { $project: { productName: 1 } }
        ]
      },
    },
    {
      $lookup: {
        from: 'clients',
        localField: 'clientId',
        foreignField: "_id",
        pipeline: [
          { $match: clientQuery },
          { $project: { firstName: 1, lastName: 1 } }
        ],
        as: 'clientDetails',
      },
    },
    { $match: { clientDetails: { $gt: {} } } },
    {
      $lookup: {
        from: 'addresses',
        localField: 'shippingAddressId',
        foreignField: "_id",
        pipeline: [
          { $match: proviceQuery },
          { $project: { province: 1 } }
        ],
        as: 'paymentAddress',
      },
    },
    { $match: { paymentAddress: { $gt: {} } } },
    {
      $lookup: {
        from: 'addresses',
        localField: 'shippingAddressId',
        foreignField: "_id",
        as: 'addressDetails',
        pipeline: [
          {
            $project: {
              address: { $ifNull: ["$address", null] },
              street: { $ifNull: ["$street", null] },
              apartment: { $ifNull: ["$apartment", null] },
              city: { $ifNull: ["$city", null] },
              zipCode: { $ifNull: ["$zipCode", null] },
            }
          }
        ]
      },
    },
    {
      $project: {
        beauticianId: { $ifNull: ["$productData.beauticianId", 0] },
        productName: { $arrayElemAt: ['$productDetails.productName', 0] },
        clientFirstName: { $arrayElemAt: ['$clientDetails.firstName', 0] },
        clientLastName: { $arrayElemAt: ['$clientDetails.lastName', 0] },
        productPrice: { $ifNull: ["$productData.price", 0] },
        totalQuantity: { $ifNull: ["$productData.totalQuantity", 0] },
        productDiscount: { $ifNull: ["$productData.discount", 0] },
        productPurchaseDate: { $ifNull: ["$createdAt", 0] },
        deliveredDate: { $ifNull: ["$createdAt", 0] },
        orderStatus: { $ifNull: ["$orderStatus", "pending"] },
        addressDetails: 1,
        shippingCharge: { $ifNull: ["$shippingCharge", 0] },
        GstInPer: 1, PstInPer: 1, HstInPer: 1, QstInPer: 1,
      }
    }
  ]);

  if (productSales.length) {
    await productSales.forEach(async (val) => {
      const GSTTAX = val?.GstInPer;
      const PSTTAX = val?.PstInPer;
      const HSTTAX = val?.HstInPer;
      const QSTTAX = val?.QstInPer;

      let tempPrice = val.productPrice * val.totalQuantity;
      tempPrice = tempPrice - val.productDiscount;

      const total = tempPrice + tempPrice * (GSTTAX / 100) + tempPrice * (HSTTAX / 100) + tempPrice * (QSTTAX / 100) + tempPrice * (PSTTAX / 100);
      // const sllikFee = (tempPrice - val.discount) / 10;

      val.TotalPrice = total;
      val.subTotal = tempPrice;
      val.sliikFee = 0;
      val.sliikFeeGST = 0;
      val.sliikFeePST = 0;
      val.sliikFeeHST = 0;
      val.sliikFeeQST = 0;
      val.GST = (tempPrice * (GSTTAX / 100))
      val.PST = (tempPrice * (PSTTAX / 100))
      val.HST = (tempPrice * (HSTTAX / 100))
      val.QST = (tempPrice * (QSTTAX / 100))
    });
  }

  if (maxPrice && minPrice) {
    if (maxPrice !== null && minPrice !== null) {
      if (productSales.length) {
        productSales = productSales.filter((val) => {
          if (val.subTotal >= parseInt(minPrice) && val.subTotal <= parseInt(maxPrice)) {
            if (val !== null) {
              return val;
            }
          }
        });
      }
    }
  }

  const productCount = productSales.length;
  productSales = productSales.slice(offsetData, offsetData + limitData);
  let chartFilter = { paymentStatus: 1 };
  if (chartSDate && chartEDate) {
    if (chartSDate !== "" && chartEDate !== "") {
      chartFilter.$expr = {
        $and: [
          {
            $gte: [
              { $toDate: '$createdAt' },
              { $toDate: chartSDate }
            ]
          },
          {
            $lte: [
              { $toDate: '$createdAt' },
              { $toDate: chartEDate }
            ]
          }
        ]
      };
    }
  }

  // This is for product sales chart
  const productSalesChart = await Order.aggregate([
    { $match: chartFilter },
    { $match: { "productData.beauticianId": new mongoose.Types.ObjectId(beauticianId) } },
  ]);

  let salesChart = [];
  if (productSalesChart.length) {
    const currentYear = year || moment().year();
    let servicesValue = []
    for (let month = 0; month < 12; month++) {

      const startDate = moment().year(currentYear).month(month).startOf('month').format('YYYY-MM-DD');
      const endDate = moment().year(currentYear).month(month).endOf('month').format('YYYY-MM-DD');

      // Filter productSalesChart within the current month
      const productData = productSalesChart.filter(ele => {
        let formateDate = moment(ele.createdAt).format("YYYY-MM-DD")
        return formateDate >= startDate && formateDate <= endDate
      })
      // Count the productSalesChart for the current month
      const count = productData.length;
      // Store the count in the servicesValue array
      servicesValue.push(count);
    }

    salesChart = monthCounts.map((ele, i) => {
      return {
        month: ele,
        services: servicesValue[i],
      }
    });
  }

  return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, beauticianData, finacialSummary, periodicStatics, TopProducts, productCount, productSales, salesChart });
});

module.exports = { updateProductRecomandedStatus, getProductDashord, getSingleProductDashboard }