const catchAsyncError = require("../../middleware/catchAsyncError");
const Packages = require("../../models/Packages");
const HttpStatus = require("../../utils/HttpStatus");


const addPackageDetail = catchAsyncError(async (req, res, next) => {
    const NewPackage = await Packages.create(req.body);
    if (NewPackage) {
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Package Detail added successfully." });
    }

});

const getAllPackageList = catchAsyncError(async (req, res, next) => {
    const AllPackageDetails = await Packages.find().select("-__v");
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Package Details", data: AllPackageDetails });
});

const updatePackageDetail = catchAsyncError(async (req, res, next) => {
    const { packageId } = req.params;
    const packageDetails = await Packages.findByIdAndUpdate(packageId, req.body);
    if (packageDetails) {
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Package Detail updated successfully." });
    }
})
module.exports = { addPackageDetail, getAllPackageList, updatePackageDetail }