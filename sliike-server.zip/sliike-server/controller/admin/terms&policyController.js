const HttpStatus = require("../../utils/HttpStatus");
const catchAsyncError = require("../../middleware/catchAsyncError");
const Terams = require("../../models/Terms");
const mongoose = require("mongoose");
const ErrorHandler = require("../../utils/ErrorHandling");
const { validationResult } = require("express-validator");

// add Terms data
const addTerms = catchAsyncError(async (req, res, next) => {
    const {terms,policy,language} = req.body;

    const errors = validationResult(req);

    if (errors.errors.length !== 0) {
        throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST);
    };
    
    const data = await Terams.create({terms,policy,language});

    return res.status(HttpStatus.OK).json({status:HttpStatus.OK,success:true,message:"Added successfully."});
});

// Get terms data
const getTerms = catchAsyncError(async(req,res,next)=>{    
    const data = await Terams.find();
    return res.status(HttpStatus.OK).json({status:HttpStatus.OK,success:true,data});
});

const getTermsAndPolicy = catchAsyncError(async(req,res,next)=>{
    const {language,type} = req.body;

    const data = await Terams.find({language})
    .select(type);

    return res.status(HttpStatus.OK).json({status:HttpStatus.OK,success:true,data});
});

// Update Terms data
const updateTerms = catchAsyncError(async(req,res,next)=>{
    const {Id} = req.params;
    const {terms,policy} = req.body;
    const data = await Terams.findOne({_id:Id});

    if(!data){
        return res.status(HttpStatus.OK).json({status:HttpStatus.OK,success:true,message:"Terms not found"});
    }

    await Terams.findByIdAndUpdate({_id:Id},{terms,policy});

    return res.status(HttpStatus.OK).json({status:HttpStatus.OK,success:true,message:"Tearms and Policy updated successfully"});
});

module.exports = { addTerms,getTerms,updateTerms,getTermsAndPolicy};