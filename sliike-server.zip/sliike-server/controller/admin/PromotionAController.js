const catchAsyncError = require("../../middleware/catchAsyncError");
const Beautician = require("../../models/Beautician");
const Promotion = require("../../models/Promotion");
const HttpStatus = require("../../utils/HttpStatus");
const ErrorHandler = require("../../utils/ErrorHandling");
const Referral = require("../../models/Referral");
const { default: mongoose } = require("mongoose");

const getBusinessNameList = catchAsyncError(async (req, res, next) => {
    const beauticianList = await Beautician.find({ isDeleted: 0, screenStatus: 7 }).select("businessName");
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, data: beauticianList });
})

const getPromotionList = catchAsyncError(async (req, res, next) => {
    const { time } = req.params;
    const { promotionFor, search, limit, offset } = req.query;
    isValidFor = ["service", "product", "all"]
    if (!isValidFor.includes(promotionFor)) {
        throw new ErrorHandler("Not found on server", HttpStatus.NOT_FOUND, false)
    }
    let searchQuery;
    let findQuery = { createdBy: 'admin' };

    // filter for time
    if (time === "past") {
        if (promotionFor === "all") {
            throw new ErrorHandler(`promotionFor:${promotionFor} is not valid for past`, HttpStatus.BAD_REQUEST, false)
        }
        findQuery.endDate = { $lte: new Date() };
        findQuery.promotionFor = promotionFor;
    } else if (time === "current") {
        findQuery.endDate = { $gte: new Date() }
    }

    const pipeline = [
        { $match: findQuery },
        {
            $lookup: {
                from: 'beauticians',
                foreignField: '_id',
                localField: 'beauticianId',
                as: 'beauticianData',
                pipeline: [{ $project: { businessName: 1 } }]
            }
        },
        {
            $project: {
                promotionFor: 1,
                promotionTitle: 1,
                subId_type: 1,
                serviceName: 1,
                description: 1,
                isDiscPercentage: 1,
                discount: 1,
                startDate: 1,
                endDate: 1,
                referenceCode: 1,
                businessName: { $arrayElemAt: ['$beauticianData.businessName', 0] }
            }
        },
    ]
    //filter for search value
    if (search) {
        searchQuery = { $match: { 'beauticianData.businessName': { $regex: search, $options: 'i' } } }
        pipeline.splice(pipeline.length - 1, 0, searchQuery);
    }

    const promotionList = await Promotion.aggregate(pipeline);
    let limitedPromotionList = promotionList;
    if (time === "past" && promotionList.length) {
        let offsetData = offset || 0;
        let limitData = limit || 10
        limitedPromotionList = promotionList.slice(offsetData, offsetData + limitData);
    }
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { totalData: promotionList?.length, promotionList: limitedPromotionList } })
})

// for get referrals 
const getReferrals = catchAsyncError(async (req, res, next) => {
    const data = await Referral.aggregate([
        {
            $lookup: {
                from: 'beauticians',
                localField: 'referralId',
                foreignField: "_id",
                as: 'referralData',
                pipeline: [
                    { $project: { businessName: 1, } }
                ]
            },
        },
        {
            $project: {
                referralId: 1, referralCode: 1, createdAt: 1, businessName: { $arrayElemAt: ['$referralData.businessName', 0] },
            }
        },
        {
            $group: {
                _id: '$referralId', // Grouping by referralId
                referralData: { $first: '$referralData' }, // Taking the first occurrence of referralData
                data: { $first: '$$ROOT' } // Taking the first occurrence of the entire document
            }
        },
        { $replaceRoot: { newRoot: '$data' } }
    ]);

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data });
});

// for get recipients 
const getRecipients = catchAsyncError(async (req, res, next) => {
    const { referralId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(referralId)) {

    }
    const data = await Referral.aggregate([
        { $match: { referralId: new mongoose.Types.ObjectId(referralId) } },
        {
            $lookup: {
                from: 'users',
                localField: 'userId',
                foreignField: "_id",
                as: 'userData',
            },
        },
        {
            $lookup: {
                from: 'clients',
                localField: 'userData._id',
                foreignField: "userId",
                as: 'clientData',
                pipeline: [
                    { $project: { firstName: 1, lastName: 1, } }
                ]
            },
        },
        {
            $lookup: {
                from: 'beauticians',
                localField: 'userData._id',
                foreignField: "userId",
                as: 'beauticainData',
                pipeline: [
                    { $project: { firstName: 1, lastName: 1, } }
                ]
            },
        },
        {
            $project: {
                referralId: 1, referralCode: 1,
                appDownloadDate: { $arrayElemAt: ['$userData.activateAsUserDate', 0] },
                firstName: {
                    $ifNull: [
                        { $arrayElemAt: ['$clientData.firstName', 0] },
                        { $arrayElemAt: ['$beauticainData.firstName', 0] },
                    ],
                },
                lastName: {
                    $ifNull: [
                        { $arrayElemAt: ['$clientData.lastName', 0] },
                        { $arrayElemAt: ['$beauticainData.lastName', 0] },
                    ],
                }
            }
        }
    ]);

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data });
});
module.exports = { getBusinessNameList, getPromotionList, getReferrals, getRecipients }