const catchAsyncError = require("../../middleware/catchAsyncError");
const ErrorHandler = require("../../utils/ErrorHandling");
const HttpStatus = require("../../utils/HttpStatus");
const Admin = require("../../models/Admin");
const formidable = require("formidable");
const bcrypt = require("bcrypt");
const { generateAdminId } = require("../../utils/generateNumericId");
const { pathEndpoint } = require("../../utils/Constant");
const { v4: uuidv4 } = require('uuid');
const { uploadFile } = require("../../libs/aws/uploadImg");
const { default: mongoose } = require("mongoose");

// for add admins
const addAdmin = catchAsyncError(async (req, res, next) => {
    const adminRole = req.role;
    const form = formidable({ multiples: true });

    form.parse(req, async (err, fields, files) => {
        const adminCount = await Admin.findOne({}).sort({ createdAt: -1 }).select({ uid: 1 });
        let tempId = "";
        if (!adminCount) {
            tempId = "SLKA-0000000";
        } else {
            tempId = adminCount.uid;
        }
        const adminUid = await generateAdminId(tempId);
        const { firstName, lastName, phoneNumber, role, email, password, dashboardSettings, beauticianSettings, clientSettings, productSettings, brandSettings, gistSettings, promotionSettings, adminSettings } = fields;
        if (adminRole == "superAdmin") {
            if (!firstName) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please enter first name" });
            if (!lastName) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please enter last name" });
            if (role !== "superAdmin" && role !== "subAdmin") return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please enter valid role" });
            if (!email) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please enter email" });
            // if (!phoneNumber) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please enter phone number" });
            if (!password) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please enter password" });
            if (!dashboardSettings) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please select dashboard Settings" });
            if (!beauticianSettings) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please select beautician Settings" });
            if (!clientSettings) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please select client Settings" });
            if (!productSettings) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please select product Settings" });
            if (!brandSettings) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please select brand Settings" });
            if (!gistSettings) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please select gist Settings" });
            if (!promotionSettings) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please select promotion Settings" });
            if (!adminSettings) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please select admins Settings" });

            const alreadyExists = await Admin.findOne({ email, isDeleted: 0 });
            if (alreadyExists) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Email is already exists" });
            }

            const settings = [dashboardSettings, beauticianSettings, clientSettings, productSettings, brandSettings, gistSettings, promotionSettings, adminSettings]

            if (settings.length) {
                const data = settings.map((val) => {
                    if (val[0].all != 0 && val[0].all != 1) {
                        return false;
                    } else if (val[0].viewOnly != 0 && val[0].viewOnly != 1) {
                        return false;
                    } else if (val[0].viewAndDownload != 0 && val[0].viewAndDownload != 1) {
                        return false;
                    }
                })
                if (data.includes(false)) {
                    return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please enter valid setting values" });
                }
            }

            let profileImage = ""
            if (files.profileImage) {
                const { mimetype } = files.profileImage;
                const img = mimetype.split("/");
                const extension = img[1].toLowerCase();
                if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                    return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: `${extension} is not allowed..` });
                }
                const fileName = (files.profileImage.originalFilename = uuidv4() + "." + extension);
                const newPath = `${pathEndpoint.adminProfile}${fileName}`;
                try {
                    const uploadImgRes = await uploadFile(files.profileImage, newPath, extension);
                    profileImage = uploadImgRes.imageUrl;
                } catch (error) {
                    return res.status(HttpStatus.ERROR).json({
                        status: HttpStatus.ERROR,
                        success: false,
                        message: 'Something went wrong in Image upload. Please try again',
                    });
                }
            }
            const hashedPassword = await bcrypt.hash(password, 10);
            await Admin.create({ uid: adminUid, firstName, lastName, phoneNumber, role, email, profileImage, password: hashedPassword, dashboardSettings, beauticianSettings, clientSettings, productSettings, brandSettings, gistSettings, promotionSettings, adminSettings });

            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: false, message: "admin added successfully" });
        } else {
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: false, message: "You are not aunticated to add sub-admins" });
        }
    })
});

// for get Admins
const getAdmins = catchAsyncError(async (req, res, next) => {
    const Id = req.admin;
    const { search, type } = req.query;
    let findQuery = {
        isDeleted: 0, _id: { $ne: Id }, isDeleted: 0
    }

    if (search) {
        if (search !== "") {
            findQuery = {
                $or: [
                    { firstName: { $regex: search, $options: 'i' } },
                    { lastName: { $regex: search, $options: 'i' } },
                ]
            }
        }
    }

    if (type) {
        if (type == "archive") {
            findQuery = {
                ...findQuery,
                isDeleted: 1
            }
        }
    }

    const data = await Admin.aggregate([
        { $match: findQuery },
        {
            $project: {
                firstName: 1, lastName: 1, uid: 1, role: 1, status: 1,
                profileImage: { $ifNull: ["$profileImage", null] }
            }
        }
    ])

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data })
});

// For change status
const changeAdminStatus = catchAsyncError(async (req, res, next) => {
    const { adminId, status } = req.body;

    if (!mongoose.Types.ObjectId.isValid(adminId)) {
        throw new ErrorHandler("Please enter valid admin Id", HttpStatus.BAD_REQUEST);
    }

    if (status != 0 && status != 1) {
        throw new ErrorHandler("Please enter valid status", HttpStatus.BAD_REQUEST);
    }

    const adminData = await Admin.findOne({ _id: adminId });

    if (adminData) {
        adminData.status = status;
        await adminData.save();
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "status changes successfully" });
    } else {
        throw new ErrorHandler("Admin details not found", HttpStatus.BAD_REQUEST);
    }
});

// update admin profile API
const chnageAdminProfile = catchAsyncError(async (req, res, next) => {
    const form = formidable({ multiples: true });

    form.parse(req, async (err, fields, files) => {
        const { adminId, firstName, lastName, phoneNumber, role, email } = fields;

        if (!mongoose.Types.ObjectId.isValid(adminId)) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please enter valid admin Id" })
        }
        if (!firstName) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please enter first name" });
        if (!lastName) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please enter last name" });
        if (role !== "superAdmin" && role !== "subAdmin") return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please enter valid role" });
        if (!email) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please enter email" });

        const adminData = await Admin.findOne({ _id: adminId });
        if (adminData) {
            adminData.firstName = firstName;
            adminData.lastName = lastName;
            adminData.phoneNumber = phoneNumber;
            adminData.email = email;
            adminData.role = role;
            if (files.profileImage) {
                const { mimetype } = files.profileImage;
                const img = mimetype.split("/");
                const extension = img[1].toLowerCase();
                if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                    return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: `${extension} is not allowed..` });
                }
                const fileName = (files.profileImage.originalFilename = uuidv4() + "." + extension);
                const newPath = `${pathEndpoint.adminProfile}${fileName}`;
                try {
                    const uploadImgRes = await uploadFile(files.profileImage, newPath, extension);
                    adminData.profileImage = uploadImgRes.imageUrl;
                } catch (error) {
                    return res.status(HttpStatus.ERROR).json({
                        status: HttpStatus.ERROR,
                        success: false,
                        message: 'Something went wrong in Image upload. Please try again',
                    });
                }
            }
            await adminData.save();
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Details updated successfully" });
        } else {
            throw new ErrorHandler("Admin details not found", HttpStatus.BAD_REQUEST);
        }
    })
});

// for update accessibility settings.
const changeSettings = catchAsyncError(async (req, res, next) => {
    const { adminId, dashboardSettings, beauticianSettings, clientSettings, productSettings, brandSettings, gistSettings, promotionSettings, adminSettings } = req.body;
    if (!mongoose.Types.ObjectId.isValid(adminId)) {
        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please enter valid admin Id" })
    }
    if (!dashboardSettings) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please select dashboard Settings" });
    if (!beauticianSettings) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please select beautician Settings" });
    if (!clientSettings) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please select client Settings" });
    if (!productSettings) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please select product Settings" });
    if (!brandSettings) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please select brand Settings" });
    if (!gistSettings) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please select gist Settings" });
    if (!promotionSettings) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please select promotion Settings" });
    if (!adminSettings) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please select admins Settings" });

    const adminData = await Admin.findOne({ _id: adminId });
    if (adminData) {
        const settings = [dashboardSettings, beauticianSettings, clientSettings, productSettings, brandSettings, gistSettings, promotionSettings, adminSettings]

        if (settings.length) {
            const data = settings.map((val) => {
                if (val[0]?.all != 0 && val[0]?.all != 1) {
                    return false;
                } else if (val[0]?.viewOnly != 0 && val[0]?.viewOnly != 1) {
                    return false;
                } else if (val[0]?.viewAndDownload != 0 && val[0]?.viewAndDownload != 1) {
                    return false;
                }
            })
            if (data.includes(false)) {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please enter valid setting values" });
            }
        }

        adminData.dashboardSettings = dashboardSettings;
        adminData.beauticianSettings = beauticianSettings;
        adminData.clientSettings = clientSettings;
        adminData.productSettings = productSettings;
        adminData.brandSettings = brandSettings;
        adminData.brandSettings = brandSettings;
        adminData.gistSettings = gistSettings;
        adminData.promotionSettings = promotionSettings;
        adminData.adminSettings = adminSettings;

        await adminData.save();
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: false, message: "Settings changed successfully" });
    } else {
        throw new ErrorHandler("Admin details not found", HttpStatus.BAD_REQUEST);
    }
});

module.exports = { addAdmin, getAdmins, changeAdminStatus, chnageAdminProfile, changeSettings }