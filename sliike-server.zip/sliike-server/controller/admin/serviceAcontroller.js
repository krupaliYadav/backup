const catchAsyncError = require("../../middleware/catchAsyncError");
const Beautician = require("../../models/Beautician");
const User = require("../../models/User");
const Client = require("../../models/Client");
const ErrorHandler = require("../../utils/ErrorHandling");
const HttpStatus = require("../../utils/HttpStatus");
const { default: mongoose } = require("mongoose");
const Appointment = require("../../models/Appointment");
const Payment = require("../../models/Payment");
const { getServiceFinancialAndDetails } = require("./beauticianAController");
const { getTopServices, getAppointCountByYearForBarChart } = require("../beautician/reportController");
const BeauticianService = require("../../models/BeauticianService");
const platform_fees = process.env.PLATFORM_FEES || 0.10;
const moment = require("moment");
const Appoiement = require("../../models/Appointment")
const getServicesDetails = catchAsyncError(async (req, res, next) => {
  const { limit, offset, search, category, type, chartSDate, chartEDate } = req.body;
  let matchQuery = { $and: [] };
  let categoryQuery = {};
  let categoryQuery1 = {};
  const limitData = parseInt(limit, 10) || 10;
  const offsetData = parseInt(offset, 10) || 0;

  if (search !== "") {
    matchQuery.$and = [...matchQuery.$and,
    { businessName: { $regex: search, $options: 'i' } },
    ];
  }

  if (category !== "") {
    categoryQuery = { $and: [{ _id: new mongoose.Types.ObjectId(category) },] }
    categoryQuery1 = { serviceName: { $gt: [] } }
  }

  if (type == "") {
    matchQuery.$and = [...matchQuery.$and,
    { isDeleted: 0 },
    ];
  }
  if (type === "archive") {
    matchQuery.$and = [...matchQuery.$and,
    { isDeleted: 1 },
    ];
  }
  if (type === "unarchive") {
    matchQuery.$and = [...matchQuery.$and,
    { isDeleted: 0 },
    ];
  }

  let chartFilter = { paymentStatus: 1 };
  if (chartSDate && chartEDate) {
    if (chartSDate !== "" && chartEDate !== "") {
      chartFilter.$expr = {
        $and: [
          {
            $gte: [
              { $toDate: '$createdAt' },
              { $toDate: chartSDate }
            ]
          },
          {
            $lte: [
              { $toDate: '$createdAt' },
              { $toDate: chartEDate }
            ]
          }
        ]
      };
    }
  }
  const serviceTransction = await Payment.aggregate([
    { $match: chartFilter },
    {
      $addFields: {
        GSTSum: { $sum: "$GST" },
        PSTSum: { $sum: "$PST" },
        QSTSum: { $sum: "$QST" },
        HSTSum: { $sum: "$HST" },
        sliikFee: 0,
        // sliikFee: { $multiply: ["$subTotal", parseFloat(platform_fees)] },
        sliikFeeGST: 0,
        // sliikFeeGST: { $sum: [{ $round: [{ $multiply: ['$subTotal', parseFloat(platform_fees), "$GstInPer", 0.01] }, 2] }, { $round: [{ $multiply: ['$subTotal', parseFloat(platform_fees), "$HstInPer", 0.01] }, 2] }] },
        sliikFeePST: 0,
        // sliikFeePST: { $sum: [{ $round: [{ $multiply: ['$sunTotal', parseFloat(platform_fees), "$PstInPer", 0.01] }, 2] }, { $round: [{ $multiply: ['$sunTotal', parseFloat(platform_fees), "$QstInPer", 0.01] }, 2] }] },
        discount: { $round: [{ $multiply: ["$sunTotal", "$discount", 0.01] }, 2] },
      }
    },
    {
      $addFields: {
        totalPSTORQST: {
          $add: ["$PSTSum", "$QSTSum"]
        },
        totalGSTORHST: { $sum: ["$GSTSum", "$HSTSum"] },
      }
    },
    {
      $group: {
        _id: null,
        discount: { $sum: "$discount" },
        totalSubTotal: { $sum: "$subTotal" },
        totalGSTORHST: { $first: '$totalGSTORHST' },
        totalPSTORQST: { $first: "$totalPSTORQST" },
        totalSliikFees: { $sum: "$sliikFee" },
        totalsliikFeeGST: { $sum: "$sliikFeeGST" },
        totalsliikFeePST: { $sum: "$sliikFeePST" },
        // totalSliikRevenue: { $sum: "$sliikFee" },
      }
    }
  ]);

  let tempData = [
    { $match: matchQuery },
    { $match: { screenStatus: 7 } },
    {
      $lookup: {
        from: 'beauticianservices',
        localField: 'beauticianServiceId',
        foreignField: "_id",
        as: 'serviceDetails',
      }
    },
    {
      $lookup: {
        from: 'appointments',
        localField: '_id',
        foreignField: "beauticianId",
        as: 'appoiementDetails',
      }
    },
    {
      $addFields:
      {
        pendingDetails: {
          $filter: {
            input: '$appoiementDetails',
            as: 'appoiement',
            cond: {
              $and: [
                { $eq: ['$$appoiement.status', 1] },
                { $gte: ['$$appoiement.dateTime', new Date()] }
              ]
            }
          }
        },
        deliverDetails: {
          $filter: {
            input: '$appoiementDetails',
            as: 'deliever',
            cond: {
              $and: [
                { $eq: ['$$deliever.status', 2] },
              ]
            }
          }
        },
        cancelDetails: {
          $filter: {
            input: '$appoiementDetails',
            as: 'cancel',
            cond: {
              $or: [
                { $eq: ['$$cancel.status', 3] },
                { $eq: ['$$cancel.status', 4] },
              ]
            }
          }
        },
        notShowDetails: {
          $filter: {
            input: '$appoiementDetails',
            as: 'cancel',
            cond: {
              $and: [
                { $eq: ['$$cancel.status', 5] },
              ]
            }
          }
        },
      },
    },
    {
      $lookup: {
        from: 'servicecategorylists',
        localField: 'serviceDetails.serviceCategory',
        foreignField: "_id",
        as: 'serviceName',
        pipeline: [
          { $match: categoryQuery },
          { $project: { serviceCategoryName: 1, serviceCategoryName_fr: 1, } }
        ]
      }
    },
    { $addFields: { totalService: { $size: "$serviceDetails" } } },
    { $addFields: { pending: { $size: "$pendingDetails" } } },
    { $addFields: { delieverd: { $size: "$deliverDetails" } } },
    { $addFields: { cancelled: { $size: "$cancelDetails" } } },
    { $addFields: { noShow: { $size: "$notShowDetails" } } },
    { $sort: { createdAt: -1 } },
    { $match: categoryQuery1 },
    {
      $addFields: {
        profileImageURL: '$profileImage'
      }
    },
    { $project: { pendingDetails: 0, appoiementDetails: 0, notShowDetails: 0, cancelDetails: 0, deliverDetails: 0, serviceDetails: 0, profileImage: 0 } },
  ]

  const countData = await Beautician.aggregate(tempData);
  const count = countData.length;

  tempData.push({ $skip: offsetData }, { $limit: limitData });
  const data = await Beautician.aggregate(tempData);

  res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, allServices: { count, serviceTransction, data } });
});
const getServiceDashboard = catchAsyncError(async (req, res, next) => {
  const { beauticianId, chartForYear, categoryId, provinceId, demographyId, startDate, endDate, gender, orderStatus, offset, limit, search } = req.body;

  let dateSearch = {};
  let categoryWhere = {};
  let provinceWhere = {};
  let appoiementWhere = {};
  let matchQuery = {};

  if (beauticianId) {
    if (!mongoose.Types.ObjectId.isValid(beauticianId)) {
      throw new ErrorHandler("Beautician Id missing.", HttpStatus.BAD_REQUEST, false)
    }
    if (chartForYear && !moment(chartForYear, "YYYY").isValid()) {
      throw new ErrorHandler("Invalid Year formate.", HttpStatus.BAD_REQUEST, false);
    }
    const { beauticiandata, serviceFinacial } = await getServiceFinancialAndDetails(beauticianId);
    const { TopServices } = await getTopServices(beauticianId, 4);
    const startOfYear = moment(chartForYear, 'YYYY').startOf('year').toDate();
    const endOfYear = moment(chartForYear, 'YYYY').endOf('year').toDate();


    const PaymentList = await Payment.aggregate([
      {
        $match: {
          createdAt: {
            $gte: startOfYear,
            $lte: endOfYear
          },
          paymentStatus: 1
        }
      }
    ]);
    // count revenue monthly
    let monthCount = []
    if (PaymentList.length) {
      const currentYear = chartForYear || moment().year();
      for (let month = 0; month < 12; month++) {
        const startDate = moment().year(currentYear).month(month).startOf('month').format('YYYY-MM-DD');
        const endDate = moment().year(currentYear).month(month).endOf('month').format('YYYY-MM-DD');
        // Filter PaymentList within the current month
        const PaymentListData = PaymentList.filter(ele => {
          let formateDate = moment(ele.createdAt).format("YYYY-MM-DD")
          return formateDate >= startDate && formateDate <= endDate
        })
        // Count the PaymentList for the current month
        let amountSum = 0;
        if (PaymentListData.length) {
          PaymentListData.forEach(payAmt => {
            let platformFees = payAmt.subTotal * platform_fees
            amountSum = amountSum + platformFees + (platformFees * (payAmt.GstInPer + payAmt.PstInPer + payAmt.HstInPer + payAmt.QstInPer) * 0.01)
          })
        }
        const count = PaymentListData.length;
        // Store the count in the monthCount array
        monthCount.push(amountSum.toFixed(2));
      }
    }
    const servicesCount = await BeauticianService.aggregate([
      {
        $match: { beauticianId: new mongoose.Types.ObjectId(beauticianId), isDelete: 0 },
      },
      {
        $group: {
          _id: null,
          nubOfCartClicked: { $sum: '$nubOfCartClicked' },
          nubOfView: { $sum: '$nubOfView' }
        }
      },
    ]);
    const clickCountList = {
      nubOfShareClicked: beauticiandata?.[0]?.nubOfShareClicked,
      nubOfCartClicked: servicesCount?.[0]?.nubOfCartClicked,
      nubOfView: servicesCount?.[0]?.nubOfView
    }

    // filter for service sales summary
    if (startDate && endDate) {
      if (startDate !== "" && endDate !== "") {
        dateSearch = {
          $expr: {
            $and: [
              {
                $gte: [
                  { $toDate: '$dateTime' },
                  { $toDate: startDate }
                ]
              },
              {
                $lte: [
                  { $toDate: '$dateTime' },
                  { $toDate: endDate }
                ]
              }
            ]
          }
        }
      }
    }

    if (categoryId) {
      if (categoryId !== "") {
        categoryWhere = { serviceCategory: new mongoose.Types.ObjectId(categoryId) }
      }
    }

    if (provinceId) {
      if (provinceId !== "") {
        provinceWhere = {
          province: new mongoose.Types.ObjectId(provinceId)
        }
      }
    }
    const today = new Date();
    if (orderStatus) {
      if (orderStatus !== "") {
        appoiementWhere = { status: orderStatus }
        if (orderStatus == 1) {// filter for upcoming
          appoiementWhere = { dateTime: { $gte: today } }
        } else if (orderStatus == 2) {//filter for completed 
          appoiementWhere = { status: 2 }
        } else if (orderStatus == 3) { // filter for cancel
          appoiementWhere = { status: { $in: [3, 4] } }
        } else if (orderStatus == 4) { //check for no-show
          appoiementWhere = { status: 5 }
        }
      }
    }

    if (gender) {
      if (gender !== "" && (gender === 'Male' || gender === 'Female')) matchQuery.gender = gender
    }

    if (search) {
      if (search !== "") {
        matchQuery.$or = [
          { firstName: { $regex: search, $options: 'i' } },
          { lastName: { $regex: search, $options: 'i' } },
        ];
      }
    }

    // for get service sales summary
    let serviceSales = await Appoiement.aggregate([
      { $match: { beauticianId: new mongoose.Types.ObjectId(beauticianId) } },
      { $match: dateSearch },
      { $match: appoiementWhere },
      {
        $lookup: {
          from: 'beauticianservices',
          localField: 'serviceId',
          foreignField: "_id",
          pipeline: [
            { $match: categoryWhere },
            { $project: { serviceCategory: 1, beauticianId: 1, serviceType: 1, price: 1, duration: 1 } }
          ],
          as: 'serviceDetails',
        },
      },
      { $match: { serviceDetails: { $gt: [] } } },
      {
        $lookup: {
          from: 'clients',
          localField: 'clientId',
          foreignField: "_id",
          pipeline: [
            { $match: matchQuery },
            { $project: { firstName: 1, lastName: 1, country: 1 } }
          ],
          as: 'clientDetails',
        },
      },
      { $match: { clientDetails: { $gt: [] } } },
      // {
      //   $lookup: {
      //     from: 'beauticians',
      //     localField: 'beauticianId',
      //     foreignField: "_id",
      //     as: 'beauticianDetails',
      //     pipeline: [
      //       { $project: { firstName: 1, lastName: 1, country: 1, businessName: 1, businessNumber: 1, address: 1 } }
      //     ]
      //   },
      // },
      // {
      //   $lookup: {
      //     from: 'addresses',
      //     localField: 'beauticianDetails.address',
      //     foreignField: "_id",
      //     as: 'beauticianAddress',
      //     pipeline: [
      //       { $project: { address: 1, province: 1, apartment: 1, city: 1, zipCode: 1, } }
      //     ]
      //   },
      // },
      {
        $unwind: { path: '$serviceDetails', preserveNullAndEmptyArrays: true },
      },
      {
        $lookup: {
          from: 'servicetypelists',
          localField: 'serviceDetails.serviceType',
          foreignField: "_id",
          pipeline: [
            { $project: { serviceTypeName: 1, serviceTypeName_fr: 1, } }
          ],
          as: 'typeDetails',
        },
      },
      {
        $lookup: {
          from: 'payments',
          localField: 'paymentDetails',
          foreignField: "_id",
          as: 'paymentDetails',
        },
      },
      {
        $lookup: {
          from: 'addresses',
          localField: 'paymentDetails.addressId',
          foreignField: "_id",
          pipeline: [
            { $match: provinceWhere },
            { $project: { address: 1, street: 1, apartment: 1 } }
          ],
          as: 'userAddress',
        },
      },
      { $match: { userAddress: { $gt: [] } } },
      {
        $project: {
          serviceName: { $arrayElemAt: ['$typeDetails.serviceTypeName', 0] },
          clientFirstName: { $arrayElemAt: ['$clientDetails.firstName', 0] },
          clientLastName: { $arrayElemAt: ['$clientDetails.lastName', 0] },
          dateTime: 1, endDateTime: 1, place: 1, status: 1, paymentDetails: 1,
          servicePrice: { $ifNull: ['$price', 0] },
          discount: 1
        }
      }
    ]);

    if (serviceSales.length) {
      await serviceSales.forEach(async (val) => {
        if (val.paymentDetails.length) {
          const GSTTAX = val?.paymentDetails[0]?.GstInPer;
          const PSTTAX = val?.paymentDetails[0]?.PstInPer;
          const HSTTAX = val?.paymentDetails[0]?.HstInPer;
          const QSTTAX = val?.paymentDetails[0]?.QstInPer;

          const total = val.servicePrice + val.servicePrice * (GSTTAX / 100) + val.servicePrice * (HSTTAX / 100) + val.servicePrice * (QSTTAX / 100) + val.servicePrice * (PSTTAX / 100) - val.paymentDetails[0].discount;
          // const sllikFee = (val.servicePrice - val.discount) / 10;

          val.paymentDetails[0].TotalPrice = total;
          val.paymentDetails[0].subTotal = val.servicePrice;
          val.paymentDetails[0].sliikFee = 0;
          val.paymentDetails[0].GST = (val.servicePrice * (GSTTAX / 100))
          val.paymentDetails[0].PST = (val.servicePrice * (PSTTAX / 100))
          val.paymentDetails[0].HST = (val.servicePrice * (HSTTAX / 100))
          val.paymentDetails[0].QST = (val.servicePrice * (QSTTAX / 100))
          val.paymentDetails[0].discount = parseInt(val?.paymentDetails[0]?.discount);
        }
      });
    }

    const serviceCount = serviceSales.length;
    serviceSales = serviceSales.slice(offset, offset + limit);

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { serviceFinacial, serviceCount, serviceSales, beauticiandata, topServices: TopServices, monthCount, clickCountList } });
  } else {
    throw new ErrorHandler("Beautician Id missing.", HttpStatus.BAD_REQUEST, false)
  }

});
module.exports = { getServicesDetails, getServiceDashboard }