const formidable = require("formidable");
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const catchAsyncError = require("../../middleware/catchAsyncError");
const ServiceCategoryList = require("../../models/ServiceCategoryList");
const ServiceTypeList = require("../../models/ServiceTypeList");
const ErrorHandler = require("../../utils/ErrorHandling");
const HttpStatus = require("../../utils/HttpStatus");
const { pathEndpoint } = require("../../utils/Constant");
const { default: mongoose } = require("mongoose");
const ProductCategoryList = require("../../models/ProductCategoryList");
const { uploadFile } = require("../../libs/aws/uploadImg");
const { deleteFile } = require("../../libs/aws/deleteImg");
const BrandCategory = require("../../models/BrandCategory");

const fetchServiceCategories = catchAsyncError(async (req, res, next) => {
    const language = req.get('Accept-Language') || "en";
    const categoriesList = await ServiceCategoryList.aggregate([
        {
            $match: { status: 1 }
            // $match: { language: language, status: 1 }
        },
        {
            $project: {
                id: 1,
                serviceCategoryName: 1,
                serviceCategoryName_fr: 1,
                colorCode: 1,
                imgPath: 1,
                language: 1,
                status: 1,
                createdAt: 1
            }
        },
        { $sort: { createdAt: 1 } }
    ]);
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: categoriesList, message: "Service categories list." });
});
const addServiceCategoryOpt = catchAsyncError(async (req, res, next) => {

    const form = formidable({ multiples: true });
    form.parse(req, async (err, fields, files) => {
        if (err) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Something is wrong with Image Uploading" });
        }
        const { serviceName, serviceName_fr, colorCode, language } = fields;
        let tempLanguage = "en"
        if (language === "en" || language === "fr") {
            tempLanguage = language;
        }
        const serviceData = await ServiceCategoryList.findOne({ serviceCategoryName: serviceName, status: 1 });
        if (serviceData) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "This Service already added" });
        }
        if (serviceName) {
            const newCategory = await ServiceCategoryList.create({ serviceCategoryName: serviceName, serviceCategoryName_fr: serviceName_fr, colorCode, language: tempLanguage })
            if (files.imgPath) {
                const { mimetype } = files.imgPath;
                const img = mimetype.split("/");
                const extension = img[1].toLowerCase();
                if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                    return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: `${extension} is not allowed..` });
                }
                const fileName = (files.imgPath.originalFilename =
                    uuidv4() + "." + extension);
                const newPath = `${pathEndpoint.CategoryImgBase}${fileName}`;
                try {
                    const uploadImgRes = await uploadFile(files.imgPath, newPath, extension);
                    newCategory.imgPath = uploadImgRes.imageUrl;
                    await newCategory.save();
                    return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, message: "Service category added successfully." });
                } catch (error) {
                    return res.status(HttpStatus.ERROR).json({
                        status: HttpStatus.ERROR,
                        success: false,
                        message: 'Something went wrong in Image upload. Please try again',
                    });
                }
            }
            return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, message: "Service category added successfully.." });
        } else {
            throw new ErrorHandler("Service Name is missing.", HttpStatus.BAD_REQUEST);
        }
    })
});
const updateServiceCategoryOpt = catchAsyncError(async (req, res, next) => {
    const { serviceCategoryId } = req.params;

    const form = formidable({ multiples: true });
    form.parse(req, async (err, fields, files) => {
        if (err) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Something is wrong with Image Uploading" });
        }
        const { serviceName, serviceName_fr, colorCode } = fields;

        const oldCategory = await ServiceCategoryList.findById(serviceCategoryId)

        if (serviceName) {
            oldCategory.serviceCategoryName = serviceName;
        }
        if (serviceName_fr) {
            oldCategory.serviceCategoryName_fr = serviceName_fr;
        }
        if (colorCode) {
            oldCategory.colorCode = colorCode;
        }

        if (files.imgPath) {
            const { mimetype } = files.imgPath;
            const img = mimetype.split("/");
            const extension = img[1].toLowerCase();
            if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: `${extension} is not allowed..` });
            }
            //add new file
            const fileName = (files.imgPath.originalFilename = uuidv4() + "." + extension);
            const newPath = `${pathEndpoint.CategoryImgBase}${fileName}`;
            try {
                const uploadImgRes = await uploadFile(files.imgPath, newPath, extension);
                //remove old file
                if (oldCategory.imgPath) {
                    const removeImg = oldCategory.imgPath.includes(process.env.AWS_BUCKET_REGION) ? oldCategory.imgPath.replace(process.env.IMAGE_BASE_URL_WITH_REGION, "") : oldCategory.imgPath.replace(process.env.IMAGE_BASE_URL, "")
                    await deleteFile(removeImg)
                }
                oldCategory.imgPath = uploadImgRes.imageUrl;
            } catch (error) {
                return res.status(HttpStatus.ERROR).json({
                    status: HttpStatus.ERROR,
                    success: false,
                    message: 'Something went wrong in Image upload. Please try again',
                });
            }
        }

        await oldCategory.save();
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Service category updated successfully.." });

    })
});
const getSingleCategory = catchAsyncError(async (req, res, next) => {
    const { categoryId } = req.params;
    const data = await ServiceCategoryList.findOne({ _id: new mongoose.Types.ObjectId(categoryId), status: 1 });

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data });
});

const deleteServiceCategoryOpt = catchAsyncError(async (req, res, next) => {
    const { categoryId } = req.body;
    if (mongoose.Types.ObjectId.isValid(categoryId)) {
        const categoryData = await ServiceCategoryList.findOne({ _id: categoryId, status: 1 });

        if (categoryData) {
            categoryData.status = 0;
            await categoryData.save();
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Service category deleted successfully" });
        } else {
            throw new ErrorHandler("Service category not found", HttpStatus.BAD_REQUEST, false)
        }
    } else {
        throw new ErrorHandler("Please enter valid service category Id", HttpStatus.BAD_REQUEST, false)
    }
});


const fetchServiceTypes = catchAsyncError(async (req, res, next) => {
    const { serviceCategoryId } = req.params;
    const language = req.get('Accept-Language') || "en";
    if (serviceCategoryId) {
        const serviceTypeList = await ServiceTypeList.find({ serviceCategoryId, language: language, status: 1 }).select('id serviceTypeName serviceTypeName_fr language status');
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: serviceTypeList, message: "Service Types list." });
    } else {
        throw new ErrorHandler("serviceCategoryId is missing.", HttpStatus.BAD_REQUEST);
    }

});

const fetchServiceWithList = catchAsyncError(async (req, res, next) => {
    const { limit, offset, search, } = req.body;
    const language = req.get('Accept-Language') || "en";

    const limitData = parseInt(limit, 10) || 10;
    const offsetData = parseInt(offset, 10) || 0;
    let matchQuery = {};
    // let matchQuery = { language: language };
    let subQuery = { serviceTypeList: { $gt: [] }, status: 1 };

    if (search !== "") {
        matchQuery = { $and: [{ _id: new mongoose.Types.ObjectId(search) }, { language: language }, { status: 1 }] };
        // subQuery = { serviceTypeList: { $gt: [] } }
    }

    let tempData = [
        {
            $lookup: {
                from: 'servicecategorylists',
                localField: 'serviceCategoryId',
                foreignField: "_id",
                pipeline: [
                    { $match: matchQuery },
                    { $project: { serviceCategoryName: 1, serviceCategoryName_fr: 1, imgPath: 1, language: 1, } }
                ],
                as: 'serviceTypeList',
            },
        },
        { $sort: { createdAt: -1 } },
        { $match: subQuery },
        {
            $project: {
                id: 1,
                serviceTypeName: 1,
                serviceTypeName_fr: 1,
                serviceTypeList: 1,
                language: 1,
                status: 1
            }
        }
    ]
    const countCategory = await ServiceTypeList.aggregate(tempData);
    const count = countCategory.length;

    tempData.push({ $skip: offsetData }, { $limit: limitData });
    const categoriesList = await ServiceTypeList.aggregate(tempData);
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { count, categoriesList }, message: "Service categories list." });
});


const addServiceTypeOpt = catchAsyncError(async (req, res, next) => {
    const { serviceId, serviceTypeName, serviceTypeName_fr, language } = req.body;
    let tempLanguage = "en"
    if (language === "en" || language === "fr") {
        tempLanguage = language;
    }
    const serviceTypeData = await ServiceTypeList.findOne({ serviceTypeName: serviceTypeName, status: 1 });
    if (serviceTypeData) {
        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "This Service type already added" });
    }
    await ServiceTypeList.create({ serviceCategoryId: serviceId, serviceTypeName, serviceTypeName_fr, language: tempLanguage })
    return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, message: "Service Type added successfully.." });
});

const updateServiceTypeOpt = catchAsyncError(async (req, res, next) => {
    const { serviceId } = req.params;
    const { serviceTypeName, serviceTypeName_fr } = req.body;
    const service = await ServiceTypeList.findOne({ _id: serviceId });
    if (!service) {
        throw new ErrorHandler("Service type not found", HttpStatus.BAD_REQUEST);
    }
    if (serviceTypeName) {
        await ServiceTypeList.findOneAndUpdate({ _id: serviceId }, { serviceTypeName, serviceTypeName_fr });
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Service category updated successfully.." });
    } else {
        throw new ErrorHandler("serviceTypeName is missing.", HttpStatus.BAD_REQUEST);
    }
})

const deleteServiceTypeOpt = catchAsyncError(async (req, res, next) => {
    const { serviceId } = req.body;

    if (mongoose.Types.ObjectId.isValid(serviceId)) {
        const serviceData = await ServiceTypeList.findOne({ _id: serviceId, status: 1 });

        if (serviceData) {
            serviceData.status = 0;
            await serviceData.save();
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Service type deleted successfully" });
        } else {
            throw new ErrorHandler("Service type not found", HttpStatus.BAD_REQUEST, false)
        }
    } else {
        throw new ErrorHandler("Please enter valid service type Id", HttpStatus.BAD_REQUEST, false)
    }
});

//for product module 
const addProductCategoryOpt = catchAsyncError(async (req, res, next) => {
    const { name, name_fr, colorCode, language } = req.body;
    let tempLanguage = "en"
    if (language === "en" || language === "fr") {
        tempLanguage = language;
    }
    if (name) {
        const productCategoryData = await ProductCategoryList.findOne({ productCategoryName: name, productCategoryName_fr: name_fr, status: 1 });
        if (productCategoryData) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "This Product category already added" });
        }
        const newCategory = await ProductCategoryList.create({ productCategoryName: name, productCategoryName_fr: name_fr, colorCode, language: tempLanguage });
        return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, message: "Product Category added successfully.." });

    } else {
        throw new ErrorHandler("Name is missing", HttpStatus.BAD_REQUEST, false)
    }
});
const getProductCatList = catchAsyncError(async (req, res, next) => {
    const language = req.get('Accept-Language') || "en";

    const data = await ProductCategoryList.find({ status: 1 }).select('productCategoryName productCategoryName_fr colorCode imgPath language status');
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data })
});
const updateProductCategory = catchAsyncError(async (req, res, next) => {
    const { prodId } = req.params;
    const { name, name_fr, colorCode } = req.body;

    if (!name) {
        throw new ErrorHandler("Name is missing", HttpStatus.BAD_REQUEST, false); // payload validation check
    }
    const isProdNameExists = await ProductCategoryList.find({ productCategoryName: name, productCategoryName_fr: name_fr, _id: { $ne: prodId } }); // check new name exists
    if (isProdNameExists.length) {
        throw new ErrorHandler("Name already exists.", HttpStatus.BAD_REQUEST, false);
    }
    if (mongoose.Types.ObjectId.isValid(prodId)) {
        const productCategoryData = await ProductCategoryList.findById(prodId);
        if (productCategoryData) {
            productCategoryData.productCategoryName = name || isProdNameExists?.[0]?.productCategoryName;
            productCategoryData.productCategoryName_fr = name_fr || isProdNameExists?.[0]?.productCategoryName_fr;
            if (colorCode) {
                productCategoryData.colorCode = colorCode;
            }
            await productCategoryData.save();    // update data
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Product category Updated successfully." })
        }
        throw new ErrorHandler("prodId  not found.", HttpStatus.BAD_REQUEST, false); //data not found Error
    } else {
        throw new ErrorHandler("Invalid prodId", HttpStatus.BAD_REQUEST, false); // invalid Id Error throw
    }
});

const deleteProductCategoryOpt = catchAsyncError(async (req, res, next) => {
    const { prodId } = req.body;

    if (mongoose.Types.ObjectId.isValid(prodId)) {
        const productCategoryData = await ProductCategoryList.findOne({ _id: prodId, status: 1 });

        if (productCategoryData) {
            productCategoryData.status = 0;
            await productCategoryData.save();
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Product category deleted successfully" });
        } else {
            throw new ErrorHandler("Product category not found", HttpStatus.BAD_REQUEST, false)
        }
    } else {
        throw new ErrorHandler("Please enter valid product category Id", HttpStatus.BAD_REQUEST, false)
    }
});

// for brand category module
const addBrandCategory = catchAsyncError(async (req, res, next) => {
    const { name, name_fr, colorCode, language } = req.body;
    let tempLanguage = "en"
    if (language === "en" || language === "fr") {
        tempLanguage = language;
    }
    if (name) {
        await BrandCategory.create({ brandCategoryName: name, brandCategoryName_fr: name_fr, colorCode, language: tempLanguage });
        return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, message: "Brand Category added successfully.." });

    } else {
        throw new ErrorHandler("Name is missing", HttpStatus.BAD_REQUEST, false)
    }
});

// for get Brand Category
const getBrandCategory = catchAsyncError(async (req, res, next) => {
    const language = req.get('Accept-Language') || "en";

    const data = await BrandCategory.find({ isDeleted: 0, }).select('brandCategoryName brandCategoryName_fr colorCode language');
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data })
});

// for update Brand Category
const updateBrandCategory = catchAsyncError(async (req, res, next) => {
    const { brandId } = req.params;
    const { name, name_fr, colorCode } = req.body;

    if (!name) {
        throw new ErrorHandler("Name is missing", HttpStatus.BAD_REQUEST, false); // payload validation check
    }
    const isBrandNameExists = await BrandCategory.find({ brandCategoryName: name, brandCategoryName_fr: name_fr, _id: { $ne: brandId } }); // check new name exists
    if (isBrandNameExists.length) {
        throw new ErrorHandler("Name already exists.", HttpStatus.BAD_REQUEST, false);
    }
    if (mongoose.Types.ObjectId.isValid(brandId)) {
        const brandCategoryData = await BrandCategory.findById(brandId);
        if (brandCategoryData) {
            brandCategoryData.brandCategoryName = name || isBrandNameExists?.[0]?.brandCategoryName;
            brandCategoryData.brandCategoryName_fr = name_fr || isBrandNameExists?.[0]?.brandCategoryName_fr;
            if (colorCode) {
                brandCategoryData.colorCode = colorCode;
            }
            await brandCategoryData.save();    // update data
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Brand category Updated successfully." })
        }
        throw new ErrorHandler("brandId  not found.", HttpStatus.BAD_REQUEST, false); //data not found Error
    } else {
        throw new ErrorHandler("Invalid brandId", HttpStatus.BAD_REQUEST, false); // invalid Id Error throw
    }
});

// for delete Brand category
const deleteBrandCategory = catchAsyncError(async (req, res, next) => {
    const { categoryId } = req.body;

    if (mongoose.Types.ObjectId.isValid(categoryId)) {
        const brandCategoryData = await BrandCategory.findOne({ _id: categoryId, isDeleted: 0 });

        if (brandCategoryData) {
            brandCategoryData.isDeleted = 1;
            await brandCategoryData.save();
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Brand category deleted successfully" });
        } else {
            throw new ErrorHandler("Brand category not found", HttpStatus.BAD_REQUEST, false)
        }
    } else {
        throw new ErrorHandler("Please enter valid brand category Id", HttpStatus.BAD_REQUEST, false)
    }
})

module.exports = { addServiceCategoryOpt, fetchServiceCategories, deleteServiceCategoryOpt, updateServiceCategoryOpt, addServiceTypeOpt, fetchServiceTypes, updateServiceTypeOpt, deleteServiceTypeOpt, getSingleCategory, fetchServiceWithList, addProductCategoryOpt, getProductCatList, updateProductCategory, deleteProductCategoryOpt, addBrandCategory, getBrandCategory, updateBrandCategory, deleteBrandCategory }; 