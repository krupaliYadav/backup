const { default: mongoose } = require("mongoose");
const catchAsyncError = require("../../middleware/catchAsyncError");
const Client = require("../../models/Client");
const HttpStatus = require("../../utils/HttpStatus");
const Appoiement = require("../../models/Appointment");
const Order = require("../../models/Order");
const ErrorHandler = require("../../utils/ErrorHandling");

// Get all Client details
const getAllClient = catchAsyncError(async (req, res, next) => {
  const { search, limit, offset, type, status } = req.body;

  let matchQuery = {};
  let statusQuery = {};
  const limitData = parseInt(limit, 10) || 15;
  const offsetData = parseInt(offset, 10) || 0;

  if (!type) {
    matchQuery = { isDeleted: 0 };
  }
  if (type === "archive") {
    matchQuery = { isDeleted: 1 };
  }
  if (type === "unarchive") {
    matchQuery = { isDeleted: 0 };
  }

  if (status == 1) {
    statusQuery = {
      isActiveUser: 1
    }
  }

  if (status == 0) {
    statusQuery = {
      isActiveUser: 0
    }
  }
  if (status === "") {
    statusQuery = {}
  }

  if (search) {
    matchQuery.$or = [
      { firstName: { $regex: search, $options: 'i' } },
      { lastName: { $regex: search, $options: 'i' } },
    ];
  }
  let tempData = [
    { $match: matchQuery },
    {
      $lookup: {
        from: 'users',
        let: { userId: '$userId' },
        pipeline: [
          { $match: { $expr: { $eq: ['$_id', '$$userId'] } } },
          { $match: statusQuery },
          { $project: { _id: 0, email: 1, phoneNumber: 1, isActiveUser: 1 } },
        ],
        as: 'userDetails',
      },
    },
    {
      $lookup: {
        from: 'addresses',
        let: { address: '$address' },
        pipeline: [
          { $match: { $expr: { $in: ['$_id', '$$address.addressId'] } } },
          { $project: { _id: 0, createdAt: 0, updatedAt: 0, __v: 0 } },
        ],
        as: 'address'
      },
    },
    {
      $lookup: {
        from: 'provinces',
        localField: 'address.province',
        foreignField: '_id',
        pipeline: [
          { $project: { name: 1, name_fr: 1, } },
        ],
        as: 'provinceDetails'
      }
    },
    {
      $lookup: {
        from: "appointments",
        localField: "_id",
        foreignField: "clientId",
        pipeline: [
          { $match: { step: 2 } },
          { $project: { _id: 0, } },
        ],
        as: "lastAppointments"
      }
    },
    {
      $addFields:
      {
        lastArrayElement: { $slice: ["$lastAppointments", -1] },
        address: {
          $map: {
            input: '$address',
            as: 'addr',
            in: {
              $mergeObjects: [
                '$$addr',
                {
                  provinceName: {
                    $arrayElemAt: ['$provinceDetails.name', 0]
                  },
                  provinceName_fr: {
                    $arrayElemAt: ['$provinceDetails.name_fr', 0]
                  }
                }
              ]
            }
          }
        }
      }
    },
    { $unwind: '$userDetails' },
    { $sort: { createdAt: -1 } },
    {
      $project: {
        _id: 1,
        uid: 1,
        firstName: 1,
        lastName: 1,
        gender: 1,
        DOB: 1,
        country_code: 1,
        isDeleted: 1,
        address: 1,
        userDetails: 1,
        profileImage: 1,
        lastArrayElement: {
          createdAt: { $arrayElemAt: ['$lastArrayElement.createdAt', 0] }
        }
      }
    }
  ]
  const results = await Client.aggregate(tempData);
  const count = results.length;

  tempData.push({ $skip: offsetData }, { $limit: limitData });
  const allClients = await Client.aggregate(tempData);

  return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, data: { count, allClients }, message: "All Client detail" })

});

// Remove Client 
const removeClient = catchAsyncError(async (req, res, next) => {
  const { clientId } = req.params;

  const client = await Client.findById({ _id: clientId });

  if (!client) {
    throw new ErrorHandler("Client not found", HttpStatus.BAD_REQUEST);
  }

  client.isDeleted = 1;
  await client.save();

  // await Client.findByIdAndDelete({ _id: clientId });

  return res.status(200).json({ status: 200, success: true, message: "Client deleted successfully" });
});

// get single client
const getSingleClient = catchAsyncError(async (req, res, next) => {
  const { clientId, limit, offset, chartSDate, chartEDate, } = req.body;
  const limitData = parseInt(limit, 10) || 10;
  const offsetData = parseInt(offset, 10) || 0;

  let dateSearch = {};
  if (chartSDate !== "" && chartEDate !== "") {
    dateSearch = {
      $expr: {
        $and: [
          {
            $gte: [
              { $toDate: '$dateTime' },
              { $toDate: chartSDate }
            ]
          },
          {
            $lte: [
              { $toDate: '$dateTime' },
              { $toDate: chartEDate }
            ]
          }
        ]
      },
    }
  }
  const userdata = await Client.aggregate([
    { $match: { _id: new mongoose.Types.ObjectId(clientId) } },
    {
      $lookup: {
        from: 'users',
        let: { userId: '$userId' },
        pipeline: [
          { $match: { $expr: { $eq: ['$_id', '$$userId'] } } },
          { $project: { _id: 0, email: 1, phoneNumber: 1, isActiveUser: 1, profileImage: 1 } },
        ],
        as: 'userDetails',
      },
    },
    {
      $lookup: {
        from: 'addresses',
        let: { address: '$address' },
        pipeline: [
          { $match: { $expr: { $in: ['$_id', '$$address.addressId'] } } },
          { $project: { _id: 0, createdAt: 0, updatedAt: 0, __v: 0 } },
        ],
        as: 'address'
      },
    },
    {
      $lookup: {
        from: 'provinces',
        localField: 'address.province',
        foreignField: '_id',
        pipeline: [
          { $project: { name: 1, name_fr: 1, } },
        ],
        as: 'provinceDetails'
      }
    },
    {
      $addFields:
      {
        address: {
          $map: {
            input: '$address',
            as: 'addr',
            in: {
              $mergeObjects: [
                '$$addr',
                {
                  provinceName: {
                    $arrayElemAt: ['$provinceDetails.name', 0]
                  },
                  provinceName_fr: {
                    $arrayElemAt: ['$provinceDetails.name_fr', 0]
                  }
                }
              ]
            }
          }
        }
      }
    },
    {
      $lookup: {
        from: 'appointments',
        localField: '_id',
        foreignField: "clientId",
        as: 'appoiementDetails',
        pipeline: [
          { $match: dateSearch }
        ]
      },
    },
    {
      $addFields:
      {
        pendingDetails: {
          $filter: {
            input: '$appoiementDetails',
            as: 'appoiement',
            // cond:  {$and: [
            //   { $eq: ['$$appoiement.status', 1]},
            //   {$gte:['$$appoiement.dateTime',new Date()]}
            // ]}
            cond: {
              $or: [
                { $eq: ['$$appoiement.status', 0] },
                { $eq: ['$$appoiement.status', 1] },
              ]
            }
          }
        },
        deliverDetails: {
          $filter: {
            input: '$appoiementDetails',
            as: 'deliever',
            cond: {
              $and: [
                { $eq: ['$$deliever.status', 2] },
              ]
            }
          }
        },
        cancelDetails: {
          $filter: {
            input: '$appoiementDetails',
            as: 'cancel',
            cond: {
              $or: [
                { $eq: ['$$cancel.status', 3] },
                { $eq: ['$$cancel.status', 4] },
              ]
            }
          }
        },
        notShowDetails: {
          $filter: {
            input: '$appoiementDetails',
            as: 'cancel',
            cond: {
              $and: [
                { $eq: ['$$cancel.status', 5] },
              ]
            }
          }
        },
      },
    },
    { $addFields: { upcoming: { $size: "$pendingDetails" } } },
    { $addFields: { completed: { $size: "$deliverDetails" } } },
    { $addFields: { cancelled: { $size: "$cancelDetails" } } },
    { $addFields: { noShow: { $size: "$notShowDetails" } } },
    { $project: { appoiementDetails: 0, cancelDetails: 0, pendingDetails: 0, favorites: 0, provinceDetails: 0, notShowDetails: 0, deliverDetails: 0 } }
  ]);


  let tempData = [
    { $match: { clientId: new mongoose.Types.ObjectId(clientId) } },
    // { $match: dateSearch },
    {
      $lookup: {
        from: 'beauticianservices',
        localField: 'serviceId',
        foreignField: "_id",
        pipeline: [
          { $project: { price: 1, serviceType: 1 } }
        ],
        as: 'serviceDetails',
      },
    },
    {
      $lookup: {
        from: 'beauticians',
        localField: 'beauticianId',
        foreignField: "_id",
        as: 'beauticianDetails',
        pipeline: [
          { $project: { firstName: 1, lastName: 1, country: 1, businessName: 1, businessNumber: 1, address: 1 } }
        ]
      },
    },
    {
      $lookup: {
        from: 'addresses',
        localField: 'beauticianDetails.address',
        foreignField: "_id",
        as: 'beauticianAddress',
        pipeline: [
          { $project: { address: 1, province: 1, apartment: 1, city: 1, zipCode: 1, } }
        ]
      },
    },
    {
      $unwind: { path: '$serviceDetails', preserveNullAndEmptyArrays: true },
    },
    {
      $lookup: {
        from: 'servicetypelists',
        localField: 'serviceDetails.serviceType',
        foreignField: "_id",
        pipeline: [
          { $project: { serviceTypeName: 1, serviceTypeName_fr: 1, } }
        ],
        as: 'typeDetails',
      },
    },
    {
      $lookup: {
        from: 'payments',
        localField: 'paymentDetails',
        foreignField: "_id",
        pipeline: [
          { $project: { BookingId: 1, addressId: 1, subTotal: 1, discount: 1, GST: 1, PST: 1, QST: 1, HST: 1, TotalPrice: 1, paymentStatus: 1 } }
        ],
        as: 'paymentDetails',
      },
    },
    {
      $lookup: {
        from: 'addresses',
        localField: 'paymentDetails.addressId',
        foreignField: "_id",
        pipeline: [
          { $project: { address: 1, street: 1, apartment: 1 } }
        ],
        as: 'userAddress',
      },
    },
  ]
  const Purchasetemp = await Appoiement.aggregate(tempData);
  const count = Purchasetemp.length;

  tempData.push({ $skip: offsetData }, { $limit: limitData });
  const servicePurchase = await Appoiement.aggregate(tempData);

  return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { count, userdata, servicePurchase } });
});

// get single client dashboard
const getClientSalesSummary = catchAsyncError(async (req, res, next) => {
  const { clientId, limit, offset } = req.body;

  if (!mongoose.Types.ObjectId.isValid(clientId)) {
    throw new ErrorHandler("Enter valid Client Id", HttpStatus.BAD_REQUEST, false)
  }

  const productLimitData = parseInt(limit, 10) || 10;
  const productOffsetData = parseInt(offset, 10) || 0;

  let productSales = await Order.aggregate([
    { $match: { clientId: new mongoose.Types.ObjectId(clientId) } },
    {
      $unwind: "$productData",
    },
    {
      $lookup: {
        from: 'beauticians',
        localField: 'productData.beauticianId',
        foreignField: "_id",
        pipeline: [
          { $project: { businessName: 1 } }
        ],
        as: 'beauticianDetails',
      },
    },
    {
      $lookup: {
        from: 'beauticianproducts',
        localField: 'productData.productId',
        foreignField: "_id",
        pipeline: [
          { $project: { productName: 1 } }
        ],
        as: 'productDetails',
      },
    },
    {
      $lookup: {
        from: 'addresses',
        localField: 'shippingAddressId',
        foreignField: "_id",
        pipeline: [
          {
            $project: {
              address: { $ifNull: ["$address", null] },
              street: { $ifNull: ["$street", null] },
              apartment: { $ifNull: ["$apartment", null] },
              city: { $ifNull: ["$city", null] },
              zipCode: { $ifNull: ["$zipCode", null] },
            }
          }
        ],
        as: 'addressDetails',
      },
    },
    { $sort: { createdAt: -1 } },
    {
      $project: {
        productName: { $arrayElemAt: ['$productDetails.productName', 0] },
        vendorName: { $arrayElemAt: ['$beauticianDetails.businessName', 0] },
        productPrice: { $ifNull: ["$productData.price", 0] },
        totalQuantity: { $ifNull: ["$productData.totalQuantity", 0] },
        productDiscount: { $ifNull: ["$productData.discount", 0] },
        productPurchaseDate: { $ifNull: ["$createdAt", 0] },
        deliveredDate: { $ifNull: ["$createdAt", 0] },
        orderStatus: { $ifNull: ["$orderStatus", "pending"] },
        addressDetails: 1,
        shippingCharge: { $ifNull: ["$shippingCharge", 0] },
        GstInPer: 1, PstInPer: 1, HstInPer: 1, QstInPer: 1,
      }
    }
  ]);

  if (productSales.length) {
    await productSales.forEach(async (val) => {
      const GSTTAX = val?.GstInPer;
      const PSTTAX = val?.PstInPer;
      const HSTTAX = val?.HstInPer;
      const QSTTAX = val?.QstInPer;

      let tempPrice = val.productPrice * val.totalQuantity;
      tempPrice = tempPrice - val.productDiscount;

      const total = tempPrice + tempPrice * (GSTTAX / 100) + tempPrice * (HSTTAX / 100) + tempPrice * (QSTTAX / 100) + tempPrice * (PSTTAX / 100);
      // const sllikFee = (tempPrice - val.discount) / 10;

      val.TotalPrice = total;
      val.subTotal = tempPrice;
      val.sliikFee = 0;
      val.sliikFeeGST = 0;
      val.sliikFeePST = 0;
      val.sliikFeeHST = 0;
      val.sliikFeeQST = 0;
      val.GST = (tempPrice * (GSTTAX / 100))
      val.PST = (tempPrice * (PSTTAX / 100))
      val.HST = (tempPrice * (HSTTAX / 100))
      val.QST = (tempPrice * (QSTTAX / 100))
    });
  }

  const productCount = productSales.length;
  productSales = productSales.slice(productOffsetData, productOffsetData + productLimitData);

  return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { productCount, productSales } });
})

module.exports = { getAllClient, removeClient, getSingleClient, getClientSalesSummary }