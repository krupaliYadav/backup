const { default: mongoose } = require("mongoose");
const catchAsyncError = require("../../middleware/catchAsyncError");
const Amenities = require("../../models/Amenities");
const Demography = require("../../models/Demography");
const HttpStatus = require("../../utils/HttpStatus");
const ErrorHandler = require("../../utils/ErrorHandling");
const HealthSafety = require("../../models/HealthSafety");

const addDemography = catchAsyncError(async (req, res, next) => {
    const { demographyName, demographyName_fr, language } = req.body;

    if (!demographyName) {
        throw new ErrorHandler("Please Enter Demography", HttpStatus.BAD_REQUEST);
    }

    const demographyData = await Demography.findOne({ demographyName, demographyName_fr, status: 1 });

    if (demographyData) {
        throw new ErrorHandler("duplicate demography name entered", HttpStatus.BAD_REQUEST);
    }

    let tempLanguage = "en"
    if (language === "en" || language === "fr") {
        tempLanguage = language;
    }

    const data = await Demography.create({ demographyName, demographyName_fr, language: tempLanguage });

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Demography added Successfully." });
});

const getAllDemography = catchAsyncError(async (req, res, next) => {
    const language = req.get('Accept-Language') || "en";

    const data = await Demography.find({ status: 1, }).select("demographyName demographyName_fr status language").sort("createdAt");
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data });
});

const updateDemography = catchAsyncError(async (req, res, next) => {
    const { demographyId } = req.params;

    const { demographyName, demographyName_fr } = req.body;

    if (demographyName) {
        await Demography.findByIdAndUpdate(demographyId, { demographyName: demographyName, demographyName_fr: demographyName_fr })
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Demography Name updated successfully.." });
    } else {
        throw new ErrorHandler("Demography Name is missing.", HttpStatus.BAD_REQUEST);
    }
});

const deleteDemography = catchAsyncError(async (req, res, next) => {
    const { demographyId } = req.body;

    if (mongoose.Types.ObjectId.isValid(demographyId)) {
        const demographyData = await Demography.findOne({ _id: demographyId });
        if (demographyData) {
            demographyData.status = 0;
            await demographyData.save();
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Demography deleted successfully" });
        } else {
            throw new ErrorHandler("Demography data not found", HttpStatus.BAD_REQUEST, false)
        }
    } else {
        throw new ErrorHandler("Please enter valid demograohy Id", HttpStatus.BAD_REQUEST, false)
    }
});

const getAmenityList = catchAsyncError(async (req, res, next) => {
    const language = req.get('Accept-Language') || "en";

    const data = await Amenities.find({ status: 1, }).select("name name_fr status").sort("createdAt")
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data });

});
const addAndUpdateAmenity = catchAsyncError(async (req, res, next) => {
    const { name, name_fr, language } = req.body;
    const { amenityId } = req.params;
    if (!name) {
        throw new ErrorHandler("Name is missing.", HttpStatus.BAD_REQUEST, false)
    }
    let tempLanguage = "en"
    if (language === "en" || language === "fr") {
        tempLanguage = language;
    }
    if (amenityId) {
        if (mongoose.Types.ObjectId.isValid(amenityId)) {
            const updateData = await Amenities.findByIdAndUpdate(amenityId, { name: name, name_fr: name_fr }, { new: true });
            if (updateData) {
                return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Amenity value is Updated successfully." });
            } else {
                throw new ErrorHandler("Selected Amenity is not found.", HttpStatus.BAD_REQUEST, false)
            }
        } else {
            throw new ErrorHandler("Amenity Id is not wrong.", HttpStatus.BAD_REQUEST, false)
        }
    } else {
        const amenityData = await Amenities.findOne({ name: name, name_fr: name_fr, status: 1 });
        if (amenityData) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "This amenity already added" });
        }
        await Amenities.create({ name: name, name_fr: name_fr, language: tempLanguage });
        return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, message: "Amenity added successfully." });
    }
});

const deleteAmenity = catchAsyncError(async (req, res, next) => {
    const { amenityId } = req.body;

    if (mongoose.Types.ObjectId.isValid(amenityId)) {
        const amenityData = await Amenities.findOne({ _id: amenityId, status: 1 });
        if (amenityData) {
            amenityData.status = 0;
            await amenityData.save();
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Amenity data deleted successfully" });
        } else {
            throw new ErrorHandler("Amenity data not found", HttpStatus.BAD_REQUEST, false)
        }
    } else {
        throw new ErrorHandler("Please enter valid Amenity Id", HttpStatus.BAD_REQUEST, false)
    }
});
const getHealthSafetyList = catchAsyncError(async (req, res, next) => {
    const language = req.get('Accept-Language') || "en";

    const data = await HealthSafety.find({ status: 1, }).select("name name_fr status language").sort("createdAt")
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data });

});
const addAndUpdateHealthSafety = catchAsyncError(async (req, res, next) => {
    const { name, name_fr, language } = req.body;
    const { healthId } = req.params;
    let tempLanguage = "en"
    if (language === "en" || language === "fr") {
        tempLanguage = language;
    }
    if (!name) {
        throw new ErrorHandler("Name is missing.", HttpStatus.BAD_REQUEST, false)
    }
    if (healthId) {
        if (mongoose.Types.ObjectId.isValid(healthId)) {
            const updateData = await HealthSafety.findByIdAndUpdate(healthId, { name: name, name_fr: name_fr }, { new: true });
            if (updateData) {
                return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Health & safety value is Updated successfully." });
            } else {
                throw new ErrorHandler("Selected Health & safety is not found.", HttpStatus.BAD_REQUEST, false)
            }
        } else {
            throw new ErrorHandler("Health & safety Id is not wrong.", HttpStatus.BAD_REQUEST, false)
        }
    } else {

        const healthSafetyData = await HealthSafety.findOne({ name: name, name_fr: name_fr, status: 1 });
        if (healthSafetyData) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "This health safety already added" });
        }
        await HealthSafety.create({ name: name, name_fr: name_fr, language: tempLanguage });
        return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, message: "Health & safety added successfully." });
    }
});

const deleteHealthSafety = catchAsyncError(async (req, res, next) => {
    const { healthSafetyId } = req.body;

    if (mongoose.Types.ObjectId.isValid(healthSafetyId)) {
        const healthSafetyData = await HealthSafety.findOne({ _id: healthSafetyId, status: 1 });
        if (healthSafetyData) {
            healthSafetyData.status = 0;
            await healthSafetyData.save();
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Health Safety deleted successfully" });
        } else {
            throw new ErrorHandler("Health Safety data not found", HttpStatus.BAD_REQUEST, false)
        }
    } else {
        throw new ErrorHandler("Please enter valid Health Safety Id", HttpStatus.BAD_REQUEST, false)
    }
});

module.exports = { addDemography, getAllDemography, updateDemography, deleteDemography, getAmenityList, addAndUpdateAmenity, deleteAmenity, getHealthSafetyList, addAndUpdateHealthSafety, deleteHealthSafety }