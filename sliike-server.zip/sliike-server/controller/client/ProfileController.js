const catchAsyncError = require("../../middleware/catchAsyncError");
const Address = require("../../models/Address");
const Client = require("../../models/Client");
const User = require("../../models/User");
const ErrorHandler = require("../../utils/ErrorHandling");
const HttpStatus = require("../../utils/HttpStatus");
const moment = require("moment");
const formidable = require("formidable");
const { pathEndpoint } = require("../../utils/Constant");
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const { uploadFile } = require("../../libs/aws/uploadImg");
const { deleteFile } = require("../../libs/aws/deleteImg");
const { validationResult } = require("express-validator");
//for profile info setting 
const updateProfileImage = catchAsyncError(async (req, res, next) => {
  const id = req.user;
  const form = formidable({ multiples: true });

  form.parse(req, async (err, fields, files) => {
    if (err) {
      throw new ErrorHandler(req.t("somethingIsWrongInImageUpload"), HttpStatus.BAD_REQUEST);
    }
    if (files.profileImage) {
      const clientDetails = await Client.findOne({ userId: id })

      const imgName = files.profileImage.originalFilename.split(".");
      const extension = imgName[imgName.length - 1];
      if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: req.t("ImageExtension", { extension: extension }) });
      }
      const fileName = (files.profileImage.originalFilename =
        uuidv4() + "." + extension);
      const newPath = `${pathEndpoint.clientProfileImg}${fileName}`;
      try {
        const uploadImgRes = await uploadFile(files.profileImage, newPath, extension);
        if (clientDetails.profileImage) {
          const removeImg = clientDetails.profileImage.includes(process.env.AWS_BUCKET_REGION) ? clientDetails.profileImage.replace(process.env.IMAGE_BASE_URL_WITH_REGION, "") : clientDetails.profileImage.replace(process.env.IMAGE_BASE_URL, "")
          await deleteFile(removeImg)
        }
        clientDetails.profileImage = uploadImgRes.imageUrl;
        await clientDetails.save();
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("profileUpadte") });
      } catch (error) {
        return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: req.t("somethingIsWrongInImageUpload") });
      }
    }
  })

})
const addPersonalInfo = catchAsyncError(async (req, res, next) => {
  const id = req.user;
  const { firstName, lastName, phoneNumber, email, day, month, year, gender } = req.body;
  const clientDetails = await Client.findOne({ userId: id }).populate({
    path: 'userId',
    match: { email, phoneNumber }
  });

  if (clientDetails.userId) {
    if (day && month && year) {
      monthNumber = moment(month, 'MMMM').format('M');
      const dateObj = moment.utc([year, monthNumber - 1, day]).local().toDate();
      clientDetails.DOB = dateObj;
    }
    clientDetails.firstName = firstName;
    clientDetails.lastName = lastName;
    clientDetails.gender = gender;
    await clientDetails.save();
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("addPersonalInfoSuccess") });
  } else {
    throw new ErrorHandler(req.t("addPersonalInfoError"), HttpStatus.CONFLICT, false)
  }

});
const getClientPersonalInfo = catchAsyncError(async (req, res, next) => {
  const id = req.user;
  const clientDetails = await Client.findOne({ userId: id }).populate({
    path: 'userId',
    select: "email phoneNumber roles"
  }).populate({ path: "address.addressId", select: "-createdAt -__v -updatedAt" }).lean();
  if (clientDetails?.userId?.roles.includes('beautician')) {
    clientDetails.isRegisterBeautician = true;
  } else {
    clientDetails.isRegisterBeautician = false;
  }
  return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Client info ", data: clientDetails });
});

const addEditClientAddress = catchAsyncError(async (req, res, next) => {
  const id = req.user;
  const { addressType, address, province, street_address, apartment, post_code } = req.body;
  const clientDetails = await Client.findOne({ userId: id }).populate({ path: "address.addressId", select: "-createdAt -__v -updatedAt" });

  if (addressType) {
    const isAddressTypeExist = clientDetails.address.filter(ele => ele.addressType === addressType);
    if (isAddressTypeExist.length > 0) {
      await Address.findByIdAndUpdate(isAddressTypeExist[0].addressId._id, { address, province, apartment, zipCode: post_code, street: street_address }, { new: true });
      return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("updateClientAddressSuccess", { addressType: addressType }) });
    } else {
      const newAddress = await Address.create({ address, province, apartment, zipCode: post_code, street: street_address });
      clientDetails.address.push({ addressId: newAddress._id, addressType });
      clientDetails.save();
      return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("addClientAddressSuccess", { addressType: addressType }) });
    }
  } else {
    throw new ErrorHandler("addressType is missing.", HttpStatus.BAD_REQUEST, false)
  }
});
const handleDeleteClientAccount = catchAsyncError(async (req, res, next) => {
  const id = req.user;
  const { deleteReason } = req.body;
  const clientDetails = await Client.findOne({ userId: id }).populate({
    path: 'userId',
    match: { isActiveUser: 1 },
    select: "isActiveUser"
  })
  if (clientDetails.userId) {
    // await User.findByIdAndUpdate(clientDetails.userId._id, { isActiveUser: 0 , $pull : { roles : 'user'}});
    await User.findByIdAndUpdate(clientDetails.userId._id, { isActiveUser: 0 });

    clientDetails.deleteReason = deleteReason;
    clientDetails.isDeleted = 1
    await clientDetails.save()
    return res.status(HttpStatus.DELETED).json({ status: HttpStatus.DELETED, success: true, message: req.t("handleDeleteClientAccountSuccess") });

  } else {
    throw new ErrorHandler("Your account is already deleted.", HttpStatus.BAD_REQUEST, false)

  }
})
//for notification setting
const handleNotificationSettings = catchAsyncError(async (req, res, next) => {
  const id = req.user;
  const { appoimentNotifications, productNotifications, emailMarketingNotifications } = req.body;
  const errors = validationResult(req);
  if (errors.errors.length !== 0) {
    throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST, false);
  };

  const clientData = await Client.findOne({ userId: id });
  if (clientData) {
    if (appoimentNotifications == 1 || appoimentNotifications == 0) {
      clientData.appoimentNotifications = appoimentNotifications;
    }
    if (productNotifications == 1 || productNotifications == 0) {
      clientData.productNotifications = productNotifications;
    }
    if (emailMarketingNotifications == 1 || emailMarketingNotifications == 0) {
      clientData.emailMarketingNotifications = emailMarketingNotifications;
    }

    await clientData.save();
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Settings changed successfully" });
  } else {
    throw new ErrorHandler(req.t("clientNotFound"), HttpStatus.BAD_REQUEST)
  }
  // const id = req.user;
  // const clientDetails = await Client.findOne({ userId: id });
  // const { appointmentText, productText, emailNotification } = req.body;

  // const notifyDetails = clientDetails.notifications;
  // if (appointmentText) {
  //   notifyDetails.appointmentText = appointmentText;
  // }
  // if (productText) {
  //   notifyDetails.productText = productText;
  // }
  // if (emailNotification) {
  //   notifyDetails.emailNotification = emailNotification;
  // }
  // clientDetails.notifications = notifyDetails;
  // await clientDetails.save();
  // return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("handleNotificationSettings") });
})
//for favorite
const addToMyFavorites = catchAsyncError(async (req, res, next) => {
  const id = req.user;
  const { beauticianId } = req.body;
  if (beauticianId) {
    const clientDetails = await Client.findOne({ userId: id });
    if (clientDetails.favorites.includes(beauticianId)) {
      throw new ErrorHandler("BeauticianId is already added", HttpStatus.BAD_REQUEST, false)
    } else {
      clientDetails.favorites.unshift(beauticianId);
      await clientDetails.save();
      return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("addToMyFavoritesSuccess") });
    }
  } else {
    throw new ErrorHandler("BeauticianId is missing", HttpStatus.BAD_REQUEST, false)
  }
});
const removeFromMyFavorites = catchAsyncError(async (req, res, next) => {
  const id = req.user;
  const { beauticianId } = req.body;
  if (beauticianId) {
    const clientDetails = await Client.findOne({ userId: id });
    clientDetails.favorites.pull(beauticianId);
    await clientDetails.save();
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("removeFromMyFavoritesSuccess") });
  } else {
    throw new ErrorHandler("BeauticianId is missing", HttpStatus.BAD_REQUEST, false)
  }
});

// for change language
const changeLanguage = catchAsyncError(async (req, res, next) => {
  const Id = req.user;

  const { language } = req.body;

  if (language !== "en" && language !== "fr") {
    throw new ErrorHandler("Please enter valid language", HttpStatus.BAD_REQUEST, false)
  };

  const userData = await User.findOne({ _id: Id });
  if (userData) {
    userData.language = language;
    await userData.save();
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("changeLanguageSuccess") });
  } else {
    throw new ErrorHandler(req.t("userNotFound"), HttpStatus.BAD_REQUEST, false)
  }
});

// for get notification
const getClientNotification = catchAsyncError(async (req, res, next) => {
  const id = req.user;
  const clientData = await Client.findOne({ userId: id }).select("appoimentNotifications productNotifications emailMarketingNotifications");
  return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, clientData })
})

// for change Notifications
const changeClientNotifications = catchAsyncError(async (req, res, next) => {
  const id = req.user;
  const { appoimentNotifications, productNotifications, emailMarketingNotifications } = req.body;
  const errors = validationResult(req);
  if (errors.errors.length !== 0) {
    throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST, false);
  };

  const clientData = await Client.findOne({ userId: id });
  if (clientData) {
    if (appoimentNotifications == 1 || appoimentNotifications == 0) {
      clientData.appoimentNotifications = appoimentNotifications;
    }
    if (productNotifications == 1 || productNotifications == 0) {
      clientData.productNotifications = productNotifications;
    }
    if (emailMarketingNotifications == 1 || emailMarketingNotifications == 0) {
      clientData.emailMarketingNotifications = emailMarketingNotifications;
    }

    await clientData.save();
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Settings changed successfully" });
  } else {
    throw new ErrorHandler(req.t("clientNotFound"), HttpStatus.BAD_REQUEST)
  }
});

module.exports = { updateProfileImage, addPersonalInfo, getClientPersonalInfo, addEditClientAddress, handleDeleteClientAccount, handleNotificationSettings, addToMyFavorites, removeFromMyFavorites, changeLanguage, getClientNotification, changeClientNotifications };
