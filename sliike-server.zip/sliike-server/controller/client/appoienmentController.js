const HttpStatus = require("../../utils/HttpStatus");
const catchAsyncError = require("../../middleware/catchAsyncError");
const BeauticianService = require("../../models/BeauticianService");
const Beautician = require("../../models/Beautician");
const Client = require("../../models/Client");
const mongoose = require("mongoose");
const ErrorHandler = require("../../utils/ErrorHandling");
const Appointment = require("../../models/Appointment");
const { validationResult } = require("express-validator");
const { fcmNotification } = require("../../utils/fcmNotification");
const BeauticianWorkHour = require("../../models/BeauticianWorkHour");

const Rating = require("../../models/Rating");
const { notificationMSGs, getPolicyDetails, referralAmount } = require("../../utils/Constant");
const moment = require("moment");
const Employee = require("../../models/Employee");
const Address = require("../../models/Address");

const { makePayment } = require("../../libs/stripe/makePayment");
const { createStripeCard } = require("../../libs/stripe/addStripeCard");
const Province = require("../../models/Province");
const { generateNumericId } = require("../../utils/generateNumericId");
const Cards = require("../../models/Cards");
const Payment = require("../../models/Payment");
const FcmNotification = require("../../models/FcmNotification");
const { createStripeCustomer } = require("../../libs/stripe/createStripeCustomer");
const User = require("../../models/User");
const { attachCustomerID } = require("../../libs/stripe/attachCustomerID");
const { detachCardDetails } = require("../../libs/stripe/detachCardDetails");
const { checkDurationFormate } = require("../../utils/formatTest");
const { appConformationBEmail, appConformationCEmail, cancelAppEmailB, cancelAppEmailC, updateAppEmailB, updateAppEmailC } = require("../../utils/emailTeplates");
const BeauticianNotification = require("../../models/BeauticianNotification");
const Referral = require("../../models/Referral");
const platform_fees = process.env.PLATFORM_FEES || 0.10;

//single appointment details
const getSingleAppointmentData = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { appId } = req.params;
    const clientData = await Client.findOne({ userId: id });
    const appointmentData = await Appointment.findOne({ _id: appId, clientId: clientData._id, step: 2 }).populate([
        {
            path: 'beauticianId',
            select: 'logo logoPath businessName rating ',
            populate: [{
                path: 'address', select: "-createdAt -updatedAt -__v",
                populate: {
                    path: 'province',
                    model: 'Province',
                    select: 'name'
                },
            }
            ],
        },
        {
            path: "serviceId", select: '-createdAt -updatedAt -__v',
            populate: [{ path: 'serviceCategory', select: '_id serviceCategoryName' }, { path: 'serviceType', select: '_id serviceTypeName ' }],
        },
        {
            path: 'stylistID', select: 'firstName lastName profileImage'
        },
        {
            path: "paymentDetails", select: 'BookingId'
        }
    ]).lean();
    const ratingData = await Rating.findOne({ appointmentId: appId }).select("rating reviews");
    if (appointmentData) {
        appointmentData.ratingData = {
            rating: ratingData?.rating || null,
            reviews: ratingData?.reviews || null,
        };
        if (appointmentData?.beauticianId?.logo) {
            appointmentData.beauticianId.logoPath = appointmentData?.beauticianId?.logo;
        }
        if (!appointmentData.paymentDetails && appointmentData.status === 0) {
            appointmentData.paymentDetails = null;
        }

        // This query Is for find promotion for particular service
        const discountData = await Appointment.aggregate([
            {
                $match: {
                    _id: new mongoose.Types.ObjectId(appId),
                    clientId: clientData._id,
                    step: 2
                }
            },
            {
                $lookup: {
                    from: 'promotions',
                    localField: 'beauticianId',
                    foreignField: 'beauticianId',
                    as: 'promotionDetails',
                    pipeline: [
                        { $project: { isDiscPercentage: 1, discount: 1, startDate: 1, endDate: 1, serviceName: 1, subTypeId: 1 } },
                        {
                            $match:
                            {
                                $and: [
                                    {
                                        startDate: {
                                            $lte: new Date(),
                                        }
                                    },
                                    {
                                        endDate: {
                                            $gte: new Date(),
                                        }
                                    },
                                ]
                            }
                        }
                    ]
                },
            },
            {
                $lookup: {
                    from: "beauticianservices",
                    localField: "serviceId",
                    foreignField: "_id",
                    as: "beauticianServiceData",
                }
            },
            {
                $unwind: { path: '$beauticianServiceData', preserveNullAndEmptyArrays: true },
            },
            {
                $lookup: {
                    from: "servicetypelists",
                    localField: "beauticianServiceData.serviceType",
                    foreignField: "_id",
                    as: "beauticianServiceData.serviceTypeData",
                }
            },
        ]);
        if (discountData.length) {
            appointmentData.promPrice = null;
            await discountData[0]?.promotionDetails.forEach((val) => {
                // if (val.subTypeId.toString() === discountData[0]?.beauticianServiceData?.serviceTypeData[0]?._id.toString()) {
                if (val?.subTypeId?.toString() === appointmentData?.serviceId?._id.toString()) {
                    if (val.isDiscPercentage == 1) {
                        appointmentData.promPrice = Math.round(discountData[0]?.beauticianServiceData?.price - (discountData[0]?.beauticianServiceData.price * val.discount / 100));
                    } else {
                        appointmentData.promPrice = Math.round(discountData[0]?.beauticianServiceData?.price - val.discount);
                    }
                }
            });
        }
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: appointmentData, message: "Appointment details fetch successfully" });
    } else {
        throw new ErrorHandler(req.t("appoimentNotFound"), HttpStatus.BAD_REQUEST, false);
    }
});
//  Add Appointment by Client
const addAppointment = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { appId } = req.params;
    const { customerId, serviceId, dateTime, employeeId, price, place, note, serviceDuration, recurringOpt } = req.body;
    const timeToCheck = moment(dateTime, 'DD MMM YYYY HH:mm');
    const errors = validationResult(req);
    if (!timeToCheck.isSameOrAfter(moment())) {
        throw new ErrorHandler("select Future date and time.", HttpStatus.BAD_REQUEST, false)
    }
    if (errors.errors.length !== 0) {
        throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST);
    };
    if (serviceDuration && !checkDurationFormate(serviceDuration)) {
        throw new ErrorHandler("Invalid formate serviceDuration.", HttpStatus.BAD_REQUEST, false)
    }
    //get serviceData data
    let serviceData = await BeauticianService.aggregate([
        { $match: { _id: new mongoose.Types.ObjectId(serviceId) } },
        {
            $lookup: {
                from: 'bookingsettings',
                localField: 'beauticianId',
                foreignField: 'beauticianId',
                as: 'bookingSetting'
            }
        },
        {
            $lookup: {
                from: 'beauticians',
                localField: 'beauticianId',
                foreignField: '_id',
                as: 'beauticianSetUp'
            }
        }
    ]);
    //check  according to booking setting and futureBooking
    if (serviceData?.[0]) {

        serviceData = serviceData[0];
        if (!serviceData.beauticianSetUp[0].stripe_id && req.baseUrl.includes("beautician")) {
            throw new ErrorHandler(req.t("stripeIsPending"), HttpStatus.BAD_REQUEST, false);
        }
        if (serviceData.beauticianSetUp[0].IsServeAtClient == 0 && place == 1) {
            throw new ErrorHandler(req.t("isNotProvideHomeService"), HttpStatus.BAD_REQUEST, false)
        }
        if (serviceData.beauticianSetUp[0].IsServeAtOwnPlace == 0 && place == 0) {
            throw new ErrorHandler(req.t("isNotProvideatOwnService"), HttpStatus.BAD_REQUEST, false)
        }
        if (!serviceData.isBookOnline) {
            throw new ErrorHandler(req.t("onlineBookingIsNotAvailableForService"), HttpStatus.BAD_REQUEST, false);
        }
        if (!serviceData.isHomeService && place == 1) {
            throw new ErrorHandler(req.t("isNotHomeService"), HttpStatus.BAD_REQUEST, false);
        }
        if (serviceData.bookingSetting?.[0]) {
            //check for confirm Auto 
            let bookingSetting = serviceData.bookingSetting?.[0]
            if (!bookingSetting.confirmAuto) {
                throw new ErrorHandler(req.t("onlineBookingIsNotAvailable"), HttpStatus.BAD_REQUEST, false);
            }
            if (bookingSetting.bookingWindow) {
                const bookingWindow = bookingSetting.bookingWindow.split(":");
                const desiredTime = moment().clone().add(parseInt(bookingWindow[0]), 'hours').add(parseInt(bookingWindow[1]), 'minutes');
                // Compare the current time with the desired time
                if (!timeToCheck.isAfter(desiredTime)) {
                    throw new ErrorHandler(req.t("bookingWindowError", { bookingWindow: bookingSetting.bookingWindow }), HttpStatus.BAD_REQUEST, false);
                }
            }
            // check time should be less than selected future value of beautician
            if (bookingSetting.futureBookingDay || bookingSetting.futureBookingMonths) {
                let desiredTime = bookingSetting.futureBookingDay ? moment().clone().add(bookingSetting.futureBookingDay, 'days') : moment().clone().add(bookingSetting.futureBookingMonths, 'months');
                let addType = bookingSetting.futureBookingDay ? 'days' : 'months';
                if (!timeToCheck.isBefore(desiredTime)) {
                    throw new ErrorHandler(req.t("inAdvanceError", { futureBookingDay: bookingSetting.futureBookingDay, futureBookingMonths: bookingSetting.futureBookingMonths, addType: addType }), HttpStatus.BAD_REQUEST, false);
                }
            }
            if (appId) {
                //check value according to rescheduling time limit value
                const oldAppointment = await Appointment.findById(appId)
                if (oldAppointment && bookingSetting.rescheduling) {
                    const bookingWindow = bookingSetting.rescheduling.split(":");
                    const desiredTime = moment.utc(oldAppointment.dateTime).subtract(parseInt(bookingWindow[0]), 'hours').subtract(parseInt(bookingWindow[1]), 'minutes');
                    if (!moment(desiredTime).isAfter(moment())) {
                        throw new ErrorHandler(req.t("rescheduleError", { rescheduling: bookingSetting.rescheduling }), HttpStatus.BAD_REQUEST, false);
                    }
                }
            }
        }

    }

    // set createdBy
    let clientId, updatedBy, createdBy, step
    if (customerId && req.baseUrl.includes("beautician")) {
        clientId = await Client.findOne({ _id: customerId });
        createdBy = updatedBy = "beautician"
        step = 1
    } else if (id && req.baseUrl.includes("client")) {
        clientId = await Client.findOne({ userId: id });
        createdBy = updatedBy = "client"
        step = 2
    } else {
        throw new ErrorHandler("Something went wrong : client details not found.", HttpStatus.BAD_GATEWAY);
    }

    if (clientId) {
        //check that current client has booked appointment for same slot and date appointment pending case
        const SameDate = new Date(Date.UTC(timeToCheck.year(), timeToCheck.month(), timeToCheck.date(), timeToCheck.hour(), timeToCheck.minute(), timeToCheck.second()));
        const isAppoByClient = await Appointment.aggregate([
            { $match: { clientId: new mongoose.Types.ObjectId(clientId._id), status: 0, dateTime: SameDate } }
        ]);
        if (isAppoByClient.length > 0) {
            throw new ErrorHandler(req.t("alreadyAppoiment"), HttpStatus.BAD_REQUEST, false)
        }
        if (serviceData) {
            const isClientEqualBeautician = await Beautician.findOne({ _id: serviceData.beauticianId, userId: clientId.userId });

            if (isClientEqualBeautician !== null) {
                throw new ErrorHandler(req.t("ownShopAppoiment"), HttpStatus.BAD_REQUEST, false);
            }
            const workHours = await BeauticianWorkHour.findOne({ beauticianId: serviceData.beauticianId });
            if (workHours) {
                let isShopOpen = workHours.dayDetails.filter(ele => {
                    return ele.day === timeToCheck.format('dddd') && ele.isOpen
                });
                const isShopCalender = workHours.calenderSetting?.filter(val => { // check work hour detail according to calender settings
                    return moment(val.date).format('YYYY-MM-DD') === timeToCheck.format('YYYY-MM-DD')
                });

                if (isShopCalender?.[0]?.isOpen) {
                    isShopOpen = isShopCalender;
                } else if (isShopCalender.length > 0 && !isShopCalender?.[0]?.isOpen) {
                    throw new ErrorHandler(req.t("shopIsNotOpen"), HttpStatus.BAD_REQUEST, false)
                }

                if (isShopOpen.length > 0) {
                    const startTime = moment(isShopOpen[0].startTime, 'HH:mm').format('HH:mm');
                    if (isShopOpen[0].endTime === "24:00") {
                        isShopOpen[0].endTime = "23:59"
                    }
                    const endTime = moment(isShopOpen[0].endTime, 'HH:mm').format('HH:mm');
                    const breakStartTime = moment(isShopOpen[0].breakStartTime, 'HH:mm').format('HH:mm');
                    const breakEndTime = moment(isShopOpen[0].breakEndTime, 'HH:mm').format('HH:mm')
                    let timeToCheckTime = timeToCheck.format('HH:mm')

                    if (timeToCheckTime >= startTime && timeToCheckTime <= endTime && !(timeToCheckTime >= breakStartTime && timeToCheckTime <= breakEndTime)) {
                        timeToCheckTime = timeToCheck.format('YYYY-MM-DD HH:mm')

                        const matchQuery = {
                            beauticianId: new mongoose.Types.ObjectId(serviceData.beauticianId),
                            $expr: {
                                $and: [
                                    {
                                        $gte: [
                                            timeToCheckTime,
                                            { $dateToString: { format: '%Y-%m-%d %H:%M', date: '$dateTime' } }
                                        ]
                                    },
                                    {
                                        $lt: [
                                            timeToCheckTime,
                                            { $dateToString: { format: '%Y-%m-%d %H:%M', date: '$endDateTime' } }
                                        ]
                                    }
                                ]
                            },
                            step: 2,
                            status: 1 // for beautician has confirm booking
                        }

                        if (appId) {
                            matchQuery._id = { $ne: new mongoose.Types.ObjectId(appId) }
                        }
                        const bookedAppointment = await Appointment.aggregate([{ $match: matchQuery }]);
                        let isBookingAllow = !(bookedAppointment.length > 0);
                        if (employeeId && bookedAppointment.length > 0) {
                            // matchQuery.stylistID = new mongoose.Types.ObjectId(employeeId);
                            let employeeAppointments = bookedAppointment.filter(appointment => {
                                return appointment.stylistID.equals(employeeId);
                            });
                            if (employeeAppointments?.length > 0) {
                                throw new ErrorHandler(req.t("stylishIsNotAvailable"), HttpStatus.BAD_REQUEST, false)
                            }
                        }
                        // check according to parallel client numbers
                        if (serviceData.noOfParallelClient) {
                            if (serviceData.noOfParallelClient > bookedAppointment?.length) {
                                isBookingAllow = true;
                            } else {
                                isBookingAllow = false;
                            }
                        }
                        // check for in between interval value
                        if (serviceData.inBetweenInterval) {
                            const interval = serviceData.inBetweenInterval.split(":");
                            const getEndTime = moment(timeToCheck).clone().subtract(parseInt(interval[0]), 'hours').subtract(parseInt(interval[1]), 'minutes').format('YYYY-MM-DD HH:mm');
                            const endOnListAppoint = await Appointment.aggregate([
                                {
                                    $match: {
                                        status: 1,
                                        beauticianId: new mongoose.Types.ObjectId(serviceData.beauticianId),
                                        serviceId: new mongoose.Types.ObjectId(serviceId),
                                        $expr: {
                                            $and: [
                                                {
                                                    $gte: [
                                                        getEndTime,
                                                        { $dateToString: { format: '%Y-%m-%d %H:%M', date: '$dateTime' } }
                                                    ]
                                                },
                                                {
                                                    $lte: [
                                                        getEndTime,
                                                        { $dateToString: { format: '%Y-%m-%d %H:%M', date: '$endDateTime' } }
                                                    ]
                                                }
                                            ]
                                        },
                                    }
                                }
                            ]);
                            if (endOnListAppoint.length > 0) isBookingAllow = false;
                            if (serviceData.noOfParallelClient > endOnListAppoint.length) {
                                isBookingAllow = true;
                            }
                        }
                        if (isBookingAllow) {
                            const formateDate = new Date(Date.UTC(timeToCheck.year(), timeToCheck.month(), timeToCheck.date(), timeToCheck.hour(), timeToCheck.minute(), timeToCheck.second()));
                            const serviceEndTime = moment(timeToCheck).add(moment.duration(serviceDuration).asMinutes(), 'minutes')
                            const endFormateDate = new Date(Date.UTC(serviceEndTime.year(), serviceEndTime.month(), serviceEndTime.date(), serviceEndTime.hour(), serviceEndTime.minute(), serviceEndTime.second()));

                            let appointmentId;
                            let updateApp;
                            if (appId) {
                                //for update appointment
                                updateApp = await Appointment.findById(appId);
                            }
                            if (updateApp && (updateApp.status === 0 || updateApp.status === 1)) {
                                updateApp.dateTime = formateDate;
                                updateApp.endDateTime = endFormateDate;
                                updateApp.updatedBy = updatedBy;
                                updateApp.note = note
                                updateApp.place = place;
                                updateApp.recurringOpt = recurringOpt;
                                updateApp.step = step
                                if (employeeId) {
                                    updateApp.stylistID = employeeId;
                                }
                                await updateApp.save();
                                const EmailData = await Appointment.aggregate([
                                    {
                                        $match: {
                                            _id: new mongoose.Types.ObjectId(appId),
                                        }
                                    },
                                    {
                                        $lookup: {
                                            from: "beauticianservices",
                                            localField: "serviceId",
                                            foreignField: "_id",
                                            as: 'serviceDetails',
                                            pipeline: [
                                                { $project: { serviceType: 1 } }
                                            ]

                                        },
                                    },
                                    {
                                        $lookup: {
                                            from: "servicetypelists",
                                            localField: "serviceDetails.serviceType",
                                            foreignField: "_id",
                                            as: 'ServiceTypeDetails',
                                            pipeline: [
                                                { $project: { serviceTypeName: 1, serviceTypeName_fr: 1, serviceCategoryId: 1 } }
                                            ]
                                        },
                                    },
                                    {
                                        $lookup: {
                                            from: "beauticians",
                                            localField: "beauticianId",
                                            foreignField: "_id",
                                            as: 'beauticianDetails',
                                        },
                                    },
                                    {
                                        $lookup: {
                                            from: "clients",
                                            localField: "clientId",
                                            foreignField: "_id",
                                            as: 'clientDetails',
                                        },
                                    },
                                    {
                                        $lookup: {
                                            from: "users",
                                            localField: "beauticianDetails.userId",
                                            foreignField: "_id",
                                            as: 'beauticianUser',
                                        },
                                    },
                                    {
                                        $lookup: {
                                            from: "users",
                                            localField: "clientDetails.userId",
                                            foreignField: "_id",
                                            as: 'userDetails',
                                        },
                                    },
                                    {
                                        $lookup: {
                                            from: "addresses",
                                            localField: "clientDetails.address.addressId",
                                            foreignField: "_id",
                                            as: "userAddressData",
                                            pipeline: [
                                                { $project: { address: 1, street: 1, apartment: 1 } }
                                            ]
                                        }
                                    },
                                    {
                                        $lookup: {
                                            from: "addresses",
                                            localField: "beauticianDetails.address",
                                            foreignField: "_id",
                                            as: "beauticianAddressData",
                                            pipeline: [
                                                { $project: { address: 1, street: 1, apartment: 1, city: 1, zipCode: 1 } }
                                            ]
                                        }
                                    },
                                    {
                                        $project: {
                                            status: 1,
                                            dateTime: 1,
                                            place: 1,
                                            beauticanEmail: { $arrayElemAt: ['$beauticianUser.email', 0] },
                                            userAddressData: 1,
                                            beauticianAddressData: 1,
                                            date: { $dateToString: { format: "%d-%m-%Y", date: "$dateTime" } },
                                            time: { $dateToString: { format: "%H:%M", date: "$dateTime" } },
                                            ServiceTypeName: { $arrayElemAt: ['$ServiceTypeDetails.serviceTypeName', 0] },
                                            ServiceTypeName_fr: { $arrayElemAt: ['$ServiceTypeDetails.serviceTypeName_fr', 0] },
                                            firstName: { $arrayElemAt: ['$clientDetails.firstName', 0] },
                                            lastName: { $arrayElemAt: ['$clientDetails.lastName', 0] },
                                            phoneNumber: { $arrayElemAt: ['$userDetails.phoneNumber', 0] },
                                            businessName: { $arrayElemAt: ['$beauticianDetails.businessName', 0] },
                                            clientEmail: { $arrayElemAt: ['$userDetails.email', 0] },
                                        }
                                    }
                                ]);

                                let tempAddess = [];
                                if (EmailData[0].place == 1) {
                                    tempAddess = EmailData[0].userAddressData.map((val) => {
                                        return [val?.apartment, val?.street, val?.address,];
                                    })
                                } else {
                                    tempAddess = EmailData[0].beauticianAddressData.map((val) => {
                                        return [val?.apartment, val?.street, val?.address, val?.city, val?.zipCode];
                                    })
                                }

                                const emailDetails = {
                                    email: EmailData[0].beauticanEmail,
                                    businessName: EmailData[0].businessName,
                                    firstName: EmailData[0].firstName,
                                    lastName: EmailData[0].lastName,
                                    phoneNumber: EmailData[0].phoneNumber.toString(),
                                    day: moment(EmailData[0].dateTime).format("dddd"),
                                    date: EmailData[0].date,
                                    time: EmailData[0].time,
                                    address: tempAddess.toString(),
                                    serviceTypeName: EmailData[0].ServiceTypeName,
                                    clientEmail: EmailData[0].clientEmail
                                }
                                await updateAppEmailB(emailDetails);
                                await updateAppEmailC(emailDetails);
                                appointmentId = updateApp._id;
                            } else {
                                //for new appointment 
                                const newApp = await Appointment.create({
                                    clientId: clientId._id, beauticianId: serviceData.beauticianId, serviceId, place, dateTime: formateDate, endDateTime: endFormateDate, price, note, createdBy, recurringOpt, step
                                });
                                if (employeeId) {
                                    newApp.stylistID = employeeId;
                                    await newApp.save();
                                }
                                appointmentId = newApp._id;

                            }
                            return res.status(HttpStatus.CREATED).json({ status: HttpStatus.CREATED, success: true, data: { appointmentId }, message: `Appointment ${appId ? 'updated' : 'added'} successfully` });
                        } else {
                            throw new ErrorHandler(req.t("chooseDiifrentTimeSlaot"), HttpStatus.BAD_REQUEST, false)
                        }
                    } else {
                        throw new ErrorHandler(req.t("beauticianTime"), HttpStatus.BAD_REQUEST, false)
                    }
                } else {
                    throw new ErrorHandler(req.t("shopIsNotOpen"), HttpStatus.BAD_REQUEST, false)
                }
            } else {
                throw new ErrorHandler(req.t("workHourNotFound"), HttpStatus.BAD_REQUEST);
            }
        } else {
            throw new ErrorHandler(req.t("serviceNotFound"), HttpStatus.BAD_REQUEST);
        }
    } else {
        throw new ErrorHandler(req.t("clientNotFound"), HttpStatus.BAD_REQUEST);
    }
});

//get employee/stylist list
const getStylishList = catchAsyncError(async (req, res, next) => {
    const { beauticianId, serviceId } = req.body;
    if (serviceId && beauticianId) {
        const stylishDetails = await Employee.aggregate([
            { $match: { beauticianId: new mongoose.Types.ObjectId(beauticianId) } },
            { $unwind: "$serviceIds" },
            { $match: { "serviceIds": new mongoose.Types.ObjectId(serviceId) } },
            { $project: { _id: 1, firstName: 1, lastName: 1 } }
        ]);
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "employee list for selected service", data: stylishDetails })
    } else {
        throw new ErrorHandler("serviceId or beauticianId is missing from query", HttpStatus.BAD_REQUEST, false)
    }
});

// Get Booked Appointment for Client
const getBookedPendingAppointment = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { appointmentIds, latitude, longitude } = req.body;
    const clientData = await Client.findOne({ userId: id });
    if (!appointmentIds) {
        throw new ErrorHandler("appointmentIds is missing", HttpStatus.BAD_REQUEST, false)
    }

    const appointmentId = appointmentIds.map(id => new mongoose.Types.ObjectId(id));
    if (clientData) {
        const data = await Appointment.find({
            _id: { $in: appointmentId },
            clientId: clientData._id,
            status: 0,
            step: 2,
            dateTime: { $gte: new Date().toLocaleString("en-US", { timeZone: "America/New_York" }) }
        }).populate([
            {
                path: 'beauticianId',
                select: 'firstName lastName gender logo logoPath businessName rating ',
                populate: [{ path: 'address', select: "-createdAt -updatedAt -__v" }],
            },
            {
                path: "serviceId", select: '-createdAt -updatedAt -__v',
                populate: [{ path: 'serviceCategory', select: '_id serviceCategoryName' }, { path: 'serviceType', select: '_id serviceTypeName' }],
            },
            {
                path: 'stylistID', select: 'firstName lastName profileImage'
            },
            {
                path: "paymentDetails", select: 'BookingId'
            }
        ]).lean();
        if (data && data[0].beauticianId.logo) {
            data[0].beauticianId.logoPath = data[0].beauticianId.logo;
        }
        if (longitude && latitude) {

            const beauticianDis = await Beautician.aggregate([
                {
                    $geoNear: {
                        near: { type: 'Point', coordinates: [parseFloat(longitude), parseFloat(latitude)] },
                        key: "location",
                        distanceField: `dis.calculated`,
                        spherical: true,
                        distanceMultiplier: 1 / 1000
                    },

                },
                { $match: { _id: new mongoose.Types.ObjectId(data[0].beauticianId._id) } }
                , {
                    $project: { dis: 1 }
                }
            ])
            if (beauticianDis && beauticianDis[0].dis) {
                data[0].beauticianId.distance = beauticianDis[0].dis.calculated.toFixed(2);
            }
        } else {
            throw new ErrorHandler(req.t("locationNotFound"), HttpStatus.BAD_REQUEST, false)
        }
        const discountData = await Appointment.aggregate([
            {
                $match: { _id: { $in: appointmentId } },
            },
            {
                $lookup: {
                    from: 'beauticianservices',
                    localField: 'serviceId',
                    foreignField: '_id',
                    pipeline: [
                        { $project: { createdAt: 0, updatedAt: 0, __v: 0, serviceCategoryId: 0 } },
                    ],
                    as: 'serviceData',
                },
            },
            {
                $lookup: {
                    from: 'servicetypelists',
                    localField: 'serviceData.serviceType',
                    foreignField: '_id',
                    pipeline: [
                        { $project: { createdAt: 0, updatedAt: 0, __v: 0, serviceCategoryId: 0 } },
                    ],
                    as: 'serviceData.serviceTypeData',
                },
            },
            {
                $lookup: {
                    from: 'promotions',
                    localField: 'beauticianId',
                    foreignField: 'beauticianId',
                    as: 'promotionDetails',
                    pipeline: [
                        { $project: { isDiscPercentage: 1, discount: 1, startDate: 1, endDate: 1, serviceName: 1, subTypeId: 1 } },
                        {
                            $match:
                            {
                                $and: [
                                    {
                                        startDate: {
                                            $lte: new Date(),
                                        }
                                    },
                                    {
                                        endDate: {
                                            $gte: new Date(),
                                        }
                                    },
                                ]
                            }
                        }
                    ]
                },
            },
        ]);

        if (data?.length) {
            data.forEach((val) => {
                val.promoPrice = null;
                if (discountData.length) {
                    discountData?.forEach((ele) => {
                        if (ele.promotionDetails.length) {
                            ele.promotionDetails.forEach((promo) => {
                                if (promo.subTypeId.toString() === ele?.serviceId.toString()) {
                                    if (val?.serviceId?._id.toString() === ele?.serviceId.toString()) {
                                        if (promo?.isDiscPercentage == 1) {
                                            val.promoPrice = Math.round(val.price - (val.price * promo.discount / 100));
                                        } else {
                                            val.promoPrice = promPrice = Math.round(val.price - promo.discount);
                                        }
                                    }
                                    // if (val?.serviceId?.serviceType?._id.toString() === ele?.serviceId.toString()) {
                                    //     if (promo?.isDiscPercentage == 1) {
                                    //         val.promoPrice = Math.round(val.price - (val.price * promo.discount / 100));
                                    //     } else {
                                    //         val.promoPrice = promPrice = Math.round(val.price - promo.discount);
                                    //     }
                                    // }
                                }
                            })
                        }
                    })
                }
            });
        }

        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data });

    } else {
        throw new ErrorHandler(req.t("clientNotFound"), HttpStatus.BAD_REQUEST);
    }
});

//past , upcoming appointment
const getAppointmentList = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { status } = req.query;
    if (!status) {
        throw new ErrorHandler("status is messing in query", HttpStatus.BAD_REQUEST, false)
    }
    const clientData = await Client.findOne({ userId: id });

    if (clientData) {
        const findQuery = { clientId: clientData._id, step: 2 }
        let matchQuery = {
            // dateTime: { $lte: new Date().toLocaleString("en-US", { timeZone: "America/New_York" }) }
        }
        if (status === "past") {
            findQuery.dateTime = { $lte: new Date().toLocaleString("en-US", { timeZone: "America/New_York" }) }
            matchQuery.dateTime = { $lte: new Date() }
        } else if (status === "upcoming") {
            findQuery.dateTime = { $gte: new Date().toLocaleString("en-US", { timeZone: "America/New_York" }) }
            matchQuery.dateTime = { $gte: new Date() }
        }
        let data = await Appointment.find(findQuery)
            .populate([
                {
                    path: 'beauticianId', select: 'firstName lastName gender profileImage logo businessName rating',
                    populate: [{ path: 'address' }],
                },
                {
                    path: "serviceId", select: '-createdAt -updatedAt -__v',
                    populate: [{ path: 'serviceCategory', select: '_id serviceCategoryName' }, { path: 'serviceType', select: '_id serviceTypeName' }],
                },
                {
                    path: 'stylistID', select: 'firstName lastName profileImage'
                },
                {
                    path: "paymentDetails", select: 'BookingId'
                }
            ])
            .sort({ createdAt: -1 })
            .lean();

        const tempData = await Appointment.aggregate([
            {
                $match: {
                    $and: [
                        matchQuery,
                        {
                            clientId: clientData._id,
                        },
                        {
                            step: 2
                        },
                        { status: 0 }
                    ]
                }
            },
            {
                $lookup: {
                    from: "beauticians",
                    localField: "beauticianId",
                    foreignField: "_id",
                    pipeline: [
                        { $project: { firstName: 1, lastName: 1, gender: 1, profileImage: 1, logo: 1, businessName: 1 } },
                    ],
                    as: "beauticianDetails"
                }
            },
            {
                $lookup: {
                    from: 'promotions',
                    localField: 'beauticianId',
                    foreignField: 'beauticianId',
                    as: 'promotionDetails',
                    pipeline: [
                        { $project: { isDiscPercentage: 1, discount: 1, startDate: 1, endDate: 1, subTypeId: 1, serviceName: 1 } },
                        {
                            $match:
                            {
                                $and: [
                                    {
                                        startDate: {
                                            $lte: new Date(),
                                        }
                                    },
                                    {
                                        endDate: {
                                            $gte: new Date(),
                                        }
                                    },
                                ]
                            }
                        }
                    ]
                },
            },
            { $lookup: { from: 'beauticianservices', localField: 'serviceId', foreignField: '_id', as: 'serviceDetails' }, },
            {
                $lookup: {
                    from: 'servicetypelists',
                    localField: 'serviceDetails.serviceType',
                    foreignField: '_id',
                    pipeline: [
                        { $project: { createdAt: 0, updatedAt: 0, __v: 0, serviceCategoryId: 0 } },
                    ],
                    as: 'serviceType',
                },
            },
            { $sort: { createdAt: - 1 } }

        ]);
        if (tempData.length && data.length) {
            data.forEach((val) => {
                val.promoPrice = null
                tempData.forEach((ele) => {
                    if (val._id.toString() === ele._id.toString()) {
                        if (ele?.promotionDetails?.length) {
                            ele.promotionDetails.forEach((promo) => {
                                if (promo?.subTypeId.toString() === val?.serviceId?.serviceType?._id.toString()) {
                                    let pro = null;
                                    if (promo.isDiscPercentage) {
                                        promPrice = val.price - (val.price * promo.discount / 100);
                                        pro = Math.round(promPrice);
                                    } else {
                                        promPrice = val.price - promo.discount;
                                        pro = Math.round(promPrice);
                                    }
                                    val.promoPrice = pro
                                }
                            })
                        }
                    }
                })
            })
        }

        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data });
    } else {
        throw new ErrorHandler(req.t("clientNotFound"), HttpStatus.BAD_REQUEST);
    }
});

//add rating and review
const addRating = catchAsyncError(async (req, res, next) => {
    const { appointmentId, rating, reviews } = req.body;
    const isAppointment = await Appointment.findOne({ _id: appointmentId });

    if (isAppointment) {
        const newRating = await Rating.create({
            appointmentId, rating
        });
        if (reviews) {
            newRating.reviews = reviews;
            await newRating.save();
        }
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("addRatingSuccess") });
    } else {
        throw new ErrorHandler(req.t("appoimentNotFound"), HttpStatus.BAD_REQUEST);
    }
});

//cancel appointment
const cancelAppointment = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { appId } = req.params;
    const clientData = await Client.aggregate([
        { $match: { userId: new mongoose.Types.ObjectId(id) } },
        {
            $lookup: {
                from: 'fcmnotifications',
                localField: '_id',
                foreignField: 'memberId',
                as: 'deviceData',
                pipeline: [
                    { $project: { firebaseToken: 1 } }
                ]
            }
        },
        {
            $project: {
                deviceData: 1,
            }
        }
    ]);

    const isPastAppointment = await Appointment.findOne({ _id: appId, clientId: clientData[0]._id });
    if (isPastAppointment && moment(isPastAppointment?.dateTime).isBefore(moment())) {
        throw new ErrorHandler(req.t("pastAppoiment"), HttpStatus.BAD_REQUEST, false);
    }
    const isFutureAppointment = await Appointment.aggregate([
        {
            $match: {
                _id: new mongoose.Types.ObjectId(appId),
                clientId: new mongoose.Types.ObjectId(clientData[0]._id),
                // dateTime: { $gte: new Date().toLocaleString("en-US", { timeZone: "America/New_York" }) }
            }
        },
        {
            $lookup: {
                from: "beauticianservices",
                localField: "serviceId",
                foreignField: "_id",
                as: 'serviceDetails',
                pipeline: [
                    { $project: { serviceType: 1 } }
                ]

            },
        },
        {
            $lookup: {
                from: "servicetypelists",
                localField: "serviceDetails.serviceType",
                foreignField: "_id",
                as: 'ServiceTypeDetails',
                pipeline: [
                    { $project: { serviceTypeName: 1, serviceTypeName_fr: 1, serviceCategoryId: 1 } }
                ]
            },
        },
        {
            $lookup: {
                from: "beauticians",
                localField: "beauticianId",
                foreignField: "_id",
                as: 'beauticianDetails',
                pipeline: [
                    { $project: { cancelProtection: 1 } }
                ]
            },
        },
        {
            $project: {
                status: 1,
                dateTime: 1,
                date: { $dateToString: { format: "%d-%m-%Y", date: "$dateTime" } },
                time: { $dateToString: { format: "%H:%M", date: "$dateTime" } },
                ServiceTypeName: { $arrayElemAt: ['$ServiceTypeDetails.serviceTypeName', 0] },
                ServiceTypeName_fr: { $arrayElemAt: ['$ServiceTypeDetails.serviceTypeName_fr', 0] },
                cancelProtection: { $arrayElemAt: ['$beauticianDetails.cancelProtection', 0] }
            }
        }
    ]);

    const EmailData = await Appointment.aggregate([
        {
            $match: {
                _id: new mongoose.Types.ObjectId(appId),
                clientId: new mongoose.Types.ObjectId(clientData[0]._id),
                // dateTime: { $gte: new Date().toLocaleString("en-US", { timeZone: "America/New_York" }) }
            }
        },
        {
            $lookup: {
                from: "beauticianservices",
                localField: "serviceId",
                foreignField: "_id",
                as: 'serviceDetails',
                pipeline: [
                    { $project: { serviceType: 1 } }
                ]

            },
        },
        {
            $lookup: {
                from: "servicetypelists",
                localField: "serviceDetails.serviceType",
                foreignField: "_id",
                as: 'ServiceTypeDetails',
                pipeline: [
                    { $project: { serviceTypeName: 1, serviceTypeName_fr: 1, serviceCategoryId: 1 } }
                ]
            },
        },
        {
            $lookup: {
                from: "beauticians",
                localField: "beauticianId",
                foreignField: "_id",
                as: 'beauticianDetails',
            },
        },
        {
            $lookup: {
                from: "clients",
                localField: "clientId",
                foreignField: "_id",
                as: 'clientDetails',
            },
        },
        {
            $lookup: {
                from: "users",
                localField: "beauticianDetails.userId",
                foreignField: "_id",
                as: 'beauticianUser',
            },
        },
        {
            $lookup: {
                from: "users",
                localField: "clientDetails.userId",
                foreignField: "_id",
                as: 'userDetails',
            },
        },
        {
            $lookup: {
                from: "addresses",
                localField: "clientDetails.address.addressId",
                foreignField: "_id",
                as: "userAddressData",
                pipeline: [
                    { $project: { address: 1, street: 1, apartment: 1 } }
                ]
            }
        },
        {
            $lookup: {
                from: "addresses",
                localField: "beauticianDetails.address",
                foreignField: "_id",
                as: "beauticianAddressData",
                pipeline: [
                    { $project: { address: 1, street: 1, apartment: 1, city: 1, zipCode: 1 } }
                ]
            }
        },
        {
            $project: {
                status: 1,
                dateTime: 1,
                place: 1,
                beauticanEmail: { $arrayElemAt: ['$beauticianUser.email', 0] },
                userAddressData: 1,
                beauticianAddressData: 1,
                date: { $dateToString: { format: "%d-%m-%Y", date: "$dateTime" } },
                time: { $dateToString: { format: "%H:%M", date: "$dateTime" } },
                ServiceTypeName: { $arrayElemAt: ['$ServiceTypeDetails.serviceTypeName', 0] },
                ServiceTypeName_fr: { $arrayElemAt: ['$ServiceTypeDetails.serviceTypeName_fr', 0] },
                cancelProtection: { $arrayElemAt: ['$beauticianDetails.cancelProtection', 0] },
                firstName: { $arrayElemAt: ['$clientDetails.firstName', 0] },
                lastName: { $arrayElemAt: ['$clientDetails.lastName', 0] },
                phoneNumber: { $arrayElemAt: ['$userDetails.phoneNumber', 0] },
                businessName: { $arrayElemAt: ['$beauticianDetails.businessName', 0] },
                bookingEmailNotification: { $arrayElemAt: ['$beauticianDetails.bookingEmailNotification', 0] },
                CancelDay: moment().format("dddd"),
                Cancellation_date: moment().format('DD-MM-YYYY'),
                clientEmail: { $arrayElemAt: ['$userDetails.email', 0] },
                Cancellation_time: moment().format("HH:MM a")
            }
        }
    ]);

    if (isFutureAppointment.length > 0 && (isFutureAppointment[0].status === 3 || isFutureAppointment[0].status === 4)) {
        throw new ErrorHandler(req.t("alredayCancel"), HttpStatus.BAD_REQUEST, false)
    }
    if (isFutureAppointment.length > 0 && moment(isFutureAppointment?.[0]?.dateTime).isAfter(moment())) {
        await Appointment.findByIdAndUpdate(appId, { status: 3, $set: { cancelationPolicyNub: isFutureAppointment[0].cancelProtection } });
        //push notification to client 
        if (clientData[0].deviceData.length > 0) {
            const deviceIds = [];
            clientData[0].deviceData.forEach(ele => {
                if (ele.firebaseToken !== null) {
                    deviceIds.push(ele.firebaseToken);
                }
            });

            if (deviceIds.length > 0) {
                let message = notificationMSGs.bookingCancelClientCtx({ serviceName: isFutureAppointment[0].ServiceTypeName, date: isFutureAppointment[0].date, time: isFutureAppointment[0].time })
                fcmNotification({ messageCtx: message, deviceIds });
            }
        }
        let tempAddess = [];
        if (EmailData[0].place == 1) {
            tempAddess = EmailData[0].userAddressData.map((val) => {
                return [val?.apartment, val?.street, val?.address,];
            })
        } else {
            tempAddess = EmailData[0].beauticianAddressData.map((val) => {
                return [val?.apartment, val?.street, val?.address, val?.city, val?.zipCode];
            })
        }

        const { policy } = getPolicyDetails(EmailData[0].cancelProtection);

        const emailDetails = {
            email: EmailData[0].beauticanEmail,
            bookingEmailNotification: EmailData[0].bookingEmailNotification,
            businessName: EmailData[0].businessName,
            firstName: EmailData[0].firstName,
            lastName: EmailData[0].lastName,
            phoneNumber: EmailData[0].phoneNumber.toString(),
            day: moment(EmailData[0].dateTime).format("dddd"),
            date: EmailData[0].date,
            time: EmailData[0].time,
            address: tempAddess.toString(),
            serviceTypeName: EmailData[0].ServiceTypeName,
            cancelDay: EmailData[0].CancelDay,
            cancelDate: EmailData[0].Cancellation_date,
            cancelTime: EmailData[0].Cancellation_time,
            cancelPolicy: policy,
            clientEmail: EmailData[0].clientEmail
        }
        if (emailDetails.bookingEmailNotification) await cancelAppEmailB(emailDetails);
        await cancelAppEmailC(emailDetails);
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, EmailData, message: req.t("cancelAppointmentSuccess") });
    } else {
        throw new ErrorHandler(req.t("appoimentNotFound"), HttpStatus.BAD_REQUEST, false);
    }
});

const getPrePaymentDetails = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { appointmentIds, addressId, isUseReferral } = req.body;

    if (appointmentIds && addressId) {
        const clientDetails = await Client.aggregate([
            { $match: { userId: new mongoose.Types.ObjectId(id) } },
            { $unwind: "$address" },
            { $match: { "address.addressId": new mongoose.Types.ObjectId(addressId) } },
            {
                $lookup: {
                    from: "addresses",
                    localField: "address.addressId",
                    foreignField: "_id",
                    as: "addressData"
                }
            },
            {
                $lookup: {
                    from: "cards",
                    localField: "_id",
                    foreignField: "clientId",
                    as: "cardData",
                    pipeline: [
                        { $match: { isPrimary: 1 } },
                        { $sort: { createdAt: -1 } },
                        { $project: { _id: 0, cardName: 1, cardLastFour: 1, cardBrand: 1, expiryMonth: 1, expiryYear: 1, cardToken: 1 } },
                    ],
                }
            }
        ]);
        if (clientDetails && clientDetails[0]?.addressData) {
            const appointmentId = appointmentIds.map(id => new mongoose.Types.ObjectId(id));

            const discountData = await Appointment.aggregate([
                {
                    $match: {
                        _id: { $in: appointmentId },
                        clientId: clientDetails[0]._id,
                        status: 0,
                        step: 2
                    }
                },
                {
                    $lookup: {
                        from: 'promotions',
                        localField: 'beauticianId',
                        foreignField: 'beauticianId',
                        as: 'promotionDetails',
                        pipeline: [
                            { $project: { isDiscPercentage: 1, discount: 1, startDate: 1, endDate: 1, serviceName: 1, subTypeId: 1 } },
                            {
                                $match:
                                {
                                    $and: [
                                        {
                                            startDate: {
                                                $lte: new Date(),
                                            }
                                        },
                                        {
                                            endDate: {
                                                $gte: new Date(),
                                            }
                                        },
                                    ]
                                }
                            }
                        ]
                    },
                },
                {
                    $lookup: {
                        from: "beauticianservices",
                        localField: "serviceId",
                        foreignField: "_id",
                        as: "beauticianServiceData",
                    }
                },
                {
                    $unwind: { path: '$beauticianServiceData', preserveNullAndEmptyArrays: true },
                },
                {
                    $lookup: {
                        from: "servicetypelists",
                        localField: "beauticianServiceData.serviceType",
                        foreignField: "_id",
                        as: "beauticianServiceData.serviceTypeData",
                    }
                },
            ]);
            let totalDiscount = 0;
            if (discountData?.length) {
                discountData.forEach((val) => {
                    if (val?.promotionDetails.length) {
                        val.promotionDetails.forEach((promotion) => {
                            if (val?.beauticianServiceData?.serviceTypeData[0]?.serviceTypeName === promotion.serviceName) {
                                let promPrice = 0;
                                if (promotion.isDiscPercentage) {
                                    promPrice = val?.beauticianServiceData?.price * promotion.discount / 100;
                                    val.promPrice = Math.round(promPrice);
                                } else {
                                    promPrice = promotion.discount;
                                    val.promPrice = Math.round(promPrice);
                                }
                                totalDiscount += promPrice;
                            }
                        });
                    }
                });
            }

            const totalPrice = await Appointment.aggregate([
                {
                    $match: {
                        _id: { $in: appointmentId },
                        clientId: clientDetails[0]._id,
                        status: 0,
                        step: 2
                    }
                },
                {
                    $group: {
                        _id: null,
                        total: { $sum: "$price" },
                        totalDiscount: { $sum: "$discount" }
                    }
                }
            ]);
            if (totalPrice && totalPrice.length > 0) {
                const getTaxValues = await Province.findById(clientDetails[0].addressData[0].province);
                if (getTaxValues) {
                    let GST = 0, PST = 0, HST = 0, QST = 0;
                    getTaxValues.subType.map(ele => {
                        if (ele.taxName === "GST") GST = GST + ele.tax;
                        if (ele.taxName === "HST") HST = ele.tax + HST;
                        if (ele.taxName === "QST") QST = ele.tax + QST;
                        if (ele.taxName === "PST") PST = ele.tax + PST;
                    });
                    let subTotal = totalPrice[0].total;
                    // if (isUseReferral == 1) {
                    //     subTotal = subTotal - clientDetails[0].referralWallet;
                    //     if (subTotal <= 0) {
                    //         subTotal = 0
                    //     }
                    // }
                    const total = subTotal + subTotal * (GST / 100) + subTotal * (HST / 100) + subTotal * (QST / 100) + subTotal * (PST / 100) - totalDiscount
                    const responseData = {
                        appointmentIds,
                        cardDetails: clientDetails[0].cardData,
                        services: appointmentId.length,
                        subTotal: totalPrice[0].total,
                        GST: (subTotal * (GST / 100)).toFixed(2),
                        HST: (subTotal * (HST / 100)).toFixed(2),
                        QST: (subTotal * (QST / 100)).toFixed(2),
                        PST: (subTotal * (PST / 100)).toFixed(2),
                        // referralAmount: totalPrice[0].total - subTotal,
                        discount: totalDiscount,
                        GstInPer: GST,
                        HstInPer: HST,
                        PstInPer: PST,
                        QstInPer: QST,
                        total: total.toFixed(2)
                    }
                    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: responseData });
                } else {
                    throw new ErrorHandler("province is not found.", HttpStatus.BAD_REQUEST);
                }
            } else {
                throw new ErrorHandler("Appointment is not in pending Status.", HttpStatus.BAD_REQUEST);
            }
        } else {
            throw new ErrorHandler("AddressId is not found.", HttpStatus.BAD_REQUEST);
        }
    } else {
        throw new ErrorHandler("appointmentIds or AddressId is missing", HttpStatus.BAD_REQUEST);
    }
});
//send payment notification
async function sendNotifications(appoData, deviceBIds, clientDeviceIds, beauticianId) {
    const notifications = [];

    appoData.forEach(async ele => {
        if (deviceBIds.length > 0) {
            let message = notificationMSGs.bookingConfirmBeauticianCtx({ serviceName: ele.ServiceTypeName, date: ele.date, time: ele.time });
            await BeauticianNotification.create({
                beauticianId: beauticianId,
                title: message.title,
                details: message.message
            })
            const notificationPromise = fcmNotification({ messageCtx: message, deviceIds: deviceBIds });
            notifications.push(notificationPromise);
        }
        if (clientDeviceIds.length > 0) {
            let message = notificationMSGs.bookingConfirmClientCtx({ serviceName: ele.ServiceTypeName, date: ele.date, time: ele.time });
            const notificationPromise = fcmNotification({ messageCtx: message, deviceIds: clientDeviceIds });
            notifications.push(notificationPromise);
        }
    });
    try {
        await Promise.all(notifications);
    } catch (err) {
        console.log('Something has gone wrong!', err);
    }
}
//make payment 
const makePaymentForServices = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const errors = validationResult(req);
    if (errors.errors.length !== 0) {
        throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST, false);
    };
    const { appointmentIds, cardName, cardNumber, cardMonth, cardYear, cardCVC, cardToken, subTotal, discount, GstInPer, HstInPer, PstInPer, QstInPer, total, addressId } = req.body;

    if (appointmentIds === undefined || appointmentIds.length === 0) {
        throw new ErrorHandler("AppointmentIds is missing!", HttpStatus.BAD_REQUEST, false);
    }
    const clientDetails = await Client.findOne({ userId: id });

    let paymentMethodID;
    let isNewCard = false;
    let cardId;
    let userCard;
    let customerId;

    const isValidIDs = appointmentIds.some(id => !mongoose.Types.ObjectId.isValid(id));
    if (isValidIDs) {
        throw new ErrorHandler("Invalid appointmentIds", HttpStatus.BAD_REQUEST, false);
    }

    const appointmentId = appointmentIds.map(id => new mongoose.Types.ObjectId(id));

    const appoData = await Appointment.aggregate([
        {
            $match: { _id: { $in: appointmentId }, status: 0 }
        },
        {
            $lookup: {
                from: "beauticians",
                localField: "beauticianId",
                foreignField: "_id",
                pipeline: [
                    { $project: { stripe_id: 1, address: 1, userId: 1, businessName: 1, bookingEmailNotification: 1 } },
                ],
                as: "beauticianData"
            }
        },
        {
            $lookup: {
                from: 'addresses',
                localField: 'beauticianData.address',
                foreignField: "_id",
                as: 'address'
            }
        },
        {
            $lookup: {
                from: 'provinces',
                localField: 'address.province',
                foreignField: "_id",
                as: 'province'
            }
        },
        {
            $lookup: {
                from: "users",
                localField: "beauticianData.userId",
                foreignField: "_id",
                pipeline: [
                    { $project: { email: 1 } },
                ],
                as: "bUserData"
            }
        },
        {
            $lookup: {
                from: "beauticianservices",
                localField: "serviceId",
                foreignField: "_id",
                as: 'serviceDetails',
                pipeline: [
                    { $project: { serviceType: 1, price: 1 } }
                ]

            },
        },
        {
            $lookup: {
                from: "servicetypelists",
                localField: "serviceDetails.serviceType",
                foreignField: "_id",
                as: 'ServiceTypeDetails',
                pipeline: [
                    { $project: { serviceTypeName: 1, serviceTypeName_fr: 1, serviceCategoryId: 1 } }
                ]
            },
        },
        {
            $lookup: {
                from: 'fcmnotifications',
                localField: 'beauticianId',
                foreignField: 'memberId',
                as: 'beauticianDeviceData',
                pipeline: [
                    { $project: { firebaseToken: 1 } }
                ]
            }
        },
        {
            $lookup: {
                from: 'promotions',
                localField: 'beauticianId',
                foreignField: 'beauticianId',
                as: 'promotionDetails',
                pipeline: [
                    { $project: { isDiscPercentage: 1, discount: 1, startDate: 1, endDate: 1, serviceName: 1, subTypeId: 1 } },
                    {
                        $match:
                        {
                            $and: [
                                {
                                    startDate: {
                                        $lte: new Date(),
                                    }
                                },
                                {
                                    endDate: {
                                        $gte: new Date(),
                                    }
                                },
                            ]
                        }
                    }
                ]
            },
        },
        {
            $project: {
                place: 1,
                beauticianId: 1,
                promotionDetails: 1,
                beauticianData: {
                    _id: { $arrayElemAt: ['$beauticianData._id', 0] },
                    stripe_id: { $arrayElemAt: ['$beauticianData.stripe_id', 0] },
                    address: { $arrayElemAt: ['$address', 0] },
                    userId: { $arrayElemAt: ['$beauticianData.userId', 0] },
                    email: { $arrayElemAt: ['$bUserData.email', 0] },
                    businessName: { $arrayElemAt: ['$beauticianData.businessName', 0] },
                    provinceName: { $arrayElemAt: ['$province.name', 0] },
                    provinceName_fr: { $arrayElemAt: ['$province.name_fr', 0] },
                    bookingEmailNotification: { $arrayElemAt: ['$beauticianData.bookingEmailNotification', 0] }
                },
                dateTime: 1,
                discount: 1,
                price: { $arrayElemAt: ['$serviceDetails.price', 0] },
                date: { $dateToString: { format: "%d-%m-%Y", date: "$dateTime" } },
                time: { $dateToString: { format: "%H:%M", date: "$dateTime" } },
                ServiceTypeId: { $arrayElemAt: ['$ServiceTypeDetails._id', 0] },
                ServiceTypeName: { $arrayElemAt: ['$ServiceTypeDetails.serviceTypeName', 0] },
                ServiceTypeName_fr: { $arrayElemAt: ['$ServiceTypeDetails.serviceTypeName_fr', 0] },
                beauticianDeviceData: 1
            }
        }
    ]);
    if (appoData.length !== appointmentId.length) {
        throw new ErrorHandler(`Appointment${appointmentId.length === 0 ? "s is" : " are"} not in pending.`, HttpStatus.BAD_REQUEST, false)
    }
    let alreadyHasBooking = []
    const appointmentsPromises = appoData.map(async (details) => {
        const temp = await Appointment.aggregate([
            {
                $match: {
                    beauticianId: new mongoose.Types.ObjectId(details.beauticianId),
                    dateTime: { $lte: new Date(details.dateTime) },
                    endDateTime: { $gt: new Date(details.dateTime) },
                    status: 1 // for beautician has confirm booking
                }
            }
        ]);
        return temp[0];

    });

    const appointmentResults = await Promise.all(appointmentsPromises);
    const userDetails = await User.findById(id)
    if (appointmentResults[0]) {
        alreadyHasBooking.push(...appointmentResults);
    }

    if (alreadyHasBooking.length > 0) {
        const bookedDates = moment(alreadyHasBooking[0].dateTime).format("DD MMM YYYY HH:mm");
        throw new ErrorHandler(req.t("alredayHasBooking", { bookedDates: bookedDates }), HttpStatus.BAD_REQUEST, false)
    }
    if (clientDetails.customerId) {
        customerId = clientDetails.customerId
    } else {

        const CreateCustomerStripe = await createStripeCustomer({ email: userDetails.email, name: clientDetails.firstName + clientDetails.lastName, phone: userDetails.phoneNumber });

        if (CreateCustomerStripe.status === 200 && CreateCustomerStripe.result) {
            customerId = CreateCustomerStripe?.result.id;
            clientDetails.customerId = customerId;
            await clientDetails.save();
        } else {
            throw new ErrorHandler(CreateCustomerStripe.message, HttpStatus.BAD_REQUEST, false);
        }
    }
    if (!cardNumber || !cardMonth || !cardYear || !cardCVC) {
        throw new ErrorHandler("Card token or card details is missing", HttpStatus.BAD_REQUEST, false);
    }
    if (cardToken) {
        paymentMethodID = cardToken;
        const oldCard = await Cards.findOne({ clientId: clientDetails._id, cardToken });
        cardId = oldCard._id
    }
    if (cardNumber && cardMonth && cardYear && cardCVC) {
        const lastFour = cardNumber.slice(12);
        const data = await Cards.findOne({ clientId: clientDetails._id, cardLastFour: parseInt(lastFour), expiryMonth: cardMonth, cardCVC });
        if (data) {
            cardId = data._id;
            paymentMethodID = data.cardToken
        } else {
            userCard = await createStripeCard({
                cardNumber,
                cardMonth,
                cardYear,
                cardCVC,
            });
            if (userCard && userCard.status === 200) {
                paymentMethodID = userCard.result.id;
                //attach customerId with payment method Id
                const isAttach = await attachCustomerID({ paymentMethodID, customerId })
                if (isAttach && isAttach.status === 200) {
                    isNewCard = true;
                } else {
                    throw new ErrorHandler(isAttach.message, HttpStatus.BAD_REQUEST, false);
                }
            } else {
                throw new ErrorHandler(userCard.message, HttpStatus.BAD_REQUEST, false);
            }
        }
    }
    // else {
    //     throw new ErrorHandler("Card token or card details is missing");
    // }

    if (paymentMethodID) {

        if (isNewCard) {
            const lastFour = cardNumber.slice(12);
            const data = await Cards.findOne({ clientId: clientDetails._id, cardLastFour: parseInt(lastFour), expiryMonth: cardMonth, cardCVC });
            if (data) {
                cardId = data._id;
            } else {
                let newCard = await Cards.create({
                    clientId: clientDetails._id,
                    cardName,
                    cardBrand: userCard.result.card.networks.available[0],
                    cardLastFour: userCard.result.card.last4,
                    expiryMonth: userCard.result.card.exp_month,
                    expiryYear: userCard.result.card.exp_year,
                    cardToken: userCard.result.id,
                    cardCVC
                });
                cardId = newCard._id;
            }
        }
        const orderID = '#' + generateNumericId(7);
        const platformCut = parseFloat(subTotal) * parseFloat(platform_fees)
        const application_fees = platformCut + platformCut * (GstInPer / 100) + platformCut * (HstInPer / 100) + platformCut * (PstInPer / 100) + platformCut * (QstInPer / 100);

        // if (referralAmount > 0) {

        // }
        const paymentInfo = await makePayment({

            paymentMethodId: paymentMethodID,
            customerId,
            amount: Math.round(total * 100),
            application_fees: 0,
            // amount: Math.round((total - application_fees) * 100),
            // application_fees: Math.round(application_fees * 100),
            currency: 'CAD',
            orderID,
            beauticianAccId: appoData[0].beauticianData[0].stripe_id
        });
        if (paymentInfo.status === 200 && cardId) {
            // Chcek for referral is there or not 
            const referralData = await Referral.findOne({ userId: id, status: 0 });
            if (referralData) {
                const referralSender = await Beautician.findOne({ _id: referralData.referralId });
                if (referralSender) {
                    console.log("inside referral sendder");
                    const walletData = await Client.findOne({ userId: referralSender.userId });
                    walletData.referralWallet += referralAmount;
                    referralData.status = 1;
                    await walletData.save();
                    await referralData.save();
                }
            }

            const newPayment = await Payment.create({
                BookingId: orderID,
                clientId: clientDetails._Id,
                appointmentIds,
                cardId,
                transactionId: paymentInfo.transactionId,
                addressId,
                subTotal,
                GST: (subTotal * (GstInPer / 100)).toFixed(2),
                PST: (subTotal * (PstInPer / 100)).toFixed(2),
                QST: (subTotal * (QstInPer / 100)).toFixed(2),
                HST: (subTotal * (HstInPer / 100)).toFixed(2),
                GstInPer,
                HstInPer,
                PstInPer,
                QstInPer,
                discount,
                TotalPrice: total,
                paymentStatus: 1
            });
            await Appointment.updateMany({ _id: { $in: appointmentId } }, { status: 1, paymentDetails: newPayment._id }, { new: true });
            await Promise.all(appoData.map(async (val) => {
                let tempDiscount = 0;
                if (val?.promotionDetails.length) {
                    val.promotionDetails.map(async (ele) => {
                        if (ele.subTypeId.toString() === val.ServiceTypeId.toString()) {
                            if (ele.isDiscPercentage) {
                                tempDiscount = val.price * ele.discount / 100
                            } else {
                                tempDiscount = ele.discount;
                            }

                        }
                    })
                }
                await Appointment.findOneAndUpdate({ _id: val?._id }, { discount: tempDiscount }, { new: true })
            }));
            // notification to beautician
            const deviceBIds = [];
            if (appoData && appoData[0].beauticianDeviceData.length > 0) {
                appoData[0].beauticianDeviceData.forEach(ele => {
                    if (ele.firebaseToken !== null) {
                        deviceBIds.push(ele.firebaseToken);
                    }
                });
            }
            //notification to client
            const clientDeviceIds = [];
            const clientDeviceData = await FcmNotification.find({ memberId: clientDetails._id }).select('firebaseToken');
            if (clientDeviceData && clientDeviceData.length > 0) {
                clientDeviceData.forEach(ele => {
                    if (ele.firebaseToken !== null) {
                        clientDeviceIds.push(ele.firebaseToken);
                    }
                });
            }
            sendNotifications(appoData, deviceBIds, clientDeviceIds, appoData[0].beauticianData[0]._id);

            //send email
            const getClientAddress = await Address.findById(addressId).populate('province');
            appoData.forEach(async ele => {
                // const priceWithTax = ele.price + ele.price * (GstInPer / 100) + ele.price * (HstInPer / 100) + ele.price * (QstInPer / 100) + ele.price * (PstInPer / 100) - ele.price * (discount / 100);
                const priceWithTax = ele.price + ele.price * (GstInPer / 100) + ele.price * (HstInPer / 100) + ele.price * (QstInPer / 100) + ele.price * (PstInPer / 100) - ele.discount;
                const address = ele.place === 0 ? (ele.beauticianData[0]?.address?.address + "," + ele.beauticianData[0]?.provinceName) : (getClientAddress?.street + "," + getClientAddress?.address + "," + getClientAddress?.province?.name);
                const emailDetails = {
                    email: ele.beauticianData[0].email,
                    bookingEmailNotification: ele.beauticianData[0].bookingEmailNotification,
                    clientEmail: userDetails.email,
                    businessName: ele.beauticianData[0].businessName,
                    firstName: clientDetails.firstName,
                    lastName: clientDetails.lastName,
                    phoneNumber: userDetails.phoneNumber,
                    date: moment(ele.dateTime).utc().format('dddd, DD-MMM-YYYY'),
                    time: moment(ele.dateTime).utc().format('HH:mm A'),
                    address: address,
                    serviceTypeName: ele.ServiceTypeName,
                    price: ele.price,
                    priceWithTax: priceWithTax
                }
                if (emailDetails.email && emailDetails.bookingEmailNotification) await appConformationBEmail(emailDetails);
                if (emailDetails.clientEmail) await appConformationCEmail(emailDetails);
            })
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, message: req.t("makePaymentForServicesSuccess"), data: { transactionId: paymentInfo.transactionId, appointmentIds, BookingId: orderID } });
        } else {
            throw new ErrorHandler(paymentInfo.errorMessage, HttpStatus.BAD_REQUEST);
        }
    } else {
        throw new ErrorHandler(req.t("cardTokenMissing"), HttpStatus.BAD_REQUEST);
    }

});

const appointmentDetails = catchAsyncError(async (req, res, next) => {
    const { bookingId, appointmentIds } = req.body;

    if (!(appointmentIds.length > 0)) {
        throw new ErrorHandler("appointmentIds is missing!", HttpStatus.BAD_REQUEST)
    }
    const appointmentId = appointmentIds.map(id => new mongoose.Types.ObjectId(id));
    const data = await Payment.aggregate([
        { $match: { BookingId: bookingId } },
        {
            $lookup: {
                from: "cards",
                localField: "cardId",
                foreignField: "_id",
                as: 'cardDetails',
                pipeline: [
                    { $project: { cardBrand: 1 } }
                ]
            },
        },
        {
            $lookup: {
                from: "appointments",
                localField: "appointmentIds",
                foreignField: "_id",
                as: 'appointmentDetails',
                pipeline: [
                    { $match: { _id: { $in: appointmentId } } },
                    { $project: { createdAt: 0, updatedAt: 0, __v: 0, recurringOpt: 0, createdBy: 0 } }
                ]
            },
        },
        {
            $lookup: {
                from: "employees",
                localField: "appointmentDetails.stylistID",
                foreignField: "_id",
                as: 'Stylist',
                pipeline: [
                    { $project: { firstName: 1, lastName: 1, profileImage: 1 } }
                ]
            },
        },
        {
            $lookup: {
                from: "beauticianservices",
                localField: "appointmentDetails.serviceId",
                foreignField: "_id",
                as: 'serviceDetails',
                pipeline: [
                    { $project: { serviceCategory: 1, serviceType: 1, price: 1, duration: 1, description: 1, } }
                ]

            },
        },
        {
            $lookup: {
                from: "servicetypelists",
                localField: "serviceDetails.serviceType",
                foreignField: "_id",
                as: 'ServiceTypeDetails',
                pipeline: [
                    { $project: { serviceTypeName: 1, serviceTypeName_fr: 1, serviceCategoryId: 1 } }
                ]
            },
        },
        {
            $lookup: {
                from: "beauticians",
                localField: "appointmentDetails.beauticianId",
                foreignField: "_id",
                as: 'beauticianDetails',
                pipeline: [
                    {
                        $project: {
                            businessName: 1,
                            address: 1,
                            logo: 1
                        }
                    }
                ]
            },
        },
        {
            $lookup: {
                from: "addresses",
                localField: "beauticianDetails.address",
                foreignField: "_id",
                as: 'Address',
                pipeline: [
                    { $project: { address: 1, province: 1, city: 1, zipCode: 1, } }
                ]
            },
        },
        {
            $lookup: {
                from: "provinces",
                localField: "Address.province",
                foreignField: "_id",
                as: 'provinceData',
                pipeline: [
                    { $project: { name: 1, name_fr: 1, } }
                ]
            },
        },
        {
            $project: {
                _id: 1,
                cardDetails: 1,
                Stylist: 1,
                subTotal: 1,
                discount: 1,
                GST: 1,
                QST: 1,
                HST: 1,
                PST: 1,
                TotalPrice: 1,
                BookingId: 1,
                paymentStatus: 1,
                appointmentDetails: {
                    $map: {
                        input: "$appointmentDetails",
                        as: "appointment",
                        in: {
                            $mergeObjects: [
                                "$$appointment",
                                {
                                    serviceDetails: {
                                        $arrayElemAt: [{
                                            $filter: {
                                                input: "$serviceDetails",
                                                as: "service",
                                                cond: { $eq: ["$$service._id", "$$appointment.serviceId"] }
                                            }
                                        }, 0]

                                    },
                                    Stylist: {
                                        $filter: {
                                            input: "$Stylist",
                                            as: "stylist",
                                            cond: { $eq: ["$$stylist._id", "$$appointment.stylistID"] }
                                        }
                                    },
                                }
                            ]
                        }
                    },

                },

                beauticianDetails: {
                    businessName: { $arrayElemAt: ['$beauticianDetails.businessName', 0] },
                    logo: { $arrayElemAt: ['$beauticianDetails.logo', 0] },
                    address: {
                        address: { $arrayElemAt: ['$Address.address', 0] },
                        province: { $arrayElemAt: ['$provinceData.name', 0] },
                        province_fr: { $arrayElemAt: ['$provinceData.name_fr', 0] },
                        city: { $arrayElemAt: ['$Address.city', 0] },
                        zipCode: { $arrayElemAt: ['$Address.zipCode', 0] },
                    }
                },
                ServiceTypeDetails: 1,
                total: { $sum: "$appointmentDetails.price" },
                GstInPer: 1,
                QstInPer: 1,
                HstInPer: 1,
                PstInPer: 1,
            }
        },
        {
            $group: {
                _id: "$_id",
                subTotal: { $first: '$subTotal' },
                discount: { $first: '$discount' },
                GST: { $first: '$GST' },
                HST: { $first: '$HST' },
                QST: { $first: '$QST' },
                PST: { $first: '$PST' },
                TotalPrice: { $first: '$TotalPrice' },
                GstInPer: { $first: '$GstInPer' },
                QstInPer: { $first: '$QstInPer' },
                HstInPer: { $first: '$HstInPer' },
                PstInPer: { $first: '$PstInPer' },
                total: { $first: '$total' },
                BookingId: { $first: '$BookingId' },
                paymentStatus: { $first: '$paymentStatus' },
                cardDetails: { $first: { $arrayElemAt: ['$cardDetails', 0] } },
                appointmentDetails: { $first: '$appointmentDetails' },
                beauticianDetails: { $first: { $arrayElemAt: ['$beauticianDetails', 0] } },
                ServiceTypeDetails: { $first: '$ServiceTypeDetails' },

            }
        }
    ]);
    if (data && data.length > 0) {
        let appoTotalCost = data[0].total;
        data[0].subTotal = appoTotalCost
        data[0].GST = (appoTotalCost * (data[0].GstInPer / 100)).toFixed(2);
        data[0].PST = (appoTotalCost * (data[0].PstInPer / 100)).toFixed(2);
        data[0].QST = (appoTotalCost * (data[0].QstInPer / 100)).toFixed(2);
        data[0].HST = (appoTotalCost * (data[0].HstInPer / 100)).toFixed(2);
        data[0].TotalPrice = (appoTotalCost + (appoTotalCost * (data[0].GstInPer / 100)) + (appoTotalCost * (data[0].PstInPer / 100)) + (appoTotalCost * (data[0].HstInPer / 100)) + (appoTotalCost * (data[0].QstInPer / 100))).toFixed(2)
    }

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data });
});

// add new card details
const addCardDetails = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { cardHolderName, cardNumber, cardMonth, cardYear, cardCVC } = req.body;
    const myArray = cardNumber.split(" ");
    const errors = validationResult(req);
    if (errors.errors.length !== 0) {
        throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST);
    };
    let customerId;
    const clientData = await Client.aggregate([
        { $match: { userId: new mongoose.Types.ObjectId(id) } },
        {
            $lookup: {
                from: 'users',
                localField: 'userId',
                foreignField: '_id',
                as: 'userData',
                pipeline: [
                    { $project: { email: 1, phoneNumber: 1 } }
                ]
            }
        }
    ]);
    const cardData = await Cards.findOne({ clientId: clientData[0]._id, cardLastFour: parseInt(myArray[3]), expiryMonth: cardMonth, cardCVC });
    if (cardData) {
        throw new ErrorHandler(req.t("cardIsExists"), HttpStatus.BAD_REQUEST, false);
    }
    if (!clientData[0].customerId) {
        let clientInfo = clientData[0];
        //create customerId
        const CreateCustomerStripe = await createStripeCustomer({ email: clientInfo.userData[0].email, name: clientInfo.firstName + clientInfo.lastName, phone: clientInfo.userData[0].phoneNumber });

        if (CreateCustomerStripe.status === 200 && CreateCustomerStripe.result) {
            customerId = CreateCustomerStripe?.result.id;
            const userInfo = await Client.findById(clientData[0]._id)
            userInfo.customerId = customerId;
            await userInfo.save();
        } else {
            throw new ErrorHandler(CreateCustomerStripe.message, HttpStatus.BAD_REQUEST, false);
        }

    } else {
        customerId = clientData[0].customerId
    }

    //create paymentMethod Id using card details
    const userCard = await createStripeCard({
        cardNumber,
        cardMonth,
        cardYear,
        cardCVC,
    });

    if (userCard && userCard.status === 200) {
        paymentMethodID = userCard.result.id;
        //attach customerId with payment method Id
        const isAttach = await attachCustomerID({ paymentMethodID, customerId })
        if (isAttach && isAttach.status === 200) {
            await Cards.create({
                clientId: clientData[0]._id,
                cardName: cardHolderName,
                cardBrand: userCard.result.card.networks.available[0],
                cardLastFour: userCard.result.card.last4,
                expiryMonth: userCard.result.card.exp_month,
                expiryYear: userCard.result.card.exp_year,
                cardToken: userCard.result.id,
                cardCVC
            });
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, message: req.t("addCardDetailsSuccess") });
        } else {
            throw new ErrorHandler(isAttach.message, HttpStatus.BAD_REQUEST, false);
        }
    } else {
        throw new ErrorHandler(userCard.message, HttpStatus.BAD_REQUEST, false);
    }
});

// for get card details
const getCardDetails = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { value } = req.params;
    const { cardToken } = req.query;
    if (value === "single" && !cardToken) {
        throw new ErrorHandler("cardToken is missing from query.", HttpStatus.BAD_REQUEST, false)
    }
    let matchQuery = cardToken ? { $match: { cardToken: cardToken } } : { $match: {} };
    const cardList = await Cards.aggregate([
        matchQuery,
        {
            $lookup: {
                from: 'clients',
                foreignField: '_id',
                localField: 'clientId',
                as: 'clientData',
            }
        },
        { $match: { 'clientData.userId': new mongoose.Types.ObjectId(id) } },
        {
            $project: {
                cardName: 1,
                cardLastFour: 1,
                cardBrand: 1,
                expiryMonth: 1,
                expiryYear: 1,
                cardToken: 1,
                cardCVC: 1,
                cardCVC: 1,
                isPrimary: 1
            }
        }
    ]);
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, data: cardList });

})

// for delete card details
const deleteCardDetails = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { cardToken } = req.params;
    const clientData = await Client.findOne({ userId: id });
    const cardData = await Cards.findOne({ cardToken, clientId: clientData._id });
    if (cardData) {
        const removeCard = await detachCardDetails({ paymentMethodId: cardData.cardToken });
        if (removeCard.status === 202) {
            await Cards.deleteOne({ cardToken: cardData.cardToken });
        }
        return res.status(HttpStatus.OK).json({ message: removeCard.message, status: HttpStatus.OK, success: true });
    }
    throw new ErrorHandler(req.t("deleteCardDetailsError"), HttpStatus.BAD_REQUEST, false);
});

const setCardASPrimary = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { cardToken } = req.params;
    const { isPrimary } = req.query;
    const clientData = await Client.findOne({ userId: id });

    const IsPrimaryCardExist = await Cards.findOne({ clientId: clientData._id, isPrimary: 1 });
    if (IsPrimaryCardExist) {
        IsPrimaryCardExist.isPrimary = 0;
        await IsPrimaryCardExist.save();
    }
    const cardUpdate = await Cards.findOneAndUpdate({ cardToken }, { isPrimary }, { new: true })
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true });
});


module.exports = { addAppointment, getBookedPendingAppointment, getStylishList, getAppointmentList, addRating, cancelAppointment, getSingleAppointmentData, makePaymentForServices, getPrePaymentDetails, appointmentDetails, addCardDetails, getCardDetails, deleteCardDetails, setCardASPrimary };

