const catchAsyncError = require("../../middleware/catchAsyncError");
const Beautician = require("../../models/Beautician");
const Client = require("../../models/Client");
const ErrorHandler = require("../../utils/ErrorHandling");
const HttpStatus = require("../../utils/HttpStatus");

// Get all beauticianDetails
const getAllBeauticianDetails = catchAsyncError(async (req, res, next) => {
    const { limit, offset } = req.query;
    const limitData = parseInt(limit, 10) || 10;
    const offsetData = parseInt(offset, 10) || 0;
    let beauticianData = await Beautician.aggregate([
        {
            $match: {
                screenStatus: 7,
                stripe_id: { $ne: null }
            }
        },
        {
            $lookup: { from: 'addresses', localField: 'address', foreignField: '_id', as: 'addressDetails' },
        },
        { $lookup: { from: 'provinces', localField: 'addressDetails.province', foreignField: '_id', as: 'provinceName', pipeline: [{ $project: { name: 1, name_fr: 1, } }] } },
        {

            $project: {
                id: 1,
                logo: 1,
                address: {
                    address: { $first: '$addressDetails.address' },
                    province: { $first: '$provinceName.name' },
                    province_fr: { $first: '$provinceName.name_fr' },
                    apartment: { $first: '$addressDetails.apartment' },
                    city: { $first: '$addressDetails.city' },
                    zipCode: { $first: '$addressDetails.zipCode' }
                },
                businessName: 1,
                rating: { $ifNull: ['$rating', null] },
                hasShop: 1,
                isLicensed: 1,
                noOfReviews: 1
            }
        }
    ]);

    const count = beauticianData.length;
    beauticianData = beauticianData.slice(offsetData, limitData + offsetData);
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { count, beauticianData } });
})

// Get Client Favorite beautician list
const getClientFavoriteList = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    let favoritesList = await Client.findOne({ userId: id, }).populate({
        path: 'favorites',
        select: '-userId -createdAt -updatedAt -__v',
        populate: [
            {
                path: 'address',
                model: 'Address',
                select: '-_id address province apartment city zipCode',
                populate: {
                    path: 'province',
                    model: 'Province',
                    select: 'name'
                },
            }]
    }).lean();
    if (favoritesList) {
        favoritesList.favorites = favoritesList?.favorites?.filter(ele => { if (ele.screenStatus >= 7 && ele.isDeleted === 0) return ele })
    }
    if (!favoritesList) {
        favoritesList = {}
        favoritesList.favorites = []
    }
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { favoritesList: favoritesList.favorites }, message: "client favorite beauticians list" });
});

//Get Recent Views beautician list
const getRecentBeauticians = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { limit, offset } = req.query;
    const limitData = parseInt(limit, 10) || 5;
    const offsetData = parseInt(offset, 10) || 0;

    let recentList = await Client.findOne({ userId: id })
        .populate({
            path: 'recent',
            select: '-userId -createdAt -updatedAt -__v -stripe_id',
            populate: {
                path: 'address',
                model: 'Address',
                select: 'address province apartment city zipCode',
                populate: {
                    path: 'province',
                    model: 'Province',
                    select: 'name'
                },
            },
        }).lean();
    if (recentList) {
        recentList.recent = recentList?.recent?.filter(ele => { if (ele.screenStatus >= 7 && ele.isDeleted === 0) return ele });
    };
    let count = recentList.recent.length;

    recentList.recent = recentList.recent.slice(offsetData, offsetData + limitData);

    if (!recentList) {
        recentList = {}
        recentList.recent = []
    }
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "client recent beauticians list", data: { count, recentList: recentList.recent } });
});

// find near beauticians
const getNearerBeauticianList = catchAsyncError(async (req, res, next) => {
    const { longitude, latitude } = req.body;
    if (longitude !== "" && latitude !== "") {
        const data = await Beautician.aggregate([
            {
                $geoNear: {
                    near: { type: 'Point', coordinates: [parseFloat(longitude), parseFloat(latitude)] },
                    key: "location",
                    distanceField: `dis.calculated`,
                    spherical: true,
                    distanceMultiplier: 1 / 1000
                }
            },
            { $match: { screenStatus: 7, isDeleted: 0, stripe_id: { $ne: null } } },
            {
                $lookup: {
                    from: 'addresses', localField: 'address', foreignField: '_id', as: 'address',
                    pipeline: [
                        { $project: { _id: 0, createdAt: 0, updatedAt: 0, __v: 0 } },
                    ],
                },
            },
            {
                $lookup: {
                    from: 'provinces', localField: 'address.province', foreignField: '_id', as: 'province',
                    pipeline: [
                        { $project: { name: 1, name_fr: 1, } },
                    ],
                },
            },
            {
                $lookup: {
                    from: 'appointments',
                    localField: '_id',
                    foreignField: 'beauticianId',
                    as: 'appointments'
                }
            },
            {
                $lookup: {
                    from: 'ratings',
                    localField: 'appointments._id',
                    foreignField: 'appointmentId',
                    as: 'ratings'
                }
            },
            {
                $project: {
                    _id: 1,
                    logo: 1,
                    address: { $arrayElemAt: ['$address', 0] },
                    province: { $arrayElemAt: ['$province', 0] },
                    businessName: 1,
                    location: 1,
                    dis: 1,
                    rating: { $ifNull: ['$rating', null] },
                    hasShop: 1,
                    isLicensed: 1,
                    noOfReviews: 1
                }
            }
        ]);
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data, message: "client favorite beauticians list" });

    } else {
        throw new ErrorHandler("longitude or latitude is missing.", HttpStatus.BAD_REQUEST, false);
    }

});

// Recomanded Beauticians
const getRecomadedBeauticians = catchAsyncError(async (req, res, next) => {
    const { longitude, latitude, limit, offset } = req.body;
    if (longitude && latitude) {
        let tempData = [
            {
                $geoNear: {
                    near: { type: 'Point', coordinates: [parseFloat(longitude), parseFloat(latitude)] },
                    key: "location",
                    minDistance: 0,
                    maxDistance: 10000,
                    distanceField: `dis.calculated`,
                    spherical: true,
                }
            },
            { $match: { isRecommended: 1, screenStatus: 7, isDeleted: 0, stripe_id: { $ne: null } } },
            {
                $lookup: {
                    from: 'addresses', localField: 'address', foreignField: '_id', as: 'address',
                    pipeline: [
                        { $project: { _id: 0, createdAt: 0, updatedAt: 0, __v: 0 } },
                    ],
                },
            },
            {
                $lookup: {
                    from: 'provinces', localField: 'address.province', foreignField: '_id', as: 'province',
                    pipeline: [
                        { $project: { name: 1, name_fr: 1, } },
                    ],
                },
            },
            {
                $project: {
                    _id: 1,
                    logo: 1,
                    businessName: 1,
                    location: 1,
                    dis: 1,
                    hasShop: 1,
                    isLicensed: 1,
                    noOfReviews: 1,
                    address: {
                        address: { $first: '$address.address' },
                        province: { $first: '$province.name' },
                        province_fr: { $first: '$province.name_fr' },
                        apartment: { $first: '$address.apartment' },
                        city: { $first: '$address.city' },
                        zipCode: { $first: '$address.zipCode' }
                    },
                    rating: 1
                }
            },
            {
                $project: {
                    _id: 1,
                    logo: 1,
                    address: { $arrayElemAt: ['$address', 0] },
                    businessName: 1,
                    location: 1,
                    dis: 1,
                    hasShop: 1,
                    isLicensed: 1,
                    noOfReviews: 1,
                    rating: { $ifNull: ['$rating', null] }
                }
            },
        ]
        const data = await Beautician.aggregate(tempData);
        const count = data.length;
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, "beauticians": { count, data } });

    } else {
        throw new ErrorHandler("longitude or latitude is missing.", HttpStatus.BAD_REQUEST, false);
    }
});
module.exports = { getAllBeauticianDetails, getClientFavoriteList, getRecentBeauticians, getNearerBeauticianList, getRecomadedBeauticians }