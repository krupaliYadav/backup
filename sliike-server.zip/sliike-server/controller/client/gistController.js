const HttpStatus = require("../../utils/HttpStatus");
const catchAsyncError = require("../../middleware/catchAsyncError");
const ErrorHandler = require("../../utils/ErrorHandling");
const Gist = require("../../models/Gist");
const formidable = require("formidable");
const { pathEndpoint } = require("../../utils/Constant");
const Client = require("../../models/Client");
const { v4: uuidv4 } = require('uuid');
const { uploadFile } = require("../../libs/aws/uploadImg");
const GistResponse = require("../../models/GistResponse");
const { default: mongoose } = require("mongoose");
const Beautician = require("../../models/Beautician");
const Admin = require("../../models/Admin");

// For create gist
const createGist = catchAsyncError(async (req, res, next) => {
    const form = formidable({ multiples: true });
    form.parse(req, async (err, fields, files) => {
        try {
            const { type, title, message, member_type } = fields;
            if (!type) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please Enter type" });
            if (!title) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please Enter title" });

            let dataId;
            if (member_type === "clients") {
                const Id = req.user;
                const clientData = await Client.findOne({ userId: Id });
                if (clientData) {
                    dataId = clientData._id
                } else {
                    return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Client details not found" });
                }
            } else if (member_type === "beauticians") {
                const Id = req.user;
                const beauticianData = await Beautician.findOne({ userId: Id });
                if (beauticianData) {
                    dataId = beauticianData._id
                } else {
                    return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Beautician details not found" });
                }
            } else if (member_type === "superAdmin") {
                const Id = req.user;
                const adminData = await Admin.findOne({ _id: Id });
                if (adminData) {
                    dataId = adminData._id;
                } else {
                    return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Admin details not found" });
                }
            } else {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please Enter valid member type" });
            }

            let tempFile;
            if (files.audioFile) {
                const ImgName = files.audioFile.originalFilename.split(".")
                const extension = ImgName[ImgName.length - 1];
                const fileName = (files.audioFile.originalFilename = uuidv4() + "." + extension);

                const newPath = `${pathEndpoint.audios}${fileName}`;

                // Upload to AWS
                const uploadImgRes = await uploadFile(files.audioFile, newPath, extension);
                tempFile = uploadImgRes.imageUrl;
            }

            await Gist.create({ createrId: dataId, title, message, member_type, audioFile: tempFile, type });

            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("createGistSuccess") })
        } catch (error) {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "something is wrong" })
        }
    })
});

// Get all gist
const getAllGist = catchAsyncError(async (req, res, next) => {
    const { user, search } = req.query;
    let userQuery = {
        isDeleted: 0,
    }
    if (user === "clients" || user === "superAdmin") {
        userQuery = {
            ...userQuery,
            $nor: [
                { type: "beauticianOnly" }
            ],
        }
    } else if (user === "beauticians") {
        userQuery = {
            // $nor: [
            //     { createdBy: "client", }
            // ],
        }
    }

    if (search) {
        if (search !== "") {
            userQuery = {
                ...userQuery,
                title: { $regex: search, $options: 'i' },
            }
        }
    }

    const data = await Gist.aggregate([
        {
            $match: userQuery
        },
        {
            $facet: {
                clientsData: [
                    {
                        $match: { member_type: "clients" }
                    },
                    {
                        $lookup: {
                            from: 'clients',
                            localField: 'createrId',
                            foreignField: "_id",
                            as: 'clientDetails',
                            pipeline: [
                                { $project: { profileImage: { $ifNull: ["$profileImage", null] } } }
                            ],
                        },
                    },
                ],
                beauticiansData: [
                    {
                        $match: { member_type: "beauticians" }
                    },
                    {
                        $lookup: {
                            from: 'beauticians',
                            localField: 'createrId',
                            foreignField: "_id",
                            as: 'clientDetails',
                            pipeline: [
                                { $project: { profileImage: { $ifNull: ["$profileImage", null] } } }
                            ],
                        },
                    },
                ],
                adminData: [
                    {
                        $match: { member_type: "superAdmin" }
                    },
                    {
                        $lookup: {
                            from: 'admins',
                            localField: 'createrId',
                            foreignField: "_id",
                            as: 'clientDetails',
                            pipeline: [
                                { $project: { profileImage: { $ifNull: ["$profileImage", null] } } }
                            ],
                        },
                    },
                ],
            }
        },
        {
            $project: {
                mergedData: {
                    $concatArrays: ["$clientsData", "$beauticiansData", "$adminData"]
                }
            }
        },
        {
            $unwind: "$mergedData"
        },
        {
            $replaceRoot: { newRoot: "$mergedData" }
        },
        {
            $lookup: {
                from: 'gistresponses',
                localField: 'responseIds',
                foreignField: "_id",
                as: 'reponses',
                pipeline: [
                    { $project: { message: 1, messageSenderId: 1, createdAt: 1 } }
                ],
            },
        },
        {
            $lookup: {
                from: 'clients',
                localField: 'reponses.messageSenderId',
                foreignField: "_id",
                as: 'clientMessagesClients',
                pipeline: [
                    { $project: { profileImage: { $ifNull: ["$profileImage", null] } } }
                ],
            }
        },
        {
            $lookup: {
                from: 'beauticians',
                localField: 'reponses.messageSenderId',
                foreignField: "_id",
                as: 'clientMessagesBeauticians',
                pipeline: [
                    { $project: { profileImage: { $ifNull: ["$profileImage", null] } } }
                ],
            }
        },
        {
            $lookup: {
                from: 'admins',
                localField: 'reponses.messageSenderId',
                foreignField: "_id",
                as: 'clientMessagesAdmin',
                pipeline: [
                    { $project: { profileImage: { $ifNull: ["$profileImage", null] } } }
                ],
            }
        },
        {
            $addFields: {
                clientMessages: { $concatArrays: ["$clientMessagesClients", "$clientMessagesBeauticians", "$clientMessagesAdmin"] }
            }
        },
        {
            $lookup: {
                from: 'gistresponses',
                localField: 'responseIds',
                foreignField: "_id",
                as: 'lastResponse',
                pipeline: [
                    { $sort: { createdAt: -1 }, },
                    { $limit: 1 },
                    { $project: { createdAt: 1 } }
                ]
            },
        },
        {
            $sort: { createdAt: -1 }
        },
        {
            $project: {
                title: 1, message: 1,
                createrId: {
                    $arrayElemAt: ['$clientDetails._id', 0]
                },
                clientProfileImage: {
                    $arrayElemAt: ['$clientDetails.profileImage', 0]
                },
                clientMessages: 1,
                audioFile: { $ifNull: ["$audioFile", null] },
                // reponses: 1,
                lastResponse:
                {
                    $cond: { if: { $gt: ["$lastResponse", []] }, then: { $arrayElemAt: ['$lastResponse.createdAt', 0] }, else: "$createdAt" }
                },
            }
        }
    ]);

    const count = data.length;

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, count, data });
});

// For get single gist details
const getSingleGist = catchAsyncError(async (req, res, next) => {
    const { gistId } = req.params;

    if (!mongoose.Types.ObjectId.isValid(gistId)) {
        throw new ErrorHandler("Please enter valid gist Id", HttpStatus.BAD_REQUEST);
    }

    const data = await Gist.aggregate([
        { $match: { _id: new mongoose.Types.ObjectId(gistId) } },
        {
            $facet: {
                clientsData: [
                    {
                        $match: { member_type: "clients" }
                    },
                    {
                        $lookup: {
                            from: 'clients',
                            localField: 'createrId',
                            foreignField: "_id",
                            as: 'clientDetails',
                            pipeline: [
                                { $project: { profileImage: { $ifNull: ["$profileImage", null] } } }
                            ],
                        },
                    },
                ],
                beauticiansData: [
                    {
                        $match: { member_type: "beauticians" }
                    },
                    {
                        $lookup: {
                            from: 'beauticians',
                            localField: 'createrId',
                            foreignField: "_id",
                            as: 'clientDetails',
                            pipeline: [
                                { $project: { profileImage: { $ifNull: ["$profileImage", null] } } }
                            ],
                        },
                    },
                ],
                adminData: [
                    {
                        $match: { member_type: "superAdmin" }
                    },
                    {
                        $lookup: {
                            from: 'admins',
                            localField: 'createrId',
                            foreignField: "_id",
                            as: 'clientDetails',
                            pipeline: [
                                { $project: { profileImage: { $ifNull: ["$profileImage", null] } } }
                            ],
                        },
                    },
                ],
            }
        },
        {
            $project: {
                mergedData: {
                    $concatArrays: ["$clientsData", "$beauticiansData", "$adminData"]
                }
            }
        },
        {
            $unwind: "$mergedData"
        },
        {
            $replaceRoot: { newRoot: "$mergedData" }
        },
        {
            $lookup: {
                from: 'gistresponses',
                localField: 'responseIds',
                foreignField: "_id",
                as: 'reponses',
                pipeline: [
                    // { $sort: { createAt: - 1 } },
                    { $project: { message: { $ifNull: ["$message", null] }, messageSenderId: 1, createdAt: 1, audioFile: { $ifNull: ["$audioFile", null] } } }
                ],
            },
        },
        {
            $lookup: {
                from: 'clients',
                localField: 'reponses.messageSenderId',
                foreignField: "_id",
                as: 'clientMessagesClients',
                pipeline: [
                    { $project: { profileImage: { $ifNull: ["$profileImage", null] } } }
                ],
            }
        },
        {
            $lookup: {
                from: 'beauticians',
                localField: 'reponses.messageSenderId',
                foreignField: "_id",
                as: 'clientMessagesBeauticians',
                pipeline: [
                    { $project: { profileImage: { $ifNull: ["$profileImage", null] } } }
                ],
            }
        },
        {
            $lookup: {
                from: 'admins',
                localField: 'reponses.messageSenderId',
                foreignField: "_id",
                as: 'clientMessagesAdmin',
                pipeline: [
                    { $project: { profileImage: { $ifNull: ["$profileImage", null] } } }
                ],
            }
        },
        {
            $addFields: {
                messangerClient: { $concatArrays: ["$clientMessagesClients", "$clientMessagesBeauticians", "$clientMessagesAdmin"] }
            }
        },
        {
            $project: {
                title: 1, createrId: 1, message: 1, audioFile: { $ifNull: ["$audioFile", null] }, createdAt: 1,
                clientProfileImage: {
                    $arrayElemAt: ['$clientDetails.profileImage', 0]
                },
                // reponses: 1,
                reponses: {
                    $map: {
                        input: "$reponses",
                        as: "res",
                        in: {
                            $mergeObjects: [
                                "$$res",
                                {
                                    clientData: {
                                        $arrayElemAt: [{
                                            $filter: {
                                                input: "$messangerClient",
                                                as: "clientData",
                                                cond: { $eq: ["$$clientData._id", "$$res.messageSenderId"] }
                                            }
                                        }, 0]
                                    },
                                }
                            ]
                        }
                    },
                },
            }
        }
    ]);

    if (data.length) {
        data[0]?.reponses.forEach((ele) => {
            ele.isGistCreateor = false;
            if (ele.messageSenderId.toString() === data[0].createrId.toString()) {
                ele.isGistCreateor = true;
            }
        })
    }

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data });
});

// for send response
const sendResponse = catchAsyncError(async (req, res, next) => {
    // const Id = req.user;
    const form = formidable({ multiples: true });
    form.parse(req, async (err, fields, files) => {
        const { gistId, message, senderType } = fields;

        if (!gistId) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please Enter gistId" });
        if (!mongoose.Types.ObjectId.isValid(gistId)) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please Enter valid gistId" });
        if (!senderType) return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please Enter senderType" });

        // const clientData = await Client.findOne({ userId: Id })
        let dataId;
        if (senderType === "clients") {
            const Id = req.user;
            const clientData = await Client.findOne({ userId: Id });
            if (clientData) {
                dataId = clientData._id
            } else {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Client details not found" });
            }
        } else if (senderType === "beauticians") {
            const Id = req.user;
            const beauticianData = await Beautician.findOne({ userId: Id });
            if (beauticianData) {
                dataId = beauticianData._id
            } else {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Beautician details not found" });
            }
        } else if (senderType === "superAdmin") {
            const Id = req.user;
            const adminData = await Admin.findOne({ _id: Id });
            if (adminData) {
                dataId = adminData._id;
            } else {
                return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Admin details not found" });
            }
        } else {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please Enter valid member type" });
        }
        const gistData = await Gist.findOne({ _id: gistId });

        if (gistData) {
            let tempFile;
            if (files.audioFile) {
                const ImgName = files.audioFile.originalFilename.split(".")
                const extension = ImgName[ImgName.length - 1];
                // if (extension !== "jpeg" && extension !== "png" && extension !== "jpg") {
                //     return res.status(HttpStatus.ERROR).json({ status: HttpStatus.ERROR, success: false, message: req.t("ImageExtension", { extension: extension }) });
                // }
                const fileName = (files.audioFile.originalFilename = uuidv4() + "." + extension);

                const newPath = `${pathEndpoint.audios}${fileName}`;

                // Upload to AWS
                const uploadImgRes = await uploadFile(files.audioFile, newPath, extension);
                tempFile = uploadImgRes.imageUrl;
            }
            const responseData = await GistResponse.create({ gistId, messageSenderId: dataId, message, senderType, audioFile: tempFile });
            gistData.responseIds.unshift(responseData._id);
            await gistData.save();

            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("sendResponseSuccess") });
        } else {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: true, message: "Please enter valid gist Id" });
        }
    })
});

// for get my gist
const getMyGist = catchAsyncError(async (req, res, next) => {
    const { member_type } = req.query
    let gistCreaterId;
    if (member_type === "clients") {
        const Id = req.user;
        const clientData = await Client.findOne({ userId: Id });
        if (clientData) {
            gistCreaterId = clientData._id
        } else {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Client details not found" });
        }
    } else if (member_type === "beauticians") {
        const Id = req.user;
        const beauticianData = await Beautician.findOne({ userId: Id });
        if (beauticianData) {
            gistCreaterId = beauticianData._id
        } else {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Beautician details not found" });
        }
    } else if (member_type === "superAdmin") {
        const Id = req.user;
        const adminData = await Admin.findOne({ _id: Id });
        if (adminData) {
            gistCreaterId = adminData._id;
        } else {
            return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Admin details not found" });
        }
    } else {
        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Please Enter valid member type" });
    }

    const data = await Gist.aggregate([
        { $match: { isDeleted: 0 } },
        {
            $lookup: {
                from: 'gistresponses',
                localField: 'responseIds',
                foreignField: "_id",
                as: 'reponses',
                pipeline: [
                    { $project: { message: 1, messageSenderId: 1, createdAt: 1 } }
                ],
            },
        },
        {
            $match: {
                $or: [
                    { createrId: new mongoose.Types.ObjectId(gistCreaterId) },
                    { 'reponses.messageSenderId': new mongoose.Types.ObjectId(gistCreaterId) }
                ]
            }
        },
        {
            $facet: {
                clientsData: [
                    {
                        $match: { member_type: "clients" }
                    },
                    {
                        $lookup: {
                            from: 'clients',
                            localField: 'createrId',
                            foreignField: "_id",
                            as: 'clientDetails',
                            pipeline: [
                                { $project: { profileImage: { $ifNull: ["$profileImage", null] } } }
                            ],
                        },
                    },
                ],
                beauticiansData: [
                    {
                        $match: { member_type: "beauticians" }
                    },
                    {
                        $lookup: {
                            from: 'beauticians',
                            localField: 'createrId',
                            foreignField: "_id",
                            as: 'clientDetails',
                            pipeline: [
                                { $project: { profileImage: { $ifNull: ["$profileImage", null] } } }
                            ],
                        },
                    },
                ],
                adminData: [
                    {
                        $match: { member_type: "superAdmin" }
                    },
                    {
                        $lookup: {
                            from: 'admins',
                            localField: 'createrId',
                            foreignField: "_id",
                            as: 'clientDetails',
                            pipeline: [
                                { $project: { profileImage: { $ifNull: ["$profileImage", null] } } }
                            ],
                        },
                    },
                ],
            }
        },
        {
            $project: {
                mergedData: {
                    $concatArrays: ["$clientsData", "$beauticiansData", "$adminData"]
                }
            }
        },
        {
            $unwind: "$mergedData"
        },
        {
            $replaceRoot: { newRoot: "$mergedData" }
        },
        {
            $lookup: {
                from: 'clients',
                localField: 'reponses.messageSenderId',
                foreignField: "_id",
                as: 'clientMessagesClients',
                pipeline: [
                    { $project: { profileImage: { $ifNull: ["$profileImage", null] } } }
                ],
            }
        },
        {
            $lookup: {
                from: 'beauticians',
                localField: 'reponses.messageSenderId',
                foreignField: "_id",
                as: 'clientMessagesBeauticians',
                pipeline: [
                    { $project: { profileImage: { $ifNull: ["$profileImage", null] } } }
                ],
            }
        },
        {
            $lookup: {
                from: 'admins',
                localField: 'reponses.messageSenderId',
                foreignField: "_id",
                as: 'clientMessagesAdmin',
                pipeline: [
                    { $project: { profileImage: { $ifNull: ["$profileImage", null] } } }
                ],
            }
        },
        {
            $addFields: {
                clientMessages: { $concatArrays: ["$clientMessagesClients", "$clientMessagesBeauticians", "$clientMessagesAdmin"] }
            }
        },
        {
            $lookup: {
                from: 'gistresponses',
                localField: 'responseIds',
                foreignField: "_id",
                as: 'lastResponse',
                pipeline: [
                    { $sort: { createdAt: -1 }, },
                    { $limit: 1 },
                    { $project: { createdAt: 1 } }
                ]
            },
        },
        {
            $sort: { createdAt: -1 }
        },
        {
            $project: {
                title: 1, message: 1,
                createrId: {
                    $arrayElemAt: ['$clientDetails._id', 0]
                },
                clientProfileImage: {
                    $arrayElemAt: ['$clientDetails.profileImage', 0]
                },
                clientMessages: 1,
                audioFile: { $ifNull: ["$audioFile", null] },
                // reponses: 1,
                lastResponse:
                {
                    $cond: { if: { $gt: ["$lastResponse", []] }, then: { $arrayElemAt: ['$lastResponse.createdAt', 0] }, else: "$createdAt" }
                },
            }
        }
    ]);

    const count = data.length
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, count, data });
});

// for delete gist
const removeGist = catchAsyncError(async (req, res, next) => {
    const { gistId } = req.body;
    const gistData = await Gist.findOne({ _id: gistId });
    if (gistData) {
        gistData.isDeleted = 1;
        await gistData.save();
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Gist removed successfully" });
    } else {
        throw new ErrorHandler("Gist details not found", HttpStatus.BAD_REQUEST, false);
    }
})

module.exports = { createGist, getAllGist, getSingleGist, sendResponse, getMyGist, removeGist }