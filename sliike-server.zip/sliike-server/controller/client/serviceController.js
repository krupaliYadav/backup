const HttpStatus = require("../../utils/HttpStatus");
const catchAsyncError = require("../../middleware/catchAsyncError");
const BeauticianService = require("../../models/BeauticianService");
const Address = require("../../models/Address");
const Beautician = require("../../models/Beautician");
const Client = require("../../models/Client");
const mongoose = require("mongoose");
const ErrorHandler = require("../../utils/ErrorHandling");
const ServiceTypeList = require("../../models/ServiceTypeList");
const { removeFromMyFavorites } = require("./ProfileController");
const { getPolicyDetails, getPolicyDetailsForNoShow } = require("../../utils/Constant");
const Rating = require("../../models/Rating");
const moment = require("moment");
const Appointment = require("../../models/Appointment");

const findAddress = catchAsyncError(async (req, res, next) => {
    const latitude = 20.92406;
    const longitude = 72.965964;
    const distanceInKilometer = 5;
    const radius = distanceInKilometer / 6378.1;
    const distance = 500;

    let query = {
        serviceCategory: { $in: [new mongoose.Types.ObjectId("6448c454983bc7ef8cf03005")] },
    }
    query = {
        ...query,
        price: {
            $gte: 295,
            $lte: 350
        }
    }
    const data = await BeauticianService.aggregate([
        { $match: query }
    ])

    return res.json(data);
})

// this is old filetr for find services
// const findServices = catchAsyncError(async (req, res, next) => {
//     const userId = req.user;
//     const { place, services, serviceTypeId, demography, sortBy, gender, maxPrice, serveAt, serveAtClient, longitude, latitude, maxDistance, minDistance, } = req.body;
//     const minPrice = 1;
//     let maximumDistance = 5000;
//     let minimumDistance = 0

//     if (maxDistance && minDistance) {
//         if (maxDistance !== "" && minDistance !== "") {
//             maximumDistance = parseFloat(maxDistance) * 1000;
//             minimumDistance = parseFloat(minDistance) * 1000;
//         }
//     }

//     let beauticianwhere = {
//         $match: {
//             screenStatus: 7,
//             stripe_id: { $ne: null }
//         }
//     };

//     let demographyWhere = {};
//     let sortwhere = {};
//     let locationwhere = {};
//     let whereCluase = [];

//     let newLookup = {
//         $lookup: { from: 'beauticianservices', localField: 'beauticianServiceId', foreignField: '_id', as: 'beauticianServiceDetails' },
//     };

//     let addresLookup = {
//         $lookup: { from: 'addresses', localField: 'address', foreignField: '_id', as: 'address' },
//     }

//     whereCluase.push(newLookup, addresLookup, beauticianwhere);

//     // Complete (testing)
//     if (services.length) {
//         let newLookup1 = {
//             $addFields: {
//                 beauticianServiceDetails: {
//                     $filter: {
//                         input: '$beauticianServiceDetails',
//                         as: 'service',
//                         cond: {
//                             $and: [
//                                 { $in: ['$$service.serviceCategory', services.map(id => new mongoose.Types.ObjectId(id))] },
//                             ]
//                         }
//                     }
//                 }
//             }
//         }
//         let newmatch1 = { $match: { beauticianServiceDetails: { $gt: [] } } }
//         whereCluase.push(newLookup1, newmatch1);
//     }
//     if (serviceTypeId && serviceTypeId.length) {
//         let newLookup2 = {
//             $addFields: {
//                 beauticianServiceDetails: {
//                     $filter: {
//                         input: '$beauticianServiceDetails',
//                         as: 'service',
//                         cond: {
//                             $and: [
//                                 { $in: ['$$service.serviceType', serviceTypeId.map(id => new mongoose.Types.ObjectId(id))] },
//                             ]
//                         }
//                     }
//                 }
//             }
//         }
//         let newmatch2 = { $match: { beauticianServiceDetails: { $gt: [] } } }
//         whereCluase.push(newLookup2, newmatch2);
//     }
//     // Compete (testing)
//     if (minPrice && maxPrice) {
//         // console.log("inside the price object", whereCluase);
//         whereCluase = [
//             ...whereCluase,
//             {
//                 $addFields: {
//                     beauticianServiceDetails: {
//                         $filter: {
//                             input: '$beauticianServiceDetails',
//                             as: 'service',
//                             cond: {
//                                 $and: [
//                                     { $gte: ['$$service.price', minPrice] },
//                                     { $lte: ['$$service.price', maxPrice] }
//                                 ]
//                             }
//                         }
//                     }
//                 }
//             }
//         ]
//         let newmatch1 = { $match: { beauticianServiceDetails: { $gt: [] } } };
//         whereCluase.push(newmatch1);
//     }

//     // Complete (testing)
//     if (gender) {
//         if (gender === "Male") {
//             beauticianwhere = { $match: { gender: "Male" } }
//             whereCluase.push(beauticianwhere);
//         }
//         if (gender === "Female") {
//             beauticianwhere = { $match: { gender: "Female" } }
//             whereCluase.push(beauticianwhere);
//         }
//         if (gender === "Other") {
//             beauticianwhere = {
//                 $match: {
//                     $or: [
//                         { gender: "Other" },
//                         { gender: "Transgender" },
//                         { gender: "prefer not to say" }
//                     ]
//                 }
//             }
//             whereCluase.push(beauticianwhere);
//         }
//     }

//     if (demography && demography.length) {
//         let isCorrectDemoId = false;
//         demography.map(ele => isCorrectDemoId = !mongoose.Types.ObjectId.isValid(ele));
//         if (isCorrectDemoId) {
//             throw new ErrorHandler("Please pass valid demography IDs.", HttpStatus.BAD_REQUEST, false);
//         }
//         let ids = demography.map((el) => { return new mongoose.Types.ObjectId(el) });
//         demographyWhere = {
//             ...demographyWhere,
//             demographicIds: { $in: ids }
//         }
//         whereCluase.push({ $match: demographyWhere })
//     }

//     // Complete (testing)
//     if (serveAt != "") {
//         if (serveAt == 0) {
//             beauticianwhere = { $match: { IsServeAtOwnPlace: 1 } }
//             whereCluase.push(beauticianwhere);
//         }

//         if (serveAt == 1) {
//             beauticianwhere = { $match: { IsServeAtClient: 1 } }
//             whereCluase.push(beauticianwhere);
//         }
//     }

//     // Complete (testing)
//     if (latitude && longitude && latitude != "" && longitude != "") {
//         locationwhere = {
//             $geoNear: {
//                 near: { type: 'Point', coordinates: [parseFloat(longitude), parseFloat(latitude)] },
//                 key: "location",
//                 minDistance: minimumDistance,
//                 maxDistance: maximumDistance,
//                 distanceField: `dis.calculated`,
//                 spherical: true,
//                 distanceMultiplier: 1 / 1000
//             },
//         }
//         whereCluase.unshift(locationwhere);
//     }

//     // Complete (testing)
//     if (sortBy === "myfavorite") {
//         const user = await Client.findOne({ userId });
//         if (user) {
//             const beauticianIds = user.favorites;
//             // if(beauticianIds){
//             let newLookup1 = { $match: { _id: { $in: beauticianIds } } }
//             whereCluase.push(newLookup1);
//             // }
//         }
//     }
//     // for racommnded here

//     const data = await Beautician.aggregate(whereCluase);

//     let message;
//     if (!data.length) {
//         message = "No result. Please review your filter selection"
//     }
//     if (data) {
//         const clientData = await Client.findOne({ userId: userId });
//         data.map((val) => {
//             val.isFav = false;
//             if (clientData.favorites.includes(val._id)) {
//                 val.isFav = true;
//             }
//             return val.isFav;
//         })
//     }
//     const count = data.length;

//     return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, data: { count, data }, message })

// });

// This is new filter for find services
const findServices = catchAsyncError(async (req, res, next) => {
    const userId = req.user;
    const { place, services, demography, sortBy, gender, maxPrice, serveAt, serveAtClient, longitude, latitude, maxDistance, minDistance, When } = req.body;
    const minPrice = 1;
    let maximumDistance = 5000;
    let minimumDistance = 0

    if (maxDistance && minDistance) {
        if (maxDistance !== "" && minDistance !== "") {
            maximumDistance = parseFloat(maxDistance) * 1000;
            minimumDistance = parseFloat(minDistance) * 1000;
        }
    }

    let beauticianwhere = {
        $match: {
            screenStatus: 7,
            stripe_id: { $ne: null }
        }
    };

    let demographyWhere = {};
    let sortwhere = {};
    let locationwhere = {};
    let whereCluase = [];

    let newLookup = {
        $lookup: { from: 'beauticianservices', localField: 'beauticianServiceId', foreignField: '_id', as: 'beauticianServiceDetails' },
    };
    whereCluase.push(beauticianwhere, newLookup);

    let addressLookup =
        [
            {
                $lookup: { from: 'addresses', localField: 'address', foreignField: '_id', as: 'addressDetails' },
            },
            { $lookup: { from: 'provinces', localField: 'addressDetails.province', foreignField: '_id', as: 'provinceName', pipeline: [{ $project: { name: 1, name_fr: 1, } }] } }
        ]

    whereCluase = [...whereCluase, ...addressLookup];

    if (When) {
        if (When !== "") {
            let bookingMatch = {};
            if (When === "7days") {
                bookingMatch = { futureBookingDay: 7 }
            }
            if (When === "1month") {
                bookingMatch = {
                    $or: [{ futureBookingDay: 14 }, { futureBookingMonths: 1 }]
                }
            }
            if (When === "5weeks") {
                bookingMatch = { futureBookingMonths: 2 }
            }
            let booking = [
                {
                    $lookup: {
                        from: 'bookingsettings',
                        localField: '_id',
                        foreignField: 'beauticianId',
                        as: 'bookingSettingData',
                        pipeline: [
                            { $match: bookingMatch }
                        ]
                    }
                },
                { $match: { bookingSettingData: { $gt: [] } } },
            ]
            whereCluase = [...whereCluase, ...booking];
        }
    }

    // Complete (testing)
    if (services.length) {
        let isCorrectServicesId = false;
        services.map(ele => isCorrectServicesId = !mongoose.Types.ObjectId.isValid(ele));
        if (isCorrectServicesId) {
            throw new ErrorHandler("Please pass valid service IDs.", HttpStatus.BAD_REQUEST, false);
        }
        let newLookup1 = {
            $addFields: {
                beauticianServiceDetails: {
                    $filter: {
                        input: '$beauticianServiceDetails',
                        as: 'service',
                        cond: {
                            $and: [
                                { $in: ['$$service.serviceCategory', services.map(id => new mongoose.Types.ObjectId(id))] },
                            ]
                        }
                    }
                }
            }
        }
        let newmatch1 = { $match: { beauticianServiceDetails: { $gt: [] } } }
        whereCluase.push(newLookup1, newmatch1);
    }

    // Compete (testing)
    if (minPrice && maxPrice) {
        whereCluase = [
            ...whereCluase,
            {
                $addFields: {
                    beauticianServiceDetails: {
                        $filter: {
                            input: '$beauticianServiceDetails',
                            as: 'service',
                            cond: {
                                $and: [
                                    { $gte: ['$$service.price', minPrice] },
                                    { $lte: ['$$service.price', maxPrice] }
                                ]
                            }
                        }
                    }
                }
            }
        ]
        let newmatch1 = { $match: { beauticianServiceDetails: { $gt: [] } } };
        whereCluase.push(newmatch1);
    }

    // Complete (testing)
    if (gender) {
        if (gender === "Male") {
            beauticianwhere = { $match: { gender: "Male" } }
            whereCluase.push(beauticianwhere);
        }
        if (gender === "Female") {
            beauticianwhere = { $match: { gender: "Female" } }
            whereCluase.push(beauticianwhere);
        }
    }

    if (demography.length) {
        let isCorrectDemoId = false;
        demography.map(ele => isCorrectDemoId = !mongoose.Types.ObjectId.isValid(ele));
        if (isCorrectDemoId) {
            throw new ErrorHandler("Please pass valid demography IDs.", HttpStatus.BAD_REQUEST, false);
        }
        let ids = demography.map((el) => { return new mongoose.Types.ObjectId(el) });
        demographyWhere = {
            ...demographyWhere,
            demographicIds: { $in: ids }
        }
        whereCluase.push({ $match: demographyWhere })
    }

    // Complete (testing)
    if (serveAt != "") {
        if (serveAt == 0) whereCluase[0].$match.IsServeAtOwnPlace = 1
        if (serveAt == 1) whereCluase[0].$match.IsServeAtClient = 1
    }
    // Complete (testing)
    if (latitude != "" && longitude != "") {
        locationwhere = {
            $geoNear: {
                near: { type: 'Point', coordinates: [parseFloat(longitude), parseFloat(latitude)] },
                key: "location",
                minDistance: minimumDistance,
                maxDistance: maximumDistance,
                distanceField: `dis.calculated`,
                spherical: true
            },
        }
        whereCluase.unshift(locationwhere);
    }

    // Complete (testing)
    if (sortBy === "myfavorite") {
        const user = await Client.findOne({ userId });
        if (user) {
            const beauticianIds = user.favorites;
            let newLookup1 = { $match: { _id: { $in: beauticianIds } } }
            whereCluase.push(newLookup1);
        }
    }
    // for racommnded here
    if (sortBy === "recommended") {
        let newLookup1 = { $match: { isRecommended: 1 } }
        whereCluase.push(newLookup1);
    }

    const finalClause = [
        {
            $lookup: {
                from: 'appointments',
                localField: '_id',
                foreignField: 'beauticianId',
                as: 'appointments'
            }
        },
        {
            $lookup: {
                from: 'ratings',
                localField: 'appointments._id',
                foreignField: 'appointmentId',
                as: 'ratings'
            }
        },
        {
            $project: { appointments: 0 }
        }
        // {
        //     $project: {
        //         id: 1,
        //         logo: 1,
        //         address: {
        //             address: { $first: '$addressDetails.address' },
        //             province: { $first: '$provinceName.name' },
        //             apartment: { $first: '$addressDetails.apartment' },
        //             city: { $first: '$addressDetails.city' },
        //             zipCode: { $first: '$addressDetails.zipCode' }
        //         },
        //         businessName: 1,
        //         rating: { $ifNull: ['$rating', null] },
        //         hasShop: 1,
        //         isLicensed: 1,
        //         noOfReviews: 1
        //     }
        // }
    ]
    whereCluase = [...whereCluase, ...finalClause];

    const data = await Beautician.aggregate(whereCluase);
    let message
    if (!data.length) {
        message = "No result. Please review your filter selection"
    }
    if (data) {
        const clientData = await Client.findOne({ userId: userId });
        data.map((val) => {
            val.isFav = false;
            if (clientData.favorites.includes(val._id)) {
                val.isFav = true;
            }
            return val.isFav;
        })
    }
    const count = data.length;

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, data: { count, data }, message })

});
const findServicesNew = catchAsyncError(async (req, res, next) => {
    const userId = req.user;
    const { place, services, demography, sortBy, gender, maxPrice, serveAt, serveAtClient, longitude, latitude, maxDistance, minDistance, When } = req.body;
    const minPrice = 1;
    let maximumDistance = 5000;
    let minimumDistance = 0

    if (maxDistance && minDistance) {
        if (maxDistance !== "" && minDistance !== "") {
            maximumDistance = parseFloat(maxDistance) * 1000;
            minimumDistance = parseFloat(minDistance) * 1000;
        }
    }

    let beauticianwhere = {
        $match: {
            screenStatus: 7,
            stripe_id: { $ne: null }
        }
    };

    let demographyWhere = {};
    let sortwhere = {};
    let locationwhere = {};
    let whereCluase = [];

    let newLookup = {
        $lookup: { from: 'beauticianservices', localField: 'beauticianServiceId', foreignField: '_id', as: 'beauticianServiceDetails' },
    };
    whereCluase.push(beauticianwhere, newLookup);

    let addressLookup =
        [
            {
                $lookup: { from: 'addresses', localField: 'address', foreignField: '_id', as: 'addressDetails' },
            },
            { $lookup: { from: 'provinces', localField: 'addressDetails.province', foreignField: '_id', as: 'provinceName', pipeline: [{ $project: { name: 1, name_fr: 1, } }] } }
        ]

    whereCluase = [...whereCluase, ...addressLookup];

    if (When) {
        if (When !== "") {
            let bookingMatch = {};
            if (When === "7days") {
                bookingMatch = { futureBookingDay: 7 }
            }
            if (When === "1month") {
                bookingMatch = {
                    $or: [{ futureBookingDay: 14 }, { futureBookingMonths: 1 }]
                }
            }
            if (When === "5weeks") {
                bookingMatch = { futureBookingMonths: 2 }
            }
            let booking = [
                {
                    $lookup: {
                        from: 'bookingsettings',
                        localField: '_id',
                        foreignField: 'beauticianId',
                        as: 'bookingSettingData',
                        pipeline: [
                            { $match: bookingMatch }
                        ]
                    }
                },
                { $match: { bookingSettingData: { $gt: [] } } },
            ]
            whereCluase = [...whereCluase, ...booking];
        }
    }

    // Complete (testing)
    if (services.length) {
        let isCorrectServicesId = false;
        services.map(ele => isCorrectServicesId = !mongoose.Types.ObjectId.isValid(ele));
        if (isCorrectServicesId) {
            throw new ErrorHandler("Please pass valid service IDs.", HttpStatus.BAD_REQUEST, false);
        }
        let newLookup1 = {
            $addFields: {
                beauticianServiceDetails: {
                    $filter: {
                        input: '$beauticianServiceDetails',
                        as: 'service',
                        cond: {
                            $and: [
                                { $in: ['$$service.serviceCategory', services.map(id => new mongoose.Types.ObjectId(id))] },
                            ]
                        }
                    }
                }
            }
        }
        let newmatch1 = { $match: { beauticianServiceDetails: { $gt: [] } } }
        whereCluase.push(newLookup1, newmatch1);
    }

    // Compete (testing)
    if (minPrice && maxPrice) {
        whereCluase = [
            ...whereCluase,
            {
                $addFields: {
                    beauticianServiceDetails: {
                        $filter: {
                            input: '$beauticianServiceDetails',
                            as: 'service',
                            cond: {
                                $and: [
                                    { $gte: ['$$service.price', minPrice] },
                                    { $lte: ['$$service.price', maxPrice] }
                                ]
                            }
                        }
                    }
                }
            }
        ]
        let newmatch1 = { $match: { beauticianServiceDetails: { $gt: [] } } };
        whereCluase.push(newmatch1);
    }

    // Complete (testing)
    if (gender) {
        if (gender === "Male") {
            beauticianwhere = { $match: { gender: "Male" } }
            whereCluase.push(beauticianwhere);
        }
        if (gender === "Female") {
            beauticianwhere = { $match: { gender: "Female" } }
            whereCluase.push(beauticianwhere);
        }
    }

    if (demography.length) {
        let isCorrectDemoId = false;
        demography.map(ele => isCorrectDemoId = !mongoose.Types.ObjectId.isValid(ele));
        if (isCorrectDemoId) {
            throw new ErrorHandler("Please pass valid demography IDs.", HttpStatus.BAD_REQUEST, false);
        }
        let ids = demography.map((el) => { return new mongoose.Types.ObjectId(el) });
        demographyWhere = {
            ...demographyWhere,
            demographicIds: { $in: ids }
        }
        whereCluase.push({ $match: demographyWhere })
    }

    // Complete (testing)
    if (serveAt != "") {
        if (serveAt == 0) whereCluase[0].$match.IsServeAtOwnPlace = 1
        if (serveAt == 1) whereCluase[0].$match.IsServeAtClient = 1
    }
    // Complete (testing)
    if (latitude != "" && longitude != "") {
        locationwhere = {
            $geoNear: {
                near: { type: 'Point', coordinates: [parseFloat(longitude), parseFloat(latitude)] },
                key: "location",
                minDistance: minimumDistance,
                maxDistance: maximumDistance,
                distanceField: `dis.calculated`,
                spherical: true
            },
        }
        whereCluase.unshift(locationwhere);
    }

    // Complete (testing)
    if (sortBy === "myfavorite") {
        const user = await Client.findOne({ userId });
        if (user) {
            const beauticianIds = user.favorites;
            let newLookup1 = { $match: { _id: { $in: beauticianIds } } }
            whereCluase.push(newLookup1);
        }
    }
    // for racommnded here
    if (sortBy === "recommended") {
        let newLookup1 = { $match: { isRecommended: 1 } }
        whereCluase.push(newLookup1);
    }

    const finalClause = [
        {
            $lookup: {
                from: 'appointments',
                localField: '_id',
                foreignField: 'beauticianId',
                as: 'appointments'
            }
        },
        {
            $lookup: {
                from: 'ratings',
                localField: 'appointments._id',
                foreignField: 'appointmentId',
                as: 'ratings'
            }
        },
        {
            $project: {
                id: 1,
                logo: 1,
                address: {
                    address: { $first: '$addressDetails.address' },
                    province: { $first: '$provinceName.name' },
                    apartment: { $first: '$addressDetails.apartment' },
                    city: { $first: '$addressDetails.city' },
                    zipCode: { $first: '$addressDetails.zipCode' }
                },
                businessName: 1,
                rating: { $ifNull: ['$rating', null] },
                hasShop: 1,
                isLicensed: 1,
                noOfReviews: 1
            }
        }
    ]
    whereCluase = [...whereCluase, ...finalClause];

    const data = await Beautician.aggregate(whereCluase);
    let message
    if (!data.length) {
        message = "No result. Please review your filter selection"
    }
    if (data) {
        const clientData = await Client.findOne({ userId: userId });
        data.map((val) => {
            val.isFav = false;
            if (clientData.favorites.includes(val._id)) {
                val.isFav = true;
            }
            return val.isFav;
        })
    }
    const count = data.length;

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, data: { count, data }, message })

});
const getBeauticianDetails = catchAsyncError(async (req, res, next) => {
    const userId = req.user;
    const { id, limit, offset } = req.body;

    if (!id) {
        throw new ErrorHandler("Please Enter Beautician Id", HttpStatus.BAD_REQUEST);
    }
    const temp = await Beautician.find({ _id: id });
    let total;
    if (temp.length) {
        total = temp[0].beauticianServiceId.length;
    }
    const data = await Beautician.aggregate([
        { $match: { _id: new mongoose.Types.ObjectId(id) } },
        {
            $lookup: {
                from: 'beauticianservices',
                localField: '_id',
                foreignField: 'beauticianId',
                pipeline: [
                    { $match: { isDelete: 0 } },
                    { $project: { createdAt: 0, updatedAt: 0, __v: 0, beauticianId: 0 } },
                ],
                as: 'beauticianServiceId',
            },
        },
        {
            $unwind: { path: '$beauticianServiceId', preserveNullAndEmptyArrays: true },
        },
        {
            $lookup: {
                from: 'servicecategorylists',
                localField: 'beauticianServiceId.serviceCategory',
                foreignField: '_id',
                pipeline: [
                    { $project: { createdAt: 0, updatedAt: 0, __v: 0, imgPath: 0, cloudImg: 0 } },
                ],
                as: 'beauticianServiceId.serviceCategory',
            },
        },
        {
            $lookup: {
                from: 'servicetypelists',
                localField: 'beauticianServiceId.serviceType',
                foreignField: '_id',
                pipeline: [
                    { $project: { createdAt: 0, updatedAt: 0, __v: 0, serviceCategoryId: 0 } },
                ],
                as: 'beauticianServiceId.serviceType',
            },
        },
        {
            $lookup: {
                from: 'addresses',
                localField: 'address',
                foreignField: '_id',
                pipeline: [
                    { $project: { _id: 0, createdAt: 0, updatedAt: 0, __v: 0 } },
                ],
                as: 'address',
            },
        },
        {
            $lookup: {
                from: 'provinces', localField: 'address.province', foreignField: '_id', as: 'province',
                pipeline: [
                    { $project: { name: 1, name_fr: 1, } },
                ],
            },
        },
        {
            $lookup: {
                from: 'bookingsettings', localField: '_id', foreignField: 'beauticianId', as: 'bookingSettings',
                pipeline: [
                    { $project: { confirmAuto: 1 } },
                ],
            },
        },
        {
            $lookup: {
                from: 'ratings',
                localField: 'appointments._id',
                foreignField: 'appointmentId',
                as: 'ratings'
            }
        },
        {
            $project: {
                id: 1,
                logo: 1,
                workSpaceImgs: 1,
                address: {
                    address: { $first: '$address.address' },
                    province: { $first: '$province.name' },
                    province_fr: { $first: '$province.name_fr' },
                    apartment: { $first: '$address.apartment' },
                    city: { $first: '$address.city' },
                    zipCode: { $first: '$address.zipCode' }
                },
                businessName: 1,
                businessNumber: 1,
                beauticianServiceId: {
                    _id: '$beauticianServiceId._id',
                    serviceCategory: { $arrayElemAt: ['$beauticianServiceId.serviceCategory', 0] },
                    serviceType: { $arrayElemAt: ['$beauticianServiceId.serviceType', 0] },
                    duration: '$beauticianServiceId.duration',
                    price: '$beauticianServiceId.price',
                    description: '$beauticianServiceId.description',
                    priceStatus: '$beauticianServiceId.priceStatus',
                    imgName: '$beauticianServiceId.imgName'
                },
                rating: 1,
                noOfReviews: 1,
                confirmAuto: { $arrayElemAt: ['$bookingSettings.confirmAuto', 0] }
            },
        },
        {
            $group: {
                _id: '$_id',
                workSpaceImgs: { $first: '$workSpaceImgs' },
                logo: { $first: '$logo' },
                address: { $first: { $arrayElemAt: ['$address', 0] } },
                beauticianServiceId: { $push: '$beauticianServiceId' },
                businessName: { $first: '$businessName' },
                businessNumber: { $first: '$businessNumber' },
                rating: { $first: '$rating' },
                noOfReviews: { $first: '$noOfReviews' },
                confirmAuto: { $first: '$confirmAuto' }
            },
        },
    ]);
    if (data && data.length > 0) {
        const clientData = await Client.findOne({ userId: userId });
        data[0].isFav = false
        if (clientData.favorites && clientData.favorites.includes(id)) {
            data[0].isFav = true;
        }
        const beauticianId = clientData.recent.includes(id);
        if (!beauticianId) {
            clientData.recent.unshift(id);
            await clientData.save();
        }

    } else {
        throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST);
    }
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, data: { total, data } })
});
const getServiceAndBeauticianOnSearch = async (search) => {
    const beauticianTypes = await ServiceTypeList.aggregate([
        { $match: { serviceTypeName: { $regex: search, $options: 'i' } } },
        {
            $lookup: {
                from: "beauticianservices",
                localField: "_id",
                foreignField: "serviceType",
                as: "beautyService"
            }
        },
        {
            $lookup: {
                from: "beauticians",
                localField: "beautyService.beauticianId",
                foreignField: "_id",
                as: "beauticianData",
                pipeline: [
                    { $match: { screenStatus: 7, isDeleted: 0, stripe_id: { $ne: null } } },
                    { $project: { logo: 1, businessName: 1, address: 1 } }
                ]
            }
        },
        {
            $lookup: {
                from: "addresses",
                localField: "beauticianData.address",
                foreignField: "_id",
                as: "address",
                pipeline: [
                    { $project: { address: 1, city: 1, province: 1, street: 1, apartment: 1, zipCode: 1 } }
                ]
            }
        },
        {
            $lookup: {
                from: 'provinces',
                localField: 'address.province',
                foreignField: "_id",
                as: 'province',
                pipeline: [
                    { $project: { name: 1, name_fr: 1, } }
                ]
            }
        },
    ])
    const serviceTypes = []
    let businessList = []
    if (beauticianTypes.length) {
        beauticianTypes.forEach(service => {
            //create service data
            serviceTypes.push({
                _id: service._id,
                serviceCategoryId: service.serviceCategoryId,
                serviceTypeName: service.serviceTypeName
            })

            if (service.beauticianData.length) {
                //create beauticianData
                service.beauticianData?.forEach(beauty => {
                    let tempData = {
                        _id: beauty._id,
                        logo: beauty.logo,
                        businessName: beauty.businessName
                    };
                    service.address?.forEach(addr => {
                        if (addr._id.equals(beauty.address)) { // match address Id
                            tempData.address = addr
                        }
                        service.province?.forEach(prov => {
                            if (addr.province.equals(prov._id)) {// match province Id
                                tempData.province = prov.name
                            }
                        })
                    })
                    businessList.push(tempData) // push data for beuticianTypes
                })
            }
        })
        // remove duplicate beautician entry
        businessList = businessList.filter((item, index, self) => {
            return index === self.findIndex(obj => obj._id.equals(item._id));
        });
    }
    return { serviceTypes, businessList }
}
const searchServiceType = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { search } = req.query;
    const userDetail = await Client.findOne({ userId: id });
    const { serviceTypes, businessList } = await getServiceAndBeauticianOnSearch(search);
    if (!userDetail.searchText.includes(search) && businessList.length > 0) {
        userDetail.searchText.unshift(search);

    }
    if (serviceTypes.length == 0 && businessList.length == 0) {
        userDetail.unSuccessfulSearch = userDetail.unSuccessfulSearch + 1
    }
    await userDetail.save();
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, data: { serviceTypes, beuticianTypes: businessList } });
})
const getRecentSearchList = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const userDetail = await Client.findOne({ userId: id });
    let resData = []
    userDetail.searchText = userDetail.searchText.slice(0, 5);
    const getAllValue = userDetail.searchText.map(async search => {
        return new Promise(async (resolve, reject) => {
            const { businessList } = await getServiceAndBeauticianOnSearch(search);
            resData = [...resData, ...businessList]
            resolve(resData);
        });
    })
    await Promise.all(getAllValue);
    resData = resData.filter((item, index, self) => {
        return index === self.findIndex(obj => obj._id === item._id);
    });
    return res.status(HttpStatus.OK).json({
        status: HttpStatus.OK,
        data: resData
    });

})
const businessDetails = catchAsyncError(async (req, res, next) => {
    const userId = req.user;
    const { id } = req.body;
    const beautician = await Beautician.aggregate([
        { $match: { _id: new mongoose.Types.ObjectId(id) } },
        {
            $lookup: {
                from: "users",
                localField: "userId",
                foreignField: "_id",
                pipeline: [
                    { $project: { _id: 0, roles: 0, resetPasswordToken: 0, isActiveBeautician: 0, __v: 0, password: 0 } },
                ],
                as: "User"
            }
        },
        {
            $lookup: {
                from: 'promotions',
                localField: '_id',
                foreignField: 'beauticianId',
                as: 'promotionDetails',
                pipeline: [
                    { $project: { isDiscPercentage: 1, discount: 1, startDate: 1, endDate: 1, serviceName: 1 } },
                    {
                        $match:
                        {
                            $and: [
                                {
                                    startDate: {
                                        $lte: new Date(),
                                    }
                                },
                                {
                                    endDate: {
                                        $gte: new Date(),
                                    }
                                },
                            ]
                        }
                    }
                ]
            },
        },
        { $lookup: { from: 'beauticianservices', localField: 'beauticianServiceId', foreignField: '_id', as: 'serviceDetails' }, },
        {
            $lookup: {
                from: 'servicetypelists',
                localField: 'serviceDetails.serviceType',
                foreignField: '_id',
                pipeline: [
                    { $project: { createdAt: 0, updatedAt: 0, __v: 0, serviceCategoryId: 0 } },
                ],
                as: 'serviceType',
            },
        },
        { $lookup: { from: 'demographies', localField: 'demographicIds', foreignField: '_id', as: 'demographys' } },
        {
            $lookup: {
                from: 'amenities', localField: 'amenityIds', foreignField: '_id', as: 'amenities', pipeline: [
                    { $project: { name: 1, name_fr: 1, } },
                ],
            }
        },
        {
            $lookup: {
                from: 'addresses', localField: 'address', foreignField: '_id', as: 'beauticianAddress',
                pipeline: [
                    { $project: { _id: 0, address: 1, province: 1, apartment: 1, city: 1, zipCode: 1 } },
                ],
            }
        },
        { $lookup: { from: 'provinces', localField: 'beauticianAddress.province', foreignField: '_id', as: 'provinceName', pipeline: [{ $project: { name: 1, name_fr: 1, } }] } },
        {
            $lookup: {
                from: "beauticianworkhours",
                localField: "_id",
                foreignField: "beauticianId",
                pipeline: [
                    { $project: { _id: 0, dayDetails: 1 } },
                ],
                as: "workHours"
            }
        },
        {
            $lookup: {
                from: "employees",
                localField: "_id",
                foreignField: "beauticianId",
                pipeline: [
                    { $project: { _id: 0, createdAt: 0, updatedAt: 0, __v: 0, beauticianId: 0 } },
                ],
                as: "Employees"
            }
        },

    ]);
    if (beautician && beautician.length > 0) {
        if (beautician[0].serviceDetails?.length) {
            beautician[0].serviceDetails?.forEach(ele => {
                beautician[0].serviceType?.forEach(service => {
                    if (service._id.equals(ele.serviceType)) {
                        ele.serviceType = service
                    }
                })
            });
            beautician[0].serviceType = null;
            if (beautician[0]?.serviceDetails) {
                beautician[0].serviceDetails.forEach((val) => {
                    val.promPrice = null;
                    beautician[0].promotionDetails.forEach((ele) => {
                        if (ele.serviceName === val.serviceType.serviceTypeName) {
                            let promPrice = ""
                            if (ele.isDiscPercentage) {
                                promPrice = val.price - (val.price * ele.discount / 100);
                                val.promPrice = Math.round(promPrice);
                            } else {
                                promPrice = val.price - ele.discount;
                                val.promPrice = Math.round(promPrice);
                            }
                        }
                    })
                })
            }
        }
        const clientData = await Client.findOne({ userId: userId });
        beautician[0].isFav = false
        if (clientData.favorites && clientData.favorites.includes(id)) {
            beautician[0].isFav = true;
        }
        const beauticianId = clientData.recent.includes(id);
        if (!beauticianId) {
            clientData.recent.unshift(id);
            await clientData.save();
        }
    } else {
        throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST);
    }

    return res.status(200).json({ status: HttpStatus.OK, success: true, beautician });
})

// const businessDetailsNew = catchAsyncError(async (req, res, next) => {
//     const { id } = req.body;
//     if (!mongoose.Types.ObjectId.isValid(id)) {
//         throw new ErrorHandler("Beautician Id is not valid.", HttpStatus.BAD_REQUEST, false)
//     }
//     const beautician = await Beautician.aggregate([
//         { $match: { _id: new mongoose.Types.ObjectId(id) } },
//         {
//             $lookup: {
//                 from: 'amenities', localField: 'amenityIds', foreignField: '_id', as: 'amenities', pipeline: [
//                     { $project: { name: 1 } },
//                 ],
//             }
//         },
//         {
//             $lookup: {
//                 from: 'addresses', localField: 'address', foreignField: '_id', as: 'beauticianAddress',
//                 pipeline: [
//                     { $project: { _id: 0, address: 1, province: 1, apartment: 1, city: 1, zipCode: 1 } },
//                 ],
//             }
//         },
//         { $lookup: { from: 'provinces', localField: 'beauticianAddress.province', foreignField: '_id', as: 'provinceName', pipeline: [{ $project: { name: 1 } }] } },
//         {
//             $lookup: {
//                 from: "beauticianworkhours",
//                 localField: "_id",
//                 foreignField: "beauticianId",
//                 pipeline: [
//                     { $project: { _id: 0, createdAt: 0, updatedAt: 0, __v: 0, beauticianId: 0, calenderSetting: 0 } },
//                 ],
//                 as: "workHours"
//             }
//         },
//         {
//             $lookup: {
//                 from: "employees",
//                 localField: "_id",
//                 foreignField: "beauticianId",
//                 pipeline: [
//                     { $match: { status: 1 } },
//                     { $project: { firstName: 1, lastName: 1, title: 1, profileImage: 1 } },
//                 ],
//                 as: "Employees"
//             }
//         },
//         {
//             $project: {
//                 _id: 1,
//                 address: {
//                     address: { $first: '$beauticianAddress.address' },
//                     province: { $first: '$provinceName.name' },
//                     apartment: { $first: '$beauticianAddress.apartment' },
//                     city: { $first: '$beauticianAddress.city' },
//                     zipCode: { $first: '$beauticianAddress.zipCode' }
//                 },
//                 businessName: 1,
//                 amenities: 1,
//                 location: 1,
//                 country_code: 1,
//                 businessNumber: 1,
//                 facebookUrl: 1,
//                 instagramUrl: 1,
//                 website: 1,
//                 description: 1,
//                 Employees: 1,
//                 workHours: 1
//             }
//         }
//     ]);

//     if (!beautician) {
//         throw new ErrorHandler("Beautician not found", HttpStatus.BAD_REQUEST);
//     }

//     return res.status(200).json({ status: HttpStatus.OK, success: true, beautician });
// })

// add counts for nubOfView, nubOfShareClicked,nubOfCartClicked
const addCountForService = catchAsyncError(async (req, res, next) => {
    const { type, dataId } = req.params;
    // validation for dataId formate
    if (!mongoose.Types.ObjectId.isValid(dataId)) {
        throw new ErrorHandler("Invalid Id.", HttpStatus.NOT_FOUND, false);
    }
    let updateServiceView;
    if (type === 'click-view') {
        updateServiceView = await BeauticianService.findByIdAndUpdate(dataId, { $inc: { nubOfView: 1 } }, { new: true });
    } else if (type === 'click-Book') {
        updateServiceView = await BeauticianService.findByIdAndUpdate(dataId, { $inc: { nubOfCartClicked: 1 } }, { new: true });
    } else if (type === 'click-share') {
        updateServiceView = await Beautician.findByIdAndUpdate(dataId, { $inc: { nubOfShareClicked: 1 } }, { new: true });
    } else {
        throw new ErrorHandler("Page not found on server.", HttpStatus.NOT_FOUND, false);
    }
    //check that any data is updated or not.
    if (updateServiceView !== null) {
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Click event saved" })
    } else {
        throw new ErrorHandler("Invalid Id.", HttpStatus.NOT_FOUND, false);

    }
})

// get beautician policy
const getBePolicyDetails = catchAsyncError(async (req, res, next) => {
    const { beauticianId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(beauticianId)) {
        throw new ErrorHandler("Invalid beauticianId", HttpStatus.BAD_REQUEST, false)
    }
    const beauticianData = await Beautician.findById(beauticianId).select("cancelProtection noShowProtection")
    if (beauticianData) {
        const cancelPolicy = getPolicyDetails(beauticianData.cancelProtection);
        const noSHowPolicy = getPolicyDetailsForNoShow(beauticianData.noShowProtection);
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { cancelPolicy, noSHowPolicy } })
    } else {
        throw new ErrorHandler("Invalid beauticianId.", HttpStatus.NOT_FOUND, false);
    }
});

// get Portfolio Images 
const getPortfolioImages = catchAsyncError(async (req, res, next) => {
    const { beauticianId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(beauticianId)) {
        throw new ErrorHandler("Invalid beauticianId", HttpStatus.BAD_REQUEST, false)
    }
    const beauticianData = await BeauticianService.find({ beauticianId }).select("imgName");
    if (beauticianData.length) {
        const imgArray = [];
        beauticianData.forEach(ele => {
            if (ele.imgName) {
                if (ele.imgName.length) {
                    ele.imgName.forEach((val) => {
                        if (val) { imgArray.push(val) }
                    })
                }
            }
        });
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: imgArray })
    }
});

const beauticianReviews = catchAsyncError(async (req, res, next) => {
    const { beauticianId } = req.body;

    let reviewList = await Rating.aggregate([
        {
            $lookup: {
                from: 'appointments',
                localField: 'appointmentId',
                foreignField: "_id",
                as: 'appointmentDeatils',
            },
        },
        {
            $lookup: {
                from: 'beauticians',
                localField: 'appointmentDeatils.beauticianId',
                foreignField: "_id",
                as: 'beauticianDetails',
            },
        },
        {
            $lookup: {
                from: 'clients',
                localField: 'appointmentDeatils.clientId',
                foreignField: "_id",
                as: 'clientDeatils',
                pipeline: [
                    {
                        $project: {
                            firstName: 1, lastName: 1,
                            profileImage: {
                                $ifNull: ["$profileImage", null]
                            },
                        }
                    }
                ]
            },
        },
        {
            $match: { 'beauticianDetails._id': new mongoose.Types.ObjectId(beauticianId) }
        },
        { $sort: { createdAt: -1 } },
        {
            $project: {
                appointmentId: 1,
                rating: 1,
                createdAt: 1,
                reviews: 1,
                clientFirstName: { $arrayElemAt: ['$clientDeatils.firstName', 0] },
                clientLastName: { $arrayElemAt: ['$clientDeatils.lastName', 0] },
                profileImage: { $arrayElemAt: ['$clientDeatils.profileImage', 0] },
                tempRatings: { $arrayElemAt: ['$beauticianDetails.rating', 0] },
            }
        }
    ]);

    let ratingWiseCount = await Rating.aggregate([
        {
            $lookup: {
                from: 'appointments',
                localField: 'appointmentId',
                foreignField: "_id",
                as: 'appointmentDeatils',
            },
        },
        {
            $lookup: {
                from: 'beauticians',
                localField: 'appointmentDeatils.beauticianId',
                foreignField: "_id",
                as: 'beauticianDetails',
            },
        },
        {
            $lookup: {
                from: 'clients',
                localField: 'appointmentDeatils.clientId',
                foreignField: "_id",
                as: 'clientDeatils',
                pipeline: [
                    {
                        $project: {
                            firstName: 1, lastName: 1,
                            profileImage: {
                                $ifNull: ["$profileImage", null]
                            },
                        }
                    }
                ]
            },
        },
        {
            $match: { 'beauticianDetails._id': new mongoose.Types.ObjectId(beauticianId) }
        },
        {
            $group: {
                _id: { $floor: "$rating" },
                count: { $sum: 1 }
            }
        },
    ]);
    let one = 0;
    let two = 0;
    let three = 0;
    let four = 0;
    let five = 0;

    if (ratingWiseCount.length) {
        ratingWiseCount.forEach(rating => {
            if (rating._id == 0) { }
            else if (rating._id == 1) { one = rating.count; }
            else if (rating._id == 2) { two = rating.count; }
            else if (rating._id == 3) { three = rating.count; }
            else if (rating._id == 4) { four = rating.count; }
            else if (rating._id == 5) { five = rating.count; }

        });
    }

    let totalRating = "0.00";
    if (reviewList.length) {
        reviewList.forEach((val) => {
            if (val.tempRatings) {
                totalRating = val.tempRatings.toFixed(2)
            }
        });
    }

    const count = reviewList.length;

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { noOfReviews: count, one, two, three, four, five, totalRating, reviewList } })
});

const getBeauticianAvailability = catchAsyncError(async (req, res, next) => {
    const { beauticianId } = req.params;
    const { dateToCheck } = req.query;
    const beauticianData = await Beautician.aggregate([
        { $match: { _id: new mongoose.Types.ObjectId(beauticianId) } },
        {
            $lookup: {
                from: 'beauticianworkhours',
                localField: '_id',
                foreignField: "beauticianId",
                as: 'beauticianWorkingHours',
            },
        },
        {
            $project: { beauticianWorkingHours: 1 }
        }
    ]);

    let timeAvailability = [
        "00:00",
        "01:00",
        "01:15",
        "01:30",
        "01:45",
        "02:00",
        "02:15",
        "02:30",
        "02:45",
        "03:00",
        "03:15",
        "03:30",
        "03:45",
        "04:00",
        "04:15",
        "04:30",
        "04:45",
        "05:00",
        "05:15",
        "05:30",
        "05:45",
        "06:00",
        "06:15",
        "06:30",
        "06:45",
        "07:00",
        "07:15",
        "07:30",
        "07:45",
        "08:00",
        "08:15",
        "08:30",
        "08:45",
        "09:00",
        "09:15",
        "09:30",
        "09:45",
        "10:00",
        "10:15",
        "10:30",
        "10:45",
        "11:00",
        "11:15",
        "11:30",
        "11:45",
        "12:00",
        "12:15",
        "12:30",
        "12:45",
        "13:00",
        "13:15",
        "13:30",
        "13:45",
        "14:00",
        "14:15",
        "14:30",
        "14:45",
        "15:00",
        "15:15",
        "15:30",
        "15:45",
        "16:00",
        "16:15",
        "16:30",
        "16:45",
        "17:00",
        "17:15",
        "17:30",
        "17:45",
        "18:00",
        "18:15",
        "18:30",
        "18:45",
        "19:00",
        "19:15",
        "19:30",
        "19:45",
        "20:00",
        "20:15",
        "20:30",
        "20:45",
        "21:00",
        "21:15",
        "21:30",
        "21:45",
        "22:00",
        "22:15",
        "22:30",
        "22:45",
        "23:00",
        "23:15",
        "23:30",
        "23:45",
        "24:00",
    ];

    // const offDaysInMonth = [];
    if (beauticianData.length) {
        const workingHours = beauticianData[0].beauticianWorkingHours[0].dayDetails;
        const startMonth = moment().format("MMMM");
        const Year = moment().format("YYYY");
        const numberOfMonths = 3;
        const offDaysInMonths = [];

        const isDayOff = ((dayName) => {
            const day = workingHours.find(day => day.day === dayName);
            return day && !day.isOpen;
        })

        // Loop through the specified number of months
        for (let i = 0; i < numberOfMonths; i++) {
            const month = new Date(startMonth + " 1," + Year); // Use the desired year
            month.setMonth(month.getMonth() + i);

            const offDaysInMonth = [];

            // Loop through the days of the current month
            for (let day = 1; day <= 31; day++) {
                const date = new Date(month.getFullYear(), month.getMonth(), day);
                const dayName = date.toLocaleDateString("en-US", { weekday: "long" });

                if (isDayOff(dayName)) {
                    const year = date.getFullYear();
                    const month = (date.getMonth() + 1).toString().padStart(2, '0');
                    const day = date.getDate().toString().padStart(2, '0');
                    const formattedDate = `${year}-${month}-${day}`;
                    offDaysInMonth.push(formattedDate);
                }
            }
            offDaysInMonths.push(offDaysInMonth);
        }

        const today = new Date();
        const tempDate = dateToCheck ? new Date(dateToCheck) : new Date();
        const dateAndTime = new Date(tempDate.toISOString());
        dateAndTime.setHours(0, 0, 0, 0);
        const beauticianTime = await Appointment.aggregate([
            {
                $match: {
                    beauticianId: new mongoose.Types.ObjectId(beauticianId),
                    dateTime: {
                        $gte: dateAndTime,
                        $lt: new Date(dateAndTime.getTime() + 24 * 60 * 60 * 1000),
                    }
                }
            }
        ]);

        if (beauticianTime.length) {
            beauticianTime.forEach((val) => {
                const startTime = val.dateTime.toISOString().slice(11, 16);
                const endTime = val.endDateTime.toISOString().slice(11, 16);

                timeAvailability = timeAvailability.filter((timeSlot) => {
                    if (timeSlot >= startTime && timeSlot < endTime) {
                        return false;
                    }
                    return true;
                });
            });
        }
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, offDaysInMonths, timeAvailability });
    } else {
        throw new ErrorHandler(req.t("beauticianNotFound"), HttpStatus.BAD_REQUEST);
    }
});
module.exports = { findServices, findServicesNew, getBeauticianDetails, findAddress, searchServiceType, getRecentSearchList, businessDetails, addCountForService, getBePolicyDetails, getPortfolioImages, beauticianReviews, getBeauticianAvailability };

