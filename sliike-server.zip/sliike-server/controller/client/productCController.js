const { validationResult } = require("express-validator");
const catchAsyncError = require("../../middleware/catchAsyncError");
const BeauticianProduct = require("../../models/BeauticianProduct");
const ErrorHandler = require("../../utils/ErrorHandling");
const Cart = require("../../models/Cart");
const HttpStatus = require("../../utils/HttpStatus");
const ProductCategoryList = require("../../models/ProductCategoryList");
const { default: mongoose } = require("mongoose");
const Client = require("../../models/Client");
const Beautician = require("../../models/Beautician");
const Order = require("../../models/Order");
const Address = require("../../models/Address");
const Province = require("../../models/Province");
const { makePayment } = require("../../libs/stripe/makePayment");
const { createStripeCard } = require("../../libs/stripe/addStripeCard");
const { createStripeCustomer } = require("../../libs/stripe/createStripeCustomer");
const User = require("../../models/User");
const Cards = require("../../models/Cards");
const { attachCustomerID } = require("../../libs/stripe/attachCustomerID");
const { generateNumericId } = require("../../utils/generateNumericId");
const { notificationMSGs } = require("../../utils/Constant");
const { fcmNotification } = require("../../utils/fcmNotification");
const FcmNotification = require("../../models/FcmNotification");
const platform_fees = process.env.PLATFORM_FEES || 0.10;
const moment = require("moment");
const BeauticianWorkHour = require("../../models/BeauticianWorkHour");
// const https = require('https');
// const axios = require('axios');
// const xml2js = require('xml2js');
// const apiKey = 'fb36864c056779e4b16bec';

// for get product list 
const getproductCategoryList = catchAsyncError(async (req, res, next) => {
    const data = await ProductCategoryList.find({}).select({ productCategoryName: 1 });

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data });
});

// for get filter products
const getFilterProduct = catchAsyncError(async (req, res, next) => {
    const Id = req.user;
    const { category, demography, sortBy, gender, maxPrice } = req.body;
    let findQuery = {
        isDelete: 0
    };
    let beauticianQuery = {
        screenStatus: 7,
        stripe_id: { $ne: null }
    };

    // This is for filter product category wise
    if (category && category.length) {
        if (!Array.isArray(category)) throw new ErrorHandler("Please category IDs inside array.", HttpStatus.BAD_REQUEST);
        const categorytemp = category.map(ele => !mongoose.Types.ObjectId.isValid(ele));

        if (categorytemp.includes(true)) {
            throw new ErrorHandler("Please Enter valid category Id", HttpStatus.BAD_REQUEST, false);
        }

        let ids = category.map((el) => { return new mongoose.Types.ObjectId(el) });
        findQuery = {
            ...findQuery,
            productCategory: { $in: ids }
        }
    }

    // This is for filter on gender of beautician
    if (gender) {
        if (gender !== "Other" && gender !== "Male" && gender !== "Female") throw new ErrorHandler("Please enter valid gender", HttpStatus.BAD_REQUEST, false);
        if (gender !== "") {
            beauticianQuery = {
                ...beauticianQuery,
                gender
            }
        }
    }

    // This is for price range filter 
    if (maxPrice !== "" & maxPrice !== null) {
        let minPrice = 0;
        findQuery = {
            ...findQuery,
            price:
            {
                $gte: minPrice,
                $lte: parseInt(maxPrice)

            }
        }
    }

    // This is for sort by filter
    if (sortBy === "myFavorites") {
        const user = await Client.findOne({ userId: Id });
        if (user) {
            const productIds = user.favProducts;
            findQuery = {
                ...findQuery,
                _id: { $in: productIds }

            }
        }
    }


    if (demography && demography.length) {
        if (!Array.isArray(demography)) throw new ErrorHandler("Please demography IDs inside array.", HttpStatus.BAD_REQUEST);
        const demographyTemp = demography.map(ele => !mongoose.Types.ObjectId.isValid(ele));

        if (demographyTemp.includes(true)) {
            throw new ErrorHandler("Please pass valid demography IDs.", HttpStatus.BAD_REQUEST, false);
        }

        let ids = demography.map((el) => { return el });
        beauticianQuery = {
            ...beauticianQuery,
            demographicIds: { $in: ids }
        }
    };

    const productData = await BeauticianProduct.aggregate([
        { $match: findQuery },
        {
            $lookup: {
                from: 'beauticians',
                localField: 'beauticianId',
                foreignField: "_id",
                as: 'beauticianDetails',
                pipeline: [
                    { $match: beauticianQuery },
                ]
            },
        },
        {
            $lookup: {
                from: 'productcategorylists',
                localField: 'productCategory',
                foreignField: "_id",
                as: 'productCategoryDetails',
                pipeline: [
                    { $project: { productCategoryName: 1, productCategoryName_fr: 1, } },
                ]
            },
        },
        { $match: { beauticianDetails: { $gt: [] } } },
        { $sort: { createdAt: -1 } },
        { $project: { imgName: 1, productName: 1, promotionDetails: 1, productCategoryDetails: 1 } }
    ]);

    if (productData.length) {
        const clientData = await Client.findOne({ userId: Id });
        productData.map((val) => {
            val.isFavProduct = false;
            val.promoPrice = null;
            if (clientData.favProducts.includes(val._id)) {
                val.isFavProduct = true;
            }

            if (val.promotionDetails) {
                if (val.promotionDetails.startDate < new Date() && val.promotionDetails.endDate > new Date()) {
                    val.promoPrice = val.promotionDetails.proPrice;
                }
            }
            return val.isFavProduct, val.promoPrice;
        });
    }

    let message;
    if (!productData.length) message = "No result. Please review your filter selection";
    const count = productData.length;

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, count, productData, message });
});

// for serach product or vendor 
const findProductOrVendor = catchAsyncError(async (req, res, next) => {
    const Id = req.user;
    const { search } = req.body;
    const ClientData = await Client.findOne({ userId: Id });
    let productQuery = {
        isDelete: 0
    };
    let beauticianQuery = {}

    if (search !== "") {
        productQuery = {
            ...productQuery,
            productName: { $regex: search, $options: 'i' }
        }

        beauticianQuery = {
            ...beauticianQuery,
            businessName: { $regex: search, $options: 'i' },
        }

    }

    const productData = await BeauticianProduct.aggregate([
        { $match: productQuery },
        {
            $lookup: {
                from: 'beauticians',
                localField: 'beauticianId',
                foreignField: '_id',
                as: 'vendorData',
                pipeline: [
                    { $project: { businessName: 1, logo: 1, profileImage: 1 } }
                ]
            }
        },
        { $project: { productName: 1, vendorData: 1 } },

    ]);
    let productList = []
    let vendorList = []
    if (productData.length) {
        productData.forEach(pro => {
            productList.push({ _id: pro._id, productName: pro.productName });
            pro.vendorData?.forEach(vendor => {
                vendorList.push(vendor)
            })
        })
    }
    if (vendorList.length) {
        vendorList = vendorList.filter((item, index, self) => {
            return index === self.findIndex(obj => obj._id.equals(item._id));
        });
    }
    const productCount = productData.length;
    const vendorCount = vendorList.length;
    if (vendorList.length) {
        if (!ClientData.productSearchText.includes(search)) {
            ClientData.productSearchText.unshift(search);
        }
    }

    await ClientData.save();

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { productList, productCount, vendorCount, vendorList } });
});

// for add product in favorites
const addProductInFavorites = catchAsyncError(async (req, res, next) => {
    const Id = req.user;
    const { productId } = req.body;

    if (!mongoose.Types.ObjectId.isValid(productId)) throw new ErrorHandler("Please enter valid product Id", HttpStatus.BAD_REQUEST, false);

    const isProduct = await BeauticianProduct.findOne({ _id: productId });

    if (isProduct) {
        const userData = await Client.findOne({ userId: Id });

        if (userData.favProducts.includes(isProduct._id)) {
            throw new ErrorHandler("Product is already in favorites", HttpStatus.BAD_REQUEST, false);
        }
        userData.favProducts.unshift(isProduct._id);
        await userData.save();
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("addProductInFavoritesSuccess") });
    } else {
        throw new ErrorHandler(req.t("productNotFound"), HttpStatus.BAD_REQUEST, false);
    }
});

// for remove product from favorites
const removeProductInFavorites = catchAsyncError(async (req, res, next) => {
    const Id = req.user;
    const { productId } = req.body;
    if (!mongoose.Types.ObjectId.isValid(productId)) throw new ErrorHandler("Please enter valid product Id", HttpStatus.BAD_REQUEST, false);

    const isProduct = await BeauticianProduct.findOne({ _id: productId });

    if (isProduct) {
        const userData = await Client.findOne({ userId: Id });

        if (!userData.favProducts.includes(isProduct._id)) {
            throw new ErrorHandler("Product already removed", HttpStatus.BAD_REQUEST, false);
        }

        userData.favProducts.pull(isProduct._id);
        await userData.save();

        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("removeProductInFavoritesSuccess") });
    } else {
        throw new ErrorHandler(req.t("productNotFound"), HttpStatus.BAD_REQUEST, false);
    }
});

// get recent product search
const getRecentProductSearch = catchAsyncError(async (req, res, next) => {
    const Id = req.user;
    const clientData = await Client.findOne({ userId: Id });
    if (clientData) {
        let resData = [];
        const getAllValue = clientData.productSearchText.map(async search => {
            return new Promise(async (resolve, reject) => {
                const newProductList = await BeauticianProduct.aggregate([
                    { $match: { productName: { $regex: search, $options: 'i' }, isDelete: 0 } },
                    {
                        $project: {
                            productName: 1, productCategoryDetails: 1, imgName: 1,
                        }
                    },
                ])
                resData = [...resData, ...newProductList]
                resolve(resData);
            });
        })
        await Promise.all(getAllValue);
        // remove duplicate beautician entry
        resData = resData.filter((item, index, self) => {
            return index === self.findIndex(obj => obj._id.equals(item._id));
        });
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, tempData: resData });
    } else {
        throw new ErrorHandler(req.t("clientNotFound"), HttpStatus.BAD_REQUEST,)
    }
});

// get favorites product list
const getFavoriteProductList = catchAsyncError(async (req, res, next) => {
    const Id = req.user;

    const clientData = await Client.findOne({ userId: Id });

    if (clientData) {

        let ids = clientData.favProducts.map((el) => { return new mongoose.Types.ObjectId(el) });
        const data = await BeauticianProduct.aggregate([
            { $match: { _id: { $in: ids }, isDelete: 0 } },
            {
                $lookup: {
                    from: 'beauticians',
                    localField: 'beauticianId',
                    foreignField: "_id",
                    as: 'beauticianDeatils',
                    pipeline: [
                        {
                            $project: {
                                rating: {
                                    $ifNull: ["$rating", 0]
                                },
                            }
                        }
                    ],
                },
            },
            {
                $project: {
                    imgName: 1, price: 1, productName: 1,
                    rating: { $arrayElemAt: ["$beauticianDeatils.rating", 0] },
                    promotionDetails: {
                        $ifNull: ["$promotionDetails", null]
                    },
                }
            }
        ]);

        if (data.length) {
            data.map((val) => {
                val.promoPrice = null;
                if (val.promotionDetails) {
                    if (val.promotionDetails.startDate < new Date() && val.promotionDetails.endDate > new Date()) {
                        val.promoPrice = val.promotionDetails.proPrice;
                    }
                }
                return val.promoPrice;
            });
        }
        const count = data.length;
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, count, data });
    } else {
        throw new ErrorHandler(req.t("clientNotFound"), HttpStatus.BAD_REQUEST);
    }
});

// get recommanded products
const getRecomadedProducts = catchAsyncError(async (req, res, next) => {
    const productData = await BeauticianProduct.aggregate([
        { $match: { isDelete: 0 } },
        {
            $lookup: {
                from: 'beauticians',
                localField: 'beauticianId',
                foreignField: "_id",
                as: 'beauticianData',
                pipeline: [
                    { $match: { isRecommended: 1, } },
                    {
                        $project: {
                            rating: {
                                $ifNull: ["$rating", 0]
                            },
                        }
                    }
                ]
            },
        },
        { $match: { beauticianData: { $gt: [] } } },
        {
            $project: {
                productName: 1, price: 1, imgName: 1,
                promotionDetails: {
                    $ifNull: ["$promotionDetails", null]
                },
                ratings: { $arrayElemAt: ["$beauticianData.rating", 0] },
            }
        }
    ]);
    if (productData.length) {
        productData.map((val) => {
            val.promoPrice = null;
            if (val.promotionDetails) {
                if (val.promotionDetails.startDate < new Date() && val.promotionDetails.endDate > new Date()) {
                    val.promoPrice = val.promotionDetails.proPrice;
                }
            }
            return val.promoPrice;
        });
    }
    const count = productData.length;
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { count, productData } })
});

// get Product details
const getSingleProductDetail = catchAsyncError(async (req, res, next) => {
    const { productPId } = req.params;
    const Id = req.user;
    const clientData = await Client.findOne({ userId: Id });

    if (!mongoose.Types.ObjectId.isValid(productPId)) {
        throw new ErrorHandler("Please Enter Valid Product Id", HttpStatus.NOT_FOUND, false);
    }

    let productDetail = await BeauticianProduct.aggregate([
        {
            $match:
            {
                $and: [
                    { _id: new mongoose.Types.ObjectId(productPId) },
                    { isDelete: 0 }
                ]
            }
        },
        {
            $lookup: {
                from: 'beauticians',
                localField: 'beauticianId',
                foreignField: "_id",
                as: 'beauticianDetails',
                pipeline: [
                    {
                        $project: {
                            rating: {
                                $ifNull: ["$rating", 0]
                            },
                            noOfReviews: {
                                $ifNull: ["$noOfReviews", 0]
                            },
                        }
                    }
                ]
            },
        },
        {
            $project: {
                beauticianId: 1, productCategory: 1, productName: 1, wtValue: 1, wtUnit: 1, htValue: 1, htUnit: 1, lengthValue: 1, lengthUnit: 1, widthValue: 1,
                imgName: 1, promotionDetails: 1, widthUnit: 1, description: 1, colorVariation: 1, price: 1, isPromotion: 1, inventoryCode: 1, isStockTrack: 1,
                stockQuantity: 1, soldQuantity: 1,
                rating: { $arrayElemAt: ["$beauticianDetails.rating", 0] },
                noOfReviews: { $arrayElemAt: ["$beauticianDetails.noOfReviews", 0] }
            }
        }
        // { $project: { nubOfCartClicked: 0, nubOfShareClicked: 0, nubOfView: 0, isDelete: 0, createdAt: 0, updatedAt: 0, __v: 0, detailStep: 0 } },
    ]);

    const produtData = await BeauticianProduct.findOne({ _id: productPId, isDelete: 0 });

    if (produtData) {
        produtData.numOfViews += 1;
        produtData.save();
    }

    if (productDetail) {
        productDetail.map((val) => {
            val.isFavProduct = false;
            val.promoPrice = null;
            if (clientData.favProducts.includes(val._id)) {
                val.isFavProduct = true;
            }
            if (val.promotionDetails) {
                if (val.promotionDetails.startDate < new Date() && val.promotionDetails.endDate > new Date()) {
                    val.promoPrice = val.promotionDetails.proPrice;
                }
            }
            return val.isFavProduct, val.promoPrice;
        });

        const productId = clientData.recentProducts.includes(productPId);
        if (!productId) {
            clientData.recentProducts.unshift(productPId);
            await clientData.save();
        }
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: productDetail, message: "Product details" });
    }
    throw new ErrorHandler("Data not found.", HttpStatus.BAD_REQUEST);
});

// get beautician product details
const getBeauticianProducts = catchAsyncError(async (req, res, next) => {
    const Id = req.user;
    const { beauticianId } = req.params;

    if (!mongoose.Types.ObjectId.isValid(beauticianId)) {
        throw new ErrorHandler("Please Enter Valid Beautician Id", HttpStatus.NOT_FOUND, false);
    }

    const beauticianData = await Beautician.findOne({ _id: beauticianId });

    if (beauticianData) {
        const productData = await BeauticianProduct.aggregate([
            { $match: { beauticianId: new mongoose.Types.ObjectId(beauticianId) } },
            {
                $lookup: {
                    from: 'beauticians',
                    localField: 'beauticianId',
                    foreignField: "_id",
                    as: 'beauticianDetails',
                    pipeline: [
                        { $project: { businessName: 1 } }
                    ],
                },
            },
            {
                $lookup: {
                    from: 'productcategorylists',
                    localField: 'productCategory',
                    foreignField: "_id",
                    as: 'categoryDetails',
                    pipeline: [
                        { $project: { productCategoryName: 1, productCategoryName_fr: 1 } }
                    ],
                },
            },
            {
                $project: {
                    productName: 1,
                    businessName: { $arrayElemAt: ['$beauticianDetails.businessName', 0] },
                    categoryName: { $arrayElemAt: ['$categoryDetails.productCategoryName', 0] },
                    categoryName_fr: { $arrayElemAt: ['$categoryDetails.productCategoryName_fr', 0] },
                    imgName: 1,
                }
            }
        ]);
        if (productData.length) {
            const clientData = await Client.findOne({ userId: Id });
            productData.map((val) => {
                val.isFavProduct = false;
                val.promoPrice = null;
                if (clientData.favProducts.includes(val._id)) {
                    val.isFavProduct = true;
                }

                if (val.promotionDetails) {
                    if (val.promotionDetails.startDate < new Date() && val.promotionDetails.endDate > new Date()) {
                        val.promoPrice = val.promotionDetails.proPrice;
                    }
                }
                return val.isFavProduct, val.promoPrice;
            });
        }
        const count = productData.length;
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, count, productData });
    } else {
        throw new ErrorHandler("Beautician details not found", HttpStatus.NOT_FOUND, false);
    }
});

// get recently viewd product list 
const getRecentViewdProdcts = catchAsyncError(async (req, res, next) => {
    const Id = req.user;
    const clientData = await Client.findOne({ userId: Id });
    const productData = await BeauticianProduct.aggregate([
        { $match: { _id: { $in: clientData.recentProducts }, isDelete: 0 } },
        {
            $lookup: {
                from: 'beauticians',
                localField: 'beauticianId',
                foreignField: "_id",
                as: 'beauticianDetails',
                pipeline: [
                    {
                        $project: {
                            rating: {
                                $ifNull: ["$rating", 0]
                            },
                        }
                    }
                ]
            },
        },
        {
            $project: {
                imgName: 1, price: 1, productName: 1,
                rating: { $arrayElemAt: ["$beauticianDetails.rating", 0] },
                promotionDetails: {
                    $ifNull: ["$promotionDetails", null]
                },
            }
        }
    ]);
    if (productData.length) {
        productData.map((val) => {
            val.promoPrice = null;
            if (val.promotionDetails) {
                if (val.promotionDetails.startDate < new Date() && val.promotionDetails.endDate > new Date()) {
                    val.promoPrice = val.promotionDetails.proPrice;
                }
            }
            return val.promoPrice;
        });
    }

    const count = productData.length;

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { count, productData } });
});

// for add product in cart or edit cart details
const addToCartProduct = catchAsyncError(async (req, res, next) => {
    //work pending for this API for different validation and logics
    const Id = req.user;
    const { productId, variations, quantity } = req.body;
    const qty = parseInt(quantity);

    if (!mongoose.Types.ObjectId.isValid(productId)) {
        throw new ErrorHandler("Please enter valid product Id.", HttpStatus.BAD_REQUEST);
    }

    const clientData = await Client.findOne({ userId: Id });
    const productData = await BeauticianProduct.findOne({ _id: productId }).select("beauticianId colorVariation price isStockTrack stockQuantity nubOfCartClicked");
    if (!productData) {
        throw new ErrorHandler("Please enter valid productId", HttpStatus.BAD_REQUEST);
    }
    let tempVariations = [];
    if (productData.colorVariation.length) {
        tempVariations = variations
    }
    const isClientEqualBeautician = await Beautician.findOne({ _id: productData.beauticianId, userId: clientData.userId });

    if (isClientEqualBeautician) {
        throw new ErrorHandler(req.t("ownShopProduct"), HttpStatus.BAD_REQUEST, false);
    }


    const cartData = await Cart.findOne({ productId, clientId: clientData._id, status: 0 });
    const beauticianProductData = await Cart.findOne({ clientId: clientData._id, beauticianId: { $ne: productData.beauticianId }, status: 0 })

    if (beauticianProductData) {
        throw new ErrorHandler(req.t("addToCartError"), HttpStatus.BAD_REQUEST);
    }

    // This part is for remove cart data
    if (cartData) {
        if (productData.colorVariation.length) {
            throw new ErrorHandler("Please Enter variation.", HttpStatus.BAD_REQUEST);
        }
        if (cartData?.variations?.length) {
            // if (variations?.length) {
            let totalQuantity = 0;
            variations.forEach(item => {
                if (productData?.colorVariation.length) {
                    if (!productData?.colorVariation?.includes(item.variationType)) {
                        throw new ErrorHandler("This variations is not matched with prodct variantions.", HttpStatus.BAD_REQUEST);
                    }
                }
                totalQuantity += parseInt(item.variationQuantity);
            });
            if (quantity != totalQuantity) {
                throw new ErrorHandler("Please Check total Quantity is not matched with variant quantity", HttpStatus.BAD_REQUEST);
            }
            cartData.variations = variations;
            cartData.totalQuantity = quantity;
            cartData.subTotal = cartData.totalQuantity * productData.price;
            // } else {
            //     await Cart.findOneAndDelete({ _id: cartData._id });
            //     return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("removeCart") });
            // }
        } else {
            if (qty) {
                if (qty !== cartData.totalQuantity) {
                    cartData.totalQuantity = qty;
                    cartData.subTotal = productData.price * cartData.totalQuantity;
                }
                if (qty === "") {
                    await Cart.findOneAndDelete({ _id: cartData._id });
                    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("removeCart") });
                }
            } else {
                throw new ErrorHandler("Please Enter Quantity", HttpStatus.BAD_REQUEST);
            }
        }
        await cartData.save();
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("quantityChanged") });
    }
    // This part is add product details into cart (for first time)
    else {
        if (productData.colorVariation?.length && !tempVariations) {
            throw new ErrorHandler("Please select variation.", HttpStatus.BAD_REQUEST);
        }
        let totalQuantity = 0;
        if (productData.colorVariation.length) {
            if (tempVariations.length) {
                tempVariations.forEach(item => {
                    if (productData.colorVariation.length) {
                        if (!productData.colorVariation.includes(item.variationType)) {
                            throw new ErrorHandler("This variations is not matched with prodct variantions.", HttpStatus.BAD_REQUEST);
                        }
                    }
                    totalQuantity += parseInt(item.variationQuantity);
                });
            } else {
                throw new ErrorHandler("Please Enter variation details", HttpStatus.BAD_REQUEST);
            }
        } else {
            if (!qty) {
                throw new ErrorHandler("Please Enter Quantity", HttpStatus.BAD_REQUEST);
            }
            totalQuantity = qty
        }

        if (qty != totalQuantity) {
            throw new ErrorHandler("Please Check total Quantity is not matched with variant quantity", HttpStatus.BAD_REQUEST);
        }

        const subTotal = productData.price * totalQuantity;

        const addCart = await Cart.create({
            clientId: clientData._id,
            productId: productId,
            beauticianId: productData.beauticianId,
            variations: tempVariations,
            // quantity: 1,
            subTotal,
            originalPrice: productData.price,
            // subQuantity: {
            //     variant,
            //     quantity
            // },
            totalQuantity
        });

        if (addCart) {
            productData.nubOfCartClicked += 1;
            await productData.save();
        }
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("addToCartProductSuccess") });
    }
});

// for remove product from cart
const removeCart = catchAsyncError(async (req, res, next) => {
    const { cartId, variationType } = req.body;
    if (!variationType) {
        throw new ErrorHandler("Please enter variationType", HttpStatus.BAD_REQUEST);
    }
    const cartData = await Cart.findOne({ _id: cartId });
    if (cartData) {
        if (cartData.variations.length) {
            cartData.variations = cartData.variations.filter(val => val.variationType !== variationType);
            let totalQuantity = 0;
            cartData.variations.forEach((ele) => {
                totalQuantity += ele.variationQuantity;
            })
            cartData.totalQuantity = totalQuantity;
            cartData.subTotal = cartData.originalPrice * cartData.totalQuantity;
            if (cartData.totalQuantity <= 0) {
                await Cart.findByIdAndDelete({ _id: cartId });
            } else {
                await cartData.save();
            }
        }
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("removeCartSuccess") });
    } else {
        throw new ErrorHandler("Cart details not found", HttpStatus.BAD_REQUEST);
    }
});

const changeCartQuanity = catchAsyncError(async (req, res, next) => {
    const { cartId, variationType, type } = req.body;

    const cartData = await Cart.findOne({ _id: cartId, status: 0 });
    if (cartData) {
        if (cartData.variations.length) {
            // if (cartData.variations.includes(variationType)) {
            if (!variationType) {
                throw new ErrorHandler("Please enter variationType", HttpStatus.BAD_REQUEST);
            }
            cartData.variations.map((val) => {
                if (val.variationType === variationType) {
                    if (type == "inc") {
                        val.variationQuantity += 1;
                    }
                    else if (type == "dec") {
                        val.variationQuantity -= 1;
                        if (val.variationQuantity <= 0) {
                            cartData.variations = cartData.variations.filter(val => val.variationType !== variationType);
                        }
                    } else {
                        throw new ErrorHandler("Please enter inc or dec", HttpStatus.BAD_REQUEST);
                    }
                }
            });

            let totalQuantity = 0;
            cartData.variations.forEach((ele) => {
                totalQuantity += ele.variationQuantity;
            })
            cartData.totalQuantity = totalQuantity;
            cartData.subTotal = cartData.originalPrice * cartData.totalQuantity;
            if (cartData.totalQuantity <= 0) {
                await Cart.findByIdAndDelete({ _id: cartId });
            } else {
                await cartData.save();
            }
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("changeCartQuanitySuccess") });
            // } else {
            //     throw new ErrorHandler("This color variant is not available in cart", HttpStatus.BAD_REQUEST);
            // }
        } else {
            if (type == "inc") {
                cartData.totalQuantity += 1;
            }
            else if (type == "dec") {
                cartData.totalQuantity -= 1;
                if (cartData.totalQuantity <= 0) {
                    cartData.variations = cartData.variations.filter(val => val.variationType !== variationType);
                }
            } else {
                throw new ErrorHandler("Please enter inc or dec", HttpStatus.BAD_REQUEST);
            }
            cartData.subTotal = cartData.originalPrice * cartData.totalQuantity;
            if (cartData.totalQuantity <= 0) {
                await Cart.findByIdAndDelete({ _id: cartId });
            } else {
                await cartData.save();
            }
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("changeCartQuanitySuccess") });
        }
    } else {
        throw new ErrorHandler("Cart details not found", HttpStatus.BAD_REQUEST);
    }
});

// for get cart Details
const getCartData = catchAsyncError(async (req, res, next) => {
    const Id = req.user;

    const clientData = await Client.findOne({ userId: Id });
    if (clientData) {
        const cartData = await Cart.aggregate([
            { $match: { clientId: new mongoose.Types.ObjectId(clientData._id), status: 0 } },
            {
                $lookup: {
                    from: 'beauticianproducts',
                    localField: 'productId',
                    foreignField: "_id",
                    as: 'productDetails',
                    pipeline: [
                        {
                            $project: {
                                imgName: 1, description: 1, colorVariation: 1, beauticianId: 1, productName: 1, price: 1,
                                promotionDetails: {
                                    $ifNull: ["$promotionDetails", null]
                                },
                            }
                        }
                    ]
                },
            },
            {
                $lookup: {
                    from: 'beauticians',
                    localField: 'productDetails.beauticianId',
                    foreignField: "_id",
                    as: 'beauticianDetails',
                    pipeline: [
                        { $project: { firstName: 1, lastName: 1, businessName: 1, } }
                    ]
                },
            },
            { $sort: { createdAt: -1 } },
            {
                $project: {
                    _id: 1,
                    variations: 1,
                    totalQuantity: 1,
                    subTotal: 1,
                    images: { $arrayElemAt: ['$productDetails.imgName', 0] },
                    description: { $arrayElemAt: ['$productDetails.description', 0] },
                    productId: { $arrayElemAt: ['$productDetails._id', 0] },
                    productPrice: { $arrayElemAt: ['$productDetails.price', 0] },
                    productName: { $arrayElemAt: ['$productDetails.productName', 0] },
                    promotionDetails: { $arrayElemAt: ['$productDetails.promotionDetails', 0] },
                    beauticianFirstName: { $arrayElemAt: ['$beauticianDetails.firstName', 0] },
                    beauticianLastName: { $arrayElemAt: ['$beauticianDetails.lastName', 0] },
                    businessName: { $arrayElemAt: ['$beauticianDetails.businessName', 0] },
                    beauticianId: { $arrayElemAt: ['$beauticianDetails._id', 0] },
                }
            },
            // { $project: { clientId: 1, productId: 1, variations: 1, totalQuantity: 1, subTotal: 1, productDetails: 1, beauticianDetails: 1 } }
        ]);



        if (cartData.length) {
            cartData.map((val) => {
                val.promoPrice = 0;
                if (val.promotionDetails !== null) {
                    if (val.promotionDetails.startDate < new Date() && val.promotionDetails.endDate > new Date()) {
                        val.promoPrice = val.promotionDetails.proPrice * val.totalQuantity;
                    }
                }
                return val.proPrice;
            });
        }
        const count = cartData.length;

        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { count, cartData } });
    } else {
        throw new ErrorHandler(req.t("clientNotFound"), HttpStatus.BAD_REQUEST);
    }
});

// add share click count
const addShareClickCount = catchAsyncError(async (req, res, next) => {
    const { prodId } = req.params;
    if (!mongoose.Types.ObjectId.isValid(prodId)) {
        throw new ErrorHandler("Invalid product Id", HttpStatus.BAD_REQUEST);
    }
    const productData = await BeauticianProduct.findById(prodId);
    if (productData) {
        productData.nubOfShareClicked = productData.nubOfShareClicked + 1;
        await productData.save();
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Click event store" });
    } else {
        throw new ErrorHandler("Invalid product Id", HttpStatus.BAD_REQUEST);
    }

});

// for get order review
const getOrderReview = catchAsyncError(async (req, res, next) => {
    const Id = req.user;
    let tempdiscount = 0;
    const { cartIds, orderType, shippingAddressId } = req.body;

    if (!mongoose.Types.ObjectId.isValid(shippingAddressId)) {
        throw new ErrorHandler("Invalid shipping address Id", HttpStatus.BAD_REQUEST);
    }

    // if (orderType !== "delivery" && orderType !== "pickup") {
    //     throw new ErrorHandler("Please enter valid order type", HttpStatus.BAD_REQUEST);
    // }

    const alreadyAddOrder = await Cart.find({ _id: { $in: cartIds }, status: 1 });
    if (alreadyAddOrder.length) {
        throw new ErrorHandler("You already pay for this products", HttpStatus.BAD_REQUEST, false);
    }

    if (cartIds && shippingAddressId) {
        const clientDetails = await Client.aggregate([
            { $match: { userId: new mongoose.Types.ObjectId(Id) } },
            { $unwind: "$address" },
            { $match: { "address.addressId": new mongoose.Types.ObjectId(shippingAddressId) } },
            {
                $lookup: {
                    from: "addresses",
                    localField: "address.addressId",
                    foreignField: "_id",
                    as: "addressData"
                }
            },
            {
                $lookup: {
                    from: "cards",
                    localField: "_id",
                    foreignField: "clientId",
                    as: "cardData",
                    pipeline: [
                        { $match: { isPrimary: 1 } },
                        { $sort: { createdAt: -1 } },
                        { $project: { cardName: 1, cardLastFour: 1, cardBrand: 1, expiryMonth: 1, expiryYear: 1, cardToken: 1 } },
                    ],
                }
            }
        ]);
        if (clientDetails && clientDetails[0]?.addressData) {
            const cartId = cartIds.map(id => new mongoose.Types.ObjectId(id));
            const productData = await Cart.aggregate([
                {
                    $match: {
                        _id: { $in: cartId },
                        clientId: clientDetails[0]._id,
                        // status: 0
                    },
                },
                {
                    $lookup: {
                        from: "beauticianproducts",
                        localField: "productId",
                        foreignField: "_id",
                        as: "productDetails",
                        pipeline: [
                            {
                                $project: {
                                    productName: 1, price: 1, productId: 1, promotionDetails: {
                                        $ifNull: ["$promotionDetails", null]
                                    },
                                }
                            }
                        ]
                    },
                },
                {
                    $project: {
                        _id: 1,
                        totalQuantity: 1,
                        subTotal: 1,
                        beauticianId: 1,
                        ProductName: { $arrayElemAt: ['$productDetails.productName', 0] },
                        productId: { $arrayElemAt: ['$productDetails._id', 0] },
                        originalPrice: { $arrayElemAt: ['$productDetails.price', 0] },
                        promotionDetails: { $arrayElemAt: ['$productDetails.promotionDetails', 0] },
                    }
                },
                // { $project: { totalQuantity: 1, productDetails: 1, subTotal: 1 } }
            ]);
            if (productData.length) {
                productData.map((val) => {

                    val.price = val.subTotal;
                    val.discount = 0;
                    if (val.promotionDetails) {
                        if (val.promotionDetails.startDate < new Date() && val.promotionDetails.endDate > new Date()) {
                            val.discount = val.totalQuantity * (val.originalPrice - val.promotionDetails.proPrice);
                            tempdiscount += val.totalQuantity * (val.originalPrice - val.promotionDetails.proPrice);
                            val.price = val.originalPrice * val.totalQuantity - val.discount;
                        }
                    }
                })
            }
            const shippingAddress = await Address.aggregate([
                {
                    $match: {
                        _id: new mongoose.Types.ObjectId(shippingAddressId),
                    },
                },
                {
                    $project: {
                        address: 1, street: 1, apartment: 1, zipCode: { $ifNull: ["$zipcode", null] }
                    }
                },
            ]);

            if (productData && productData.length > 0) {
                const getTaxValues = await Province.findById(clientDetails[0].addressData[0].province);
                if (getTaxValues) {
                    let GST = 0, PST = 0, HST = 0, QST = 0;
                    getTaxValues.subType.map(ele => {
                        if (ele.taxName === "GST") GST = GST + ele.tax;
                        if (ele.taxName === "HST") HST = ele.tax + HST;
                        if (ele.taxName === "QST") QST = ele.tax + QST;
                        if (ele.taxName === "PST") PST = ele.tax + PST;
                    });
                    let tempSubTotal = 0;
                    let tempDiscount = 0;
                    productData.forEach((val) => {
                        tempSubTotal += val.price;
                    });

                    const total = tempSubTotal + tempSubTotal * (GST / 100) + tempSubTotal * (HST / 100) + tempSubTotal * (QST / 100) + tempSubTotal * (PST / 100) - tempDiscount;

                    const responseData = {
                        productData: productData,
                        cardDetails: clientDetails[0].cardData,
                        shippingAddress: shippingAddress,
                        subTotal: tempSubTotal,
                        GST: (tempSubTotal * (GST / 100)).toFixed(2),
                        HST: (tempSubTotal * (HST / 100)).toFixed(2),
                        QST: (tempSubTotal * (QST / 100)).toFixed(2),
                        PST: (tempSubTotal * (PST / 100)).toFixed(2),
                        discount: tempdiscount,
                        GstInPer: GST,
                        HstInPer: HST,
                        PstInPer: PST,
                        QstInPer: QST,
                        orderType: orderType,
                        total: total.toFixed(2),
                    }
                    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, responseData, });
                } else {
                    throw new ErrorHandler("Province details not found", HttpStatus.BAD_REQUEST);
                }
            } else {
                throw new ErrorHandler("Cart details not found", HttpStatus.BAD_REQUEST);
            }
        } else {
            throw new ErrorHandler("AddressId is not found.", HttpStatus.BAD_REQUEST);
        }
    } else {
        throw new ErrorHandler("cartId or shippingAddressId or billingAddressId is missing", HttpStatus.BAD_REQUEST);
    }
});

// add product into checkout
const addOrderToPlace = catchAsyncError(async (req, res, next) => {
    const Id = req.user;

    // const { appointmentIds, cardName, cardNumber, cardMonth, cardYear, cardCVC, cardToken, subTotal, discount, GstInPer, HstInPer, PstInPer, QstInPer, total, addressId } = req.body;
    const { productData, cardName, cardNumber, cardMonth, cardYear, cardCVC, cardToken, subTotal, discount, total, GstInPer, PstInPer, HstInPer, QstInPer, shippingAddressId, billingAddressId, orderType } = req.body;

    const errors = validationResult(req);
    if (errors.errors.length !== 0) {
        throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST, false);
    };

    if (!productData) {
        throw new ErrorHandler("Products missing", HttpStatus.BAD_REQUEST, false);
    }

    if (!productData.length) {
        throw new ErrorHandler("Product Details is missing", HttpStatus.BAD_REQUEST, false);
    }

    if (!mongoose.Types.ObjectId.isValid(shippingAddressId)) {
        throw new ErrorHandler("Invalid shipping address Id", HttpStatus.BAD_REQUEST);
    }

    if (!mongoose.Types.ObjectId.isValid(billingAddressId)) {
        throw new ErrorHandler("Invalid billing address Id", HttpStatus.BAD_REQUEST);
    }

    const cartIds = [];
    const isValidIDs = productData.map(val => {
        if (!mongoose.Types.ObjectId.isValid(val.productId)) return false;

        if (!mongoose.Types.ObjectId.isValid(val.beauticianId)) return false;

        if (!val.price) return false;

        if (!val.totalQuantity) return false;

        if (val.cartId) {
            cartIds.push(val.cartId)
        }
    });

    const alreadyAddOrder = await Cart.find({ _id: { $in: cartIds }, status: 1 });
    if (alreadyAddOrder.length) {
        throw new ErrorHandler("You already pay for this products", HttpStatus.BAD_REQUEST, false);
    }

    if (isValidIDs.includes(false)) {
        throw new ErrorHandler("Something is missing or pass wrong id's in product Data", HttpStatus.BAD_REQUEST, false);
    }

    const userDetails = await User.findOne({ _id: Id });
    const clientDetails = await Client.aggregate([
        { $match: { userId: new mongoose.Types.ObjectId(Id) } },
        { $unwind: "$address" },
        { $match: { "address.addressId": new mongoose.Types.ObjectId(shippingAddressId) } },
        {
            $lookup: {
                from: "addresses",
                localField: "address.addressId",
                foreignField: "_id",
                as: "addressData"
            }
        },
    ]);

    if (clientDetails && clientDetails[0]?.addressData) {

        const isValidbillingAddress = await Address.findOne({ _id: billingAddressId });
        if (!isValidbillingAddress) {
            throw new ErrorHandler("Please Enter valid billing address Id", HttpStatus.BAD_REQUEST);
        }

        // const clientDetails = await Client.findOne({ userId: Id });

        if (!clientDetails[0]?.customerId) {
            let clientInfo = clientDetails[0];
            const CreateCustomerStripe = await createStripeCustomer({ email: clientInfo.userData[0].email, name: clientInfo.firstName + clientInfo.lastName, phone: clientInfo.userData[0].phoneNumber });

            if (CreateCustomerStripe.status === 200 && CreateCustomerStripe.result) {
                customerId = CreateCustomerStripe?.result.id;
                const userInfo = await Client.findById(clientDetails[0]._id)
                userInfo.customerId = customerId;
                await userInfo.save();
            } else {
                throw new ErrorHandler(CreateCustomerStripe.message, HttpStatus.BAD_REQUEST, false);
            }
        }

        // This is for check customer Id is exists or not and if not then create it.
        const CreateCustomerStripe = await createStripeCustomer({ email: userDetails.email, name: clientDetails[0].firstName + clientDetails[0].lastName, phone: userDetails.phoneNumber });

        if (CreateCustomerStripe.status === 200 && CreateCustomerStripe.result) {
            customerId = CreateCustomerStripe?.result.id;
            const userInfo = await Client.findById(clientDetails[0]._id)
            userInfo.customerId = customerId;
            await userInfo.save();
        } else {
            throw new ErrorHandler(CreateCustomerStripe.message, HttpStatus.BAD_REQUEST, false);
        }

        // This is for check card token is exists or not and if not founded then generate it
        if (cardToken) {
            paymentMethodID = cardToken;
            const oldCard = await Cards.findOne({ clientId: clientDetails[0]._id, cardToken });
            if (oldCard) {
                cardId = oldCard._id
            }
        } else if (cardNumber && cardMonth && cardYear && cardCVC) {
            userCard = await createStripeCard({
                cardNumber,
                cardMonth,
                cardYear,
                cardCVC,
            });
            if (userCard && userCard.status === 200) {
                paymentMethodID = userCard.result.id;
                //attach customerId with payment method Id
                const isAttach = await attachCustomerID({ paymentMethodID, customerId })
                if (isAttach && isAttach.status === 200) {
                    isNewCard = true;
                } else {
                    throw new ErrorHandler(isAttach.message, HttpStatus.BAD_REQUEST, false);
                }
            } else {
                throw new ErrorHandler(userCard.message, HttpStatus.BAD_REQUEST, false);
            }
        } else {
            throw new ErrorHandler(req.t("cardTokenMissing"));
        }

        if (paymentMethodID) {

            if (isNewCard) {
                let newCard = await Cards.create({
                    clientId: clientDetails[0]._id,
                    cardName,
                    cardBrand: userCard.result.card.networks.available[0],
                    cardLastFour: userCard.result.card.last4,
                    expiryMonth: userCard.result.card.exp_month,
                    expiryYear: userCard.result.card.exp_year,
                    cardToken: userCard.result.id
                });
                cardId = newCard._id;
            }

            const orderID = '#' + generateNumericId(7);
            const platformCut = parseFloat(subTotal) * parseFloat(platform_fees)
            const application_fees = platformCut + platformCut * (GstInPer / 100) + platformCut * (HstInPer / 100) + platformCut * (PstInPer / 100) + platformCut * (QstInPer / 100);

            const beauticianData = await Beautician.findOne({ _id: productData[0].beauticianId })
            //             const createShipmentUrl = 'https://soa-gw.canadapost.ca/rs/ship/shipment';

            //             const shipmentDataXml = `
            // <shipment xmlns="http://www.canadapost.ca/ws/shipment">
            //   <requestedShippingPoint>H2B1A0</requestedShippingPoint>
            //   <destPostalCode>K1A0B1</destPostalCode>
            //   <parcelCharacteristics>
            //     <weight>1.0</weight>
            //   </parcelCharacteristics>
            //   <services>
            //     <service>
            //       <name>DOM.EP</name>
            //     </service>
            //   </services>
            // </shipment>
            // `;

            //             const xmlBuilder = new xml2js.Builder({ headless: true });
            //             const shipmentXmlString = xmlBuilder.buildObject(shipmentDataXml);
            //             await axios.post(createShipmentUrl, shipmentXmlString, {
            //                 headers: {
            //                     'Authorization': `Bearer ${apiKey}`,
            //                     'Content-Type': 'application/vnd.cpc.shipment-v8+xml',
            //                     'Accept': 'application/vnd.cpc.shipment-v8+xml',
            //                 },
            //             })
            //                 .then(response => {
            //                     console.log('Shipment created successfully:');
            //                     console.log(response.data);
            //                 })
            //                 .catch(error => {
            //                     console.log("🚀 ~ file: productCController.js:1286 ~ addOrderToPlace ~ error:", error)
            //                     // console.error('Error creating shipment:', error.response ? error.response.data : error.message);
            //                 });

            const paymentInfo = await makePayment({
                paymentMethodId: paymentMethodID,
                customerId,
                amount: Math.round(total * 100),
                application_fees: 0,
                // application_fees: Math.round(application_fees * 100),
                currency: 'CAD',
                orderID,
                beauticianAccId: beauticianData.stripe_id,
            });
            if (paymentInfo.status === 200 && cardId) {
                const newPayment = await Order.create({
                    orderID: orderID,
                    clientId: clientDetails[0]._id,
                    productData,
                    cardId,
                    transactionId: paymentInfo.transactionId,
                    shippingAddressId,
                    billingAddressId,
                    subTotal,
                    GST: (subTotal * (GstInPer / 100)).toFixed(2),
                    PST: (subTotal * (PstInPer / 100)).toFixed(2),
                    QST: (subTotal * (QstInPer / 100)).toFixed(2),
                    HST: (subTotal * (HstInPer / 100)).toFixed(2),
                    orderType,
                    GstInPer,
                    HstInPer,
                    PstInPer,
                    QstInPer,
                    discount,
                    TotalPrice: total,
                    paymentStatus: 1
                });
                if (newPayment) {
                    let cartIds = [];
                    productData.map((val) => {
                        return cartIds.push(val.cartId)
                    });

                    const productIds = [];
                    if (cartIds.length) {
                        await Cart.updateMany({ _id: cartIds }, { status: 1 });
                        if (productData.length) {
                            await Promise.all(productData.map(async (val) => {
                                productIds.push(new mongoose.Types.ObjectId(val.productId));
                                const productDetails = await BeauticianProduct.findOne({ _id: val.productId });
                                if (productDetails) {
                                    const qty = productDetails.soldQuantity + val.totalQuantity;
                                    productDetails.soldQuantity = qty;
                                    await productDetails.save();
                                }
                            }));
                        }
                    }
                    const notificationData = await BeauticianProduct.aggregate([
                        { $match: { _id: { $in: productIds } } }
                    ]);
                    const notifications = [];
                    let clientDeviceIds = [];
                    const clientDeviceData = await FcmNotification.find({ memberId: clientDetails._id }).select('firebaseToken');
                    if (clientDeviceData && clientDeviceData.length > 0) {
                        clientDeviceData.forEach(ele => {
                            if (ele.firebaseToken !== null) {
                                clientDeviceIds.push(ele.firebaseToken);
                            }
                        });
                    }
                    if (notificationData.length) {
                        notificationData.forEach((val) => {
                            if (clientDeviceIds.length) {
                                let message = notificationMSGs.productOrderConfirmClientCtx({ productName: val.productName, date: val.date, time: ele.time });
                                const notificationPromise = fcmNotification({ messageCtx: message, deviceIds: clientDeviceIds });
                                notifications.push(notificationPromise);
                            }
                        });
                    }
                    try {
                        await Promise.all(notifications);
                    } catch (err) {
                        console.log('Something has gone wrong!', err);
                    }
                    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("addOrderToPlaceSuccess"), });
                }
            } else {
                throw new ErrorHandler(paymentInfo.errorMessage, HttpStatus.BAD_REQUEST);
            }
        } else {
            throw new ErrorHandler(req.t("cardTokenMissing"), HttpStatus.BAD_REQUEST);
        }
    } else {
        throw new ErrorHandler("Address details not found", HttpStatus.BAD_REQUEST);
    }

});

// get my order 
const getMyOrders = catchAsyncError(async (req, res, next) => {
    const Id = req.user;
    const { type } = req.user;
    if (type === "pending") {

    } else if (type === "delivered") {

    } else if (type === "cancelled") {

    }

    const clientDetails = await Client.findOne({ userId: Id });
    if (clientDetails) {
        const data = await Order.aggregate([
            { $match: { clientId: clientDetails._id } },
            {
                $lookup: {
                    from: 'beauticianproducts',
                    localField: 'productData.productId',
                    foreignField: "_id",
                    as: 'productDetails',
                },
            },
            {
                $lookup: {
                    from: 'beauticians',
                    localField: 'productData.beauticianId',
                    foreignField: "_id",
                    as: 'beauticianDetails',
                    pipeline: [
                        { $project: { businessName: 1 } }
                    ]
                },
            },
            { $sort: { createdAt: -1 } },
            {
                $project: {
                    productName: { $arrayElemAt: ["$productDetails.productName", 0] },
                    productPrice: { $arrayElemAt: ["$productData.price", 0] },
                    productImages: { $arrayElemAt: ["$productDetails.imgName", 0] },
                    vendorName: { $arrayElemAt: ["$beauticianDetails.businessName", 0] },
                }
            }
        ]);
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data });
    } else {
        throw new ErrorHandler("Client details not found", HttpStatus.BAD_REQUEST);
    }
});

// get client address and 
const getClientAddress = catchAsyncError(async (req, res, next) => {
    const Id = req.user;

    const clientDetails = await Client.aggregate([
        { $match: { userId: new mongoose.Types.ObjectId(Id) } },
        {
            $lookup: {
                from: 'addresses',
                localField: 'address.addressId',
                foreignField: "_id",
                as: 'addressdata',
                pipeline: [
                    {
                        $project: {
                            address: { $ifNull: ["$address", null] },
                            apartment: { $ifNull: ["$apartment", null] },
                            city: { $ifNull: ["$city", null] },
                            street: { $ifNull: ["$street", null] },
                            zipCode: { $ifNull: ["$zipCode", null] },
                        }
                    }
                ],
            },
        },
        {
            $project: {
                firstName: 1,
                lastName: 1,
                addressId: { $arrayElemAt: ["$address.addressId", 0] },
                address: { $arrayElemAt: ["$addressdata.address", 0] },
                street: { $arrayElemAt: ["$addressdata.street", 0] },
                apartment: { $arrayElemAt: ["$addressdata.apartment", 0] },
                zipCode: { $arrayElemAt: ["$addressdata.zipCode", 0] },
            },
        }
    ]);
    if (clientDetails) {
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, clientDetails })
    } else {
        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Client details not found" })
    }
});

// for Update shipping address 
const updateShippingInfo = catchAsyncError(async (req, res, next) => {
    const Id = req.user;

    const { firstName, lastName, province, phoneNumber, zipCode, deliveryAddress, apartment } = req.body;
    const errors = validationResult(req);
    if (errors.errors.length !== 0) {
        throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST, false);
    };
    if (!mongoose.Types.ObjectId.isValid(province)) throw new ErrorHandler("Please enter valid province Id", HttpStatus.BAD_REQUEST, false);

    const provinceData = await Province.findOne({ _id: province });
    if (!provinceData) throw new ErrorHandler("Province deatils not found", HttpStatus.BAD_REQUEST, false);

    const userData = await User.findOne({ _id: Id });
    userData.phoneNumber = phoneNumber;
    await userData.save();

    const clientDeatils = await Client.findOne({ userId: Id });
    clientDeatils.firstName = firstName;
    clientDeatils.lastName = lastName;
    await clientDeatils.save();

    const addressData = await Address.findOne({ _id: clientDeatils.address[0].addressId });
    addressData.zipCode = zipCode;
    addressData.address = deliveryAddress;
    addressData.apartment = apartment;
    addressData.province = province;
    await addressData.save();

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("updateShippingInfoSuccess") });
});

// for verify Pickup details
const verifyPickupDetails = catchAsyncError(async (req, res, next) => {
    const { beauticianId, dateTime, firstName, email, phoneNumber } = req.body;
    const timeToCheck = moment(dateTime, 'DD MMM YYYY HH:mm');
    if (!mongoose.Types.ObjectId.isValid(beauticianId)) {
        throw new ErrorHandler("Please enter valid beauticianId", HttpStatus.BAD_REQUEST, false);
    }
    const errors = validationResult(req);
    if (errors.errors.length !== 0) {
        throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST, false);
    };

    const workHours = await BeauticianWorkHour.findOne({ beauticianId: beauticianId });

    if (workHours) {
        let isShopOpen = workHours.dayDetails.filter(ele => {
            return ele.day === timeToCheck.format('dddd') && ele.isOpen
        });
        const isShopCalender = workHours.calenderSetting?.filter(val => { // check work hour detail according to calender settings
            return moment(val.date).format('YYYY-MM-DD') === timeToCheck.format('YYYY-MM-DD')
        });

        if (isShopCalender?.[0]?.isOpen) {
            isShopOpen = isShopCalender;
        } else if (isShopCalender.length > 0 && !isShopCalender?.[0]?.isOpen) {
            throw new ErrorHandler(req.t("shopIsNotOpen"), HttpStatus.BAD_REQUEST, false)
        }

        if (isShopOpen.length > 0) {
            const startTime = moment(isShopOpen[0].startTime, 'HH:mm').format('HH:mm');
            if (isShopOpen[0].endTime === "24:00") {
                isShopOpen[0].endTime = "23:59"
            }
            const endTime = moment(isShopOpen[0].endTime, 'HH:mm').format('HH:mm');
            const breakStartTime = moment(isShopOpen[0].breakStartTime, 'HH:mm').format('HH:mm');
            const breakEndTime = moment(isShopOpen[0].breakEndTime, 'HH:mm').format('HH:mm')
            let timeToCheckTime = timeToCheck.format('HH:mm')

            if (timeToCheckTime >= startTime && timeToCheckTime <= endTime && !(timeToCheckTime >= breakStartTime && timeToCheckTime <= breakEndTime)) {
                return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: `Client can pickup order in this time` });
            } else {
                throw new ErrorHandler(req.t("beauticianTime"), HttpStatus.BAD_REQUEST, false)
            }
        } else {
            throw new ErrorHandler(req.t("shopIsNotOpen"), HttpStatus.BAD_REQUEST, false)
        }
    } else {
        throw new ErrorHandler(req.t("workHourNotFound"), HttpStatus.BAD_REQUEST);
    }
});
module.exports = { getproductCategoryList, getFilterProduct, findProductOrVendor, addProductInFavorites, removeProductInFavorites, getRecentProductSearch, getFavoriteProductList, getRecomadedProducts, getSingleProductDetail, getBeauticianProducts, getRecentViewdProdcts, addToCartProduct, removeCart, changeCartQuanity, addShareClickCount, getCartData, getOrderReview, addOrderToPlace, getMyOrders, getClientAddress, updateShippingInfo, verifyPickupDetails }