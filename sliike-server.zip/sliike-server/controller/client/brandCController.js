const catchAsyncError = require("../../middleware/catchAsyncError");
const HttpStatus = require("../../utils/HttpStatus");
const ErrorHandler = require("../../utils/ErrorHandling");
const Client = require("../../models/Client")
const Brand = require("../../models/Brand")
const ServiceCategory = require("../../models/ServiceCategoryList")
const mongoose = require("mongoose");
const BrandProducts = require("../../models/BrandProducts");
const BrandCategory = require("../../models/BrandCategory");
const Beautician = require("../../models/Beautician");
const currentDate = new Date()

// for add brand in favorites
const addToMyFavorites = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { brandId } = req.body;

    if (!mongoose.Types.ObjectId.isValid(brandId)) throw new ErrorHandler("Please Enter Valid Brand Id", HttpStatus.BAD_REQUEST, false);

    if (brandId) {
        const clientDetails = await Client.findOne({ userId: id });

        // check brand is exits or not 
        const isExitsBrand = await Brand.findOne({ _id: brandId, isDeleted: 0 })
        if (!isExitsBrand) {
            throw new ErrorHandler("Brand is not found", HttpStatus.BAD_REQUEST, false)
        }

        if (clientDetails.favBrands.includes(brandId)) {
            throw new ErrorHandler("Brand is already added into favorites", HttpStatus.BAD_REQUEST, false)
        } else {
            clientDetails.favBrands.unshift(brandId);
            await clientDetails.save();
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("addToMyFavoritesBrandsSuccess") });
        }
    } else {
        throw new ErrorHandler("brandId is missing", HttpStatus.BAD_REQUEST, false)
    }
});

// for remove brand from favorites
const removeBrandFromFavorites = catchAsyncError(async (req, res, next) => {
    const Id = req.user;
    const { brandId } = req.body;
    if (!mongoose.Types.ObjectId.isValid(brandId)) throw new ErrorHandler("Please enter valid brand Id", HttpStatus.BAD_REQUEST, false);

    const isBrand = await Brand.findOne({ _id: brandId, isDeleted: 0 });

    if (isBrand) {
        const userData = await Client.findOne({ userId: Id });

        if (!userData.favBrands.includes(isBrand._id)) {
            throw new ErrorHandler("Brand already removed from favorites", HttpStatus.BAD_REQUEST, false);
        }

        userData.favBrands.pull(isBrand._id);
        await userData.save();

        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("removeBrandFromFavoritesSuccess") });
    } else {
        throw new ErrorHandler("Brand details not found", HttpStatus.BAD_REQUEST, false);
    }
});

// get fav brand list
const getFavBrandList = catchAsyncError(async (req, res, next) => {
    const Id = req.user
    let myFavBrand = []

    const clientData = await Client.findOne({ userId: Id })
    if (clientData) {
        const BrandIds = await clientData.favBrands.map((val) => { return new mongoose.Types.ObjectId(val) })
        if (BrandIds?.length > 0) {
            myFavBrand = await Brand.aggregate([
                {
                    $match: { _id: { $in: BrandIds }, endDate: { $gte: currentDate }, isDeleted: 0 }
                },
                {
                    $lookup: {
                        from: 'brandcategorylists',
                        localField: 'brandCategoryId',
                        foreignField: '_id',
                        as: 'categoryData',
                        pipeline: [
                            { $project: { brandCategoryName: 1, brandCategoryName_fr: 1, } }
                        ]
                    }
                },
                {
                    $project: {
                        _id: 1,
                        brandName: 1,
                        brandCategory: { $arrayElemAt: ['$categoryData.brandCategoryName', 0] },
                        brandCategory_fr: { $arrayElemAt: ['$categoryData.brandCategoryName_fr', 0] },
                        brandBanner: {
                            $ifNull: ["$brandBanner", null]
                        }
                    }
                }
            ])
        }
        const count = myFavBrand.length
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, count, myFavBrand, message: "Fav Brand details load successfully" })
    } else {
        throw new ErrorHandler(req.t("clientNotFound"), HttpStatus.BAD_REQUEST, false)
    }
});

const findBrandsProducts = catchAsyncError(async (req, res, next) => {
    const Id = req.user;
    const ClientData = await Client.findOne({ userId: Id });
    const { search } = req.body;
    let brandQuery = {
    };

    if (search) {
        brandQuery = {
            ...brandQuery,
            productName: { $regex: search, $options: 'i' }
        }
    }

    const brandData = await BrandProducts.aggregate([
        { $match: brandQuery },
        {
            $lookup: {
                from: 'brands',
                localField: 'brandId',
                foreignField: '_id',
                as: 'brandData',
                pipeline: [
                    { $match: { step: 3, isDeleted: 0 } },
                    { $project: { brandName: 1, brandLogo: 1 } }
                ]
            }
        },
        { $match: { brandData: { $gt: [] } } },
        { $project: { productName: 1, brandData: 1 } },
    ]);

    let productList = []
    let brandList = []
    if (brandData.length) {
        brandData.forEach(ele => {
            productList.push({ _id: ele._id, productName: ele.productName });
            ele.brandData?.forEach(vendor => {
                brandList.push(vendor)
            })
        })
    }
    if (brandList.length) {
        brandList = brandList.filter((item, index, self) => {
            return index === self.findIndex(obj => obj._id.equals(item._id));
        });
    }

    if (brandList.length) {
        if (!ClientData.brandSearchText.includes(search)) {
            ClientData.brandSearchText.unshift(search);
        }
    }

    await ClientData.save();

    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data: { productList, brandList } });
});

/*
 * get brand list by filter
 *here we are able to search by brand name and filter by category wise
 */
const getFilterBrand = catchAsyncError(async (req, res, next) => {
    const Id = req.user
    let { categoryIds, productIds } = req.body

    let ClientData = await Client.findOne({ userId: Id });

    if (categoryIds?.length > 0) {
        for (const ele of categoryIds) {
            if (!mongoose.Types.ObjectId.isValid(ele)) {
                throw new ErrorHandler("Please pass valid service IDs.", HttpStatus.BAD_REQUEST, false);
            } else {
                const isCategoryExists = await BrandCategory.findOne({ _id: ele });
                if (!isCategoryExists) {
                    throw new ErrorHandler("Brand category Id dose not exits", HttpStatus.BAD_REQUEST, false);
                }
            }
        }
    }

    let query = { step: 3, isDeleted: 0, endDate: { $gte: currentDate } }
    if (categoryIds?.length > 0) {
        query = { ...query, brandCategoryId: { $in: categoryIds.map(id => new mongoose.Types.ObjectId(id)) } }
    }
    if (productIds) {
        if (productIds.length) {
            query = { ...query, brandProductId: { $in: productIds.map(id => new mongoose.Types.ObjectId(id)) } }
        }
    }
    const data = await Brand.aggregate([
        { $match: query },
        {
            $lookup: {
                from: 'brandcategorylists',
                localField: 'brandCategoryId',
                foreignField: "_id",
                as: 'brandCategoryId',
                pipeline: [
                    { $project: { brandCategoryName: 1, brandCategoryName_fr: 1, } }
                ]
            }
        },
        { $unwind: "$brandCategoryId" },
        {
            $project: {
                _id: 1,
                brandName: 1,
                brandCategoryId: 1,
                brandBanner: {
                    $ifNull: ["$brandBanner", null]
                },
            }
        }
    ])
    // check brand is fav or not
    if (data) {
        data?.map(val => {
            val.isFavBrand = false;
            if (ClientData.favBrands.includes(val._id)) {
                val.isFavBrand = true
            }
            return val.isFavBrand
        })
    }
    const count = data.length
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, count, data, message: "Details load successfully" })
})

/*Recent search brands*/
const getRecentSearchBrand = catchAsyncError(async (req, res, next) => {
    const Id = req.user
    let ClientData = await Client.findOne({ userId: Id });

    if (ClientData) {
        resData = []
        let getBrand = ClientData?.brandSearchText.map(async (search) => {
            return new Promise(async (resolve, reject) => {
                const newBrandList = await Brand.aggregate([
                    {
                        $match: {
                            step: 3,
                            isDeleted: 0,
                            endDate: { $gte: currentDate }
                        }
                    },
                    {
                        $lookup: {
                            from: 'brandproducts',
                            localField: 'brandProductId',
                            foreignField: "_id",
                            as: 'proData',
                            pipeline: [
                                { $match: { productName: { $regex: search, $options: 'i' } } }
                            ]
                        },
                    },
                    {
                        $lookup: {
                            from: 'brandcategorylists',
                            localField: 'brandCategoryId',
                            foreignField: "_id",
                            as: 'categoryData',
                            pipeline: [
                                { $project: { brandCategoryName: 1, brandCategoryName_fr: 1, } }
                            ]
                        },
                    },
                    { $match: { proData: { $gt: [] } } },
                    {
                        $project: {
                            _id: 1,
                            brandName: 1,
                            brandCategory: { $arrayElemAt: ["$categoryData.brandCategoryName", 0] },
                            brandCategory_fr: { $arrayElemAt: ["$categoryData.brandCategoryName_fr", 0] },
                            brandBanner: {
                                $ifNull: ["$brandBanner", null]
                            }
                        }
                    }
                ])
                resData = [...resData, ...newBrandList]
                resolve(resData)
            })
        })
        await Promise.all(getBrand);
    }
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, resData, message: "Details load successfully" })
})

/*Get single brand details*/
const getSingleBrandDetails = catchAsyncError(async (req, res, next) => {
    const Id = req.user
    const brandId = req.params.brandId
    const clientData = await Client.findOne({ userId: Id })

    if (!mongoose.Types.ObjectId.isValid(brandId)) {
        throw new ErrorHandler("Please Enter Valid Brand Id", HttpStatus.BAD_REQUEST, false);
    }

    let brandDetails = await Brand.aggregate([
        { $match: { _id: new mongoose.Types.ObjectId(brandId), isDeleted: 0, endDate: { $gte: currentDate } } },
        {
            $lookup: {
                from: 'brandcategorylists',
                localField: 'brandCategoryId',
                foreignField: "_id",
                as: 'brandCategory',
            },
        },
        {
            $lookup: {
                from: 'brandproducts',
                localField: '_id',
                foreignField: "brandId",
                as: 'productDetails',
                pipeline: [
                    { $project: { productImageName: 1, productName: 1, productPrice: 1 } }
                ],
            },
        },
        {
            $project: {
                _id: 1,
                brandName: 1,
                brandBanner: 1,
                brandCategory: {
                    $arrayElemAt: ['$brandCategory.brandCategoryName', 0]
                },
                brandCategory_fr: {
                    $arrayElemAt: ['$brandCategory.brandCategoryName_fr', 0]
                },
                productDetails: 1,
            }
        }
    ])

    if (brandDetails.length > 0) {
        brandDetails.map((brand => {
            brand.isFavBrand = false;
            if (clientData.favBrands.includes(brand._id)) {
                brand.isFavBrand = true;
            }
            return brand.isFavBrand
        }));

        const brandData = await Brand.findOne({ _id: brandId });
        if (brandData) {
            brandData.numOfViews += 1;
            await brandData.save()
        }
    } else {
        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Brand not found" })
    }
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, brandDetails, message: "Brand details" });
});

// Get Single Product
const getSingleBrandProduct = catchAsyncError(async (req, res, next) => {
    const Id = req.user;
    const { productId } = req.params;

    if (!mongoose.Types.ObjectId.isValid(productId)) {
        throw new ErrorHandler("Please Enter Valid Product Id", HttpStatus.BAD_REQUEST, false);
    }
    const clientDetails = await Client.findOne({ userId: Id });

    // for get single product details
    let productData = await BrandProducts.findOne({ _id: productId })
        .populate({ path: 'brandId', select: 'brandLogo websiteUrl' })
        .select("uid productName productPrice productUnit productSize keyFeatures description productImageName weightUnit weightValue").lean();

    productData.isFavBrandProd = false;
    if (clientDetails.favBrandProds.includes(productId)) {
        productData.isFavBrandProd = true;
    }

    // for get may like products
    const allProducts = await Brand.aggregate([
        {
            $match: { brandProductId: new mongoose.Types.ObjectId(productId) }
        },
        {
            $lookup: {
                from: 'brandproducts',
                localField: 'brandProductId',
                foreignField: "_id",
                as: 'productDetails',
                pipeline: [
                    { $project: { productName: 1, productImageName: 1 } }
                ]
            }
        },
        { $project: { productDetails: 1, } },
    ]);
    if (productData) {
        // if (allProducts) {
        return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: false, productData, mayLikeProducts: allProducts[0]?.productDetails })
        // }
    } else {
        return res.status(HttpStatus.BAD_REQUEST).json({ status: HttpStatus.BAD_REQUEST, success: false, message: "Product details not found" })
    }
});

// get all Category brands
const getAllCategoryBrands = catchAsyncError(async (req, res, next) => {
    const data = await BrandCategory.aggregate([
        {
            $lookup: {
                from: 'brands',
                localField: '_id',
                foreignField: "brandCategoryId",
                as: 'brandData',
                pipeline: [
                    { $project: { brandName: 1, brandLogo: 1, brandBanner: 1 } }
                ],
            },
        },
        { $project: { brandCategoryName: 1, brandData: 1 } }
    ]);
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, data })
});

// add brandProduct in fav
const addToFavoritesBrandProducts = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const { productId } = req.body;

    if (!mongoose.Types.ObjectId.isValid(productId)) throw new ErrorHandler("Please Enter Valid Brand Id", HttpStatus.BAD_REQUEST, false);

    if (productId) {
        const clientDetails = await Client.findOne({ userId: id });

        // check brand is exits or not 
        const isExitsBrand = await BrandProducts.findOne({ _id: productId, isDeleted: 0 })
        if (!isExitsBrand) {
            throw new ErrorHandler("Brand Product is not found", HttpStatus.BAD_REQUEST, false)
        }

        if (clientDetails.favBrandProds.includes(productId)) {
            throw new ErrorHandler("Brand product is already added into favorites", HttpStatus.BAD_REQUEST, false)
        } else {
            clientDetails.favBrandProds.unshift(productId);
            await clientDetails.save();
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: req.t("addToFavoritesBrandProductsSuccess") });
        }
    } else {
        throw new ErrorHandler("productId is missing", HttpStatus.BAD_REQUEST, false)
    }
});

// store number of buy clicks and share clicks
const storeClicks = catchAsyncError(async (req, res, next) => {
    const id = req.user
    const { type, brandId, userType } = req.body;

    if (!mongoose.Types.ObjectId.isValid(brandId)) {
        throw new ErrorHandler("Please enter valid Id", HttpStatus.BAD_REQUEST, false)
    }

    const brandData = await Brand.findOne({ _id: brandId });

    if (brandData) {
        if (type === "shareClick") {
            brandData.shareClick += 1;
            await brandData.save();
            return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "data store successfully" });
        } else if (type === "buyClick") {
            if (userType === "clients") {
                const clientData = await Client.findOne({ userId: id });
                if (clientData) {
                    if (!brandData.buyerId.includes(clientData._id)) {
                        brandData.buyerId.unshift(clientData._id);
                        brandData.buyer_type.unshift("clients");
                        await brandData.save();
                    }
                    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "data store successfully" });
                } else {
                    throw new ErrorHandler("Client details not found", HttpStatus.BAD_REQUEST, false)
                }
            } else if (userType === "beauticians") {
                const beauticianData = await Beautician.findOne({ userId: id });
                if (beauticianData) {
                    if (!brandData.buyerId.includes(beauticianData._id)) {
                        brandData.buyerId.unshift(beauticianData._id);
                        brandData.buyer_type.unshift("beauticians");
                        await brandData.save();
                    }
                    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "data store successfully" });
                } else {
                    throw new ErrorHandler("Beautician details not found", HttpStatus.BAD_REQUEST, false)
                }
            } else {
                throw new ErrorHandler("Please enter valid user type", HttpStatus.BAD_REQUEST, false)
            }
        } else {
            throw new ErrorHandler("Please enter valid type", HttpStatus.BAD_REQUEST, false)
        }
    } else {
        throw new ErrorHandler("Brand details not found", HttpStatus.BAD_REQUEST, false)
    }
});

module.exports = {
    addToMyFavorites,
    removeBrandFromFavorites,
    getFavBrandList,
    findBrandsProducts,
    getFilterBrand,
    getRecentSearchBrand,
    getSingleBrandDetails,
    getSingleBrandProduct,
    getAllCategoryBrands,
    addToFavoritesBrandProducts,
    storeClicks
}