const { body, param } = require("express-validator");
const ErrorHandler = require("../utils/ErrorHandling");
const HttpStatus = require("../utils/HttpStatus");
const { default: mongoose } = require("mongoose");
const moment = require("moment");
const BeauticianService = require("../models/BeauticianService");

const regiserValidation = [
    body("firstName").not().isEmpty().trim().withMessage("First Name is required.."),
    body("lastName").not().isEmpty().trim().withMessage("Last Name is required.."),
    body("email").not().isEmpty().trim().withMessage("Email is required."),
    body("password").not().isEmpty().trim().withMessage("Password is required."),
    body("country").not().isEmpty().trim().withMessage("Country is required."),
    body("phoneNumber").not().isEmpty().trim().withMessage("Phone Number is required."),
    body("country_code").not().isEmpty().trim().withMessage("Country Code is required."),
];

const socialLoginValidation = [
    body("firstName").not().isEmpty().trim().withMessage("First Name is required.."),
    body("lastName").not().isEmpty().trim().withMessage("Last Name is required.."),
    body("email").not().isEmpty().trim().withMessage("Email is required."),
    body("country").not().isEmpty().trim().withMessage("Country is required."),
    body("phoneNumber").not().isEmpty().trim().withMessage("Phone Number is required."),
    body("country_code").not().isEmpty().trim().withMessage("Country Code is required."),
    body("signUpType").not().isEmpty().trim().withMessage("Please select signup type."),
];

const adminSignupValidation = [
    body("email").not().isEmpty().trim().withMessage("Please Enter Email id."),
    body("password").not().isEmpty().trim().withMessage("Please Enter Password."),
    body("firstName").not().isEmpty().trim().withMessage("Please Enter First name."),
    body("lastName").not().isEmpty().trim().withMessage("Please Enter Last name."),
    body("phoneNumber").not().isEmpty().trim().withMessage("Phone Number is required.")
];

const SingInValidation = [
    body("email").not().isEmpty().trim().withMessage("Please Enter Email id."),
    body("password").not().isEmpty().trim().withMessage("Please Enter Password."),
    // body("deviceToken").not().isEmpty().trim().withMessage("Please provide deviceToken."),
    // query("role").not().isEmpty().trim().withMessage("Role is required."),
];

// const businessValidation = [
//     body("businessName").not().isEmpty().trim().withMessage("Business Name is required."),
//     body("businessNumber").not().isEmpty().trim().withMessage("Phone Number is required."),
//     body("address").not().isEmpty().trim().withMessage("Address is required."),
//     body("province").not().isEmpty().trim().withMessage("Province is required."),
//     body("street_address").not().isEmpty().trim().withMessage("Street Address is required."),
//     // body("apartment").not().isEmpty().trim().withMessage("Apartment Name is required."),
//     body("city").not().isEmpty().trim().withMessage("City is required."),
//     body("post_code").not().isEmpty().trim().withMessage("Post Code is required."),
// ]
const businessValidation = [
    body("businessName").not().isEmpty().trim().withMessage("businessNameValidation"),
    body("businessNumber").not().isEmpty().trim().withMessage("businessNumberValidation"),
    body("address").not().isEmpty().trim().withMessage("addressValidation"),
    body("province").not().isEmpty().trim().withMessage("provinceValidation"),
    body("street_address").not().isEmpty().trim().withMessage("street_addressValidation"),
    // body("apartment").not().isEmpty().trim().withMessage("Apartment Name is required."),
    body("city").not().isEmpty().trim().withMessage("cityValidation"),
    body("post_code").not().isEmpty().trim().withMessage("post_codeValidation"),
]

const serviceTypeValidation = [
    body("serviceTypeName").not().isEmpty().trim().withMessage("Service Type Name is required."),
    body("serviceId").not().isEmpty().trim().withMessage("serviceId is required."),
]

const appointmentValidation = [
    body("serviceId").not().isEmpty().trim().withMessage("Service Details is required."),
    body("dateTime").not().isEmpty().trim().withMessage("Service Date and time is required."),
    body("price").not().isEmpty().trim().withMessage("Price is required for Appointment."),
    body("place").not().isEmpty().trim().withMessage("Place is required for Appointment."),
    body("serviceDuration").not().isEmpty().trim().withMessage("serviceDuration is required for Appointment."),
]

const invitationValidation = [
    body("firstName").not().isEmpty().trim().withMessage("Please enter first name."),
    body("lastName").not().isEmpty().trim().withMessage("Please enter last name."),
    body("email").not().isEmpty().trim().withMessage("Please enter Email."),
    body("phoneNumber").not().isEmpty().trim().withMessage("Please enter phone number"),
    body("country").not().isEmpty().trim().withMessage("Please enter country"),
    body("country_code").not().isEmpty().trim().withMessage("Please enter country code"),
]

const termsValidation = [
    body("terms").not().isEmpty().trim().withMessage("Please enter Terms."),
    body("policy").not().isEmpty().trim().withMessage("Please enter Policy."),
    body("language").not().isEmpty().trim().withMessage("Please selcet language."),
]
const paymentControllerValidation = [
    body("subTotal").not().isEmpty().trim().withMessage("SubTotal is missing."),
    body("discount").not().isEmpty().trim().withMessage("discount is missing."),
    body("GstInPer").not().isEmpty().trim().withMessage("GstInPer is missing."),
    body("HstInPer").not().isEmpty().trim().withMessage("HstInPer is missing."),
    body("PstInPer").not().isEmpty().trim().withMessage("PstInPer is missing."),
    body("QstInPer").not().isEmpty().trim().withMessage("QstInPer is missing."),
    body("total").not().isEmpty().trim().withMessage("total is missing."),
    body("addressId").not().isEmpty().trim().withMessage("addressId is missing."),
]
const calenderAdjustmentValidation = [
    body("day").not().isEmpty().trim().custom((value) => {
        const validDays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
        if (!validDays.includes(value)) {
            throw new ErrorHandler("Invalid day.", HttpStatus.BAD_REQUEST, false);
        }
        return true;
    }),
    body("date").not().isEmpty().trim().withMessage("date is missing."),
    body("isOpen").not().isEmpty().isBoolean().withMessage("isOpen is missing."),
    (req, res, next) => {
        const { isOpen, startTime, endTime, breakStartTime, breakEndTime } = req.body;
        if (isOpen && (!startTime || !endTime)) {
            return res.status(400).json({ message: "Missing values for startTime ,endTime." });
        }
        if (isOpen && breakStartTime && !breakEndTime) {
            return res.status(400).json({ message: "Missing values for breakEndTime." });
        }
        next();
    }
];
const cardDetailValidation = [
    body("cardHolderName").not().isEmpty().trim().withMessage("cardHolderName is missing."),
    body("cardNumber").not().isEmpty().trim().withMessage("cardNumber is missing."),
    body("cardMonth").not().isEmpty().trim().isNumeric().withMessage("cardMonth is missing."),
    body("cardYear").not().isEmpty().trim().isNumeric().withMessage("cardYear is missing."),
    body("cardCVC").not().isEmpty().trim().isNumeric().withMessage("cardCVC is missing."),
];

const addPromotionValidation = [
    body("promotionFor").not().isEmpty().trim().custom((value) => {
        const validDays = ["product", "service"];
        if (!validDays.includes(value)) {
            throw new ErrorHandler("invalidFor", HttpStatus.BAD_REQUEST, false);
        }
        return true;
    }),
    body("promotionTitle").not().isEmpty().trim().withMessage("titleMissing"),
    body("subTypeId").not().isEmpty().custom((value) => {
        if (!mongoose.Types.ObjectId.isValid(value)) {
            throw new ErrorHandler("Invalid subTypeId.", HttpStatus.BAD_REQUEST, false);
        }
        return true;
    }),
    body("serviceName").not().isEmpty().trim().withMessage("serviceNameMissing"),
    body("isDiscPercentage").not().isEmpty().isBoolean().withMessage("isDiscPercentage is missing."),
    body("discount").not().isEmpty().trim().isNumeric().withMessage("discountMissing"),
    body("startDate").not().isEmpty().trim().withMessage("startDateMissing"),
    body("endDate").not().isEmpty().trim().withMessage("endDateMissing"),
    (req, res, next) => {
        const { startDate, endDate, isDiscPercentage, discount } = req.body;
        if (isDiscPercentage && discount > 100) {
            throw new ErrorHandler('notvalidDiscount', HttpStatus.BAD_REQUEST, false);
        }
        if (!(startDate && endDate)) {
            throw new ErrorHandler('Date range value missing.', HttpStatus.BAD_REQUEST, false);
        }
        if (moment(startDate, "YYYY-MM-DD", true).format("YYYY-MM-DD") !== startDate || moment(endDate, "YYYY-MM-DD", true).format("YYYY-MM-DD") !== endDate) {
            throw new ErrorHandler("Invalid date formate.", HttpStatus.BAD_REQUEST, false);
        }
        next();
    }
]

//for InviteCustomer API
const validateClientList = [
    body("contactDetails").not().isEmpty().withMessage("contactDetailsMissing")
    // body('contactDetails').custom((contactDetails) => {
    //     const validationPromises = contactDetails.map((contact) => {
    //         return new Promise((resolve, reject) => {
    //             if (!/^\d{10}$/.test(contact.phoneNumber)) {
    //                 reject(new Error('Phone number should be 10 digits.'));
    //             } else {
    //                 resolve();
    //             }
    //         });
    //     });

    //     return Promise.all(validationPromises);
    // }),
];

//for AddProduct
const productAddValidator = [
    body("productId").not().isEmpty().custom((value) => {
        if (!mongoose.Types.ObjectId.isValid(value)) {
            throw new ErrorHandler("Invalid productId.", HttpStatus.BAD_REQUEST, false);
        }
        return true;
    }),
    body("productCategory").not().isEmpty().custom((value) => {
        if (!mongoose.Types.ObjectId.isValid(value)) {
            throw new ErrorHandler("Invalid productCategory.", HttpStatus.BAD_REQUEST, false);
        }
        return true;
    }),
    body("productName").not().isEmpty().trim().withMessage("productName is missing."),
    body("wtValue").not().isEmpty().trim().withMessage("wtValue is missing."),
    body("wtUnit").not().isEmpty().trim().withMessage("wtUnit is missing."),
    body("htValue").not().isEmpty().trim().withMessage("htValue is missing."),
    body("htUnit").not().isEmpty().trim().withMessage("htUnit is missing."),
    body("lengthValue").not().isEmpty().trim().withMessage("lengthValue is missing."),
    body("lengthUnit").not().isEmpty().trim().withMessage("lengthUnit is missing."),
    body("widthValue").not().isEmpty().trim().withMessage("widthValue is missing."),
    body("widthUnit").not().isEmpty().trim().withMessage("widthUnit is missing."),
    body("description").not().isEmpty().trim().withMessage("description is missing."),
    body("price").not().isEmpty().trim().withMessage("price is missing."),
    body("inventoryCode").not().isEmpty().trim().withMessage("inventoryCode is missing."),
    body("isPromotion").not().isEmpty().isBoolean().withMessage("isPromotion is missing."),
    body("isStockTrack").not().isEmpty().isBoolean().withMessage("isStockTrack is missing."),
    (req, res, next) => {
        const { isPromotion, proPrice, discount, startDate, endDate, stockQuantity, isStockTrack } = req.body;
        if (isStockTrack && !stockQuantity) {
            throw new ErrorHandler("Missing values for stockQuantity.", 400, false);
        }
        if (isPromotion && (!proPrice || !discount || !startDate || !endDate)) {
            throw new ErrorHandler("Missing values for proPrice, discount, startDate or endDate.", 400, false);
        }
        if (moment(startDate, "YYYY-MM-DD", true).format("YYYY-MM-DD") !== startDate || moment(endDate, "YYYY-MM-DD", true).format("YYYY-MM-DD") !== endDate) {
            throw new ErrorHandler("Invalid date formate.", HttpStatus.BAD_REQUEST, false);
        }
        next();
    }
];
const productPIdValidator = [
    param("productPId").not().isEmpty().custom((value) => {
        if (!mongoose.Types.ObjectId.isValid(value)) {
            throw new ErrorHandler("Invalid productId.", HttpStatus.BAD_REQUEST, false);
        }
        return true;
    })
];
const productEditValidator = [
    (req, res, next) => {
        const { isPromotion, proPrice, discount, startDate, endDate } = req.body;
        if (isPromotion && (!proPrice || !discount || !startDate || !endDate)) {
            throw new ErrorHandler("Missing values for proPrice, discount, startDate or endDate.", 400, false);
        }
        if (moment(startDate, "YYYY-MM-DD", true).format("YYYY-MM-DD") !== startDate || moment(endDate, "YYYY-MM-DD", true).format("YYYY-MM-DD") !== endDate) {
            throw new ErrorHandler("Invalid date formate.", HttpStatus.BAD_REQUEST, false);
        }
        next();
    }
];

const pushNotificationValidator = [
    body("sendTo").not().isEmpty().trim().withMessage("Please select beauticain or client for message."),
    body("title").not().isEmpty().trim().withMessage("Title is required."),
    body("message").not().isEmpty().trim().withMessage("Message is required."),
];

const orderValidation = [
    // body("productData").not().isEmpty().trim().withMessage("Prdouct data missing."),
    body("subTotal").not().isEmpty().trim().withMessage("SubTotal is missing."),
    body("GstInPer").not().isEmpty().trim().withMessage("GstInPer is missing."),
    body("HstInPer").not().isEmpty().trim().withMessage("HstInPer is missing."),
    body("PstInPer").not().isEmpty().trim().withMessage("PstInPer is missing."),
    body("QstInPer").not().isEmpty().trim().withMessage("QstInPer is missing."),
    body("total").not().isEmpty().trim().withMessage("total is missing."),
    body("shippingAddressId").not().isEmpty().trim().withMessage("shipping AddressId is missing."),
    body("billingAddressId").not().isEmpty().trim().withMessage("billing AddressId is missing."),
];

const discountValidation = [
    // body("clientIds").not().isEmpty().trim().withMessage("Client Id is missing."),
    body("promotionTitle").not().isEmpty().trim().withMessage("Promotion Title is missing."),
    body("description").not().isEmpty().trim().withMessage("Description is missing."),
    body("isDiscPercentage").not().isEmpty().trim().withMessage("Is Discount in Percentage is missing."),
    body("discount").not().isEmpty().trim().withMessage("Discount is missing."),
    body("startDate").not().isEmpty().trim().withMessage("Start Date is missing."),
    body("endDate").not().isEmpty().trim().withMessage("End Date is missing."),
    body("discountCode").not().isEmpty().trim().withMessage("discount Code is missing."),
    (req, res, next) => {
        const { startDate, endDate, isDiscPercentage, discount } = req.body;
        // if (isDiscPercentage && discount > 100) {
        //     throw new ErrorHandler('Discount must be less than or equal to 100.', HttpStatus.BAD_REQUEST, false);
        // }
        if (!(startDate && endDate)) {
            throw new ErrorHandler('Date range value missing.', HttpStatus.BAD_REQUEST, false);
        }
        if (moment(startDate, "YYYY-MM-DD", true).format("YYYY-MM-DD") !== startDate || moment(endDate, "YYYY-MM-DD", true).format("YYYY-MM-DD") !== endDate) {
            throw new ErrorHandler("Invalid date formate.", HttpStatus.BAD_REQUEST, false);
        }
        next();
    }
];

const emailMarketingValidation = [
    // body("clientIds").not().isEmpty().trim().withMessage("Please Enter clientIds"),
    body("title").not().isEmpty().trim().withMessage("emailTitleMissing"),
    body("content").not().isEmpty().trim().withMessage("contentMissing"),
];

const brandValidation = [
    'brandName',
    'brandCategoryId',
    'brandOwner',
    'email',
    'phoneNumber',
    'country',
    'address',
    'city',
    'province',
    'postalCode',
    'targetAudience',
    'targetDemographicId',
    'registeredDate',
    'sliikePlan',
    'contractType',
    'startDate',
    'endDate',
    'contractDuration',
    'plateFormFee',
    'discount',
    'discountAmount',
    'HSTOrGST',
    'QSTOrPST',
    'totalFeeCharge',
    'websiteUrl',
    'shippingPolicyUrl',
    'returnPolicyUrl'
];

const brandProductValidation = [
    'productName',
    'productPrice',
    'productSize',
    'description',
    'productImageName',
];

const productValidation = [
    'productName',
    'productCategory',
    'wtUnit',
    'wtValue',
    'htValue',
    'htUnit',
    'lengthValue',
    'widthValue',
    'widthUnit',
    'description',
    'price',
    'inventoryCode',
    'isPromotion',
    'isStockTrack',
];

const shippingValidation = [
    body("firstName").not().isEmpty().trim().withMessage("First Name is missing."),
    body("lastName").not().isEmpty().trim().withMessage("Last Name is missing."),
    body("province").not().isEmpty().trim().withMessage("province is missing."),
    body("phoneNumber").not().isEmpty().trim().withMessage("phone Number is missing."),
    body("zipCode").not().isEmpty().trim().withMessage("zip Code is missing."),
    body("deliveryAddress").not().isEmpty().trim().withMessage("delivery Address is missing."),
    body("apartment").not().isEmpty().trim().withMessage("apartment is missing."),
];

const pickupValidation = [
    body("dateTime").not().isEmpty().trim().withMessage("Date and time is missing"),
    body("firstName").not().isEmpty().trim().withMessage("first Name is missing."),
    body("email").not().isEmpty().trim().withMessage("email is missing."),
    body("phoneNumber").not().isEmpty().trim().withMessage("phone Number is missing."),
];

const clientNotificationValidation = [
    body("appoimentNotifications").not().isEmpty().trim().withMessage("Appoiment notification key is missing"),
    body("productNotifications").not().isEmpty().trim().withMessage("Product notification key is missing"),
    body("emailMarketingNotifications").not().isEmpty().trim().withMessage("Email marketing notification key is missing"),
];

const beauticainNotificationValidation = [
    body("bookingEmailNotification").not().isEmpty().trim().withMessage("booking Email Notification key is missing"),
    body("productSalesNotification").not().isEmpty().trim().withMessage("product Sales Notification key is missing"),
    body("dailyStatsNotification").not().isEmpty().trim().withMessage("daily Stats Notification key is missing"),
    body("reviewNotification").not().isEmpty().trim().withMessage("review Notification key is missing"),
    body("onMyPostNotification").not().isEmpty().trim().withMessage("on MyPost Notification key is missing"),
    body("onCommentNotification").not().isEmpty().trim().withMessage("on Comment Notification key is missing"),
    body("onBrandNotification").not().isEmpty().trim().withMessage("on Brand Notification key is missing"),
];

const myClientNotificationValidation = [
    body("onServicePromoNotification").not().isEmpty().trim().withMessage("on Service Promo Notification key is missing"),
    body("onProductPromoNotification").not().isEmpty().trim().withMessage("on Product Promo Notification key is missing"),
];

const updateBeauticianValidation = [
    body("firstName").not().isEmpty().trim().withMessage("First Name is required.."),
    body("lastName").not().isEmpty().trim().withMessage("Last Name is required.."),
    body("email").not().isEmpty().trim().withMessage("Email is required."),
    body("phoneNumber").not().isEmpty().trim().withMessage("Phone Number is required."),
    body("businessName").not().isEmpty().trim().withMessage("Business name is required."),
    body("businessNumber").not().isEmpty().trim().withMessage("Business number is required."),
    body("coordinates").not().isEmpty().withMessage("Coordinates is required."),
    body("country").not().isEmpty().trim().withMessage("Country is required."),
    body("province").not().isEmpty().custom((value) => {
        if (!mongoose.Types.ObjectId.isValid(value)) {
            throw new ErrorHandler("Invalid province id.", HttpStatus.BAD_REQUEST, false);
        }
        return true;
    }),
    body("address").not().isEmpty().trim().withMessage("Address is required."),
    body("apartment").not().isEmpty().trim().withMessage("Apartment is required."),
    body("city").not().isEmpty().trim().withMessage("City is required."),
    body("pinCode").not().isEmpty().trim().withMessage("Pin code is required."),
];
module.exports = { productValidation, regiserValidation, socialLoginValidation, businessValidation, SingInValidation, serviceTypeValidation, appointmentValidation, invitationValidation, termsValidation, adminSignupValidation, paymentControllerValidation, calenderAdjustmentValidation, cardDetailValidation, addPromotionValidation, validateClientList, productAddValidator, productPIdValidator, productEditValidator, pushNotificationValidator, orderValidation, discountValidation, emailMarketingValidation, brandValidation, brandProductValidation, shippingValidation, pickupValidation, clientNotificationValidation, beauticainNotificationValidation, myClientNotificationValidation, updateBeauticianValidation }
