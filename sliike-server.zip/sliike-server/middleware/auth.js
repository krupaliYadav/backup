const jwt = require("jsonwebtoken");
const ErrorHandler = require("../utils/ErrorHandling");
const catchAsyncError = require("./catchAsyncError");
const User = require("../models/User");
const Admin = require("../models/Admin");

exports.isAunticatedUser = catchAsyncError(async (req, res, next) => {

    const headers = req.headers.authorization;

    if (!headers) {
        throw new ErrorHandler("Please login to access this resource", 401);
    }

    const token = headers.split(" ")[1];

    if (!token) {
        throw new ErrorHandler("Please Enter valid Token", 401);
    }

    const data = jwt.verify(token, process.env.JWT_SEC);

    const user = await User.findById(data._id);

    if (!user) {
        throw new ErrorHandler("Token is expired or Invalid.", 401);
    }
    req.user = data._id;

    next();
});

exports.isAunticatedBeautician = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const user = await User.findById(id);

    if (user.roles.includes("beautician")) {
        if (user.isActiveBeautician === 0) {
            throw new ErrorHandler("Your account is deactivated.", 401);
        }
        next();
    } else {
        throw new ErrorHandler("Please Register your self as Beautician", 401);
    }
})
exports.isAuthenticatedClient = catchAsyncError(async (req, res, next) => {
    const id = req.user;
    const user = await User.findById(id);

    if (user.roles.includes("user")) {
        if (user.isActiveUser === 0) {
            throw new ErrorHandler("Your account is deactivated.", 401);
        }
        next();
    } else {
        throw new ErrorHandler("Please Register your self as User", 401);
    }
})


exports.isAuthorizedRole = catchAsyncError(async (req, res, next) => {
    const headers = req.headers.authorization;

    if (!headers) {
        throw new ErrorHandler("Please login to access this resource", 401);
    }

    const token = headers.split(" ")[1];

    if (!token) {
        throw new ErrorHandler("Please Enter valid Token", 401);
    }

    const data = jwt.verify(token, process.env.JWT_SEC);

    const user = await User.findById(data._id);
    const admin = await Admin.findById(data._id);

    if (user) {
        req.user = data._id;
    } else if (admin) {
        req.user = data._id;
    } else {
        throw new ErrorHandler("Token is expired or Invalid.", 401);
    }
    next();
});

exports.isAuthenticateAdmin = catchAsyncError(async (req, res, next) => {

    const headers = req.headers.authorization;

    if (!headers) {
        throw new ErrorHandler("Please login to access this resource", 401);
    }

    const token = headers.split(" ")[1];

    if (!token) {
        throw new ErrorHandler("Please Enter valid Token", 401);
    }

    const data = jwt.verify(token, process.env.JWT_SEC);
    const admin = await Admin.findById(data._id);

    if (!admin) {
        throw new ErrorHandler("Token is expired or Invalid.", 401);
    }
    req.admin = data._id;
    req.role = admin.role;

    next();
});