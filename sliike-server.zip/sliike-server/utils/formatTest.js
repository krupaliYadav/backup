const checkDurationFormate = (value) => {
    const durationPattern = /^\d{2}:\d{2}$/;
    return durationPattern.test(value)
};

module.exports = { checkDurationFormate }