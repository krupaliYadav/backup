const responseHandler = (statusCode,success,message,data) => {
    return {
      statusCode: statusCode || 200,
    //   hasError: hasError || false,
      success,
      data ,
      message: message || null,
    };
  };
  
  module.exports = responseHandler;