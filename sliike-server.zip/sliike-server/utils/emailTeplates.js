const path = require("path");
const ejs = require("ejs");
const sendEmail = require("./sendEmails");
const Beautician = require("../models/Beautician");
const { EmailImages } = require("./Constant");
const nodeMailer = require("nodemailer");


//Welcome Mail for Beautician
const signupMail = async ({ email, firstName }) => {
    const templatepath = path.join(__dirname, "../public/assets/Templates/Singup.ejs");

    const logo = EmailImages.logo;
    const facebook = EmailImages.facebook;
    const linkdin = EmailImages.linkdin;
    const instra = EmailImages.instra;
    const corporationLogo = EmailImages.corporationLogo;

    const data = await ejs.renderFile(templatepath, { firstName, logo, corporationLogo, facebook, linkdin, instra });
    await sendEmail({
        email,
        subject: `Thank you for Signing-up on Sliike`,
        message: data,
    });
};
//Welcome Mail for Client
const signupMailClient = async ({ email, firstName }) => {
    const templatepath = path.join(__dirname, "../public/assets/Templates/SingUpClient.ejs");

    const logo = EmailImages.logo;
    const facebook = EmailImages.facebook;
    const linkdin = EmailImages.linkdin;
    const instra = EmailImages.instra;
    const corporationLogo = EmailImages.corporationLogo;

    const data = await ejs.renderFile(templatepath, { firstName, logo, corporationLogo, facebook, linkdin, instra });
    await sendEmail({
        email,
        subject: `Thank you for Signing-up on Sliike`,
        message: data,
    });
};

// Send forgot password Email
const forgotPasswordMail = async ({ email, OTP }) => {
    const templatepath = path.join(__dirname, "../public/assets/Templates/ForgotPassword.ejs");

    const logo = EmailImages.logo;
    const facebook = EmailImages.facebook;
    const linkdin = EmailImages.linkdin;
    const instra = EmailImages.instra;
    const corporationLogo = EmailImages.corporationLogo;

    const data = await ejs.renderFile(templatepath, { OTP, logo, corporationLogo, facebook, linkdin, instra });
    await sendEmail({
        email,
        subject: `Forgot Password`,
        message: data,
    });
}

// Verify account
const verifyAuthOtp = async ({ email, otp }) => {
    const templatepath = path.join(__dirname, "../public/assets/Templates/Verification.ejs");

    const logo = EmailImages.logo;
    const facebook = EmailImages.facebook;
    const linkdin = EmailImages.linkdin;
    const instra = EmailImages.instra;
    const corporationLogo = EmailImages.corporationLogo;

    const data = await ejs.renderFile(templatepath, { otp, logo, corporationLogo, facebook, linkdin, instra });
    await sendEmail({
        email,
        subject: `Email Verification`,
        message: data,
    });
}

// Beautician Add New Service successfully.
const addNewService = async ({ email, businessName }) => {
    const templatepath = path.join(__dirname, "../public/assets/Templates/NewService.ejs");

    const logo = EmailImages.logo;
    const facebook = EmailImages.facebook;
    const linkdin = EmailImages.linkdin;
    const instra = EmailImages.instra;
    const corporationLogo = EmailImages.corporationLogo;

    const data = await ejs.renderFile(templatepath, { businessName, logo, corporationLogo, facebook, linkdin, instra });
    await sendEmail({
        email,
        subject: `Added new Service`,
        message: data,
    });
};

// Password Reset Successfully.
const resetSuccessfully = async ({ email }) => {
    const templatepath = path.join(__dirname, "../public/assets/Templates/ResetSuccessfully.ejs");

    const logo = EmailImages.logo;
    const facebook = EmailImages.facebook;
    const linkdin = EmailImages.linkdin;
    const instra = EmailImages.instra;
    const corporationLogo = EmailImages.corporationLogo;

    const data = await ejs.renderFile(templatepath, { logo, corporationLogo, facebook, linkdin, instra });
    await sendEmail({
        email,
        subject: `Password reset successfully`,
        message: data,
    });
};

// send Inavitation mail from the Beautician
const sendInvtaionMail = async ({ name, email, firstName, lastName }) => {
    const templatepath = path.join(__dirname, "../public/assets/Templates/Invitaion.ejs");

    const logo = EmailImages.logo;
    const facebook = EmailImages.facebook;
    const linkdin = EmailImages.linkdin;
    const instra = EmailImages.instra;
    const corporationLogo = EmailImages.corporationLogo

    const data = await ejs.renderFile(templatepath, { name, firstName, lastName, logo, corporationLogo, facebook, linkdin, instra });
    await sendEmail({
        email,
        subject: `Invitation`,
        message: data,
    });
};

// send Inavitation mail from the Beautician
const sendBeauticainInvtaionMail = async ({ email, firstName, lastName }) => {
    const templatepath = path.join(__dirname, "../public/assets/Templates/AdminInvitaion.ejs");

    const logo = EmailImages.logo;
    const facebook = EmailImages.facebook;
    const linkdin = EmailImages.linkdin;
    const instra = EmailImages.instra;
    const corporationLogo = EmailImages.corporationLogo

    const data = await ejs.renderFile(templatepath, { firstName, lastName, logo, corporationLogo, facebook, linkdin, instra });
    await sendEmail({
        email,
        subject: `Invitation`,
        message: data,
    });
};

//send congratulation mail 
const sendCongratulationsMail = async ({ email, firstName }) => {
    const templatepath = path.join(__dirname, "../public/assets/Templates/Congratulations.ejs");

    const logo = EmailImages.logo;
    const facebook = EmailImages.facebook;
    const linkdin = EmailImages.linkdin;
    const instra = EmailImages.instra;
    const corporationLogo = EmailImages.corporationLogo;

    const data = await ejs.renderFile(templatepath, { firstName, logo, corporationLogo, facebook, linkdin, instra });
    await sendEmail({
        email,
        subject: `Congratulations`,
        message: data,
    });
};
// add appointment by beautician mail to beautician(4.1)
const bookingServiceBEmail = async (info) => {
    const templatepath = path.join(__dirname, "../public/assets/Templates/ServiceBookingBtoB4_1.ejs");

    const logo = EmailImages.logo;
    const facebook = EmailImages.facebook;
    const linkdin = EmailImages.linkdin;
    const instra = EmailImages.instra;
    const corporationLogo = EmailImages.corporationLogo;

    let temp = info.phoneNumber.toString();
    temp = temp.replace(/(\d{3})(\d{3})(\d{4})/, "($1)-$2-$3");

    info = { ...info, logo, corporationLogo, facebook, linkdin, instra, phoneNumber: temp }

    const data = await ejs.renderFile(templatepath, info);
    await sendEmail({
        email: info.email,
        subject: `New service booking`,
        message: data,
    });
};
// add appointment by beautician mail to client(4.2)
const bookingServiceCEmail = async (info) => {
    const templatepath = path.join(__dirname, "../public/assets/Templates/ServiceBookingBtoC4_2.ejs");
    //redirect link pending from APP side
    info.redirectLink = ":;javascript";

    const logo = EmailImages.logo;
    const facebook = EmailImages.facebook;
    const linkdin = EmailImages.linkdin;
    const instra = EmailImages.instra;
    const corporationLogo = EmailImages.corporationLogo;
    info = { ...info, logo, corporationLogo, facebook, linkdin, instra }

    const data = await ejs.renderFile(templatepath, info);
    await sendEmail({
        email: info.clientEmail,
        subject: `New service booking`,
        message: data,
    });
};
// reminder appointment by beautician mail to client(4.2)
const ReminderServiceCEmail = async (info) => {
    const templatepath = path.join(__dirname, "../public/assets/Templates/ServiceBookingBtoC4_2.ejs");
    //redirect link pending from APP side
    info.redirectLink = ":;javascript"
    const logo = EmailImages.logo;
    const facebook = EmailImages.facebook;
    const linkdin = EmailImages.linkdin;
    const instra = EmailImages.instra;
    const corporationLogo = EmailImages.corporationLogo
    info = { ...info, logo, corporationLogo, facebook, linkdin, instra }

    const data = await ejs.renderFile(templatepath, info);
    await sendEmail({
        email: info.clientEmail,
        subject: `Appointment Reminder`,
        message: data,
    });
};
// appointment conformation to beautician (4.3a & 4.3b with deposit)
const appConformationBEmail = async (info) => {
    const templatepath = path.join(__dirname, "../public/assets/Templates/AppConfirmB_4_3_AB.ejs");

    let temp = info.phoneNumber.toString();
    temp = temp.replace(/(\d{3})(\d{3})(\d{4})/, "($1)-$2-$3");

    const logo = EmailImages.logo;
    const facebook = EmailImages.facebook;
    const linkdin = EmailImages.linkdin;
    const instra = EmailImages.instra;
    const corporationLogo = EmailImages.corporationLogo;
    info = { ...info, logo, corporationLogo, facebook, linkdin, instra, phoneNumber: temp }

    const data = await ejs.renderFile(templatepath, info);
    await sendEmail({
        email: info.email,
        subject: `Appointment Confirmation`,
        message: data,
    });
};
// appointment conformation to beautician (4.3a & 4.3b with deposit)
const appConformationCEmail = async (info) => {
    const templatepath = path.join(__dirname, "../public/assets/Templates/AppConfirmC_4_4_A.ejs");

    const logo = EmailImages.logo;
    const facebook = EmailImages.facebook;
    const linkdin = EmailImages.linkdin;
    const instra = EmailImages.instra;
    const corporationLogo = EmailImages.corporationLogo;
    info = { ...info, logo, corporationLogo, facebook, linkdin, instra }

    const data = await ejs.renderFile(templatepath, info);
    await sendEmail({
        email: info.clientEmail,
        subject: `Appointment conformation`,
        message: data,
    });
};

// cancel Appointment email to Beautician
const cancelAppEmailB = async (info) => {
    const templatepath = path.join(__dirname, "../public/assets/Templates/AppCancelB.ejs");
    const logo = EmailImages.logo;
    const facebook = EmailImages.facebook;
    const linkdin = EmailImages.linkdin;
    const instra = EmailImages.instra;
    const corporationLogo = EmailImages.corporationLogo

    let temp = info.phoneNumber.toString();
    temp = temp.replace(/(\d{3})(\d{3})(\d{4})/, "($1)-$2-$3");

    const details = {
        businessName: info.businessName,
        firstName: info.firstName,
        lastName: info.lastName,
        phoneNumber: temp,
        day: info.day,
        date: info.date,
        time: info.time,
        address: info.address,
        serviceTypeName: info.serviceTypeName,
        cancelDay: info.cancelDay,
        cancelDate: info.cancelDate,
        cancelTime: info.cancelTime,
        cancelPolicy: info.cancelPolicy,
        logo,
        corporationLogo
        // facebook,linkdin,instra
    }
    const data = await ejs.renderFile(templatepath, details);
    await sendEmail({
        email: info.email,
        subject: `Appointment Cancellation`,
        message: data,
    });
};
// cancel Appointment email to Client
const cancelAppEmailC = async (info) => {
    const templatepath = path.join(__dirname, "../public/assets/Templates/AppCancelC.ejs");
    const logo = EmailImages.logo;
    const corporationLogo = EmailImages.corporationLogo;
    const details = {
        businessName: info.businessName,
        firstName: info.firstName,
        lastName: info.lastName,
        phoneNumber: info.phoneNumber,
        day: info.day,
        date: info.date,
        time: info.time,
        address: info.address,
        serviceTypeName: info.serviceTypeName,
        cancelDay: info.cancelDay,
        cancelDate: info.cancelDate,
        cancelTime: info.cancelTime,
        cancelPolicy: info.cancelPolicy,
        logo, corporationLogo
    }
    const data = await ejs.renderFile(templatepath, details);
    await sendEmail({
        email: info.clientEmail,
        subject: `Appointment Cancellation`,
        message: data,
    });
};

// update Appointmet email to beautician
const updateAppEmailB = async (info) => {
    try {
        const templatepath = path.join(__dirname, "../public/assets/Templates/EditAppointmentB.ejs");
        let temp = info.phoneNumber.toString();
        temp = temp.replace(/(\d{3})(\d{3})(\d{4})/, "($1)-$2-$3");

        const details = {
            businessName: info.businessName,
            firstName: info.firstName,
            lastName: info.lastName,
            phoneNumber: temp,
            day: info.day,
            date: info.date,
            time: info.time,
            address: info.address,
            serviceTypeName: info.serviceTypeName,
            logo: EmailImages.logo,
            corporationLogo: EmailImages.corporationLogo,
        }
        const data = await ejs.renderFile(templatepath, details);
        await sendEmail({
            email: info.email,
            subject: `Appointment Modification`,
            message: data,
        });
    } catch (error) {
    }

};

// Update Appointment email to client
const updateAppEmailC = async (info) => {
    const templatepath = path.join(__dirname, "../public/assets/Templates/EditAppointmentC.ejs");
    const details = {
        businessName: info.businessName,
        firstName: info.firstName,
        lastName: info.lastName,
        phoneNumber: info.phoneNumber,
        day: info.day,
        date: info.date,
        time: info.time,
        address: info.address,
        serviceTypeName: info.serviceTypeName,
        logo: EmailImages.logo,
        corporationLogo: EmailImages.corporationLogo,
    }
    const data = await ejs.renderFile(templatepath, details);
    await sendEmail({
        email: info.clientEmail,
        subject: `Appointment Modification`,
        message: data,
    });
};

// Remainder mail to Beautician for appointment 
const sendReminderB = async (info) => {
    const templatepath = path.join(__dirname, "../public/assets/Templates/ReminderB.ejs");

    const logo = EmailImages.logo;
    const facebook = EmailImages.facebook;
    const linkdin = EmailImages.linkdin;
    const instra = EmailImages.instra;
    const corporationLogo = EmailImages.corporationLogo;
    let temp = info.phoneNumber.toString();
    temp = temp.replace(/(\d{3})(\d{3})(\d{4})/, "($1)-$2-$3");

    info = { ...info, logo, corporationLogo, facebook, linkdin, instra, phoneNumber: temp }

    const data = await ejs.renderFile(templatepath, info);
    await sendEmail({
        email: info.email,
        subject: `Appointment Remainder`,
        message: data,
    });
};

// Remainder mail to Client for appointment
const sendReminderC = async (info) => {
    const templatepath = path.join(__dirname, "../public/assets/Templates/ReminderC.ejs");

    const logo = EmailImages.logo;
    const facebook = EmailImages.facebook;
    const linkdin = EmailImages.linkdin;
    const instra = EmailImages.instra;
    const corporationLogo = EmailImages.corporationLogo;
    info = { ...info, logo, corporationLogo, facebook, linkdin, instra }

    const data = await ejs.renderFile(templatepath, info);
    await sendEmail({
        email: info.clientEmail,
        subject: `Appointment Remainder`,
        message: data,
    });
};

// Service successfully delivered to client
const markAsDelivered = async (info) => {
    const templatepath = path.join(__dirname, "../public/assets/Templates/DeliveredEmailC.ejs");

    info.redirectLink = ":;javascript"
    info.logo = EmailImages.logo;
    info.facebook = EmailImages.facebook;
    info.linkdin = EmailImages.linkdin;
    info.instra = EmailImages.instra;
    info.corporationLogo = EmailImages.corporationLogo;

    const data = await ejs.renderFile(templatepath, info);
    await sendEmail({
        email: info.clientEmail,
        subject: `Mark as Delivered`,
        message: data,
    });
};

// Service No show to client
const noShowC = async (info) => {
    const templatepath = path.join(__dirname, "../public/assets/Templates/NoShowEmailC.ejs");

    info.redirectLink = ":;javascript"
    info.logo = EmailImages.logo;
    info.corporationLogo = EmailImages.corporationLogo;

    const data = await ejs.renderFile(templatepath, info);
    await sendEmail({
        email: info.clientEmail,
        subject: `No Show`,
        message: data,
    });
};

// mail for customer care 
const customerCare = async (info) => {
    try {
        const templatepath = path.join(__dirname, "../public/assets/Templates/CustomerCare.ejs");

        let temp = info.phoneNumber.toString();
        temp = temp.replace(/(\d{3})(\d{3})(\d{4})/, "($1)-$2-$3");

        info.corporationLogo = EmailImages.corporationLogo;
        info.logo = EmailImages.logo;
        info.phoneNumber = temp;

        const data = await ejs.renderFile(templatepath, info);

        const transporter = nodeMailer.createTransport({
            host: process.env.SMTP_SERVICE,
            auth: {
                user: process.env.SMTP_MAIL,
                pass: process.env.SMTP_PASSWORD
            }
        });

        const mailOptions = {
            from: process.env.SMTP_MAIL,
            to: "connect@sliike.com",
            cc: "susan.karimu@sliike.com",
            subject: "Get a call from sliike",
            html: data,
        };

        await transporter.sendMail(mailOptions);
    } catch (error) {
    }
};

// send feed back from beautician and user
const addFeedbackMail = async (info) => {
    try {
        const templatepath = path.join(__dirname, "../public/assets/Templates/FeedBack.ejs");
        let temp = info.phoneNumber.toString();
        temp = temp.replace(/(\d{3})(\d{3})(\d{4})/, "($1)-$2-$3");

        info.logo = EmailImages.logo;
        info.corporationLogo = EmailImages.corporationLogo;
        info.phoneNumber = temp;

        const data = await ejs.renderFile(templatepath, info);

        const transporter = nodeMailer.createTransport({
            host: process.env.SMTP_SERVICE,
            auth: {
                user: process.env.SMTP_MAIL,
                pass: process.env.SMTP_PASSWORD
            }
        });

        const mailOptions = {
            from: process.env.SMTP_MAIL,
            to: "connect@sliike.com",
            cc: "susan.karimu@sliike.com",
            subject: "Feedback",
            html: data,
        };

        await transporter.sendMail(mailOptions);
    } catch (error) {
        return error
    }
};

//file send in email
const shareFileEmail = async (info) => {
    try {
        const transporter = nodeMailer.createTransport({
            host: process.env.SMTP_SERVICE,
            auth: {
                user: process.env.SMTP_MAIL,
                pass: process.env.SMTP_PASSWORD
            }
        });

        const mailOptions = {
            from: process.env.SMTP_MAIL,
            to: info.email,
            subject: info.subject,
            text: info.text,
            attachments: [
                {
                    filename: info.filename,
                    path: info.filePath,
                    contentType: 'application/pdf'
                }
            ]
        };
        const info1 = await transporter.sendMail(mailOptions);
    } catch (error) {
        return error
    }
};

// for Email marketing
const emailMarketingFunc = async (info) => {
    const templatepath = path.join(__dirname, "../public/assets/Templates/EmailMarketing.ejs");

    info.redirectLink = ":;javascript"
    info.logo = EmailImages.logo;
    info.corporationLogo = EmailImages.corporationLogo;

    const data = await ejs.renderFile(templatepath, info);
    await sendEmail({
        email: info.reciptions,
        subject: info.title,
        message: data,
    });
};

// For add products 
const addProductMail = async (info) => {
    const templatepath = path.join(__dirname, "../public/assets/Templates/AddProduct.ejs");

    info.redirectLink = ":;javascript"
    info.logo = EmailImages.logo;
    info.facebook = EmailImages.facebook;
    info.linkdin = EmailImages.linkdin;
    info.instra = EmailImages.instra;
    info.corporationLogo = EmailImages.corporationLogo;

    const data = await ejs.renderFile(templatepath, info);
    await sendEmail({
        email: info.beauticianEmail,
        subject: `New Product Added`,
        message: data,
    });
}


module.exports = { signupMail, signupMailClient, addNewService, forgotPasswordMail, resetSuccessfully, verifyAuthOtp, sendInvtaionMail, sendCongratulationsMail, bookingServiceBEmail, bookingServiceCEmail, appConformationBEmail, appConformationCEmail, ReminderServiceCEmail, cancelAppEmailB, cancelAppEmailC, sendReminderB, updateAppEmailB, updateAppEmailC, sendReminderC, markAsDelivered, noShowC, customerCare, addFeedbackMail, shareFileEmail, emailMarketingFunc, sendBeauticainInvtaionMail, addProductMail }

