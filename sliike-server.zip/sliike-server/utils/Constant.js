const AppId = "com.app.sliike";
const AppStoreId = 6451386099; //com.sliike.apps
const referralAmount = 20;
const pathEndpoint = {
    CategoryImgBase: 'images/category/',
    clientProfileImg: 'images/client/profileImg/',
    beauticianLogo: 'images/beautician/logo/',
    beauticianWorkSpace: 'images/beautician/workSpace/',
    beauticianProfile: 'images/beautician/profileImg/',
    beauticianLicense: 'images/beautician/licenseImg/',
    beauticianServiceImg: 'images/beautician/serviceImg/',
    beauticianProductImg: 'images/beautician/product/',
    employeeProfile: 'images/beautician/employee/',
    adminProfile: 'images/admin/',
    noteFile: 'images/note',
    adminBrandBanner: '/images/admin/brandBanner/',
    adminBrandLogo: '/images/admin/brandLogo/',
    adminBrandProductImage: '/images/admin/brandProductImg',
    audios: '/images/audio'
}

const EmailImages = {
    logo: process.env.IMAGE_BASE_URL + 'images/green-logo.png',
    facebook: process.env.IMAGE_BASE_URL + 'images/facebook.png',
    instra: process.env.IMAGE_BASE_URL + 'images/instra.png',
    linkdin: process.env.IMAGE_BASE_URL + 'images/linkdin.png',
    corporationLogo: process.env.IMAGE_BASE_URL + 'images/sliike-corporation2.png'
}

// const Constants = {
//     CategoryImgBase: process.env.BASE_URL + pathEndpoint.CategoryImgBase,
//     ClientProfileImg: process.env.BASE_URL + pathEndpoint.clientProfileImg,
//     beauticianLogo: process.env.BASE_URL + pathEndpoint.beauticianLogo,
//     beauticianWorkSpace: process.env.BASE_URL + pathEndpoint.beauticianWorkSpace,
//     beauticianProfile: process.env.BASE_URL + pathEndpoint.beauticianProfile,
//     beauticianLicense: process.env.BASE_URL + pathEndpoint.beauticianLicense,
//     beauticianServiceImg: process.env.BASE_URL + pathEndpoint.beauticianServiceImg,
//     beauticianProductImg: process.env.BASE_URL + pathEndpoint.beauticianProductImg,
//     EmployeeProfile: process.env.BASE_URL + pathEndpoint.employeeProfile,
//     adminProfile: process.env.BASE_URL + pathEndpoint.adminProfile
// }

const notificationMSGs = {
    signUpUserCtx: {
        title: 'Welcome to Sliike',
        message: 'Yay! You created your Sliike user profile. Next step is to complete your personal profile to and start using the app.',
        content: 'USER_SIGNUP'
    },
    businessSetUPCtx: {
        title: 'Welcome to Sliike',
        message: 'Yay! You created your Sliike Business profile. Next step is to complete your profile to make your business visible to clients across Canada.',
        content: 'BEAUTICIAN_BUSINESS_SETUP'
    },
    congratsCtx: {
        title: 'Congratulations!',
        message: 'You have completed your Sliike Business profile. Now, go to the “More” section and complete your bank details on Stripe, photos, demographics, licence, taxes etc.',
        content: 'BEAUTICIAN_CONGRATS'
    },
    addNewServiceCtx(serviceTypeName) {
        return {
            title: 'New Service Listed',
            message: `Congratulations! You have successfully listed a new service: ${serviceTypeName}.`,
            content: 'BEAUTICIAN_CONGRATS'
        }
    },
    bookingConfirmClientCtx(data) {
        return {
            title: 'Service Booking Confirmation',
            message: `You successfully booked ${data.serviceName}, which is scheduled for ${data.date} at ${data.time}.`,
            content: 'CLIENT_SERVICE_BOOKED'
        }
    },
    bookingCancelClientCtx(data) {
        return {
            title: 'Service Cancellation Confirmation',
            message: `You successfully cancelled ${data.serviceName}, which is scheduled for  ${data.date} at ${data.time}.The beautician cancellation policy will apply for reimbursement.`,
            content: 'SERVICE_CANCELED'
        }
    },
    bookingConfirmBeauticianCtx(data) {
        return {
            title: 'New Service Booking Alert',
            message: `A client booked ${data.serviceName}, which is scheduled for  ${data.date} at ${data.time}.`,
            content: 'SERVICE_BOOKED'
        }
    },
    productOrderConfirmClientCtx(data) {
        return {
            title: 'Product Order Confirmation',
            message: `You successfully ordered ${data.productName}, on  ${data.date} at ${data.time}.`,
            content: 'PRODUCT_ORDERED'
        }
    },
}

const getPolicyDetails = (number) => {
    let policy = "";
    let title = "";
    switch (number) {
        case 1:
            title = "Free";
            policy = "Cancellation allowed at any time. Full refund";
            break;

        case 2:
            title = "Flexible";
            policy = "All cancelation done 12 hours before appointment is fully refunded";
            break;

        case 3:
            title = "Strict";
            policy = "50% charge on cancellation between 24 and 10 hours before the appointment. 50% refund.";
            break;

        case 4:
            title = "Very Strict";
            policy = "Full charge on cancellation less than 10 hours before the appointment. No refund.";
            break;

        default:
            break;
    }
    return { policy, title }
}
const getPolicyDetailsForNoShow = (number) => {
    let policy = "";
    let title = "";
    switch (number) {
        case 1:
            title = "None";
            policy = "Reschedule appointment to a new date and time with no consequences attached.";
            break;

        case 4:
            title = "Very Strict";
            policy = "Full charge and no refund to client.";
            break;

        default:
            break;
    }
    return { policy, title }
}
module.exports = { AppId, AppStoreId, referralAmount, pathEndpoint, notificationMSGs, EmailImages, getPolicyDetails, getPolicyDetailsForNoShow }
