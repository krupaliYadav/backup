const { v4: uuidv4 } = require('uuid');

const generateNumericId = (length) => {
  const uuid = uuidv4().replace(/-/g, ''); // Remove hyphens from UUID
  return uuid.slice(0, length);
}

const generateBeauticianId = (length) => {
  let uid = "";
  let pieces = length.split('-');
  let lastNum = pieces[1];
  lastNum = parseInt(lastNum, 10);
  lastNum++;

  if (lastNum < 9) {
    uid = "SLKB" + "-" + "000000" + lastNum.toString()
  } else if (lastNum < 99) {
    uid = "SLKB" + "-" + "00000" + lastNum.toString()
  }
  else if (lastNum < 999) {
    uid = "SLKB" + "-" + "0000" + lastNum.toString()
  }
  else if (lastNum < 9999) {
    uid = "SLKB" + "-" + "000" + lastNum.toString()
  }
  else if (lastNum < 99999) {
    uid = "SLKB" + "-" + "00" + lastNum.toString()
  }
  else if (lastNum < 999999) {
    uid = "SLKB" + "-" + "0" + lastNum.toString()
  }
  else if (lastNum <= 9999999) {
    uid = "SLKB" + "-" + lastNum.toString()
  }
  return uid;
}

const generateClientId = (length) => {
  let uid = "";
  let pieces = length.split('-');
  let lastNum = pieces[1];
  lastNum = parseInt(lastNum, 10);
  lastNum++;

  if (lastNum < 9) {
    uid = "SLKC" + "-" + "000000" + lastNum.toString()
  } else if (lastNum < 99) {
    uid = "SLKC" + "-" + "00000" + lastNum.toString()
  }
  else if (lastNum < 999) {
    uid = "SLKC" + "-" + "0000" + lastNum.toString()
  }
  else if (lastNum < 9999) {
    uid = "SLKC" + "-" + "000" + lastNum.toString()
  }
  else if (lastNum < 99999) {
    uid = "SLKC" + "-" + "00" + lastNum.toString()
  }
  else if (lastNum < 999999) {
    uid = "SLKC" + "-" + "0" + lastNum.toString()
  }
  else if (lastNum <= 9999999) {
    uid = "SLKC" + "-" + lastNum.toString()
  }

  return uid;
}

const generateAdminId = (length) => {
  let uid = "";
  let pieces = length.split('-');
  let lastNum = pieces[1];
  lastNum = parseInt(lastNum, 10);
  lastNum++;

  if (lastNum < 9) {
    uid = "SLKA" + "-" + "000000" + lastNum.toString()
  } else if (lastNum < 99) {
    uid = "SLKA" + "-" + "00000" + lastNum.toString()
  }
  else if (lastNum < 999) {
    uid = "SLKA" + "-" + "0000" + lastNum.toString()
  }
  else if (lastNum < 9999) {
    uid = "SLKA" + "-" + "000" + lastNum.toString()
  }
  else if (lastNum < 99999) {
    uid = "SLKA" + "-" + "00" + lastNum.toString()
  }
  else if (lastNum < 999999) {
    uid = "SLKA" + "-" + "0" + lastNum.toString()
  }
  else if (lastNum <= 9999999) {
    uid = "SLKA" + "-" + lastNum.toString()
  }

  return uid;
}


const generateBrandProductId = (length) => {
  let uid = "";
  let pieces = length.split('-');
  let lastNum = pieces[1];
  lastNum = parseInt(lastNum, 10);
  lastNum++;

  if (lastNum < 9) {
    uid = "SLKU" + "-" + "000000" + lastNum.toString()
  } else if (lastNum < 99) {
    uid = "SLKU" + "-" + "00000" + lastNum.toString()
  }
  else if (lastNum < 999) {
    uid = "SLKU" + "-" + "0000" + lastNum.toString()
  }
  else if (lastNum < 9999) {
    uid = "SLKU" + "-" + "000" + lastNum.toString()
  }
  else if (lastNum < 99999) {
    uid = "SLKU" + "-" + "00" + lastNum.toString()
  }
  else if (lastNum < 999999) {
    uid = "SLKU" + "-" + "0" + lastNum.toString()
  }
  else if (lastNum <= 9999999) {
    uid = "SLKU" + "-" + lastNum.toString()
  }
  return uid;
}

const generateReferenceCode = (num) => {
  const randomNum = Math.floor(Math.random() * 10000000000).toString().padStart(num, '0');  // Generate a random 6-digit number
  return "#" + randomNum;
}
const generateInventoryCode = (num) => {
  const randomNum = Math.floor(Math.random() * 1000000).toString().padStart(num, '0');  // Generate a random 6-digit number
  return "SKU" + randomNum;
}
const phoneNumberPipeline = (phoneNumberString) => {
  var cleaned = ('' + phoneNumberString).replace(/\D/g, '');
  var match = cleaned.match(/^(1|)?(\d{3})(\d{3})(\d{4})$/);
  if (match) {
    var intlCode = (match[1] ? '+1 ' : '');
    return [intlCode, '(', match[2], ') ', match[3], '-', match[4]].join('');
  }
  return null;
}

// const generateClientId = (length) => {
//   let uid = ""
//   if (length < 9) {
//     uid = "SLKC000000" + length
//   } else if (length < 99) {
//     uid = "SLKC00000" + length
//   }
//   else if (length < 999) {
//     uid = "SLKC0000" + length
//   }
//   else if (length < 9999) {
//     uid = "SLKC000" + length
//   }
//   else if (length < 99999) {
//     uid = "SLKC00" + length
//   }
//   else if (length < 999999) {
//     uid = "SLKC0" + length
//   }
//   else if (length < 9999999) {
//     uid = "SLKC" + length
//   }

//   return uid;
// }

const generateBrandId = (length) => {
  let uid = "";
  let pieces = length.split('-');
  let lastNum = pieces[1];
  lastNum = parseInt(lastNum, 10);
  lastNum++;

  if (lastNum < 9) {
    uid = "SLKB" + "-" + "000000" + lastNum.toString()
  } else if (lastNum < 99) {
    uid = "SLKB" + "-" + "00000" + lastNum.toString()
  }
  else if (lastNum < 999) {
    uid = "SLKB" + "-" + "0000" + lastNum.toString()
  }
  else if (lastNum < 9999) {
    uid = "SLKB" + "-" + "000" + lastNum.toString()
  }
  else if (lastNum < 99999) {
    uid = "SLKB" + "-" + "00" + lastNum.toString()
  }
  else if (lastNum < 999999) {
    uid = "SLKB" + "-" + "0" + lastNum.toString()
  }
  else if (lastNum <= 9999999) {
    uid = "SLKB" + "-" + lastNum.toString()
  }

  return uid;
}

module.exports = { generateNumericId, generateBeauticianId, generateClientId, generateBrandProductId, generateReferenceCode, phoneNumberPipeline, generateInventoryCode, generateBrandId, generateAdminId }