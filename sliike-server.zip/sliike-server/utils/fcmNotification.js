const FCM = require('fcm-node');
const serverKey = process.env.FCM_SERVER_KEY;
const fcm = new FCM(serverKey);

async function fcmNotification({ messageCtx, deviceIds }) {
    return new Promise((resolve, reject) => {
        const messageBody = {
            registration_ids: deviceIds,
            notification: {
                title: messageCtx.title,
                body: messageCtx.message,
                content_available: true,
                priority: 'high',
                requestTime: new Date().getTime(),
            },
            data: {
                content: messageCtx.content
            },
        };

        fcm.send(messageBody, (err, response) => {
            if (err) {
                console.log('err: ', err);
                resolve(null);
            } else {
                console.log('Successfully sent with response: ', response);
                resolve(response);
            }
        });
    });
}
module.exports = { fcmNotification };