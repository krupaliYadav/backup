const mongoose = require("mongoose");

const brandSchema = mongoose.Schema(
    {
        brandName: {
            type: String,
            required: [true, "Brand name is Required"]
        },
        uid: {
            type: String,
            unique: true
        },
        brandCategoryId: {
            type: mongoose.Schema.ObjectId,
            ref: "BrandCategoryList",
            // require: [true, "serviceCategoryId is Required"]
        },
        brandOwner: {
            type: String,
            required: [true, "Brand owner name is Required"]
        },
        email: {
            type: String,
            required: [true, "Email is Required"]
        },
        phoneNumber: {
            type: Number,
            required: [true, "Phone Number is Required"],
        },
        country: {
            type: String,
            required: [true, "Country is Required"]
        },
        address: {
            type: String,
            required: [true, "Address is Required"]
        },
        city: {
            type: String,
            required: [true, "City is Required"]
        },
        province: {
            type: String,
            required: [true, "Province is Required"]
        },
        postalCode: {
            type: String,
            required: [true, "Postal Code is Required"]
        },
        targetAudience: {
            type: Number,
            enum: [0, 1, 2, 3, 4, 5],
            comment: '0=all, 1=men, 2=women, 3=young people, 4=men&women, 5=seniors',
            required: [true, "Target Audience is Required"]
        },
        targetDemographicId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Demography'
        },
        registeredDate: {
            type: Date,
            required: [true, "Registered date is Required"]
        },
        sliikePlan: {
            type: String,
            enum: ['Sliike Basic', 'Sliike Pro', 'Sliike Premium'],
            required: [true, "sliike Plan is Required"]
        },
        contractType: {
            type: Number,
            enum: [0, 1],
            comment: '0=new, 1=renewal',
            required: [true, "Contract Type is Required"]
        },
        startDate: {
            type: Date,
            required: [true, "Start date is Required"]
        },
        endDate: {
            type: Date,
            required: [true, "End date is Required"]
        },
        contractDuration: {
            type: String,
            required: [true, "Contract Duration is Required"]
        },
        plateFormFee: {
            type: Number,
            required: [true, "Plate form fee is Required"]
        },
        discount: {
            type: Number,
            required: [true, "Discount is Required"],
            comment: " in percentage"
        },
        discountAmount: {
            type: Number,
            required: [true, "Discount amount is Required"],
        },
        HSTOrGST: {
            type: Number,
            required: [true, "HST/GST is Required"],
        },
        QSTOrPST: {
            type: Number,
            required: [true, "QST/PST is Required"],
        },
        totalFeeCharge: {
            type: Number,
            required: [true, "Total fee charge is Required"],
        },
        websiteUrl: {
            type: String,
            required: [true, "Website url is Required"]
        },
        shippingPolicyUrl: {
            type: String,
            required: [true, "Shipping policy url is Required"]
        },
        returnPolicyUrl: {
            type: String,
            required: [true, "Return policy url is Required"]
        },
        brandLogo: {
            type: String,
        },
        brandBanner: {
            type: String,
        },
        step: {
            type: Number,
            enum: [1, 2, 3],
            default: 1,
            comment: '0 = brand added, 1= brand product added, 2= brand successfully added',
        },
        status: {
            type: Number,
            enum: [0, 1],
            default: 1,
            comment: '1 = active, 0= inactive',
        },
        brandProductId: [{
            type: mongoose.Schema.ObjectId,
            ref: "BrandProducts",
        }],
        buyerId: [{
            type: mongoose.Schema.ObjectId,
            refPath: 'member_type'
        }],
        buyer_type: [{
            type: String,
            enum: ["clients", "beauticians"],
            required: true
        }],
        numOfViews:{
            type: Number,
            default: 0,
        },
        shareClick: {
            type: Number,
            default: 0,
        },
        isDeleted: {
            enum: [0, 1],
            type: Number,
            default: 0,
            comment: '0 = notDeleted, 1= deleted',
        },
    },
    { timestamps: true }
);


module.exports = mongoose.model("Brand", brandSchema);
