const mongoose = require("mongoose");

const discountSchema = mongoose.Schema({
    clientIds: {
        type: [mongoose.Schema.ObjectId],
        ref: "Client",
        require: [true, "clientId's is Required"]
    },
    promotionTitle: {
        type: String,
        required: [true, "promotionTitle is Required"]
    },
    description: {
        type: String,
    },
    isDiscPercentage: {
        type: Number,
        enum: [0, 1],
        comment: "0 = discount in Amount , 1 =  discount in percentage"
    },
    discount: {
        type: Number
    },
    startDate: {
        type: Date
    },
    endDate: {
        type: Date
    },
    discountCode: {
        type: String,
        unique: true
    },
    language:{
        enum: ["en", "fr"],
        type: String,
        default: "en",
    },
}, { timestamps: true })

module.exports = mongoose.model("Discount", discountSchema);