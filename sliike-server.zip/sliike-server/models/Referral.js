const mongoose = require("mongoose");

const referralSchema = mongoose.Schema({
    referralId: {
        type: mongoose.Schema.ObjectId,
        ref: "Beautician",
    },
    referralCode: {
        type: String,
    },
    userId: {
        type: mongoose.Schema.ObjectId,
        ref: "User",
    },
    sendDate: {
        type: Date
    },
    status: {
        enum: [0, 1],
        type: Number,
        default: 0,
    }
}, { timestamps: true });


module.exports = mongoose.model("Referral", referralSchema);