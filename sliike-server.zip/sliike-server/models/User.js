const mongoose = require("mongoose");
// const mongoosePaginate = require('mongoose-paginate-v2');
const userSchema = mongoose.Schema({
    email: {
        type: String,
        required: [true, "Email is Required"]
    },
    password: {
        type: String,
        // required: [true, "Password is Required"],
        // minLength: [6, "Password must be 6 character"],
    },
    phoneNumber: {
        type: Number,
        required: [true, "Phone Number is Required"],
    },
    resetPasswordToken: {
        type: String,
    },
    isVerified: {
        enum: [0, 1],
        type: Number,
        default: 0,
    },
    roles: {
        enum: ['beautician', 'user'],
        type: [String],
        required: true
    },
    isActiveUser: {
        enum: [0, 1],
        type: Number,
        default: 0,
        comment: '0 = deactivate, 1= active',
    },
    isActiveBeautician: {
        enum: [0, 1],
        type: Number,
        default: 0,
        comment: '0 = deactivate, 1= active',
    },
    language: {
        enum: ["en", "fr"],
        type: String,
        default: "en",
    },
    referBy: {
        type: mongoose.Schema.ObjectId,
        ref: "Referral",
    },
    activateAsUserDate: { type: Date },
    activateAsBeauticianDate: { type: Date },
    inActivateUserDate: { type: Date },
    inActivateBeauticianDate: { type: Date }
}, { timestamps: true });
// userSchema.plugin(mongoosePaginate);
module.exports = mongoose.model("User", userSchema);