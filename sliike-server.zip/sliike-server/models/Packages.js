const mongoose = require("mongoose");

const packageSchema = mongoose.Schema({
    name:{
        type:String,
        unique: true,
        required:[true,"name is Required"]
    },
    ServiceCharge:{
        type:Number,
        comment: "value will count in percentage"
    },
    ProductServiceCharge : {
        type:Number,
        comment: "value will count in percentage"
    },
    employeeNumber : {
        type: Number,
    },
    freeTrialDuration : {
        type: String
    },
    serviceDescription: {
        type: [String]
    },
    productDescription : {
        type: [String]
    },
    chargesPerMonth : {
        type:  Number,
        required:[true,"charges is Required"]        
    }
},{timestamps:true})

module.exports = mongoose.model("Package",packageSchema);