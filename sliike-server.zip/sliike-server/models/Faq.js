const mongoose = require("mongoose");

const faqSchema = mongoose.Schema({
    useFor: {
        type: String,
        enum: ['client', 'beautician'],
        required: [true, "userFor is Required"]
    },
    question: {
        type: String,
        required: [true, "question is Required"]
    },
    answer: {
        type: String,
        required: [true, "answer is Required"]
    }
}, { timestamps: true });

module.exports = mongoose.model("Faq", faqSchema);