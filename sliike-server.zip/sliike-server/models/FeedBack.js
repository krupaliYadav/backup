const mongoose = require("mongoose");

const feedbackSchema = mongoose.Schema({
    memberId: {
        type: mongoose.Schema.ObjectId,
        refPath: 'member_type'
    },
    member_type: {
        type: String,
        enum: ["Client", "Beautician"],
        required: true
    },
    subject: {
        type: String,
        required: [true, "subject is Required"]
    },
    description: {
        type: String,
        required: [true, "description is Required"]
    }
}, { timestamps: true });

module.exports = mongoose.model("Feedback", feedbackSchema);