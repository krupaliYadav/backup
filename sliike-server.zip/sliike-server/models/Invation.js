const mongoose = require("mongoose");

const invitationSchema = mongoose.Schema({
    firstName: {
        type: String,
    },
    lastName: {
        type: String,
    },
    email: {
        type: String,
    },
    phoneNumber: {
        type: String,
    },
    status: {
        enum: [0, 1],
        type: Number,
        default: 1,
        comment: '0 = deactivate, 1= active',
    }
}, { timestamps: true });

module.exports = mongoose.model("Invation", invitationSchema);