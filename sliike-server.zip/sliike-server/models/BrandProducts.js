const mongoose = require("mongoose");

const brandProductSchema = mongoose.Schema({
    brandId: {
        type: mongoose.Schema.ObjectId,
        ref: "Brand",
    },
    uid: {
        type: String,
    },
    productName: {
        type: String,
    },
    productPrice: {
        type: Number,
    },
    productUnit: {
        type: String,
    },
    productSize: {
        type: String,
    },
    weightUnit: {
        type: String,
    },
    weightValue: {
        type: String,
    },
    keyFeatures: [String],
    description: {
        type: String,
    },
    productImageName: {
        type: String
    },
    status: {
        type: Number,
        enum: [0, 1],
        default: 0,
        Comment: "0 : de-active, 1 active"
    },
    isDeleted: {
        type: Number,
        enum: [0, 1],
        default: 0,
        Comment: "0 : not deleted , 1 deleted"
    }
}, { timestamps: true })

module.exports = mongoose.model("BrandProducts", brandProductSchema);