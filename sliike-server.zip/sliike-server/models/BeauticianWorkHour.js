const mongoose = require("mongoose");

const workHourSchema = mongoose.Schema({
    beauticianId: {
        type: mongoose.Schema.ObjectId,
        ref: "Beautician",
        unique: true,
        require: [true, "beauticianId is Required"]
    },
    dayDetails: [
        {
            day: {
                enum: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
                type: String,
                require: [true, "Day is required."]
            },
            startTime: {
                type: String
            },
            endTime: {
                type: String
            },

            breakStartTime: {
                type: String
            },
            breakEndTime: {
                type: String
            },
            isOpen: {
                type: Boolean,
                require: [true, "isOpen value is required."]
            }
        }
    ],
    calenderSetting: [
        {
            day: {
                enum: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
                type: String,
            },
            _date: {
                type: Date,
            },
            get date() {
                return this._date;
            },
            set date(value) {
                this._date = value;
            },
            startTime: {
                type: String
            },
            endTime: {
                type: String
            },
            breakStartTime: {
                type: String
            },
            breakEndTime: {
                type: String
            },
            isOpen: {
                type: Boolean,
                require: [true, "isOpen value is required."]
            }
        }
    ]
}, { timestamps: true });

module.exports = mongoose.model("BeauticianWorkHour", workHourSchema);