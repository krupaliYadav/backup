

const mongoose = require("mongoose");

const cardSchema = mongoose.Schema({
    clientId: {
        type: mongoose.Schema.ObjectId,
        ref: "Client",
        require: [true, "clientId is Required"]
    },
    paymentMethodID: {
        type: String,
        require: [true, "paymentCustomerId is Required"]
    },
    cardName: {
        type: String,
        require: [true, "cardName is Required"]
    },
    cardLastFour: {
        type: Number,
        require: [true, "cardLastFour is Required"]
    },
    cardBrand: {
        type: String,
    },
    expiryMonth: {
        type: Number,
    },
    expiryYear: {
        type: Number,
    },
    cardToken: {
        type: String,
        require: [true, "cardToken is Required"]
    },
    cardCVC: {
        type: Number
    },
    isPrimary: {
        enum: [0, 1],
        type: Number,
        default: 0,
    },
}, { timestamps: true });

module.exports = mongoose.model("Card", cardSchema);