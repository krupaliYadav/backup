const mongoose = require("mongoose");

const promotionSchema = mongoose.Schema({
    beauticianId: {
        type: mongoose.Schema.ObjectId,
        ref: "Beautician",
        require: [true, "beauticianId is Required"]
    },
    promotionFor: {
        type: String,
        enum: ['service', 'product'],
        required: [true, "promotionFor is Required"]
    },
    promotionTitle: {
        type: String,
        required: [true, "promotionTitle is Required"]
    },
    subTypeId: {
        type: mongoose.Schema.ObjectId,
        refPath: 'subId_type'
    },
    subId_type: {
        type: String,
        enum: ["BeauticianService", "BeauticianProduct"],
        required: true
    },
    serviceName: {
        type: String,
        required: [true, "serviceName is Required"]
    },
    description: {
        type: String,
    },
    isDiscPercentage: {
        type: Number,
        enum: [0, 1],
        comment: "0 = discount in Amount , 1 =  discount in percentage "
    },
    discount: {
        type: Number
    },
    startDate: {
        type: Date
    },
    endDate: {
        type: Date
    },
    language: {
        enum: ["en", "fr"],
        type: String,
        default: "en",
    },
    referenceCode: {
        type: String,
        unique: true
    },
    createdBy: {
        type: String,
        enum: ['admin', 'beautician']
    }

}, { timestamps: true })

module.exports = mongoose.model("Promotion", promotionSchema);