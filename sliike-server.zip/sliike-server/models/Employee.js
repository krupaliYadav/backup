const mongoose = require("mongoose");

const employeeSchema = mongoose.Schema({
    beauticianId: {
        type: mongoose.Schema.ObjectId,
        ref: "Beautician",
        require: [true, "beauticianId is Required"]
    },
    profileImage: {
        type: String,
    },
    firstName: {
        type: String,
        required: [true, "firstName is Required"]
    },
    lastName: {
        type: String,
        required: [true, "LastName is Required"]
    },
    phoneNumber: {
        type: Number,
    },
    country_code: {
        type: String,
    },
    email: {
        type: String,
        require: [true, "email is Required"]
    },
    title: {
        type: String,
    },
    notes: {
        type: String,
    },
    calenderColor: {
        type: String,
    },
    permissionLevel: {
        type: String,
    },
    workHours: {
        startTime: {
            type: String
        },
        endTime: {
            type: String
        },
    },
    serviceIds: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'BeauticianService'
    }],
    // isCalenderBooking : {
    //     enum:[0,1],
    //     type:Number,
    //     default:0,
    //     comment: '0 = deactivate, 1= active',
    // },
    status: {
        enum: [0, 1],
        type: Number,
        default: 1,
        comment: '0 = deactivate, 1= active',
    }
}, { timestamps: true });

employeeSchema.set('toObject', { virtuals: true })
employeeSchema.set('toJSON', { virtuals: true })

employeeSchema.virtual('profileImgPath').get(function () {
    return this.profileImage;
});

module.exports = mongoose.model("Employee", employeeSchema);