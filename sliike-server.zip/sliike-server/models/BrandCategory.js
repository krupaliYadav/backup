const mongoose = require("mongoose");

const brandCategorySchema = mongoose.Schema({
    brandCategoryName: {
        type: String,
        unique: false,
        required: [true, "Service category name is Required"]
    },
    brandCategoryName_fr: {
        type: String,
        unique: false,
        required: [true, "Service category name is Required"]
    },
    colorCode: {
        type: String
    },
    language: {
        enum: ["en", "fr"],
        type: String,
        default: "en",
    },
    isDeleted: {
        type: Number,
        enum: [0, 1],
        default: 0,
        Comment: "0 : not deleted , 1 deleted"
    }
}, { timestamps: true })

module.exports = mongoose.model("BrandCategoryList", brandCategorySchema);