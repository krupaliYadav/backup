const mongoose = require("mongoose");

const cartSchema = mongoose.Schema(
    {
        clientId: {
            type: mongoose.Schema.ObjectId,
            ref: "Client",
        },
        beauticianId: {
            type: mongoose.Schema.ObjectId,
            ref: "Beautician",
        },
        productId: {
            type: mongoose.Schema.ObjectId,
            ref: "BeauticianProduct",
        },
        variations: [
            {
                variationType: { type: String },
                variationQuantity: { type: Number, min: 0 }
            }
        ],
        totalQuantity: {
            type: Number,
            min: 0,
            require: [true, "totalQuantity is required."]
        },
        originalPrice: {
            type: Number,
        },
        subTotal: {
            type: Number,
        },
        isAvailable: {
            type: Boolean,
            default: true
        },
        isInStock: {
            type: Boolean,
            default: true
        },
        status: {
            type: Number,
            enum: [0,1],
            default: 0,
            comment: '0 = active, 1= inactive',
        },
    },
    { timestamps: true }
);


module.exports = mongoose.model("Cart", cartSchema);
