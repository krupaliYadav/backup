const mongoose = require("mongoose");

const fcmNotificationSchema = mongoose.Schema({
    memberId:{
        type: mongoose.Schema.ObjectId,
        refPath: 'member_type'
    },
    member_type: {  type: String, enum: ["Client","Beautician"], required: true },
    deviceToken: {
        type: String
    },
    firebaseToken : {
        type: String
    },
},{timestamps:true});

module.exports = mongoose.model("FcmNotification",fcmNotificationSchema);