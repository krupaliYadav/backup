const mongoose = require("mongoose");
const beauticianProductSchema = mongoose.Schema(
    {
        beauticianId: {
            type: mongoose.Schema.ObjectId,
            ref: "Beautician",
        },
        productCategory: {
            type: mongoose.Schema.ObjectId,
            ref: "ProductCategoryList",
        },
        productName: {
            type: String,
        },
        // weight
        wtValue: {
            type: Number,
        },
        wtUnit: {
            type: String,
        },
        //height
        htValue: {
            type: Number,
        },
        htUnit: {
            type: String,
        },
        lengthValue: { type: Number },
        lengthUnit: { type: String },
        widthValue: { type: Number },
        widthUnit: { type: String },
        description: { type: String, maxlength: 150 },
        colorVariation: { type: [String] },
        price: {
            type: Number,
        },
        isPromotion: {
            type: Boolean,
            default: false,
        },
        promotionDetails: {
            proPrice: { type: Number },
            discount: { type: Number, comment: "in percentage" },
            startDate: { type: Date },
            endDate: { type: Date },
        },
        inventoryCode: {
            type: String,
        },
        isStockTrack: {
            type: Boolean,
        },
        stockQuantity: {
            type: Number,
            default: 0,
        },
        soldQuantity: {
            type: Number,
            default: 0,
        },
        nubOfCartClicked: {
            type: Number,
            default: 0,
        },
        nubOfShareClicked: {
            type: Number,
            default: 0,
        },
        nubOfView: {
            type: Number,
            default: 0,
        },
        imgName: {
            type: [String],
        },
        detailStep: { type: Number, default: 1, max: 2 },
        rating: {
            type: Number,
            default: 0,
        },
        numOfViews: {
            type: Number,
            default: 0
        },
        numOfShare: {
            type: Number,
            default: 0
        },
        numOfAddToCart: {
            type: Number,
            default: 0
        },
        isDelete: {
            type: Number,
            default: 0,
            enum: [0, 1],
            comment: "1 : deleted , 0 :not deleted",
        },
    },
    { timestamps: true }
);

beauticianProductSchema.set("toObject", { virtuals: true });
beauticianProductSchema.set("toJSON", { virtuals: true });

beauticianProductSchema.virtual('imgURL').get(function () {
    return this.imgName;
});

module.exports = mongoose.model("BeauticianProduct", beauticianProductSchema);
