const mongoose = require("mongoose");

const appointmentSchema = mongoose.Schema({
    clientId: {
        type: mongoose.Schema.ObjectId,
        ref: "Client",
        require: [true, "ClientId is Required"]
    },
    beauticianId: {
        type: mongoose.Schema.ObjectId,
        ref: "Beautician",
        require: [true, "BeauticianId is Required"]
    },
    serviceId: {
        type: mongoose.Schema.ObjectId,
        ref: "BeauticianService",
        require: [true, "BeauticianId is Required"]
    },
    stylistID: {
        type: mongoose.Schema.ObjectId,
        ref: "Employee",
        default: null
    },
    paymentDetails: {
        type: mongoose.Schema.ObjectId,
        ref: "Payment",
    },
    dateTime: {
        type: Date,
        require: [true, "dateTime is Required"]
    },
    endDateTime: {
        type: Date,
        require: [true, "endDateTime is Required"]
    },
    price: {
        type: Number,
    },
    discount: {
        type: Number,
        default: 0
    },
    place: {
        enum: [0, 1],
        type: Number,
        default: 0,
        comment: '0 = Beautician Place, 1= At Client Place',
    },
    note: {
        type: String
    },
    status: {
        enum: [0, 1, 2, 3, 4, 5],
        type: Number,
        default: 0,
        comment: '0 = pending, 1 = Accepted,2 = delivered, 3 = cancelByClient ,4=cancelByBeautician , 5= client no show',
    },
    createdBy: {
        enum: ['client', 'beautician'],
        type: String,
    },
    updatedBy: {
        enum: ['client', 'beautician'],
        type: String,
    },
    recurringOpt: {
        type: String,
        default: null
    },
    isDepositReq: {
        type: Boolean
    },
    depositAmtPercentage: {
        type: Number
    },
    cancelationPolicyNub: {
        type: Number,
        enum: [1, 2, 3, 4],
    },
    noShowPolicyNub: {
        type: Number,
        enum: [1, 2, 3, 4],
    },
    step: {
        type: Number,
        enum: [1, 2],
        default: 1
    }

}, { timestamps: true });

module.exports = mongoose.model("Appointment", appointmentSchema);
