const mongoose = require("mongoose");

const ServiceTypeSchema = mongoose.Schema({
    serviceCategoryId: {
        type: mongoose.Schema.ObjectId,
        ref: "ServiceCategoryList",
        require: [true, "serviceCategoryId is Required"]
    },
    serviceTypeName: {
        type: String,
        unique: false,
        required: [true, "ServiceTypeName is Required"]
    },
    serviceTypeName_fr: {
        type: String,
        unique: false,
        required: [true, "ServiceTypeName is Required"]
    },
    language: {
        enum: ["en", "fr"],
        type: String,
        default: "en",
    },
    status: {
        enum: [0, 1],
        type: Number,
        default: 1,
        comment: '0 = deactive, 1= active',
    }

}, { timestamps: true })

module.exports = mongoose.model("ServiceTypeList", ServiceTypeSchema);