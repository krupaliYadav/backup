const mongoose = require("mongoose");
// const Appointment = require("./Appointment");
// const Beautician = require("./Beautician");

const ratingSchema = mongoose.Schema({
    appointmentId: {
        type: mongoose.Schema.ObjectId,
        ref: "Appointment",
        unique: true,
        require: [true, "appointmentIds is Required"]
    },
    rating: {
        type: Number,
        require: [true, "rating is Required"]
    },
    reviews: {
        type: String
    },
    likes: {
        type: Number
    },
    replays:
        [
            {
                senderId: {
                    type: mongoose.Schema.ObjectId,
                    ref: "Beautician",
                },
                message: { type: String },
            },

        ]
}, { timestamps: true });

ratingSchema.post('save', async function (doc) {
    const Appointment = mongoose.model('Appointment');
    const Beautician = mongoose.model('Beautician');

    const appointment = await Appointment.findById(doc.appointmentId);
    const beauticianId = appointment.beauticianId;
    const allAppointment = await Appointment.find({ beauticianId });
    const appointmentIds = allAppointment.map(ele => ele._id);
    const ratings = await this.model('Rating').find({ appointmentId: { $in: appointmentIds } });
    const filteredRatings = ratings.filter(rating => rating.reviews !== undefined);
    const averageRating = ratings.reduce((total, rating) => total + rating.rating, 0) / ratings.length;
    const beautician = await Beautician.findById(beauticianId);
    beautician.rating = averageRating;
    beautician.noOfReviews = filteredRatings.length;
    await beautician.save();
});

module.exports = mongoose.model("Rating", ratingSchema);