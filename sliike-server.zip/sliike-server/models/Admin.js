const mongoose = require("mongoose");

const adminSchema = mongoose.Schema({
    uid: {
        type: String,
        unique: true
    },
    firstName: {
        type: String,
        required: [true, "firstName is Required"]
    },
    lastName: {
        type: String,
        required: [true, "LastName is Required"]
    },
    email: {
        type: String,
        required: [true, "Email is Required"]
    },
    password: {
        type: String,
        required: [true, "Password is Required"],
        minLength: [6, "Password must be 6 character"],
    },
    phoneNumber: {
        type: Number,
    },
    profileImage: {
        type: String,
    },
    role: {
        enum: ['superAdmin', 'subAdmin'],
        type: String,
        default: "subAdmin",
        required: true
    },
    isDeleted: {
        enum: [0, 1],
        type: Number,
        default: 0,
        comment: '0 = not deleted, 1= deleted',
    },
    status: {
        enum: [0, 1],
        type: Number,
        default: 1,
        comment: '0 = deactive, 1= active',
    },
    dashboardSettings: [
        {
            all: {
                enum: [0, 1],
                type: Number,
                default: 0,
                comment: '0 = not allowed, 1= allowed',
            },
            viewOnly: {
                enum: [0, 1],
                type: Number,
                default: 0,
                comment: '0 = not allowed, 1= allowed',
            },
            viewAndDownload: {
                enum: [0, 1],
                type: Number,
                default: 0,
                comment: '0 = not allowed, 1= allowed',
            },
        }
    ],
    beauticianSettings: [
        {
            all: {
                enum: [0, 1],
                type: Number,
                default: 0,
                comment: '0 = not allowed, 1= allowed',
            },
            viewOnly: {
                enum: [0, 1],
                type: Number,
                default: 0,
                comment: '0 = not allowed, 1= allowed',
            },
            viewAndDownload: {
                enum: [0, 1],
                type: Number,
                default: 0,
                comment: '0 = not allowed, 1= allowed',
            },
        }
    ],
    clientSettings: [
        {
            all: {
                enum: [0, 1],
                type: Number,
                default: 0,
                comment: '0 = not allowed, 1= allowed',
            },
            viewOnly: {
                enum: [0, 1],
                type: Number,
                default: 0,
                comment: '0 = not allowed, 1= allowed',
            },
            viewAndDownload: {
                enum: [0, 1],
                type: Number,
                default: 0,
                comment: '0 = not allowed, 1= allowed',
            },
        }
    ],
    productSettings: [
        {
            all: {
                enum: [0, 1],
                type: Number,
                default: 0,
                comment: '0 = not allowed, 1= allowed',
            },
            viewOnly: {
                enum: [0, 1],
                type: Number,
                default: 0,
                comment: '0 = not allowed, 1= allowed',
            },
            viewAndDownload: {
                enum: [0, 1],
                type: Number,
                default: 0,
                comment: '0 = not allowed, 1= allowed',
            },
        }
    ],
    brandSettings: [
        {
            all: {
                enum: [0, 1],
                type: Number,
                default: 0,
                comment: '0 = not allowed, 1= allowed',
            },
            viewOnly: {
                enum: [0, 1],
                type: Number,
                default: 0,
                comment: '0 = not allowed, 1= allowed',
            },
            viewAndDownload: {
                enum: [0, 1],
                type: Number,
                default: 0,
                comment: '0 = not allowed, 1= allowed',
            },
        }
    ],
    gistSettings: [
        {
            all: {
                enum: [0, 1],
                type: Number,
                default: 0,
                comment: '0 = not allowed, 1= allowed',
            },
            viewOnly: {
                enum: [0, 1],
                type: Number,
                default: 0,
                comment: '0 = not allowed, 1= allowed',
            },
            viewAndDownload: {
                enum: [0, 1],
                type: Number,
                default: 0,
                comment: '0 = not allowed, 1= allowed',
            },
        }
    ],
    promotionSettings: [
        {
            all: {
                enum: [0, 1],
                type: Number,
                default: 0,
                comment: '0 = not allowed, 1= allowed',
            },
            viewOnly: {
                enum: [0, 1],
                type: Number,
                default: 0,
                comment: '0 = not allowed, 1= allowed',
            },
            viewAndDownload: {
                enum: [0, 1],
                type: Number,
                default: 0,
                comment: '0 = not allowed, 1= allowed',
            },
        }
    ],
    adminSettings: [
        {
            all: {
                enum: [0, 1],
                type: Number,
                default: 0,
                comment: '0 = not allowed, 1= allowed',
            },
            viewOnly: {
                enum: [0, 1],
                type: Number,
                default: 0,
                comment: '0 = not allowed, 1= allowed',
            },
            viewAndDownload: {
                enum: [0, 1],
                type: Number,
                default: 0,
                comment: '0 = not allowed, 1= allowed',
            },
        }
    ],
    isDeleted: {
        enum: [0, 1],
        type: Number,
        default: 0,
        comment: '0 = notDeleted, 1= deleted',
    },
}, { timestamps: true });

module.exports = mongoose.model("Admin", adminSchema);