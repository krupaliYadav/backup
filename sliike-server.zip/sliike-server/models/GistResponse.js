const mongoose = require("mongoose");

const gistResponseSchema = mongoose.Schema({
    gistId: {
        type: mongoose.Schema.ObjectId,
        ref: "Gist",
    },
    message: {
        type: String,
        // required: true
    },
    audioFile: {
        type: String,
    },
    messageSenderId: {
        type: mongoose.Schema.ObjectId,
        refPath: 'member_type'
    },
    senderType: {
        type: String,
        enum: ["clients", "beauticians", "subAdmin", "superAdmin"],
        required: true
    },
}, { timestamps: true });

module.exports = mongoose.model("GistResponse", gistResponseSchema);