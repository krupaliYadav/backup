const mongoose = require("mongoose");

const ServiceCategorySchema = mongoose.Schema({
    serviceCategoryName: {
        type: String,
        unique: false,
        required: [true, "Service category name is Required"]
    },
    serviceCategoryName_fr: {
        type: String,
        unique: false,
        required: [true, "Service category name is Required"]
    },
    imgPath: {
        type: String
    },
    colorCode: {
        type: String
    },
    language: {
        enum: ["en", "fr"],
        type: String,
        default: "en",
    },
    status: {
        enum: [0, 1],
        type: Number,
        default: 1,
        comment: '0 = deactive, 1= active',
    }
}, { timestamps: true })

module.exports = mongoose.model("ServiceCategoryList", ServiceCategorySchema);