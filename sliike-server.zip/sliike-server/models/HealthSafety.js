const mongoose = require("mongoose");

const healthSafetySchema = mongoose.Schema({
    name: {
        type: String,
        unique: false,
        required: [true, "Service category name is Required"]
    },
    name_fr: {
        type: String,
        unique: false,
        // required: [true, "Service category name is Required"]
    },
    language: {
        enum: ["en", "fr"],
        type: String,
        default: "en",
    },
    status: {
        enum: [0, 1],
        type: Number,
        default: 1,
        comment: '0 = deactivate, 1= active',
    }
}, { timestamps: true });

module.exports = mongoose.model("HealthSafety", healthSafetySchema);