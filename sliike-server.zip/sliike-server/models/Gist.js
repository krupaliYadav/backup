const mongoose = require("mongoose");

const gistSchema = mongoose.Schema({
    createrId: {
        type: mongoose.Schema.ObjectId,
        refPath: 'member_type'
    },
    member_type: {
        type: String,
        enum: ["clients", "beauticians", "subAdmin", "superAdmin"],
        required: true
    },
    title: {
        type: String,
    },
    message: {
        type: String,
    },
    audioFile: {
        type: String,
    },
    type: {
        type: String,
        enum: ["everyone", "beauticianOnly"],
        required: true,
    },
    responseIds: {
        type: [mongoose.Schema.ObjectId],
        ref: "GistResponse",
        default: []
    },
    isDeleted: {
        enum: [0, 1],
        type: Number,
        default: 0,
        comment: '0 = not deleted, 1= deleted',
    },
}, { timestamps: true });

module.exports = mongoose.model("Gist", gistSchema);