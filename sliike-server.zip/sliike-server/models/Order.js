const mongoose = require("mongoose");

const orderSchema = mongoose.Schema({
    orderID: {
        type: String,
        unique: true,
        require: [true, "orderID is required."]
    },
    clientId: {
        type: mongoose.Schema.ObjectId,
        ref: "Client",
        require: [true, "ClientId is Required"]
    },
    productData: [
        {
            beauticianId: {
                type: mongoose.Schema.ObjectId,
                ref: "Beautician",
            },
            productId: {
                type: mongoose.Schema.ObjectId,
                ref: "BeauticianProduct",
            },
            price: {
                type: Number,
            },
            discount: {
                type: Number,
            },
            totalQuantity: {
                type: Number,
            }
        }
    ],
    cardId: {
        type: mongoose.Schema.ObjectId,
        ref: "Card",
        require: [true, "payment method Id is Required"]
    },
    transactionId: {
        type: String,
        require: [true, "transaction Id is Required"]
    },
    shippingAddressId: {
        type: mongoose.Schema.ObjectId,
        ref: "Address",
    },
    billingAddressId: {
        type: mongoose.Schema.ObjectId,
        ref: "Address",
    },
    subTotal: {
        type: Number,
    },
    GST: {
        type: Number,
        default: 0
    },
    PST: {
        type: Number,
        default: 0
    },
    HST: {
        type: Number,
        default: 0
    },
    QST: {
        type: Number,
        default: 0,
    },
    GstInPer: {
        type: Number,
        default: 0
    },
    PstInPer: {
        type: Number,
        default: 0
    },
    HstInPer: {
        type: Number,
        default: 0
    },
    QstInPer: {
        type: Number,
        default: 0
    },
    discount: {
        type: Number,
        default: 0,
    },
    TotalPrice: {
        type: Number,
    },
    orderType: {
        enum: ["delivery", "pickup"],
        type: String,
    },
    pickupDetails: {
        dateAndTime: {
            type: Date,
        },
        firstName: {
            type: String,
        },
        email: {
            type: String,
        },
        phoneNumber: {
            type: Number,
        },
    },
    paymentStatus: {
        enum: [0, 1, 2],
        type: Number,
        default: 0,
        comment: '0 = pending, 1 = confirmed, 2 = failed',
    }
}, { timestamps: true });

module.exports = mongoose.model("Order", orderSchema);