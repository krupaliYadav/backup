const mongoose = require("mongoose");

const termsSchema = mongoose.Schema({
    terms : {
        type: String,
        require:[true,"Terms is Required"]
    },
    policy:{
        type:String,
        required:[true,"Policy is Required"]
    },
    language:{
        enum: ["English", "French"],
        type: String,
        default: "English",
    },
    status:{
        enum: [0, 1],
        type: Number,
        default: 0,
    }
},{timestamps:true});

module.exports = mongoose.model("terms",termsSchema);