const express = require("express");
const morgan = require('morgan')
const cors = require("cors");
const app = express();
const i18next = require("i18next");
const Backend = require("i18next-fs-backend");
const i18Middleware = require("i18next-http-middleware")
const dotenv = require("dotenv");
dotenv.config();
app.set('view engine', 'ejs');
const connectDatabase = require("./config/connectDatabase");
const moment = require('moment-timezone');
const cron = require("node-cron");
const errorMiddleware = require("./middleware/Error");
const { RemainderMail } = require("./libs/cron/RemainderEmails")

// This is for convert languages
i18next.use(Backend).use(i18Middleware.LanguageDetector)
    .init({
        fallbackLng: 'en',
        backend: {
            loadPath: './locales/{{lng}}/translation.json'
        }
    });
app.use(i18Middleware.handle(i18next));
const router = require("./routes");
const { RemovePendingAppointment } = require("./libs/cron/RemovePendingAppointment");
dotenv.config();
const port = process.env.PORT || 3000;

app.use(express.text());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());
app.options("*", cors());
app.use(express.static('public'));
app.use(morgan('dev'))


// crown for remainder mail for appoiemnet
// * * * * * (for every one min)
// 0 */12 * * * (for every 12 hours)
// cron.schedule("0 */12 * * *", function () {
//     RemainderMail();
// });

// This crown is for every 48 hours to remove Appointment
cron.schedule("0 0 */2 * *", function () {
    RemovePendingAppointment();
});

// Middleware function to set default time zone
const setDefaultTimeZone = (req, res, next) => {
    moment.tz.setDefault(process.env.TIMEZONE || 'America/New_York');
    next();
};
app.get("/", (req, res) => {
    res.status(200).json({ status: 200, message: "Hello working finely.." });
})
app.use("/api/v1", setDefaultTimeZone, router);

app.use((req, res, next) => {
    res.status(404).json({ status: 404, success: false, message: "Page not found on the server" });
})

app.use(errorMiddleware);

app.listen(port, () => {
    console.log(`Server is listing on http://localhost:${port}`);
    connectDatabase()
});

process.on("unhandledRejection", (err) => {
    console.log("Error inside the unhandledrejection", err)
    console.log(`Error:${err.message}`);
    console.log(`Shutting down due to unhandled promise rejection `);

});