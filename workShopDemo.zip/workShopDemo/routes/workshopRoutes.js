const express = require("express")
const routes = express.Router()
const controller = require("../controller/workshopController")
const upload = require("../middleware/multer")
const validator = require("../middleware/validator")
const { addWorkshop, updateWorkshop, getWorkshop, updateShopImg } = require("../validation/validationIndex")

routes
    .post("/", upload.array("shopImg"), validator.body(addWorkshop), controller.addWorkshop)
    .put("/:id", upload.array("shopImg"), validator.body(updateWorkshop), controller.updateWorkshop)
    .put("/shopImg/:id", upload.array("shopImg"), validator.body(updateShopImg), controller.updateShopImg)
    .get("/", controller.getWorkshopList)
    .get("/:id", validator.params(getWorkshop), controller.getWorkshop)
    .delete("/:id", controller.delete)


module.exports = routes