const express = require("express")
const routes = express.Router()
const workshop = require("./workshopRoutes")


routes.use("/api/v1/workshop", workshop)

module.exports = routes