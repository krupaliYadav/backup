const Workshop = require("../model/workshopModel")
const deleteFile = require("../util/fileDelete")

// add workshop
exports.addWorkshop = async (req, res) => {
    try {
console.log(req.t);
        const shop = await Workshop.findOne({ ownerEmail: req.body.ownerEmail })
        if (shop) {
            return res.status(400).json({ error: true, message: req.t("Successful") })
        }

        const workshopData = {
            ownerName: req.body.ownerName,
            ownerEmail: req.body.ownerEmail,
            ownerPhoneNo: req.body.ownerPhoneNo,
            shopName: req.body.shopName,
            shopAddress: req.body.shopAddress,
            shopImg: []
        };

        if (req.files) {
            req.files.forEach(img => {
                workshopData.shopImg.push({ name: img.filename });
            })
        }
        const data = await Workshop.create(workshopData)
        res.status(200).json({ error: false, message: "Workshop details add successfully..", data })
    } catch (err) {
        return res.status(400).json({ error: true, message: err.message })
    }
}

// update workshop
exports.updateWorkshop = async (req, res) => {
    try {
        const id = req.params.id

        const shop = await Workshop.findOne({ _id: id })
        if (!shop) {
            return res.status(404).json({ error: true, message: "Workshop details not found...!" })
        }
        // it is for add new img
        if (req.files) {
            if (shop.shopImg.length >= 5) {
                return res.status(400).json({ error: true, message: "Only five images can apply...!" })
            } else {
                req.files.forEach(img => {
                    shop.shopImg.push({ name: img.filename })
                })
                shop.save()
            }

        }
        await Workshop.findByIdAndUpdate({ _id: id }, req.body)
        res.status(200).json({ error: false, message: "Workshop details update successfully.." })
    } catch (err) {
        return res.status(400).json({ error: true, message: err.message })
    }
}

// update shopImg form old to new
exports.updateShopImg = async (req, res) => {
    try {
        const id = req.params.id
        const { shopImgId } = req.body

        const shop = await Workshop.findOne({ _id: id })
        if (!shop) {
            return res.status(404).json({ error: true, message: "Workshop details not found...!" })
        }

        if (req.files.length === 0) {
            return res.status(400).json({ error: true, message: "If you want to update shopImg then please select new shop image....!!" })
        }

        shop.shopImg.filter(img => {
            if (img._id.toString() === shopImgId.toString()) {
                if (req.files.length > 1) {
                    return res.status(400).json({ error: true, message: "Please select only one image for update image....!!" })
                } else {
                    img.name = req.files.map(img => img.filename).join('')
                    shop.save()
                    deleteFile(img.name)
                    res.status(200).json({ error: false, message: "Workshop details update successfully.." })
                }
            }
        })
    } catch (err) {
        return res.status(400).json({ error: true, message: err.message })
    }
}

// get workshop
exports.getWorkshop = async (req, res) => {
    try {
        const id = req.params.id

        const data = await Workshop.findOne({ _id: id })
        if (!data) {
            return res.status(404).json({ error: true, message: "Data not found for display...!" })
        }
        res.status(200).json({ error: false, message: "Workshop details add update..", data })
    } catch (err) {
        return res.status(400).json({ error: true, message: err.message })
    }
}

// get list of work shop
exports.getWorkshopList = async (req, res) => {
    try {
        let query = {}
        if (req.query.search) {
            query.shopName = { $regex: req.query.search, $options: "i" }
        }
        const data = await Workshop.find(query)
        if (data.length === 0) {
            return res.status(404).json({ error: true, message: "Data not found for display...!" })
        }
        res.status(200).json({ error: false, message: "Workshop details load successfully..", data })
    } catch (err) {
        return res.status(400).json({ error: true, message: err.message })
    }
}

// delete workshop or specific img from db and also from folder
exports.delete = async (req, res) => {
    try {
        const id = req.params.id
        const { shopImgId } = req.body

        const shop = await Workshop.findOne({ _id: id })
        if (!shop) {
            return res.status(404).json({ error: true, message: "Shop not found...." })
        }
        if (req.params.id && !shopImgId) {
            await Workshop.findByIdAndDelete({ _id: id })
            res.status(200).json({ error: false, message: "Workshop details delete successfully.." })
        }
        if (id && shopImgId) {
            const imgs = await Workshop.findOne({ _id: id })
            const data = await Workshop.findByIdAndUpdate({ _id: id }, { $pull: { shopImg: { _id: { $in: shopImgId } } } })
            //remove img from public folder
            imgs.shopImg.filter(img => {
                shopImgId.map(id => {
                    if (id.toString() === img._id.toString()) {
                        deleteFile(img.name)
                    }
                })
            })
            res.status(200).json({ error: false, message: "Shop image delete successfully..", data })
        }

    } catch (err) {
        return res.status(400).json({ error: true, message: err.message })
    }
}