const joi = require("joi")

const addWorkshop = joi.object().keys({
    ownerName: joi.string().required().messages({
        "string.empty": "Owner name is required... ",
    }),
    ownerEmail: joi.string().email({ tlds: { allow: ["in", "com", "net"] }, maxDomainSegments: 2 }).required().messages({
        "*": "Please enter valid email..",
        "string.empty": "Email is required ",
    }),
    ownerPhoneNo: joi.string().min(10).max(10).required().messages({
        'string.min': 'Phone number should have at least 10 characters',
        'string.max': 'Phone number should not exceed 10 characters',
        'string.empty': 'Owner phone number is required',
    }),
    shopName: joi.string().required().messages({
        "string.empty": "Workshop name is required... ",
    }),
    shopAddress: joi.string().required().messages({
        "string.empty": "Workshop address is required... ",
    }),
    shopImg: joi.any()
}).optional()

const updateWorkshop = joi.object().keys({
    shopImgId: joi.string(),
    ownerName: joi.string(),
    ownerEmail: joi.string().email().messages({
        "*": "Please enter valid email..",
    }),
    ownerPhoneNo: joi.string().min(10).max(10).messages({
        'string.min': 'Phone number should have at least 10 characters',
        'string.max': 'Phone number should not exceed 10 characters',
    }),
    shopName: joi.string(),
    shopAddress: joi.string(),
    shopImg: joi.any()
})

const updateShopImg = joi.object().keys({
    shopImgId: joi.string().required().messages({
        "string.empty": "Owner name is required... ",
    }),
})

const getWorkshop = joi.object().keys({
    id: joi.string().required().messages({
        "string.empty": "Owner name is required... ",
    }),
})
module.exports = {
    addWorkshop,
    updateWorkshop,
    getWorkshop,
    updateShopImg
}