require("dotenv").config()
require("./config/databaseConfig")
const express = require('express')
const path = require("path")
const routes = require("./routes/index")
const validationError = require("./util/validationError")
const i18next=require("i18next")
const Backend= require("i18next-fs-backend")
const i18nextMiddleware = require("i18next-http-middleware")
const app = express()
const port = process.env.PORT || 3000
i18next.use(Backend).use(i18nextMiddleware.LanguageDetector)
.init({
    fallbackLng:"fr",
    Backend:{
        loadPath:'./locales/{{lng}}/translation.json'
    }
})
app.use(i18nextMiddleware.handle(i18next))
app.use(express.json())
app.use("/public", express.static(path.join(__dirname, "/public")))
app.use(routes)
app.use(validationError)


app.listen(port, () => {
    console.log(`Server is running on ${port}!`)
});