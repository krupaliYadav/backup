const mongoose = require("mongoose")
const { Schema } = mongoose
const shopImgSchema = new Schema({
    name: {
        type: String
    }
})


const workshopSchema = new Schema({
    ownerName: {
        type: String,
        required: [true, "Owner name is required.."]
    },
    ownerEmail: {
        type: String,
        required: [true, "Owner email is required.."]
    },
    ownerPhoneNo: {
        type: String,
        required: [true, "Owner phone number is required.."]
    },
    shopName: {
        type: String,
        required: [true, "Workshop name is required.."]
    },
    shopAddress: {
        type: String,
        required: [true, "Workshop address is required.."]
    },
    shopImg: {
        type: [shopImgSchema]
    }
}, { timestamps: true })

module.exports = mongoose.model("Workshop", workshopSchema)