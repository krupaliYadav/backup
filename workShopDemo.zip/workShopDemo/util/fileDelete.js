const fs = require("fs")
const path = require('path');

const fileDelete = (fileName) => {
    const imagePathToDelete = path.join(__dirname, ".." + `/public/${fileName}`)
    fs.unlink(`${imagePathToDelete}`, (err) => {
        if (err) {
            console.log("File delete from public folder error: ", err);
        } else {
            console.log("file deleted from public folder successfully..");
        }
    });
}
module.exports = fileDelete