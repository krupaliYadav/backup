const validationError = (err, req, res, next) => {
    if (err && err.error && err.error.isJoi) {
        return res.status(400).json({ Error: true, message: err.error.message });
    }
    return res.status(500).json({ Error: true, message: err.message });
}

module.exports = validationError