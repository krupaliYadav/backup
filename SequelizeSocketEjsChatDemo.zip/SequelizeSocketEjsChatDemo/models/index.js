const { sequelize } = require("../config/database")
const Sequelize = require("sequelize");
const User = require("./user")

const db = {};
db.Sequelize = Sequelize;
db.sequelize = sequelize;
db.sequelize.sync()
    // { alter: true }
    .then(() => console.log("Re-sync"))

module.exports = db



