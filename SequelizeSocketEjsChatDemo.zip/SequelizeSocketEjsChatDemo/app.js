require('dotenv').config()
const express = require('express')
const app = express()
const port = process.env.PORT || 3000
const cors = require("cors")
const path = require("path")
require("./models/index")

app.get('/signup', (req, res) => {
    res.sendFile(__dirname + "/views/signup.html")
})
app.use(express.json());
app.use('/script', express.static(path.join(__dirname, 'script')));
// console.log(a);
app.listen(port, () => {
    console.log(`Sever is running on ${port}!`)
})
