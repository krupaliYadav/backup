const { body, param } = require("express-validator");

const inquiryEmailValidation = [
    body("name").not().isEmpty().trim().withMessage("Name is required.."),
    body("email").not().isEmpty().trim().withMessage("Email is required."),
    body("phoneNumber").not().isEmpty().trim().withMessage("Phone Number is required."),
    body("description").not().isEmpty().trim().withMessage("Description  is required."),
];

module.exports = {
    inquiryEmailValidation
}