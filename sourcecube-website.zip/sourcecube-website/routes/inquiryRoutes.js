const router = require("express").Router();
const inquiryController = require("../controller/inquiry")
const { inquiryEmailValidation } = require("../middleware/validations")

router.post("/", inquiryEmailValidation, inquiryController.getInTouchMail)
router.post("/mail", inquiryController.inquiryMail)

module.exports = router