const express = require("express")
const inquiryRoutes = require("./inquiryRoutes")
const router = express.Router()

router.use("/inquiry", inquiryRoutes)

module.exports = router


