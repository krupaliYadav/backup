const { validationResult } = require("express-validator");
const catchAsyncError = require("../middleware/catchAsyncError");
const HttpStatus = require("../utils/HttpStatus")
const ErrorHandler = require("../utils/ErrorHandling")
const path = require("path")
const ejs = require('ejs')
const { sendEmail } = require("../utils/sendEmail")
const moment = require("moment")

const getInTouchMail = catchAsyncError(async (req, res, next) => {
    const { name, email, phoneNumber, description } = req.body
    const errors = validationResult(req);
    if (errors.errors.length !== 0) {
        throw new ErrorHandler(errors?.errors[0]?.msg, HttpStatus.BAD_REQUEST);
    };
    const date = moment().format("DD MMM YYYY")

    const templatePath = path.join(__dirname, "../public/getInTouchMail.ejs")
    const data = await ejs.renderFile(templatePath, { name, email, phoneNumber, description, date });
    await sendEmail({
        email,
        to: process.env.MAIL,
        subject: 'Get In Touch Email',
        message: data
    })
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Mail Send successfully" });
})

const inquiryMail = catchAsyncError(async (req, res, next) => {
    const { email } = req.body
    const date = moment().format("DD MMM YYYY")

    const templatePath = path.join(__dirname, "../public/inquiryMail.ejs")
    const data = await ejs.renderFile(templatePath, { email, date });
    await sendEmail({
        email,
        to: process.env.MAIL,
        subject: 'inquiry Email',
        message: data
    })
    return res.status(HttpStatus.OK).json({ status: HttpStatus.OK, success: true, message: "Mail Send successfully" });
})

module.exports = {
    getInTouchMail,
    inquiryMail
}