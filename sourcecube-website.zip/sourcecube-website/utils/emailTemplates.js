const path = require("path")
const ejs = require('ejs')
const { sendEmail } = require("./sendEmail")


const getInTouchMail = async (options) => {
    const { name, email, phoneNumber, description } = options
    const templatePath = path.join(__dirname, "../public/inquiryMail.ejs")
    const data = await ejs.renderFile(templatePath, { name, email, phoneNumber, description });
    await sendEmail({
        email,
        subject: 'Inquiry Email',
        message: data
    })
}
module.exports = {
    getInTouchMail
}