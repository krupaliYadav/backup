const nodemailer = require("nodemailer")

const sendEmail = async (options) => {
    const transporter = nodemailer.createTransport({
        host: process.env.SMTP_SERVICE,
        auth: {
            user: process.env.SMTP_MAIL,
            pass: process.env.SMTP_PASSWORD
        }
    })

    transporter.verify((error, success) => {
        if (error) {
            console.log("error", error)
            console.log('Error in mail transporter');
        } else {
            console.log('Mail Server is running');
        }
    })
    const mailOptions = {
        from: options.email,
        to: options.to,
        subject: options.subject,
        html: options.message,
    }

    await transporter.sendMail(mailOptions)
}

module.exports = {
    sendEmail
}