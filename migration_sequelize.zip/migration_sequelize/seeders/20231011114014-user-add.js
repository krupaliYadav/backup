'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    /**
     * Add seed commands here.
     *
     * Example:
     * await queryInterface.bulkInsert('People', [{
     *   name: 'John Doe',
     *   isBetaMember: false
     * }], {});
    */

    await queryInterface.bulkInsert('users', [
      {
        name: "Test user 1",
        email: "test.user1@gmail.com",
        password: "user1@123",
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        name: "Test user 2",
        email: "test.user2@gmail.com",
        password: "user2@123",
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        name: "Test user 3",
        email: "test.user3@gmail.com",
        password: "user3@123",
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ])
  },

  // async down(queryInterface, Sequelize) {
  /**
   * Add commands to revert seed here.
   *
   * Example:
   * await queryInterface.bulkDelete('People', null, {});
   */
  // }
  async down(queryInterface, Sequelize) {
    return queryInterface.bulkDelete('users', null, {});
  }
};
