require("dotenv").config()
const express = require('express')
const app = express()
const port = process.env.PORT || 3000
app.set("view engine", "ejs")

app.get('/', (req, res) => {
    var characters = [
        {
            name: 'Harry',
            designation: "Student"
        },
        {
            name: 'Dumbledore',
            designation: "Headmaster"
        },
        {
            name: 'Snape',
            designation: "Professor"
        },
        {
            name: 'Hermione',
            designation: "Student"
        }
    ];
    var subheading = "I though we should involve some magic";

    res.render("index", {
        characters: characters,
        subheading: subheading
    });
})

app.get("/magic", function (req, res) {
    res.render("magic");
});

app.listen(port, () => console.log(`Sever is running on ${port}!`))