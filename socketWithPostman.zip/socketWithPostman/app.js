require("dotenv").config()
const express = require('express')
const app = express()
const port = process.env.PORT || 3000
const http = require("http").Server(app)
const io = require("socket.io")(http)
require("./config/socket")(io)
require("./config/db")


app.get('/', (req, res) => res.send('Hello World!'))
http.listen(port, () => console.log(`Server is running on port ${port}!`))