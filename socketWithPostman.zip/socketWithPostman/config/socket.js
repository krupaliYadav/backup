const userController = require("../controller/userController")
module.exports = (io) => {
    io.on("connection", (socket) => {
        console.log("Socket connection created...", socket.id);

        socket.on("request", async (data) => {
            // console.log(data);

            switch (data.event) {
                case "login":
                    var result = await userController.addUser(data)
                    break;
                default:
                    break;
            }
            socket.emit("response", result)
        })


    })

}