const User = require("../model/userModel")

exports.addUser = async (data) => {
    const user = await User.findOne({ email: data.email })
    if (user) {
        return { error: true, message: "User is already exits.." }
    }
    let setData = {
        firstName: data.firstName,
        lastName: data.lastName,
        email: data.email
    }
    const result = await User.create(setData)
    return { error: false, message: "User added successfully", result }
}