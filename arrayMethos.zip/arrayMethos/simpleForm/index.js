document.addEventListener("DOMContentLoaded", function () {
    var form = document.getElementById('form')

    form.addEventListener('submit', function (event) {
        event.preventDefault()

        var firstName = document.getElementById('fname').value
        var LastName = document.getElementsByName("lname")[0].value;
        var email = document.getElementById("email").value
        var DOB = document.getElementById("dob").value
        var gender = document.querySelector('input[name=gender]:checked').value
        var selectElement = document.getElementById('country').value

        // document.write("FORM INFORMATION<br>")
        // document.write("<br>First Name: " + firstName)
        // document.write("<br>Last name: " + LastName)
        // document.write("<br>Email: " + email)
        // document.write("<br>DOB: " + DOB)
        // document.write("<br>Gender: " + gender)
        // document.write("<br>Country: " + selectElement)

        document.write("FORM INFORMATION<br>")
        document.write("<First Name: " + firstName)
        document.write("<br>Last name: " + LastName)
        document.write("<br>Email: " + email)
        document.write("<br>DOB: " + DOB)
        document.write("<br>Gender: " + gender)
        document.write("<br>Country: " + selectElement)



    })
})

