const str = "hello"
const str2 = 'World xcf df';
// chartAt=> it retune chart at given index
let result = str.charAt(3)

// concat=> concat two string
result = str.concat(' ', str2)

// indexOf => index of word
result = str2.indexOf('xcf')

// tolowercase
result = str.toLocaleLowerCase()

// touppercase
result = str.toUpperCase()

// first letter capital
result = str.charAt(0).toUpperCase() + str.slice(1)

// trim
const string = "     hello"
result = string.trim()
console.log(result);
