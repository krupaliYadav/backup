const data = [
    {
        "UserName": "krupali",
        "email": "krupali.yadav@yopmail.com",
        "phoneNumber": 9913657943,
        "country": "India",
        "role": "user"
    },
    {
        "UserName": "ankit",
        "email": "ankit.dabhekar@yopmail.com",
        "phoneNumber": 9913657944,
        "country": "India",
        "role": "user"
    },
    {
        "UserName": "anvi",
        "email": "anvi.yadav@yopmail.com",
        "phoneNumber": 9913657945,
        "country": "USA",
        "role": "admin"
    },
    {
        "UserName": "anjali",
        "email": "anjali.patel@yopmail.com",
        "phoneNumber": 991365943,
        "country": "USA",
        "role": "user"
    },
    {
        "UserName": "ganesh",
        "email": "ganesh.yadav@yopmail.com",
        "phoneNumber": 991365943,
        "country": "India",
        "role": "admin"
    },
    {
        "UserName": "manisha",
        "email": "manish.yadav@yopmail.com",
        "phoneNumber": 9813657943,
        "country": "Canada",
        "role": "manager"
    },
    {
        "UserName": "aarti",
        "email": "arti.kadu@yopmail.com",
        "phoneNumber": 9313657943,
        "country": "Canada",
        "role": "manager"
    },
    {
        "UserName": "sujal",
        "email": "sujal.kadu@yopmail.com",
        "phoneNumber": 9313657643,
        "country": "India",
        "role": "user"
    },
    {
        "UserName": "chetan",
        "email": "chetan.more@yopmail.com",
        "phoneNumber": 9323657943,
        "country": "USA",
        "role": "manager"
    },
    {
        "UserName": "vibha",
        "email": "vibha.patel@yopmail.com",
        "phoneNumber": 9313657243,
        "country": "India",
        "role": "admin"
    }
]

// let usaUsers = []
// let indiaUsers = []
// let canadaUsers = []
// let admin = []
// let users = []
// let manager = []

// data.map(user => {
//     if (user.country === "India") {
//         indiaUsers.push(user)
//     }
//     if (user.country === 'Canada') {
//         canadaUsers.push(user)
//     }
//     if (user.country === 'USA') {
//         usaUsers.push(user)
//     }
//     if (user.role === 'user') {
//         users.push(user)
//     }
//     if (user.role === 'admin') {
//         admin.push(user)
//     }
//     if (user.role === "manager") {
//         manager.push(user)
//     }
// })

// const country = {
//     indiaUsers: indiaUsers,
//     usaUsers: usaUsers,
//     canadaUsers: canadaUsers
// }

// const role = {
//     admin: admin,
//     users: users,
//     manager: manager
// }

function countryFilter(country) {
    return data.filter(user => user.country === country)
}
function roleFilter(role) {
    return data.filter(user => user.role === role)
}
// let canadaUsers = countryFilter("Canada")
// let indiaUsers = countryFilter("India")
// let usaUsers = countryFilter("USA")
// let admin = roleFilter("admin")
// let user = roleFilter("user")
// let manager = roleFilter("manager")

// const country = {
//     India: indiaUsers,
//     USA: usaUsers,
//     Canada: canadaUsers
// }
// const role = {
//     Admin: admin,
//     User: user,
//     Manager: manager
// }
// console.log(country, role);

let canadaUser = data.filter(user => user.country === "Canada")
let indiaUser = data.filter(user => user.country === "India")
let usaUser = data.filter(user => user.country === "USA")
const country = {
    India: indiaUser,
    USA: usaUser,
    Canada: canadaUser
}
console.log(country);