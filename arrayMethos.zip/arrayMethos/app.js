const array = [1, 2, 3, 4, 5, 6, 3]
const array1 = ["a", "b", "c"]
// at =>it return element of index of at()
let result = array.at(2)

// concat => it use for concat two array
result = array.concat(array1)

// filter => it goes for each element of array
let words = ['spray', 'limit', 'elite', 'exuberant', 'destruction', 'present'];
result = words.filter(word => word.length > 6);

// find => PThe find() method is used to retrieve the first element in an array that satisfies a given condition.
result = words.find(word => word.length > 6);

// findIndex=>this method retrieve index of first element in an array that satisfies a given condition.
result = words.findIndex(word => word === "limit");

// flat array
const arr1 = [0, 1, 2, [3, 4]];
result = arr1.flat()
// if we are use Infinity it remove all array and return single array[[]]
const arr2 = [0, 1, 2, [[[3, 4]]]];
result = arr2.flat(Infinity)

//forEach=>for each use for loop through array .it not crete new array
words.forEach((word) => {
    // console.log(word);
})

// include=> it return true or false if it include 
result = words.includes("limitt")

// join=>The join() method creates and returns a new string by concatenating all of the elements in an array 
const array2 = ['k', 'r', 'u', 'p', 'a']
result = array2.join('')

// map=>The map() method creates a new array populated with the results of calling a provided function on every element in the calling array.
result = array.map(num => {
    return num * 2
})

//pop=> remove last element of array
result = array.pop()

// push => add new element in the last of array
result = array.push(12)

//shift=> remove first element in the  array
result = array.shift()

// unshift => add new element in the start of array
result = array.unshift(12)

// slice=> it return selected element 
result = array.slice(2, 5)
console.log(result);






